﻿using FTC.SMSProvider.Entity;
using FTCApi.Dtos;
using FTCApi.Dtos.Notification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.SMSProvider
{
    public interface ISmsGatewayProvider
    {
        Task<string> SendMessage(SMSGateway smsGateway, SMSGatewayParam gatewayParam,int id);

        string GetRequestString(SMSGateway smsGateway, SMSGatewayParam gatewayParam,int id);
    }
}
