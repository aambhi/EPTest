﻿using FTC.SMSProvider.Entity;
using FTC.SMSProvider.Helper;
using FTCApi.Dtos;
using FTCApi.Dtos.Notification;
using System;
using System.Threading.Tasks;

namespace FTC.SMSProvider.Host
{
    public class PhononSMSProvider:ISmsGatewayProvider
    {

        #region Public Methods

        /// <summary>
        /// This method is use to send message using phonon sms gateway
        /// </summary>
        /// <param name="smsGateway"></param>
        /// <param name="gatewayParam"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<string> SendMessage(SMSGateway smsGateway, SMSGatewayParam gatewayParam, int id)
        {
            // build request object
            var messageObject = BuildObject(smsGateway, gatewayParam, id);

            //make post request
            var result = HttpClientHelper.PostXMLAsync(smsGateway, messageObject);

            //result
            return await Task.Run(() => result);
        }

        /// <summary>
        /// This method is use to get request object
        /// </summary>
        /// <param name="smsGateway"></param>
        /// <param name="gatewayParam"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public string GetRequestString(SMSGateway smsGateway, SMSGatewayParam gatewayParam, int id)
        {
            var requestObject = BuildObject(smsGateway, gatewayParam, id);
            requestObject.User = null;
            var serRoot = new SerializeDeserialize<Root>();

            // serailize object in string data
            var xmlInString = serRoot.SerializeData(requestObject);
            return xmlInString;

        }

        #endregion

        #region Private Methods

        /// <summary>
        /// This method is use to build request object
        /// </summary>
        /// <param name="smsGateway"></param>
        /// <param name="gatewayParam"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        private Root BuildObject(SMSGateway smsGateway, SMSGatewayParam gatewayParam, int id)
        {
            var root = new Root
            {
                Job = new Job
                {
                    JDF1 = "JobDefination" + id,
                    NDNCScrub = "N",
                    Message = gatewayParam.Message,
                    SMS = new JobSMS
                    {
                        PhoneNo = Convert.ToInt64(gatewayParam.MobileNumber),
                        UDF1 = "UserDefined" + id,
                    },

                },
                User = new User
                {
                    password = smsGateway.Password,
                    UserID = smsGateway.UserName,
                }
            };

            return root;

        } 

        #endregion
    }
}
