﻿using FTC.SMSProvider.Helper;
using FTCApi.Dtos;
using FTCApi.Dtos.Notification;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace FTC.SMSProvider.Host
{
    public class TwilioSMSProvider : ISmsGatewayProvider
    {
        #region Public Methods

        /// <summary>
        /// This method is us to send message using twillo sms gateway
        /// </summary>
        /// <param name="smsGateway"></param>
        /// <param name="gatewayParam"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<string> SendMessage(SMSGateway smsGateway, SMSGatewayParam gatewayParam, int id)
        {

            var messageObject = BuildObject(gatewayParam);
            var result = HttpClientHelper.PostAsync(smsGateway, messageObject);

            return await Task.Run(() => result);

        }

        /// <summary>
        /// This methos is use to get request string
        /// </summary>
        /// <param name="smsGateway"></param>
        /// <param name="gatewayParam"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public string GetRequestString(SMSGateway smsGateway, SMSGatewayParam gatewayParam, int id)
        {
            return JsonConvert.SerializeObject(gatewayParam);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// This method is use to build request object
        /// </summary>
        /// <param name="gatewayParam"></param>
        /// <returns></returns>
        private static FormUrlEncodedContent BuildObject(SMSGatewayParam gatewayParam)
        {

            return new FormUrlEncodedContent(new[]
                 {
                            new KeyValuePair<string, string>("To",$"+{gatewayParam.MobileNumber}"),
                            new KeyValuePair<string, string>("From", gatewayParam.FromEmail),
                            new KeyValuePair<string, string>("Body", gatewayParam.Message)
                        });

        } 

        #endregion
    }
}
