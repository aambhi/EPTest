﻿using FTC.SMSProvider.Entity;
using FTCApi.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FTC.SMSProvider.Helper
{
    public class HttpClientHelper
    {

        /// <summary>
        /// This method is use to post data 
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="root">todo: describe root parameter on PostXMLAsync</param>
        /// <returns>returns response string</returns>
        public async static Task<string> PostXMLAsync(SMSGateway smsGateway, Root root)
        {
            var responseString = string.Empty;
            using (var client = new HttpClient { BaseAddress = new Uri(smsGateway.BaseUrl) })
            {

                var serRoot = new SerializeDeserialize<Root>();

                var xmlInString = serRoot.SerializeData(root);
                using (var stringContent = new StringContent(xmlInString, Encoding.UTF8, "application/xml"))
                {
                    var response = await client.PostAsync(smsGateway.RequestUrl, stringContent);
                    response.EnsureSuccessStatusCode();
                    
                    responseString = await response.Content.ReadAsStringAsync();
                }
            }
            return responseString;
        }


        public async static Task<string> PostAsync(SMSGateway smsGateway, FormUrlEncodedContent content)
        {
            var responseString = string.Empty;
            using (var client = new HttpClient { BaseAddress = new Uri(smsGateway.BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                    Convert.ToBase64String(Encoding.ASCII.GetBytes($"{smsGateway.UserName}:{smsGateway.Password}")));

                var smsResponse = await client.PostAsync(smsGateway.RequestUrl, content);
                smsResponse.EnsureSuccessStatusCode();
                responseString = await smsResponse.Content.ReadAsStringAsync();
            }
            return responseString;

        }
    }
}
