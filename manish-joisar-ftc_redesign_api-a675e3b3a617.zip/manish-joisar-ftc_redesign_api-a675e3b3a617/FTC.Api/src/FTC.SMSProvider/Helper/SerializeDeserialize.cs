﻿using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace FTC.SMSProvider.Helper
{
    public class SerializeDeserialize<T>

    {
        StringBuilder sbData;

        StringWriter swWriter;

        XDocument xDoc;

        XmlSerializer xmlSerializer;

        public SerializeDeserialize()
        {

            sbData = new StringBuilder();

        }

        public string SerializeData(T data)
        {

            return SerializeToString(data);
        }

        public static string SerializeToString(T value)
        {
            var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
            var serializer = new XmlSerializer(value.GetType());
            var settings = new XmlWriterSettings
            {
                Indent = true,
                OmitXmlDeclaration = true
            };

            using (var stream = new StringWriter())
            using (var writer = XmlWriter.Create(stream, settings))
            {
                serializer.Serialize(writer, value, emptyNamepsaces);
                return stream.ToString();
            }
        }

    }
}
