﻿
using System.Xml.Serialization;

namespace FTC.SMSProvider.Entity
{

    public class Root
    {
        public Root()
        {

        }

        private User userField;
        private Job jobField;

        [XmlElement]
        public User User
        {
            get
            {
                return this.userField;
            }
            set
            {
                this.userField = value;
            }
        }

        [XmlElement]
        public Job Job
        {
            get
            {
                return this.jobField;
            }
            set
            {
                this.jobField = value;
            }
        }
    }


    public class User
    {
        public User()
        {

        }

        private string userIDField;

        private string passwordField;

        [XmlElement]
        public string UserID
        {
            get
            {
                return this.userIDField;
            }
            set
            {
                this.userIDField = value;
            }
        }

        [XmlElement]
        public string password
        {
            get
            {
                return this.passwordField;
            }
            set
            {
                this.passwordField = value;
            }
        }
    }


    public class Job
    {
        public Job()
        {
        }

        private string jDF1Field;

        private object jDF2Field;

        private string nDNCScrubField;

        private object ignoreDuplicatesField;

        private string messageField;

        private JobSMS sMSField;

        [XmlElement]
        public string JDF1
        {
            get
            {
                return this.jDF1Field;
            }
            set
            {
                this.jDF1Field = value;
            }
        }

        [XmlElement]
        public object JDF2
        {
            get
            {
                return this.jDF2Field;
            }
            set
            {
                this.jDF2Field = value;
            }
        }

        [XmlElement]
        public string NDNCScrub
        {
            get
            {
                return this.nDNCScrubField;
            }
            set
            {
                this.nDNCScrubField = value;
            }
        }

        [XmlElement]
        public object IgnoreDuplicates
        {
            get
            {
                return this.ignoreDuplicatesField;
            }
            set
            {
                this.ignoreDuplicatesField = value;
            }
        }

        [XmlElement]
        public string Message
        {
            get
            {
                return this.messageField;
            }
            set
            {
                this.messageField = value;
            }
        }

        [XmlElement]
        public JobSMS SMS
        {
            get
            {
                return this.sMSField;
            }
            set
            {
                this.sMSField = value;
            }
        }
    }


    public class JobSMS
    {

        private long phoneNoField;

        private string uDF1Field;

        private object uDF2Field;

        [XmlElement]
        public long PhoneNo
        {
            get
            {
                return this.phoneNoField;
            }
            set
            {
                this.phoneNoField = value;
            }
        }

        [XmlElement]
        public string UDF1
        {
            get
            {
                return this.uDF1Field;
            }
            set
            {
                this.uDF1Field = value;
            }
        }

        [XmlElement]
        public object UDF2
        {
            get
            {
                return this.uDF2Field;
            }
            set
            {
                this.uDF2Field = value;
            }
        }
    }
}