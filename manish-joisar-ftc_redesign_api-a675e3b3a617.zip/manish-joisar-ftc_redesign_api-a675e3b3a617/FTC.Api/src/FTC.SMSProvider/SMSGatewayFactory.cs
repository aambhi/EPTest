﻿using FTC.SMSProvider.Host;
using FTCApi.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.SMSProvider
{
    public class SMSGatewayFactory
    {

        /// <summary>
        /// 
        /// </summary>
        public abstract class ProviderContainer
        {
            public abstract ISmsGatewayProvider GetProvider(SMSGatways provider);
        }

        /// <summary>
        /// This method returns provider concreate object
        /// </summary>
        public class SMSProviderFactory : ProviderContainer
        {
            public override ISmsGatewayProvider GetProvider(SMSGatways provider)
            {
                switch (provider)
                {
                    case SMSGatways.PHONON:
                        return new PhononSMSProvider();
                    case SMSGatways.TWILIO:
                        return new TwilioSMSProvider();
                    default:
                        return new TwilioSMSProvider();
                }
            }
        }

    }
}
