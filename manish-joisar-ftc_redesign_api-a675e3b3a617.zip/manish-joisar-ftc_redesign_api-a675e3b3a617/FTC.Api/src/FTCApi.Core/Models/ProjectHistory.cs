﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class ProjectHistory
    {
        public int Id { get; set; }
        public int? ProjectId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public int? PlanId { get; set; }

        public virtual Project Project { get; set; }
        public virtual AuxiliaryUser UpdatedByNavigation { get; set; }
        public virtual RecruiterPlan Plan { get; set; }
    }
}
