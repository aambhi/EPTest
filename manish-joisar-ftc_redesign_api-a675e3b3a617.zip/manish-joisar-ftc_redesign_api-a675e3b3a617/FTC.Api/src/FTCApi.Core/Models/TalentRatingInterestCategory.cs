﻿namespace FTCApi.Core.Models
{
    public class TalentRatingInterestCategory
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? InterestCategoryId { get; set; }
        public float? Rating { get; set; }

        public virtual InterestCategory InterestCategory { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
