﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class FeaturePermission
    {
        public FeaturePermission()
        {
            FeatureRolePermission = new HashSet<FeatureRolePermission>();
        }

        public int Id { get; set; }
        public int? FeatureId { get; set; }
        public int? FeatureOperationId { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual ICollection<FeatureRolePermission> FeatureRolePermission { get; set; }
        public virtual Feature Feature { get; set; }
        public virtual FeatureOperation FeatureOperation { get; set; }
    }
}
