﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class ProjectJobStatus
    {

        public ProjectJobStatus()
        {
            TalentJobHistory = new HashSet<TalentJobHistory>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string RGB { get; set; }

        public virtual ICollection<TalentJobHistory> TalentJobHistory { get; set; }
    }
}
