﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class TalentSpecialHost
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public short? SpecialHostId { get; set; }
        public string Value1 { get; set; }
        public string Value2 { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? StatusId { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }


        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual ContestSpecialHost SpecialHost { get; set; }
        public virtual Status Status { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
