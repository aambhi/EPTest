﻿namespace FTCApi.Core.Models
{
    public class TalentInterestCategory
    {
        public int Id { get; set; }
        public int TalentId { get; set; }
        public int InterestCategoryId { get; set; }

        public InterestCategory InterestCategory { get; set; }
        public Talent Talent { get; set; }
    }
}
