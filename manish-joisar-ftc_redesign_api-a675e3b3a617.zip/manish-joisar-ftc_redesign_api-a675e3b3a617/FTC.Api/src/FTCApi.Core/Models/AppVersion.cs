﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class AppVersion
    {
        public int Id { get; set; }
        public short DeviceOsId { get; set; }
        public string Version { get; set; }
        public bool Permissible { get; set; }
        public DateTime? Date { get; set; }
        public string Feature { get; set; }

        public virtual MstDeviceOs DeviceOs { get; set; }
    }
}
