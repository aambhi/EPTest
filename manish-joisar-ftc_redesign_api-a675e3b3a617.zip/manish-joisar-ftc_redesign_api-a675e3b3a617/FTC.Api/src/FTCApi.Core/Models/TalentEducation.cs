﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentEducation
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public string School { get; set; }
        public string Course { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Year { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? SchoolId { get; set; }

        public virtual Talent Talent { get; set; }
        public virtual School SchoolNavigation { get; set; }
    }
}
