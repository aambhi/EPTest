﻿namespace FTCApi.Core.Models
{
    public class ContestSubmissionMedia
    {
        public int Id { get; set; }
        public int? ContestSubmissionId { get; set; }
        public int? MediaFileId { get; set; }

        public virtual ContestSubmission ContestSubmission { get; set; }
        public virtual MediaFile MediaFile { get; set; }
    }
}
