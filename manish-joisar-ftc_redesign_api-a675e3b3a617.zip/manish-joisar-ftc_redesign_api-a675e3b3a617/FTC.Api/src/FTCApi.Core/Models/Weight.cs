﻿namespace FTCApi.Core.Models
{
    public class Weight
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string ShortDescription { get; set; }
        public int? Kgs { get; set; }
        public int? Lbs { get; set; }
    }
}
