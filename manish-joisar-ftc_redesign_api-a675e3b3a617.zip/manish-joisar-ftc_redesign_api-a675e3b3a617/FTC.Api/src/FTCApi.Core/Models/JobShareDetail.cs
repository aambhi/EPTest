﻿using System;

namespace FTCApi.Core.Models
{
    public class JobShareDetail
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public string EmailIds { get; set; }
        public string Notes { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual ProjectJob Job { get; set; }
    }
}
