﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentPhysicalAttribute
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }        
        public int? HairColorId { get; set; }
        public int? HairTypeId { get; set; }
        public int? HairLengthId { get; set; }
        public int? SkinColorId { get; set; }
        public int? EyeColorId { get; set; }
        public int? HeightId { get; set; }
        public int? WeightSizeId { get; set; }
        public int? ChestSizeId { get; set; }
        public int? WaistId { get; set; }
        public int? BodyTypeId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public int? VerifiedBy { get; set; }
        public bool? Verified { get; set; }
        public DateTime? VerifiedOn { get; set; }
    }
}
