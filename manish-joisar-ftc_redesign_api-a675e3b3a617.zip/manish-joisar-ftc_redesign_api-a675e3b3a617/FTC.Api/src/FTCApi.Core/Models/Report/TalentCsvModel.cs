﻿using System.ComponentModel.DataAnnotations;

namespace FTCApi.Core.Models.Report
{
    public class TalentCsvModel
    {
        [Display(Name = "Talent Id")]
        public int id { get; set; }

        [Display(Name = "Talent UID")]
        public int? uid { get; set; }

        [Display(Name = "Full Name")]
        public string fullName { get; set; }

        [Display(Name = "Email")]
        public string email { get; set; }

        [Display(Name = "Gender")]
        public string gender { get; set; }

        [Display(Name = "DOB")]
        public string dob { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobile { get; set; }

        [Display(Name = "Whatsup Mobile No.")]
        public string whatsupMobile { get; set; }

        [Display(Name = "Talent Profile URL")]
        public string talentProfileURL { get; set; }

        [Display(Name = "Onboarded")]
        public string onboarded { get; set; }

        [Display(Name = "Profile Completion %")]
        public int? profileCompletionPercentage { get; set; }

        [Display(Name = "Terms & Condition Accepted")]
        public string termsConditionAccepted { get; set; }

        [Display(Name = "City")]
        public string city { get; set; }

        [Display(Name = "Status")]
        public string status { get; set; }

        [Display(Name = "Passport Country")]
        public string passportCountry { get; set; }

        [Display(Name = "Expiry Passport Date")]
        public string passportExpirationDate { get; set; }

        [Display(Name = "Visa Year")]
        public string VisaYear { get; set; }

        [Display(Name = "Visa Type")]
        public string VisaType { get; set; }

        [Display(Name = "About Me")]
        public string aboutMe { get; set; }

        [Display(Name = "Guardian Name")]
        public string guardianName { get; set; }

        [Display(Name = "Guardian Relation")]
        public string guardianRelation { get; set; }

        [Display(Name = "Guardian Mobile No.")]
        public string guardianMobile { get; set; }

        [Display(Name = "Guardian Email")]
        public string guardianEmailId { get; set; }

        [Display(Name = "Shared Profile Name")]
        public string sharedProfileName { get; set; }

        [Display(Name = "Ftc Rating")]
        public float? ftcRating { get; set; }

        [Display(Name = "Overall Rating")]
        public float? overallRating { get; set; }

        [Display(Name = "Recruiter Rating")]
        public float? recruiterRating { get; set; }

        [Display(Name = "Interest Rating")]
        public float? interestRating { get; set; }

        [Display(Name = "Rating Notes")]
        public string ratingNotes { get; set; }

        [Display(Name = "Talent Rating Rmark")]
        public string talentRatingRmark { get; set; }

        [Display(Name = "IsProfilePrivate")]
        public string isProfilePrivate { get; set; }

        [Display(Name = "Tier")]
        public string tier { get; set; }

        [Display(Name = "Height In Inches")]
        public string heightInInches { get; set; }

        [Display(Name = "Weight In Kgs")]
        public int? weightInKgs { get; set; }

        [Display(Name = "ChestSize In Inches")]
        public string chestSizeInInches { get; set; }

        [Display(Name = "WaistSize In Inches")]
        public string waistSizeInInches { get; set; }

        [Display(Name = "Body Type")]
        public string bodyType { get; set; }

        [Display(Name = "Skin Color")]
        public string skinColor { get; set; }

        [Display(Name = "Eye Color")]
        public string eyeColor { get; set; }

        [Display(Name = "Hair Color")]
        public string hairColor { get; set; }

        [Display(Name = "Hair Length")]
        public string hairLength { get; set; }

        [Display(Name = "Hair Type")]
        public string hairType { get; set; }

        [Display(Name = "isVerified")]
        public string isVerified { get; set; }

        [Display(Name = "Agency Agent Name")]
        public string agencyAgentName { get; set; }

        [Display(Name = "Agency Agent Email")]
        public string agencyAgentEmail { get; set; }

        [Display(Name = "Agency Agent Mobile No.")]
        public string agencyAgentMobileNo { get; set; }

        [Display(Name = "Budget")]
        public string budget { get; set; }

        [Display(Name = "View Count")]
        public string viewCount { get; set; }

        [Display(Name = "Address")]
        public string address { get; set; }

        [Display(Name = "Ethnicity")]
        public string ethnicity { get; set; }

        [Display(Name = "Language")]
        public string language { get; set; }

        [Display(Name = "Tag")]
        public string tag { get; set; }

        [Display(Name = "Interest Category")]
        public string interestcategory { get; set; }

        [Display(Name = "Talent Category")]
        public string talentcategory { get; set; }

        [Display(Name = "Association")]
        public string talentAssociation { get; set; }

        [Display(Name = "Education")]
        public string talentEducation { get; set; }

        [Display(Name = "Experience")]
        public string talentExperience { get; set; }
    }
}
