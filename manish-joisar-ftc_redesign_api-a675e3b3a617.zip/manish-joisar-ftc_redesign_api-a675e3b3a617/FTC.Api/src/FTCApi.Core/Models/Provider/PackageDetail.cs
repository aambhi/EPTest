﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FTCApi.Core.Models.Provider;
using System.Runtime.Serialization;

namespace FTCApi.Core.Models.Provider
{

    public class PackageDetail
    {

        public string accountStatus { get; set; }

        public string rmn { get; set; }

        public List<SubscriptionDetail> subscriptionDetails { get; set; }
        public string transMessage { get; set; }

        public string hasPVR { get; set; }

        public string subscriberName { get; set; }

        public string subscriberId { get; set; }

        public string source { get; set; }

        public string isPremiumUser { get; set; }

        public string transStatus { get; set; }
    }
}
