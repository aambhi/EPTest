﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models.Provider
{
    public class KeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
