﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models.Provider
{
    public class RootObject
    {
        public AccountDetails accountDetails { get; set; }
    }
}
