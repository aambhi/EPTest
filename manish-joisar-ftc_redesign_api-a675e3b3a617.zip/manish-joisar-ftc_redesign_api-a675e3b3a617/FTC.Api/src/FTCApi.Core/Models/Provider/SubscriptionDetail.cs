﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace FTCApi.Core.Models.Provider
{

    public class SubscriptionDetail
    {

        public string packageCategory { get; set; }
        
        public string packageId { get; set; }
  
        public string packageName { get; set; }

        public string packageType { get; set; }
    }
}
