﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models.Provider
{
    public class Endpoints
    {
        public string RMN { get; set; }
        public string SUBSCRIPTION { get; set; }
        public string ENDPOINT { get; set; }
    }
}
