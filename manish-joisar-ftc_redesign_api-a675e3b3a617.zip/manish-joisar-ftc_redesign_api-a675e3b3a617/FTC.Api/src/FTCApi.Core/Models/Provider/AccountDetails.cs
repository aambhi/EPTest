﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using FTCApi.Core.Models.Provider;

namespace FTCApi.Core.Models.Provider
{

    public class AccountDetails
    {
        
        public string subscriberId { get; set; }
       
        public object rmn { get; set; }
       
        public string source { get; set; }
       
        public string transStatus { get; set; }

       
        public string transMessage { get; set; }
       
        public List<AccountDetail> accountDetails { get; set; }
    }
}
