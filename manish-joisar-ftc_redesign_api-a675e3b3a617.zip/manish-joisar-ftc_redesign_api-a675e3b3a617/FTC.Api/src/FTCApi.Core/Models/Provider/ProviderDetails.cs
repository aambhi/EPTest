﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FTCApi.Core.Models.Provider
{
    
    public class ProviderDetails
    {
        public string SubscriberId { get; set; }

        public int TalentId { get; set; }

        public int ContestId { get; set; }

        public int ProviderId { get; set; }
 
        public string rmn { get; set; }

        [JsonIgnore]
        public ContestProvider ContestProvider { get; set; }

    }
}
