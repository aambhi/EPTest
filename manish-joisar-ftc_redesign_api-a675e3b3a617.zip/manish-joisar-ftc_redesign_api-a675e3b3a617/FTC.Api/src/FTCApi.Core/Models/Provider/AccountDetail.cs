﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace FTCApi.Core.Models.Provider
{

    
    public class AccountDetail
    {
        
        public string subscriberId { get; set; }
       
        public string rmn { get; set; }
      
        public string customerName { get; set; }
       
        public string accountStatus { get; set; }
       
        public string accountType { get; set; }
      
        public string accountSubType { get; set; }
      
        public string accountCategory { get; set; }
      
        public string email { get; set; }
    }
}
