﻿namespace FTCApi.Core.Models
{
    public class ProjectJobHairColor
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? HaircolorId { get; set; }

        public virtual HairColor HairColor { get; set; }
        public virtual ProjectJob ProjectJob { get; set; }
    }
}
