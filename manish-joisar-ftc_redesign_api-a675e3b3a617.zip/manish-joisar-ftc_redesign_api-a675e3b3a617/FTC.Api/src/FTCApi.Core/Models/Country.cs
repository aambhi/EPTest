﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Country
    {
        public Country()
        {
            AuxiliaryUser = new HashSet<AuxiliaryUser>();
            Address = new HashSet<Address>();
            City = new HashSet<City>();
            ProjectJob = new HashSet<ProjectJob>();
            TalentMobileCountry = new HashSet<Talent>();
            TalentWhatsupCountry = new HashSet<Talent>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string MobileCode { get; set; }
        public string Nationality { get; set; }

        public virtual ICollection<Address> Address { get; set; }
        public virtual ICollection<City> City { get; set; }
        public virtual ICollection<ProjectJob> ProjectJob { get; set; }
        public virtual ICollection<AuxiliaryUser> AuxiliaryUser { get; set; }
        public virtual ICollection<Talent> TalentMobileCountry { get; set; }
        public virtual ICollection<Talent> TalentWhatsupCountry { get; set; }
    }
}
