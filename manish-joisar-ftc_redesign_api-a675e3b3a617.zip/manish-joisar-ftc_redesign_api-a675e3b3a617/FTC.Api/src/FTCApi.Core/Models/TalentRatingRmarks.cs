﻿using FTCApi.Dtos;
using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentRatingRmarks
    {


        public bool? Verified { get; set; }

        public DateTime? VerifiedOn { get; set; }

        public int? VerifiedBy { get; set; }

        public string VerifiedByName { get; set; }

        public List<TalentTalentCategoryType> TalentTalentCategory { get; set; }

        public List<TalentInterestCategoryType> TalentInterestCategory { get; set; }

        public int TalentId { get; set; }

        public string TalentProfileURL { get; set; }

        public List<TalentRatingRmarkDto> TalentRatingRMarks { get; set; }
    }
}
