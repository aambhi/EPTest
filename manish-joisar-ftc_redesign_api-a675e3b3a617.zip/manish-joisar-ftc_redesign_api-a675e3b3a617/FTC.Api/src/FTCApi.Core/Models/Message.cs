﻿using System;

namespace FTCApi.Core.Models
{
    public class Message
    {
        public int Id { get; set; }
        public int? FromTalentId { get; set; }
        public int? ToTalentId { get; set; }
        public int? FromAuxiliaryId { get; set; }
        public int? ToAuxiliaryId { get; set; }
        public string MessageText { get; set; }
        public int? JobId { get; set; }
        public bool? Read { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual AuxiliaryUser FromAuxiliary { get; set; }
        public virtual Talent FromTalent { get; set; }
        public virtual ProjectJob Job { get; set; }
        public virtual AuxiliaryUser ToAuxiliary { get; set; }
        public virtual Talent ToTalent { get; set; }
    }
}
