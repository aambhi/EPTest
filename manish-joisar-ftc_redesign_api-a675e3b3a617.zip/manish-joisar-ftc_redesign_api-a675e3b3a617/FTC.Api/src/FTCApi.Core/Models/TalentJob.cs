﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentJob
    {
        public TalentJob()
        {
            TalentJobSpecialHost = new HashSet<TalentJobSpecialHost>();
        }

        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? JobId { get; set; }

        public float? Rating { get; set; }
        public short? CollaboratorFeedback { get; set; }
        public bool? EmailSent { get; set; }


        public bool? NotSelected { get; set; }
        public bool? SelectedForAudition { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int StatusId { get; set; }
       
        public ProjectJobStatus Status { get; set; }
        public virtual ProjectJob Job { get; set; }
        public virtual Talent Talent { get; set; }

        public virtual ICollection<TalentJobSpecialHost> TalentJobSpecialHost { get; set; }
    }
}
