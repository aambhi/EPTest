﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class MstSortOrderType
    {
        public MstSortOrderType()
        {
            JobTalentRecommended = new HashSet<JobTalentRecommended>();
        }

        public short SotId { get; set; }
        public string SotDesc { get; set; }
        public short? SotOrder { get; set; }

        public virtual ICollection<JobTalentRecommended> JobTalentRecommended { get; set; }
    }
}
