﻿namespace FTCApi.Core.Models
{
    public class NotificationDetail
    {
        public int Id { get; set; }
        public short? NotificationHeaderId { get; set; }
        public string Type { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public bool Send { get; set; }
        public bool SendToAllRole { get; set; }        
        public virtual NotificationHeader NotificationHeader { get; set; }
    }
}
