﻿namespace FTCApi.Core.Models
{
    public class TalentShareDetail
    {
        public int Id { get; set; }
        public string EmailIds { get; set; }
        public string Notes { get; set; }
        public int? TalentId { get; set; }

        public virtual Talent Talent { get; set; }
    }
}
