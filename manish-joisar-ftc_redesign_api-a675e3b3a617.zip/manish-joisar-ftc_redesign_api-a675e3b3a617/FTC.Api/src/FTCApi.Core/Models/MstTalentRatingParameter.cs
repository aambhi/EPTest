﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class MstTalentRatingParameter
    {
        public MstTalentRatingParameter()
        {
            TalentRatingParameter = new HashSet<TalentRatingParameter>();
        }

        public short Id { get; set; }
        public string Description { get; set; }

        public virtual ICollection<TalentRatingParameter> TalentRatingParameter { get; set; }
    }
}
