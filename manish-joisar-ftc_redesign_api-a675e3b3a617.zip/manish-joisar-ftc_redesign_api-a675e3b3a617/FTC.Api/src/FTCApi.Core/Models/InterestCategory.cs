﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class InterestCategory
    {
        public InterestCategory()
        {
            ProjectJob = new HashSet<ProjectJob>();
            TalentInterestCategory = new HashSet<TalentInterestCategory>();
            AuxiliaryUserExperience = new HashSet<AuxiliaryUserExperience>();
            TalentRatingInterestCategory = new HashSet<TalentRatingInterestCategory>();
            TalentRatingRmark = new HashSet<TalentRatingRmark>();
            Project = new HashSet<Project>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string SelectedIcon { get; set; }
        public string NotselectedIcon { get; set; }
        public int? StatusId { get; set; }

        public ICollection<ProjectJob> ProjectJob { get; set; }
        public ICollection<TalentInterestCategory> TalentInterestCategory { get; set; }
        public virtual ICollection<AuxiliaryUserExperience> AuxiliaryUserExperience { get; set; }
        public ICollection<TalentExperience> TalentExperience { get; set; }
        public virtual ICollection<TalentRatingInterestCategory> TalentRatingInterestCategory { get; set; }
        public virtual ICollection<TalentRatingRmark> TalentRatingRmark { get; set; }
        public virtual ICollection<Project> Project { get; set; }
    }
}
