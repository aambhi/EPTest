﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class TraceSmsGateway
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? TalentId { get; set; }
        public string CountryCode { get; set; }
        public string Mobile { get; set; }
        public string Message { get; set; }
        public DateTime? CreatedOn { get; set; }
        public short? SmsGatewayId { get; set; }
        public string SmsRequest { get; set; }
        public string SmsResponse { get; set; }
        public bool? Sent { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual MstSmsGateway SmsGateway { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
