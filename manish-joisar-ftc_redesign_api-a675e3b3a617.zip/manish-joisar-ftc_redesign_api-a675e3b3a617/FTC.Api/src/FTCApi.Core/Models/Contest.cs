﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Contest
    {
        public Contest()
        {
            Submission = new HashSet<ContestSubmission>();
            ContestProvider = new HashSet<ContestProvider>();
            UserNotification = new HashSet<UserNotification>();
            ContestStatusHistory = new HashSet<ContestStatusHistory>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public string ShortDetail { get; set; }
        public string Description { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int AuxiliaryUserId { get; set; }
        public string Thumbnail { get; set; }
        public string Packages { get; set; }
        public int? StatusId { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public short? Order { get; set; }
        public string Gratification { get; set; }        
        public string PrivateKey { get; set; }
        public short? NumberPosition { get; set; }
        public int? MediaFileTypeId { get; set; }
        public int? VerifiedBy { get; set; }
        public string CreativeDirection { get; set; }
        public string IdentificationLabel { get; set; }
        public bool? ValidationRequired { get; set; }
        public bool WinnerPublished { get; set; }
        public string Assets { get; set; }
        public string TermsAndConditions { get; set; }
        public int? ContestTypeId { get; set; }
        public string EngagementLink { get; set; }
        public DateTime? VerifiedOn { get; set; }

        public string TempBannerImage { get; set; }
        public string TextColor { get; set; }

        public virtual ICollection<ContestSubmission> Submission { get; set; }
        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual FileType MediaFileType { get; set; }
        public virtual Status Status { get; set; }
        public virtual ContestType Type { get; set; }
        public virtual AuxiliaryUser UpdatedByNavigation { get; set; }

        public virtual ICollection<ContestProvider> ContestProvider { get; set; }
        public virtual ICollection<UserNotification> UserNotification { get; set; }
        public virtual ICollection<ContestStatusHistory> ContestStatusHistory { get; set; }
    }
}
