﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class ContestSubmission
    {
        public ContestSubmission()
        {
            ContestResult = new HashSet<ContestResult>();
            ContestSubmissionMedia = new HashSet<ContestSubmissionMedia>();
        }

        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? ContestId { get; set; }
        public string Value1 { get; set; }
        public string Value2 { get; set; }
        public DateTime? ParticipatedDate { get; set; }
        public string IpAddress { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string ApiResponse { get; set; }
        public bool? Selected { get; set; }

        public virtual ICollection<ContestResult> ContestResult { get; set; }
        public virtual ICollection<ContestSubmissionMedia> ContestSubmissionMedia { get; set; }
        public virtual Contest Contest { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
