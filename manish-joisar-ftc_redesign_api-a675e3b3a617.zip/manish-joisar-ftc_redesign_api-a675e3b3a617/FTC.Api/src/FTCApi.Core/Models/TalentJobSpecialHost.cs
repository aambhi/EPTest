﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class TalentJobSpecialHost
    {
        public int Id { get; set; }
        public int? TalentJobId { get; set; }
        public short? SpecialHostId { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual ContestSpecialHost SpecialHost { get; set; }
        public virtual TalentJob TalentJob { get; set; }
    }
}
