﻿namespace FTCApi.Core.Models
{
    public class AuxiliaryUserAward
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public string Name { get; set; }
        public string Criteria { get; set; }
        public int? Year { get; set; }
        public string AddtionalDetails { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
    }
}
