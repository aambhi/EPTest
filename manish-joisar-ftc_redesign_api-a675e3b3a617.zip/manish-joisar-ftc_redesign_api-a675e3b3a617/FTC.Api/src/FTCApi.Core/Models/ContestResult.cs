﻿namespace FTCApi.Core.Models
{
    public class ContestResult
    {
        public int Id { get; set; }
        public short? ContestRank { get; set; }
        public int ContestSubmissionId { get; set; }

        public virtual ContestSubmission ContestSubmission { get; set; }
    }
}
