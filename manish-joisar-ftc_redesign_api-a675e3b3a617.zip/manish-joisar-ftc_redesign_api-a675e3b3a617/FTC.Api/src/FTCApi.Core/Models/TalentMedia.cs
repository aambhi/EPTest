﻿namespace FTCApi.Core.Models
{
    public class TalentMedia
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? MediaFileId { get; set; }
        public string Flag { get; set; }

        public virtual MediaFile MediaFile { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
