﻿using System;

namespace FTCApi.Core.Models
{
    public class AuxiliaryUserToken
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public string Email { get; set; }
        public string SMS { get; set; }
        public string Type { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateUpdated { get; set; }
        public string Email1 { get; set; }
        public string Mobile1 { get; set; }
        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
    }
}
