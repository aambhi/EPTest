﻿namespace FTCApi.Core.Models
{
    public class ProjectJobEyeColor
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? EyecolorId { get; set; }

        public virtual EyeColor EyeColor { get; set; }
        public virtual ProjectJob ProjectJob { get; set; }
    }
}
