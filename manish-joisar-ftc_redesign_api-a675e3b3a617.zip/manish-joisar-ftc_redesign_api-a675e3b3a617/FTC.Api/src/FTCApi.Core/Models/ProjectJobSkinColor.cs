﻿namespace FTCApi.Core.Models
{
    public class ProjectJobSkinColor
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? SkinColorId { get; set; }

        public virtual ProjectJob ProjectJob { get; set; }
        public virtual SkinColor SkinColor { get; set; }
    }
}
