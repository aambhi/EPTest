﻿namespace FTCApi.Core.Models
{
    public class AuxiliaryRecruiter
    {
        public int AuxiliaryId { get; set; }
        public int? RecruiterTypeId { get; set; }
        public string ContestBannerImage { get; set; }
        public string BusinessPhoneNumber { get; set; }
        public string BusinessPermanentAddress { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual RecruiterType RecruiterType { get; set; }
    }
}
