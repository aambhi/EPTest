﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Ethnicity
    {
        public Ethnicity()
        {
            TalentEthnicity = new HashSet<TalentEthnicity>();
            ProjectJobEthnicity = new HashSet<ProjectJobEthnicity>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }

        public virtual ICollection<ProjectJobEthnicity> ProjectJobEthnicity { get; set; }
        public virtual ICollection<TalentEthnicity> TalentEthnicity { get; set; }
    }
}
