﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class NotificationHeader
    {
        public NotificationHeader()
        {
            NotificationDetail = new HashSet<NotificationDetail>();
        }

        public short Id { get; set; }
        public string FromEmail { get; set; }
        public string MailFooter { get; set; }
        public string Type { get; set; }

        public virtual ICollection<NotificationDetail> NotificationDetail { get; set; }
    }
}
