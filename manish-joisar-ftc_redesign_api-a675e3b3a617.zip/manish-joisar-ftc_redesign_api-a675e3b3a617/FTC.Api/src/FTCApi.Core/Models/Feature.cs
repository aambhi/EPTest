﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Feature
    {
        public Feature()
        {
            FeaturePermission = new HashSet<FeaturePermission>();
            TalentStatusHistory = new HashSet<TalentStatusHistory>();
        }

        public int Id { get; set; }
        public string Desc { get; set; }

        public virtual ICollection<FeaturePermission> FeaturePermission { get; set; }
        public virtual ICollection<TalentStatusHistory> TalentStatusHistory { get; set; }
    }
}
