﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class ContestSpecialHost
    {
        public ContestSpecialHost()
        {
            TalentJobSpecialHost = new HashSet<TalentJobSpecialHost>();
            TalentSpecialHost = new HashSet<TalentSpecialHost>();
        }

        public short Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public string Name { get; set; }
        public string Parameters { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual ICollection<TalentJobSpecialHost> TalentJobSpecialHost { get; set; }
        public virtual ICollection<TalentSpecialHost> TalentSpecialHost { get; set; }
    }
}
