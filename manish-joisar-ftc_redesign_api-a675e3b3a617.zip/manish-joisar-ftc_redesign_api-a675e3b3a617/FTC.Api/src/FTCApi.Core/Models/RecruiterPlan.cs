﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public partial class RecruiterPlan
    {
        public RecruiterPlan()
        {
            AuxiliaryRecruiterTransaction = new HashSet<AuxiliaryRecruiterTransaction>();
            Project = new HashSet<Project>();
            RecruiterPlanUser = new HashSet<RecruiterPlanUser>();
            ProjectHistory = new HashSet<ProjectHistory>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public float? Amount { get; set; }
        public short? RoleCount { get; set; }
        public short? RecommendedCount { get; set; }
        public short? AuditionSelectionCount { get; set; }
        public bool? ViewPortfolio { get; set; }
        public bool? AllowedOnlineAudition { get; set; }
        public bool? ProvideNotesRating { get; set; }
        public short? ProjectValidity { get; set; }
        public bool? ManagePayments { get; set; }
        public bool? SocialIntegration { get; set; }
        public bool? DiscountOnStudioBooking { get; set; }
        public bool? DedicatedSupport { get; set; }
        public short? NumberOfUsers { get; set; }
        public bool? Customized { get; set; }
        public short? ManageContract { get; set; }
        public short? ViewAuditionHistory { get; set; }
        public int StatusId { get; set; }
        public string  Description { get; set; }
        public bool IsFreePlan { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public virtual ICollection<Project> Project { get; set; }
        public virtual ICollection<RecruiterPlanUser> RecruiterPlanUser { get; set; }
        public virtual ICollection<AuxiliaryRecruiterTransaction> AuxiliaryRecruiterTransaction { get; set; }
        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual ICollection<ProjectHistory> ProjectHistory { get; set; }
    }
}
