﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class SecurityQuestion
    {
        public SecurityQuestion()
        {
            AuxiliarySecurityQuestion = new HashSet<AuxiliarySecurityQuestion>();
        }
        public int Id { get; set; }
        public string Description { get; set; }

        public virtual ICollection<AuxiliarySecurityQuestion> AuxiliarySecurityQuestion { get; set; }
    }
}
