﻿using System;

namespace FTCApi.Core.Models
{
    public class JobNotes
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? TalentId { get; set; }
        public string Notes { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual ProjectJob Job { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
