﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class AuditionType
    {
        public AuditionType()
        {
            JobAudition = new HashSet<JobAudition>();
        }

        public short Id { get; set; }
        public string Description { get; set; }

        public virtual ICollection<JobAudition> JobAudition { get; set; }
    }
}
