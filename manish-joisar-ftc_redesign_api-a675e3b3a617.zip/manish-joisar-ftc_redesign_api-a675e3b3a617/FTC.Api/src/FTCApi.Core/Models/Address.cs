﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Address
    {
        public Address()
        {
            TalentAddress = new HashSet<TalentAddress>();
            AuxiliaryUserAddress = new HashSet<AuxiliaryUserAddress>();
        }

        public int Id { get; set; }
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public int? CountryId { get; set; }
        public int? CityId { get; set; }
        public string ZipCode { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string Type { get; set; }

        public ICollection<TalentAddress> TalentAddress { get; set; }
        public City City { get; set; }
        public Country Country { get; set; }
        //public State State { get; set; }


        public virtual ICollection<AuxiliaryUserAddress> AuxiliaryUserAddress { get; set; }
    }
}
