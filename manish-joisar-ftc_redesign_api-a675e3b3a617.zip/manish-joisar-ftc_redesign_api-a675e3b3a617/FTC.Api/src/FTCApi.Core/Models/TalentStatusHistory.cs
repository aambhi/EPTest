﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class TalentStatusHistory
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? StatusId { get; set; }
        public int? FeatureId { get; set; }
        public string text { get; set; }

        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual Feature Feature { get; set; }
        public virtual Status Status { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
