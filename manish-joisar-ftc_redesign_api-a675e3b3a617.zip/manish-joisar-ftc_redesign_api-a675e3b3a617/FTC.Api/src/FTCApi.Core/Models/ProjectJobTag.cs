﻿namespace FTCApi.Core.Models
{
    public class ProjectJobTag
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? TagId { get; set; }

        public virtual ProjectJob ProjectJob { get; set; }
        public virtual Tag Tag { get; set; }
    }
}
