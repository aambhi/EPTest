﻿using FTCApi.Dtos;
using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentRatings
    {
        public int TalentId { get; set; }

        public bool? Verified { get; set; }

        public DateTime? VerifiedOn { get; set; }

        public int? VerifiedBy { get; set; }

        public string VerifiedByName { get; set; }

        public float? FtcRating { get; set; }             

        public float? RecruiterRating { get; set; }

        public int? RecruiterRatingCount { get; set; }

        public string RatingNotes { get; set; }

        public float? OverallRating { get; set; }

        public float? InterestRating { get; set; }

        public string TalentProfileURL { get; set; }

        public virtual ICollection<TalentRatingParameterDto> TalentRatingParameter { get; set; }

        public virtual ICollection<TalentRatingInterestCategoryDto> TalentRatingInterestCategory { get; set; }


        public virtual ICollection<TalentRatingTalentCategoryDto> TalentRatingTalentCategory { get; set; }

    }
}
