﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class SkinColor
    {
        public SkinColor()
        {
            ProjectJobSkincolor = new HashSet<ProjectJobSkinColor>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string RGB { get; set; }
        public string Status { get; set; }

        public virtual ICollection<ProjectJobSkinColor> ProjectJobSkincolor { get; set; }
    }
}
