﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class BodyType
    {
        public BodyType()
        {
            ProjectJobBodytype = new HashSet<ProjectJobBodytype>();
        }
        public int Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public virtual ICollection<ProjectJobBodytype> ProjectJobBodytype { get; set; }
    }
}
