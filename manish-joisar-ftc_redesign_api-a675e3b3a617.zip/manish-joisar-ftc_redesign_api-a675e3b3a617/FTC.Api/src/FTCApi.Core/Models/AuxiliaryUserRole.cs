﻿using System;

namespace FTCApi.Core.Models
{
    public class AuxiliaryUserRole
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? RoleId { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Role Role { get; set; }
    }
}
