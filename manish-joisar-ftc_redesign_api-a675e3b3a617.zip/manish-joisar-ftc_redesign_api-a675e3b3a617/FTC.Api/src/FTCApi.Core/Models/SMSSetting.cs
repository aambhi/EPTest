﻿namespace FTCApi.Core.Models
{
    public class SMSSetting
    {

        public string Sid { get; set; }
        public string Token { get; set; }
        public string BaseUri { get; set; }
        public string RequestUri { get; set; }
        public string From { get; set; }

    }
}
