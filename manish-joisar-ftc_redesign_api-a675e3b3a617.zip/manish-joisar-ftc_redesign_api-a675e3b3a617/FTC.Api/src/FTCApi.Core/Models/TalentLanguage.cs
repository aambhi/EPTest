﻿namespace FTCApi.Core.Models
{
    public class TalentLanguage
    {
        public int Id { get; set; }
        public int LanguageId { get; set; }
        public int TalentId { get; set; }

        public virtual Language Language { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
