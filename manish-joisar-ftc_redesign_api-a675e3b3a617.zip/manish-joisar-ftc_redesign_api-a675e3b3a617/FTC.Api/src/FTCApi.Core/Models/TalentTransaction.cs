﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentTransaction
    {
        public TalentTransaction()
        {
            TalentTransactionDetail = new HashSet<TalentTransactionDetail>();
        }

        public int Id { get; set; }
        public int TalentId { get; set; }
        public string OrderId { get; set; }
        public string PaymentId { get; set; }
        public float? Amount { get; set; }
        public int? StatusId { get; set; }
        public string PaymentGatewayResponse { get; set; }
        public DateTime CreatedOn { get; set; }

        public virtual ICollection<TalentTransactionDetail> TalentTransactionDetail { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
