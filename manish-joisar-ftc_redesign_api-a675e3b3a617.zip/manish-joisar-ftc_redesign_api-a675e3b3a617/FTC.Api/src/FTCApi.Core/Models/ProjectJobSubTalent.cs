﻿namespace FTCApi.Core.Models
{
    public class ProjectJobSubTalent
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? JobSubTalentId { get; set; }

        public virtual ProjectJob ProjectJob { get; set; }
        public virtual TalentCategory TalentCategory { get; set; }
    }
}
