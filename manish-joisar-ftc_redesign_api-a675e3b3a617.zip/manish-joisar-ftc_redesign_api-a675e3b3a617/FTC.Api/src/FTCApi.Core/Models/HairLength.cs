﻿namespace FTCApi.Core.Models
{
    public class HairLength
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
    }
}
