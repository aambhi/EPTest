﻿namespace FTCApi.Core.Models
{
    public class Height
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public float? Inches { get; set; }
        public int? Cms { get; set; }
        public string ShortDescription { get; set; }
    }
}
