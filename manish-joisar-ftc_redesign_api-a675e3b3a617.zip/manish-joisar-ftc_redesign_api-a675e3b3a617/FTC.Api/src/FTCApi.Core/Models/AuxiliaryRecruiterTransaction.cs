﻿using System;

namespace FTCApi.Core.Models
{
    public class AuxiliaryRecruiterTransaction
    {
        public int Id { get; set; }
        public string OrderId { get; set; }
        public string PaymentId { get; set; }
        public int? StatusId { get; set; }
        public string PaymentGatewayResponse { get; set; }
        public DateTime CreatedOn { get; set; }
        public int ProjectId { get; set; }
        public float? Amount { get; set; }
        public int? PlanId { get; set; }
        public short? TransactionTypeId { get; set; }

        public virtual Project Project { get; set; }
        public virtual RecruiterPlan RecruiterPlan { get; set; }
        public virtual Status Status { get; set; }
        public virtual TransactionType TransactionType { get; set; }
    }
}
