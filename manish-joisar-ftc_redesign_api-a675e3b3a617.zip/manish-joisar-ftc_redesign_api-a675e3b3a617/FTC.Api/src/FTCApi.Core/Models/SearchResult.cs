﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class SearchResult<T>
    {
        public IEnumerable<T> Results { get; set; }
        public int TotalResults { get; set; }
        public int Previous { get; set; }
        public int Next { get; set; }
    }
}
