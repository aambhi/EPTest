﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public partial class ProductionHouseCategory
    {
        public ProductionHouseCategory()
        {
            ProductionHouse = new HashSet<ProductionHouse>();
        }

        public int Id { get; set; }
        public string Desc { get; set; }

        public virtual ICollection<ProductionHouse> ProductionHouse { get; set; }
    }
}
