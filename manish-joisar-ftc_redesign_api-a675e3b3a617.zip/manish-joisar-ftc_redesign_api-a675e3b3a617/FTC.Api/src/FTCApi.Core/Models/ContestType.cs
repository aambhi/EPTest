﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class ContestType
    {
        public ContestType()
        {
            Contest = new HashSet<Contest>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string LongDescription { get; set; }

        public virtual ICollection<Contest> Contest { get; set; }
    }
}
