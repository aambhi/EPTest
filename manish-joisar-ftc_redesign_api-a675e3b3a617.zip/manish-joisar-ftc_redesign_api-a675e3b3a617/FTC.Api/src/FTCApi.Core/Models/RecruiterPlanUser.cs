﻿namespace FTCApi.Core.Models
{
    public class RecruiterPlanUser
    {
        public int Id { get; set; }
        public int? RecruiterPlanId { get; set; }
        public int? AuxiliaryUserId { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual RecruiterPlan RecruiterPlan { get; set; }
    }
}
