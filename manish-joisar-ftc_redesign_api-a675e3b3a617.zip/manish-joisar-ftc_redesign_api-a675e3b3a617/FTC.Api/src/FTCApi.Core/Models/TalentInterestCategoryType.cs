﻿namespace FTCApi.Core.Models
{
    public class TalentInterestCategoryType
    {

        public int? InterestCategoryId { get; set; }

        public string Description { get; set; }
    }
}
