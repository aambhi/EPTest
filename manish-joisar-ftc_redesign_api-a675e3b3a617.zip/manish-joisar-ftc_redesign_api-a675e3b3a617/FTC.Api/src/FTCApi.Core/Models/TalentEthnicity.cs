﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentEthnicity
    {
        public int Id { get; set; }
        public int TalentId { get; set; }
        public int Ethnicity { get; set; }

        public virtual Ethnicity EthnicityNavigation { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
