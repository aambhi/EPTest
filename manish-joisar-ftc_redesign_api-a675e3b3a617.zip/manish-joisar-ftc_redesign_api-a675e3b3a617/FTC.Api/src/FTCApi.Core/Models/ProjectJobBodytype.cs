﻿namespace FTCApi.Core.Models
{
    public class ProjectJobBodytype
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? BodytypeId { get; set; }

        public virtual BodyType BodyType { get; set; }
        public virtual ProjectJob ProjectJob { get; set; }
    }
}
