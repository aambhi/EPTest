﻿namespace FTCApi.Core.Models
{
    public class ProjectLocation
    {
        public int Id { get; set; }
        public int? ProjectId { get; set; }
        public int? CountryId { get; set; }
        public int? StateId { get; set; }
        public int? CityId { get; set; }

        public Project Project { get; set; }
    }
}
