﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class MstDeviceOs
    {
        public MstDeviceOs()
        {
            AppVersion = new HashSet<AppVersion>();
            Talent = new HashSet<Talent>();
        }

        public short Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<AppVersion> AppVersion { get; set; }
        public virtual ICollection<Talent> Talent { get; set; }
    }
}
