﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class TraceEmailGateway
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? TalentId { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string EmailRequest { get; set; }
        public string EmailResponse { get; set; }
        public bool? Sent { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
