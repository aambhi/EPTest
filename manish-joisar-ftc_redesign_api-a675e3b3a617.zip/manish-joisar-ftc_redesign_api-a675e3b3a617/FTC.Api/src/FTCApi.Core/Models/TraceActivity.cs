﻿using System;

namespace FTCApi.Core.Models
{
    public class TraceActivity
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public string Route { get; set; }
        public string Functionality { get; set; }
        public string Browser { get; set; }
        public string IpAddress { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
