﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TagCategory
    {
        public TagCategory()
        {
            Tag = new HashSet<Tag>();
        }


        public int Id { get; set; }
        public string Description { get; set; }
        public bool? TagTalentRelated { get; set; }

        public virtual ICollection<Tag> Tag { get; set; }
        
    }
}
