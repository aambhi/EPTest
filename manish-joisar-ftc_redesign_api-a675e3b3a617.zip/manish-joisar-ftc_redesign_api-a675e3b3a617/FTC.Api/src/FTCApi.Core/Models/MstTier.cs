﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class MstTier
    {
        public MstTier()
        {
            Talent = new HashSet<Talent>();
        }

        public short TierId { get; set; }
        public string TierDesc { get; set; }

        public virtual ICollection<Talent> Talent { get; set; }
    }
}
