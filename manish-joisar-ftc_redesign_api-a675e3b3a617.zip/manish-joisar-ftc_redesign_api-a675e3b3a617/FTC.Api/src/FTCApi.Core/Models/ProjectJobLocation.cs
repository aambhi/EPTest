﻿namespace FTCApi.Core.Models
{
    public class ProjectJobLocation
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? CityId { get; set; }

        public virtual City City { get; set; }
        public virtual ProjectJob ProjectJob { get; set; }
    }
}
