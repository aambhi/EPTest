﻿namespace FTCApi.Core.Models
{
    public class TalentSocialLink
    {
        public int Id { get; set; }
        public int TalentId { get; set; }
        public short SocialLinkId { get; set; }
        public string Link { get; set; }

        public virtual SocialLink SocialLink { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
