﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class City
    {
        public City()
        {
            Address = new HashSet<Address>();
            ProjectJobLocation = new HashSet<ProjectJobLocation>();
        }

        public int CityId { get; set; }
        public string CityDescription { get; set; }
        public int? CityCountryId { get; set; }
        public string CityState { get; set; }
        public string CityStateCode { get; set; }

        public ICollection<Address> Address { get; set; }
        public ICollection<ProjectJobLocation> ProjectJobLocation { get; set; }
        public Country CityCountry { get; set; }
    }
}
