﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class AuxiliaryUser
    {
        public AuxiliaryUser()
        {
            TalentTagTaltagCreatedByNavigation = new HashSet<TalentTag>();
            TalentTagTaltagUpdatedByNavigation = new HashSet<TalentTag>();
            AuxiliaryUserAssociation = new HashSet<AuxiliaryUserAssociation>();
            AuxiliaryUserAssignedUaAuxiliaryUser = new HashSet<AuxiliaryUserAssigned>();
            AuxiliaryUserAssignedUaAssignedAuxiliaryUser = new HashSet<AuxiliaryUserAssigned>();
            AuxiliaryUserRole = new HashSet<AuxiliaryUserRole>();
            AuxiliaryUserAddress = new HashSet<AuxiliaryUserAddress>();
            AuxiliaryUserSocialLink = new HashSet<AuxiliaryUserSocialLink>();
            AuxiliaryUserExperience = new HashSet<AuxiliaryUserExperience>();
            AuxiliaryUserAward = new HashSet<AuxiliaryUserAward>();
            AuxiliaryUserToken = new HashSet<AuxiliaryUserToken>();
            AuxiliarySecurityQuestion = new HashSet<AuxiliarySecurityQuestion>();
            ContestContestAuxiliaryUser = new HashSet<Contest>();
            ContestContestCreatedByNavigation = new HashSet<Contest>();
            ContestContestUpdatedByNavigation = new HashSet<Contest>();
            ContestProvider = new HashSet<ContestProvider>();
            ContestSpecialHost = new HashSet<ContestSpecialHost>();
            RazorPayStaging = new HashSet<RazorPayStaging>();
            Project = new HashSet<Project>();
            UserNotification = new HashSet<UserNotification>();
            MessageMesFromAuxiliary = new HashSet<Message>();
            MessageMesToAuxiliary = new HashSet<Message>();
            AuxiliaryUserStatusHistory = new HashSet<AuxiliaryUserStatusHistory>();
            AuxiliaryUserStatusHistoryCreatedByNavigation = new HashSet<AuxiliaryUserStatusHistory>();
            ProjectJobStatusHistory = new HashSet<ProjectJobStatusHistory>();
            ContestStatusHistory = new HashSet<ContestStatusHistory>();
            JobTalentRecommended = new HashSet<JobTalentRecommended>();
            RecruiterPlan = new HashSet<RecruiterPlan>();

            TraceActivity = new HashSet<TraceActivity>();
            TraceLogin = new HashSet<TraceLogin>();
            RecruiterPlanUser = new HashSet<RecruiterPlanUser>();
            TraceSmsGateway = new HashSet<TraceSmsGateway>();
            TalentStatusHistory = new HashSet<TalentStatusHistory>();
            ProjectHistory = new HashSet<ProjectHistory>();
            ProjectJobHistory = new HashSet<ProjectJobHistory>();
            TalentSpecialHost = new HashSet<TalentSpecialHost>();
            TraceEmailGateway = new HashSet<TraceEmailGateway>();
            WhitelistExclude = new HashSet<WhitelistExclude>();
        }

        public int Id { get; set; }
        public string FullName { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public bool? Verified { get; set; }
        public int? VerifiedBy { get; set; }
        public DateTime? VerifiedOn { get; set; }

        public int? TypeId { get; set; }
        public int? StatusId { get; set; }

        public string Mobile { get; set; }
        public int? ParentAuxiliaryUserId { get; set; }
        public string AuthToken { get; set; }

        public string MobileCountryCode { get; set; }
        public bool? Onboarded { get; set; }
        public bool? TermsConditionAccepted { get; set; }
        public string ProfileURL { get; set; }

        public int? MobileCountryId { get; set; }

        public AuxiliaryRecruiter AuxiliaryRecruiter { get; set; }
        public virtual ICollection<AuxiliaryUserAssigned> AuxiliaryUserAssignedUaAuxiliaryUser { get; set; }

        public virtual ICollection<AuxiliaryUserAssigned> AuxiliaryUserAssignedUaAssignedAuxiliaryUser { get; set; }
        public virtual ICollection<AuxiliaryUserRole> AuxiliaryUserRole { get; set; }
        public ICollection<TalentTag> TalentTagTaltagCreatedByNavigation { get; set; }
        public ICollection<TalentTag> TalentTagTaltagUpdatedByNavigation { get; set; }
        //public virtual ICollection<AuxiliaryUserAssigned> AuxiliaryUserAssigned { get; set; }

        public virtual ICollection<TraceSmsGateway> TraceSmsGateway { get; set; }

        public AuxiliaryUserType AuType { get; set; }

        public virtual ICollection<AuxiliaryUserAssociation> AuxiliaryUserAssociation { get; set; }

        public virtual ICollection<AuxiliaryUserSocialLink> AuxiliaryUserSocialLink { get; set; }

        public virtual ICollection<AuxiliaryUserAddress> AuxiliaryUserAddress { get; set; }

        public virtual ICollection<AuxiliaryUserExperience> AuxiliaryUserExperience { get; set; }

        public virtual ICollection<AuxiliaryUserAward> AuxiliaryUserAward { get; set; }

        public virtual ICollection<AuxiliaryUserToken> AuxiliaryUserToken { get; set; }

        public virtual ICollection<AuxiliaryUser> InverseAuParentAuxiliaryUser { get; set; }
        public virtual ICollection<AuxiliarySecurityQuestion> AuxiliarySecurityQuestion { get; set; }

        public virtual AuxiliaryUser ParentAuxiliaryUser { get; set; }

        public virtual ICollection<Contest> ContestContestAuxiliaryUser { get; set; }

        public virtual ICollection<Contest> ContestContestCreatedByNavigation { get; set; }

        public virtual ICollection<Contest> ContestContestUpdatedByNavigation { get; set; }

        public virtual ICollection<ContestProvider> ContestProvider { get; set; }

        public virtual ICollection<ContestSpecialHost> ContestSpecialHost { get; set; }

        public virtual ICollection<RazorPayStaging> RazorPayStaging { get; set; }
        public virtual ICollection<Project> Project { get; set; }

        public virtual ICollection<UserNotification> UserNotification { get; set; }

        public virtual ICollection<Message> MessageMesFromAuxiliary { get; set; }

        public virtual ICollection<Message> MessageMesToAuxiliary { get; set; }
        public virtual ICollection<TraceActivity> TraceActivity { get; set; }
        public virtual ICollection<TraceLogin> TraceLogin { get; set; }
        public virtual ICollection<RecruiterPlanUser> RecruiterPlanUser { get; set; }

        public virtual ICollection<AuxiliaryUserStatusHistory> AuxiliaryUserStatusHistory { get; set; }
        public virtual ICollection<AuxiliaryUserStatusHistory> AuxiliaryUserStatusHistoryCreatedByNavigation { get; set; }

        public virtual ICollection<TalentStatusHistory> TalentStatusHistory { get; set; }
        public virtual ICollection<ProjectJobStatusHistory> ProjectJobStatusHistory { get; set; }
        public virtual ICollection<ContestStatusHistory> ContestStatusHistory { get; set; }
        public virtual Country MobileCountry { get; set; }

        public virtual ICollection<JobTalentRecommended> JobTalentRecommended { get; set; }

        public virtual ICollection<TraceEmailGateway> TraceEmailGateway { get; set; }
        public virtual ICollection<RecruiterPlan> RecruiterPlan { get; set; }

        public virtual ICollection<ProjectHistory> ProjectHistory { get; set; }
        public virtual ICollection<ProjectJobHistory> ProjectJobHistory { get; set; }

        public virtual ICollection<TalentSpecialHost> TalentSpecialHost { get; set; }
        public virtual ICollection<WhitelistExclude> WhitelistExclude { get; set; }
    }
}
