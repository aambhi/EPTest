﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentTransactionDetail
    {
        public int Id { get; set; }
        public int? TalentTransactionId { get; set; }
        public short TalentPlanId { get; set; }
        public DateTime? EndDate { get; set; }

        public virtual TalentPlan TalentPlan { get; set; }
        public virtual TalentTransaction TalentTransaction { get; set; }
    }
}
