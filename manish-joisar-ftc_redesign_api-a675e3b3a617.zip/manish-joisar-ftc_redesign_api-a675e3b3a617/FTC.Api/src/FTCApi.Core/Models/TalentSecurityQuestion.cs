﻿namespace FTCApi.Core.Models
{
    public class TalentSecurityQuestion
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? SecurityQuestionId { get; set; }
        public string Answer { get; set; }
    }
}
