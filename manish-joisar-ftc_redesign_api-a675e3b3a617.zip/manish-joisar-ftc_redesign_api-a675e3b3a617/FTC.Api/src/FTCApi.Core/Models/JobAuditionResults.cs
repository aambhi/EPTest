﻿using FTCApi.Dtos.JobAuditionsDtos;
using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class JobAuditionResults<T>
    {
        public string Project { get; set; }
        public string  JobTitle { get; set; }
        public string JobDetails { get; set; }
        public int JobId { get; set; }

        
        public string CollabratorComments { get; set; }

        public IEnumerable<T> Results { get; set; }
        public int TotalResults { get; set; }
        public int?  PendingAuditionSelectionCount { get; set; }

        public int? JobNumberOfRole { get; set; }
        public bool? ProvideNotesRating { get; set; }
        public short? ViewAuditionHistory { get; set; }
        public DateTime? JobEndDate { get; set; }
        public bool? ViewAuditions { get; set; }

        public List<ProjectJobStatusDto> SelectedForAuditionTabs { get; set; }
    }
}
