﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class RecruiterType
    {
        public RecruiterType()
        {
            AuxiliaryRecruiter = new HashSet<AuxiliaryRecruiter>();
        }

        public int Id { get; set; }
        public string Description { get; set; }

        public virtual ICollection<AuxiliaryRecruiter> AuxiliaryRecruiter { get; set; }
    }
}
