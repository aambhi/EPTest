﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class ContestStatusHistory
    {
        public int Id { get; set; }
        public int? ContestId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? StatusId { get; set; }

        public virtual Contest Contest { get; set; }
        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual Status Status { get; set; }
    }
}
