﻿using System;

namespace FTCApi.Core.Models
{
    public class User:BaseModel
    {
        public string FirstName { get; set; }
        /// <summary>
        /// Last name
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// mobile number
        /// </summary>
        public string MobileNumber { get; set; }
        /// <summary>
        /// email
        /// </summary>
        public string Email { get; set; }

        public bool IsActive { get; set; }
        /// <summary>
        /// IsRegistered
        /// </summary>
        public bool IsRegistered { get; set; }
        /// <summary>
        /// IsLocked
        /// </summary>
        public bool IsLocked { get; set; }
        public DateTime LastLoginDate { get; set; }
        public Guid UniqueId { get; set; }
        public int RoleId { get; set; }
        public string SocialUserId { get; set; }
        public string PhoneCode { get; set; }
        public string CountryCode { get; set; }
        public string IsoCode { get; set; }
    }
}
