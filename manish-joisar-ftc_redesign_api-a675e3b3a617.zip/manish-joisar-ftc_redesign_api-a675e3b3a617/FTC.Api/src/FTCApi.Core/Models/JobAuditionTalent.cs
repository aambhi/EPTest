﻿using System;

namespace FTCApi.Core.Models
{
    public class JobAuditionTalent
    {
        public int Id { get; set; }
        public int? JobAuditionId { get; set; }
        public int? TalentId { get; set; }
        public string Notes { get; set; }
        public int? MoveToAuditionId { get; set; }
        public bool? NotSelected { get; set; }
        public bool? MovedToNextStage { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public virtual JobAudition JobAudition { get; set; }
        public virtual JobAudition MoveToAudition { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
