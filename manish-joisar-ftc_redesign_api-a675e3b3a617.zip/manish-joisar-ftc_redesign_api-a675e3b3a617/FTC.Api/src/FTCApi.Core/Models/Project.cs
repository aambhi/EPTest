﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public partial class Project
    {
        public Project()
        {
         
            AuxiliaryUserAssigned = new HashSet<AuxiliaryUserAssigned>();
            ProjectLocation = new HashSet<ProjectLocation>();
            ProjectMedia = new HashSet<ProjectMedia>();
            AuxiliaryRecruiterTransaction = new HashSet<AuxiliaryRecruiterTransaction>();
            UserNotification = new HashSet<UserNotification>();
            ProjectHistory = new HashSet<ProjectHistory>();
        }

        public int Id { get; set; }
        public int AuxiliaryUserId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int? InterestId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public DateTime? EventDate { get; set; }
        public string Image { get; set; }
        public string Video { get; set; }
        public string ProductionHouse { get; set; }
        public string DirectorName { get; set; }
        public string ProducerName { get; set; }
        public bool? Verified { get; set; }
        public int? VerifiedBy { get; set; }
        public DateTime? VerifiedOn { get; set; }
        public int? StatusId { get; set; }
        public int? ProductionHouseId { get; set; }
        public int? PlanId { get; set; }
        public string CompanyBrand { get; set; }
        public int? AdAgencyId { get; set; }
        public string AdAgency { get; set; }
        public bool? CastingRequired { get; set; }
        public string TheatreGroup { get; set; }
        public bool IsPaid { get; set; }
        public bool IsPaidOffline { get; set; }
        public virtual ICollection<ProjectHistory> ProjectHistory { get; set; }

        public virtual ICollection<AuxiliaryUserAssigned> AuxiliaryUserAssigned { get; set; }
        public virtual ICollection<ProjectLocation> ProjectLocation { get; set; }
        public virtual ICollection<ProjectMedia> ProjectMedia { get; set; }
        public virtual ProductionHouse AdAgencyNavigation { get; set; }
        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual InterestCategory Interest { get; set; }
        public virtual RecruiterPlan Plan { get; set; }
        public virtual ProductionHouse ProductionHouseNavigation { get; set; }
        public virtual ICollection<AuxiliaryRecruiterTransaction> AuxiliaryRecruiterTransaction { get; set; }
        public virtual ICollection<UserNotification> UserNotification { get; set; }
    }
}
