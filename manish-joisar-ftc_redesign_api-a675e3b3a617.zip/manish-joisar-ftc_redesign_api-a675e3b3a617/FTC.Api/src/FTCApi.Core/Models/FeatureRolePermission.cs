﻿using System;

namespace FTCApi.Core.Models
{
    public class FeatureRolePermission 
    {
        public int Id { get; set; }
        public int? RoleId { get; set; }
        public int? FeaturePermissionId { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual FeaturePermission FeaturePermission { get; set; }
        public virtual Role Role { get; set; }
    }
}
