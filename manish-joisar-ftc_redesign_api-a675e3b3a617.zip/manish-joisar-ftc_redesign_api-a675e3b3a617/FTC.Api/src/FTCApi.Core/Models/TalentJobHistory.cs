﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentJobHistory
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? TalentId { get; set; }
        public int? JobStatusId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? AuditionId { get; set; }

        public virtual JobAudition Audition { get; set; }

        public virtual ProjectJob Job { get; set; }
        public virtual ProjectJobStatus JobStatus { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
