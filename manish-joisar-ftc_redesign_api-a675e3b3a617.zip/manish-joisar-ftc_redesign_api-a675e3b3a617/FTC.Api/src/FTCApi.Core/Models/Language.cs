﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Language
    {
        public Language()
        {
            ProjectJobLanguage = new HashSet<ProjectJobLanguage>();
            TalentLanguage = new HashSet<TalentLanguage>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }

        public virtual ICollection<TalentLanguage> TalentLanguage { get; set; }
        public virtual ICollection<ProjectJobLanguage> ProjectJobLanguage { get; set; }
    }
}
