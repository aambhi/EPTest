﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class FileType
    {
        public FileType()
        {
            MediaFile = new HashSet<MediaFile>();
            Contest = new HashSet<Contest>();
            ProjectJob = new HashSet<ProjectJob>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public string AllowedExtensions { get; set; }

        public string Icon { get; set; }

        public virtual ICollection<MediaFile> MediaFile { get; set; }
        public virtual ICollection<ProjectJob> ProjectJob { get; set; }

        public virtual ICollection<Contest> Contest { get; set; }
    }
}
