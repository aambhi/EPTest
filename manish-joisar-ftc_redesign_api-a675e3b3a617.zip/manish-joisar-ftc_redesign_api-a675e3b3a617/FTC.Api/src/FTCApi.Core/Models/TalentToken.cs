﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentToken
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string SMS { get; set; }
        public string LoginType { get; set; }
        public int? TalentId { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateUpdated { get; set; }
        public string Email1 { get; set; }
        public string Mobile1 { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
