﻿using System;

namespace FTCApi.Core.Models
{
    public class JobShareViewDetail
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual ProjectJob Job { get; set; }
    }
}
