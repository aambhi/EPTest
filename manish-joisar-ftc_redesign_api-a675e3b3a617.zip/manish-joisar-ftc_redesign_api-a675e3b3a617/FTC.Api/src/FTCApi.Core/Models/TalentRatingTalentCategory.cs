﻿namespace FTCApi.Core.Models
{
    public class TalentRatingTalentCategory
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? TalentCategoryId { get; set; }
        public float? Rating { get; set; }

        public virtual TalentCategory TalentCategory { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
