﻿namespace FTCApi.Core.Models
{
    public class AuxiliaryUserSocialLink
    {
        public int AuxiliaryUserId { get; set; }
        public short SocialLinkId { get; set; }
        public string Link { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual SocialLink SocialLink { get; set; }
    }
}
