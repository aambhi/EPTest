﻿using System;

namespace FTCApi.Core.Models
{
    public class AuxiliaryUserAssigned
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? AssignedAuxiliaryUserId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ProjectId { get; set; }
        public int? JobId { get; set; }

        public virtual AuxiliaryUser AssignedAuxiliaryUser { get; set; }
        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual ProjectJob Job { get; set; }
        public virtual Project Project { get; set; }
    }
}
