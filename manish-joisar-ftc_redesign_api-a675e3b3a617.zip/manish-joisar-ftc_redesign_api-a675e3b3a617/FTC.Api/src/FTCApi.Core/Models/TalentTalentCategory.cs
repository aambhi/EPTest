﻿namespace FTCApi.Core.Models
{
    public class TalentTalentCategory
    {
        public int Id { get; set; }

        public int TalentId { get; set; }

        public int TalentCategoryId { get; set; }

        public TalentCategory TalentCategory { get; set; }

        public Talent Talent { get; set; }
    }
}
