﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class MstSmsGateway
    {
        public MstSmsGateway()
        {
            TraceSmsGateway = new HashSet<TraceSmsGateway>();
        }

        public short Id { get; set; }
        public string Name { get; set; }
        public bool DomesticDefault { get; set; }
        public bool InternationalDefault { get; set; }
        public string BaseUrl { get; set; }
        public string DomesticUserid { get; set; }
        public string DomesticPassword { get; set; }
        public string InternationalUserid { get; set; }
        public string InternationalPassword { get; set; }
        public string RequestUrl { get; set; }

        public virtual ICollection<TraceSmsGateway> TraceSmsGateway { get; set; }
    }
}
