﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    /*
    public class State
    {
        public State()
        {
            Address = new HashSet<Address>();
            City = new HashSet<City>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public int? CountryId { get; set; }

        public virtual ICollection<Address> Address { get; set; }
        public virtual ICollection<City> City { get; set; }
        public virtual Country Country { get; set; }
    }
    */
}
