﻿namespace FTCApi.Core.Models
{
    public class AuxiliaryUserAddress
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? AddressId { get; set; }

        public virtual Address Address { get; set; }
        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
    }
}
