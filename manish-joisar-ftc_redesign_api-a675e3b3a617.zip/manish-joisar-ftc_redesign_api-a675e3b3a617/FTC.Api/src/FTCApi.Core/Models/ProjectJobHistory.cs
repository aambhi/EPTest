﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class ProjectJobHistory
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual ProjectJob Job { get; set; }
        public virtual AuxiliaryUser UpdatedByNavigation { get; set; }
    }
}
