﻿namespace FTCApi.Core.Models
{
    public class ChestSize
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public double Inches { get; set; }
        public double Cms { get; set; }
        public string ShortDescription { get; set; }
    }
}
