﻿namespace FTCApi.Core.Models
{
    public class TalentInTransit
    {
        public short? Order { get; set; }

        public int? TalentId { get; set; }
        public int StatusId { get; set; }
        public string StatusDescription { get; set; }
        public int? JobId { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
