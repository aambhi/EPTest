﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentPlan
    {
        public TalentPlan()
        {
            TalentPlanFeature = new HashSet<TalentPlanFeature>();
            TalentTransactionDetail = new HashSet<TalentTransactionDetail>();
        }

        public short Id { get; set; }
        public string Name { get; set; }
        public string Brief { get; set; }
        public string Description { get; set; }
        public short? Period { get; set; }
        public float? Amount { get; set; }
        public int StatusId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual ICollection<TalentPlanFeature> TalentPlanFeature { get; set; }
        public virtual ICollection<TalentTransactionDetail> TalentTransactionDetail { get; set; }
    }
}
