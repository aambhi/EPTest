﻿namespace FTCApi.Core.Models
{
    public class ProjectJobLanguage
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? LanguageId { get; set; }

        public virtual ProjectJob Job { get; set; }
        public virtual Language Language { get; set; }
    }
}
