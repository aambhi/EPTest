﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public partial class ProductionHouse
    {
        public ProductionHouse()
        {
            ProjectPrjAdAgencyNavigation = new HashSet<Project>();
            ProjectPrjProductionHouseNavigation = new HashSet<Project>();
            TalentExperience = new HashSet<TalentExperience>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public int? StatusId { get; set; }
        public int? CategoryId { get; set; }

        public virtual ICollection<Project> ProjectPrjAdAgencyNavigation { get; set; }
        public virtual ICollection<Project> ProjectPrjProductionHouseNavigation { get; set; }
        public virtual ICollection<TalentExperience> TalentExperience { get; set; }
        public virtual ProductionHouseCategory Category { get; set; }
        public virtual Status Status { get; set; }
    }
}
