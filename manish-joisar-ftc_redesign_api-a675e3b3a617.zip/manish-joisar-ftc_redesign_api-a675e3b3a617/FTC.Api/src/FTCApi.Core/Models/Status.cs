﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Status
    {
        public Status()
        {
            MediaFile = new HashSet<MediaFile>();
            TalentCategory = new HashSet<TalentCategory>();
            Talent = new HashSet<Talent>();
            Contest = new HashSet<Contest>();
            ProductionHouse = new HashSet<ProductionHouse>();
            School = new HashSet<School>();
            AuxiliaryRecruiterTransaction = new HashSet<AuxiliaryRecruiterTransaction>();
            AuxiliaryUserStatusHistory = new HashSet<AuxiliaryUserStatusHistory>();
            TalentStatusHistory = new HashSet<TalentStatusHistory>();
            ProjectJobStatusHistory = new HashSet<ProjectJobStatusHistory>();
            ContestStatusHistory = new HashSet<ContestStatusHistory>();
            TalentPlan = new HashSet<TalentPlan>();
            TalentSpecialHost = new HashSet<TalentSpecialHost>();
            WhitelistExclude = new HashSet<WhitelistExclude>();
        }

        public int Id { get; set; }
        public string Description { get; set; }

        public ICollection<MediaFile> MediaFile { get; set; }
        public ICollection<TalentCategory> TalentCategory { get; set; }
        public ICollection<Talent> Talent { get; set; }
        public virtual ICollection<Contest> Contest { get; set; }

        public virtual ICollection<ProductionHouse> ProductionHouse { get; set; }

        public virtual ICollection<School> School { get; set; }
        public virtual ICollection<AuxiliaryRecruiterTransaction> AuxiliaryRecruiterTransaction { get; set; }
        public virtual ICollection<AuxiliaryUserStatusHistory> AuxiliaryUserStatusHistory { get; set; }
        public virtual ICollection<TalentStatusHistory> TalentStatusHistory { get; set; }
        public virtual ICollection<ProjectJobStatusHistory> ProjectJobStatusHistory { get; set; }
        public virtual ICollection<ContestStatusHistory> ContestStatusHistory { get; set; }
        public virtual ICollection<TalentPlan> TalentPlan { get; set; }
        public virtual ICollection<TalentSpecialHost> TalentSpecialHost { get; set; }
        public virtual ICollection<WhitelistExclude> WhitelistExclude { get; set; }
    }
}
