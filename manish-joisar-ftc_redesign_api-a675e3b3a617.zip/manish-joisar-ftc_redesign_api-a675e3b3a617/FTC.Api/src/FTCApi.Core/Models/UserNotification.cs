﻿using System;

namespace FTCApi.Core.Models
{
    public class UserNotification
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public string Text { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ProjectId { get; set; }
        public int? JobId { get; set; }
        public int? ContestId { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public bool Read { get; set; }
        public short? UrlRoute { get; set; }
        public int? ReferenceAuxiliaryUserId { get; set; }
        

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Contest Contest { get; set; }
        public virtual ProjectJob Job { get; set; }
        public virtual Project Project { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
