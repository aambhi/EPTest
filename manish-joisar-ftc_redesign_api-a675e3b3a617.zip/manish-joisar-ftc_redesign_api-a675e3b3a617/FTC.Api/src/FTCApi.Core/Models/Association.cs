﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Association
    {
        public Association()
        {
            AuxiliaryUserAssociation = new HashSet<AuxiliaryUserAssociation>();
        }


        public int Id { get; set; }
        public string Description { get; set; }

        public virtual ICollection<AuxiliaryUserAssociation> AuxiliaryUserAssociation { get; set; }
    }
}
