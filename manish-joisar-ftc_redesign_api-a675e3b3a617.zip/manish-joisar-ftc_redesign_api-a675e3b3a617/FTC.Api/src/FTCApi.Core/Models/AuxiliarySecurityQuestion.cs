﻿namespace FTCApi.Core.Models
{
    public class AuxiliarySecurityQuestion
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? SecurityQuestionId { get; set; }
        public string Answer { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual SecurityQuestion SecurityQuestion { get; set; }
    }
}
