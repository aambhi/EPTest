﻿namespace FTCApi.Core.Models
{
    public class TalentRatingRmark
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? TalentCategoryId { get; set; }
        public int? InterestCategoryId { get; set; }

        public virtual InterestCategory InterestCategory { get; set; }
        public virtual TalentCategory TalentCategory { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
