﻿namespace FTCApi.Core.Models
{
    public class AuxiliaryUserExperience
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? InterestCategoryId { get; set; }
        public string ProjectTitle { get; set; }
        public string CompanyName { get; set; }
        public int? Year { get; set; }
        public string AddtionalDetails { get; set; }
        public string Link { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual InterestCategory InterestCategory { get; set; }
    }
}
