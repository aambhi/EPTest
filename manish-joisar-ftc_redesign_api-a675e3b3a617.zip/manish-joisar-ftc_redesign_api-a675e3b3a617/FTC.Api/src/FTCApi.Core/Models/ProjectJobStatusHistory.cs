﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class ProjectJobStatusHistory
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? StatusId { get; set; }

        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual ProjectJob Job { get; set; }
        public virtual Status JshStatus { get; set; }
    }
}
