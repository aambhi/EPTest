﻿using System;

namespace FTCApi.Core.Models
{
    public partial class RazorPayStaging
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public string OrderId { get; set; }
        public string PaymentId { get; set; }
        public int? StatusId { get; set; }
        public string Response { get; set; }
        public DateTime? CreatedOn { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
