﻿namespace FTCApi.Core.Models
{
    public class TalentRatingParameter
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public short? RatingParameterId { get; set; }
        public float? Rating { get; set; }

        public virtual MstTalentRatingParameter RatingParameter { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
