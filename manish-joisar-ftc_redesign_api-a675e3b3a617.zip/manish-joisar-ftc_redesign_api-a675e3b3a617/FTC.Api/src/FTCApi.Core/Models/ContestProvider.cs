﻿namespace FTCApi.Core.Models
{
    public class ContestProvider
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }

        public int? ContestId { get; set; }

        public string Endpoint { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }

        public virtual Contest Contest { get; set; }
    }
}
