﻿namespace FTCApi.Core.Models
{
    public class TalentPlanFeature
    {
        public short Id { get; set; }
        public short? TalentPlanId { get; set; }
        public short? TalentFeatureId { get; set; }
        public int? ImageCount { get; set; }
        public int? VideoCount { get; set; }
        public int? AudioCount { get; set; }
        public int? ScriptCount { get; set; }

        public virtual TalentFeature TalentFeature { get; set; }
        public virtual TalentPlan TalentPlan { get; set; }
    }
}
