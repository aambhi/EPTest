﻿using System;

namespace FTCApi.Core.Models
{
    public class BaseModel
    {
        /// <summary>
        /// Unique Identifier for the entity
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Id of the user, who last modified the data
        /// </summary>
        public int LastModifiedBy { get; set; }

        /// <summary>
        /// date when the data was last modified
        /// </summary>
        public DateTime LastModifiedDate { get; set; }
    }
}
