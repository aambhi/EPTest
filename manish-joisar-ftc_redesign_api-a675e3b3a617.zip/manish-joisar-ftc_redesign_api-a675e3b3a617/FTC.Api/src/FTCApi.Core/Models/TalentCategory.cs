﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentCategory
    {
        public TalentCategory()
        {
            ProjectJob = new HashSet<ProjectJob>();
            TalentTalentCategory = new HashSet<TalentTalentCategory>();
            TalentExperience = new HashSet<TalentExperience>();
            ProjectJobSubTalent = new HashSet<ProjectJobSubTalent>();
            TalentRatingRmark = new HashSet<TalentRatingRmark>();
            TalentRatingTalentCategory = new HashSet<TalentRatingTalentCategory>();
            SubTalentCategory = new HashSet<TalentExperience>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public int? ParentId { get; set; }
        public string SelectedIcon { get; set; }
        public string NotSelectedIcon { get; set; }
        public int? StatusId { get; set; }

        public virtual ICollection<ProjectJob> ProjectJob { get; set; }
        public ICollection<TalentTalentCategory> TalentTalentCategory { get; set; }
        public virtual TalentCategory TalParent { get; set; }
        public virtual ICollection<TalentCategory> InverseTalParent { get; set; }
        public virtual Status TalStatus { get; set; }

        public virtual ICollection<TalentExperience> TalentExperience { get; set; }

        public virtual ICollection<ProjectJobSubTalent> ProjectJobSubTalent { get; set; }

        public virtual ICollection<TalentRatingRmark> TalentRatingRmark { get; set; }

        public virtual ICollection<TalentRatingTalentCategory> TalentRatingTalentCategory { get; set; }

        public virtual ICollection<TalentExperience> SubTalentCategory { get; set; }
    }
}