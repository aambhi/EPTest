﻿using FTCApi.Core.Enums;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class SearchParameters
    {
        public const int DefaultPageSize = 10;

        public SearchParameters()
        {
            InterestFilter = new List<Dictionary<string, string>>();
            AdvanceFilter = new List<Dictionary<string, string>>();
            SearchFor = new Dictionary<string, string>();
            PageSize = DefaultPageSize;
            PageIndex = 0;
            Previous = -1;
            Next = 0;
            SortOrder = SortOrder.Ascending;
        }

        public List<Dictionary<string, string>> InterestFilter { get; set; }

        public List<Dictionary<string, string>> AdvanceFilter { get; set; }

        public Dictionary<string, string> SearchFor { get; set; }

        public int PageIndex { get; set; }

        public int Previous { get; set; }

        public int Next { get; set; }

        public int PageSize { get; set; }

        public string SortOn { get; set; }

        public SortOrder SortOrder { get; set; }

        public void SetDefaultsForUnsetProperties()
        {
            if (PageSize <= 0)
            {
                PageSize = DefaultPageSize;
            }

            if (PageIndex < 0)
            {
                PageIndex = 0;
            }
        }
    }
}