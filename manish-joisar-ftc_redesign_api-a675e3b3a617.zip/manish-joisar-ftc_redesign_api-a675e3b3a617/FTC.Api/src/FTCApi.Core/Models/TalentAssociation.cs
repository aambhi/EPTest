﻿namespace FTCApi.Core.Models
{
    public class TalentAssociation
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? AssociationId { get; set; }
        public string MembershipId { get; set; }

        public virtual Talent Talent { get; set; }
    }
}
