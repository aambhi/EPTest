﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class FeatureOperation
    {
        public FeatureOperation()
        {
            FeaturePermission = new HashSet<FeaturePermission>();
        }

        public int Id { get; set; }
        public string Desc { get; set; }

        public virtual ICollection<FeaturePermission> FeaturePermission { get; set; }
    }
}
