﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentAddress
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? AddressId { get; set; }

        public Address Address { get; set; }
        public Talent Talent { get; set; }
    }
}
