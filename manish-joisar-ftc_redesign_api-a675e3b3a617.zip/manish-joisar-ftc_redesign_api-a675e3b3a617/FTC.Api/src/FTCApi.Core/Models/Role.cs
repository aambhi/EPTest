﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Role
    {
        public Role()
        {
            AuxiliaryUserRole = new HashSet<AuxiliaryUserRole>();
            FeatureRolePermission = new HashSet<FeatureRolePermission>();
        }

        public int RoleId { get; set; }
        public string RoleDesc { get; set; }

        public virtual ICollection<AuxiliaryUserRole> AuxiliaryUserRole { get; set; }
        public virtual ICollection<FeatureRolePermission> FeatureRolePermission { get; set; }
    }
}
