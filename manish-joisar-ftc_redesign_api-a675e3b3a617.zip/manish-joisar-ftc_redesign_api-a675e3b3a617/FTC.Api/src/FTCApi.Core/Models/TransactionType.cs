﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.Models
{
    public class TransactionType
    {
        public TransactionType()
        {
            AuxiliaryRecruiterTransaction = new HashSet<AuxiliaryRecruiterTransaction>();
        }

        public short Id { get; set; }
        public string Description { get; set; }

        public virtual ICollection<AuxiliaryRecruiterTransaction> AuxiliaryRecruiterTransaction { get; set; }
    }
}
