﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class AuxiliaryUserType
    {
        public AuxiliaryUserType()
        {
            AuxiliaryUser = new HashSet<AuxiliaryUser>();
        }

        public int Id { get; set; }
        public string Description { get; set; }

        public ICollection<AuxiliaryUser> AuxiliaryUser { get; set; }
    }
}
