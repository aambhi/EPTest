﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class ProjectJob
    {
        public ProjectJob()
        {
            AuxiliaryUserAssigned = new HashSet<AuxiliaryUserAssigned>();
            JobAudition = new HashSet<JobAudition>();
            JobShareDetail = new HashSet<JobShareDetail>();
            JobShareViewDetail = new HashSet<JobShareViewDetail>();


            JobTalentRecommended = new HashSet<JobTalentRecommended>();
            ProjectJobBodytype = new HashSet<ProjectJobBodytype>();
            ProjectJobEthnicity = new HashSet<ProjectJobEthnicity>();
            ProjectJobEyecolor = new HashSet<ProjectJobEyeColor>();
            ProjectJobHairColor = new HashSet<ProjectJobHairColor>();
            ProjectJobKeywordTag = new HashSet<ProjectJobKeywordTag>();
            ProjectJobLanguage = new HashSet<ProjectJobLanguage>();
            ProjectJobLocation = new HashSet<ProjectJobLocation>();
            ProjectJobSkinColor = new HashSet<ProjectJobSkinColor>();
            ProjectJobSubTalent = new HashSet<ProjectJobSubTalent>();
            ProjectJobTag = new HashSet<ProjectJobTag>();
            TalentJob = new HashSet<TalentJob>();
            TalentJobHistory = new HashSet<TalentJobHistory>();
            UserNotification = new HashSet<UserNotification>();
            Message = new HashSet<Message>();
            JobMedia = new HashSet<JobMedia>();
            JobAudition = new HashSet<JobAudition>();
            JobNotes = new HashSet<JobNotes>();
            ProjectJobStatusHistory = new HashSet<ProjectJobStatusHistory>();
            ProjectJobHistory = new HashSet<ProjectJobHistory>();
        }

        public short? NumberOfRole { get; set; }
        public string ColloaboratorComments { get; set; }
        public string Token { get; set; }

        public virtual ICollection<AuxiliaryUserAssigned> AuxiliaryUserAssigned { get; set; }

        public virtual ICollection<JobShareDetail> JobShareDetail { get; set; }
        public virtual ICollection<JobShareViewDetail> JobShareViewDetail { get; set; }


        public int Id { get; set; }
        public int ProjectId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Gender { get; set; }
        public int? TalentCategoryId { get; set; }
        public int? InterestCategoryId { get; set; }
        public string CharacterDescription { get; set; }
        public string RoleType { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? InternalEndDate { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string ReferenceMedia { get; set; }
        public int? MinAge { get; set; }
        public int? MaxAge { get; set; }
        public int? MinHeightId { get; set; }
        public int? MaxHeightId { get; set; }
        public int? MinWeightId { get; set; }
        public int? MaxWeightId { get; set; }
        public int? HairLengthId { get; set; }
        public int? HairTypeId { get; set; }
        public int? MinWaistSizeId { get; set; }
        public int? MinChestSizeId { get; set; }
        public int? MaxWaistSizeId { get; set; }
        public int? MaxChestSizeId { get; set; }
        public int? StatusId { get; set; }
        public bool? CastRequired { get; set; }
        public int? NationalityId { get; set; }
        public bool? ExperienceRequired { get; set; }
        public int? MinBudget { get; set; }
        public int? MaxBudget { get; set; }
        public bool? IntrovideoRequired { get; set; }
        public bool? HeadshotRequired { get; set; }
        public bool? SideprofileRequired { get; set; }
        public bool? AssociationRequired { get; set; }
        public bool? PassportRequired { get; set; }
        public string Keywords { get; set; }
        public int? MediaFiletypeId { get; set; }
        public bool? IsFeaturedJob { get; set; }
        
        public Project Project { get; set; }
        public virtual InterestCategory InterestCategory { get; set; }
        public virtual TalentCategory JobTalentCategory { get; set; }
        public virtual HairLength HairLength { get; set; }
        public virtual HairType HairType { get; set; }
        public virtual Height MinHeight { get; set; }
        public virtual Height MaxHeight { get; set; }
        public virtual Weight MinWeight { get; set; }
        public virtual Weight MaxWeight { get; set; }
        public virtual ChestSize MinChestSize { get; set; }
        public virtual ChestSize MaxChestSize { get; set; }
        public virtual WaistSize MinWaistSize { get; set; }
        public virtual WaistSize MaxWaistSize { get; set; }
        public virtual FileType JobMediaFiletype { get; set; }
        public virtual Country JobNationality { get; set; }
        public ProjectJobStatus Status { get; set; }

        public virtual ICollection<JobTalentRecommended> JobTalentRecommended { get; set; }
        public virtual ICollection<ProjectJobBodytype> ProjectJobBodytype { get; set; }
        public virtual ICollection<ProjectJobEthnicity> ProjectJobEthnicity { get; set; }
        public virtual ICollection<ProjectJobEyeColor> ProjectJobEyecolor { get; set; }
        public virtual ICollection<ProjectJobHairColor> ProjectJobHairColor { get; set; }
        public virtual ICollection<ProjectJobKeywordTag> ProjectJobKeywordTag { get; set; }
        public virtual ICollection<ProjectJobLanguage> ProjectJobLanguage { get; set; }
        public virtual ICollection<ProjectJobLocation> ProjectJobLocation { get; set; }
        public virtual ICollection<ProjectJobSkinColor> ProjectJobSkinColor { get; set; }
        public virtual ICollection<ProjectJobSubTalent> ProjectJobSubTalent { get; set; }
        public virtual ICollection<ProjectJobTag> ProjectJobTag { get; set; }
        public virtual ICollection<TalentJob> TalentJob { get; set; }
        public virtual ICollection<TalentJobHistory> TalentJobHistory { get; set; }

        public virtual ICollection<UserNotification> UserNotification { get; set; }
        public virtual ICollection<Message> Message { get; set; }
        public virtual ICollection<JobMedia> JobMedia { get; set; }
        public virtual ICollection<JobAudition> JobAudition { get; set; }
        public virtual ICollection<JobNotes> JobNotes { get; set; }

        public virtual ICollection<ProjectJobStatusHistory> ProjectJobStatusHistory { get; set; }
        public virtual ICollection<ProjectJobHistory> ProjectJobHistory { get; set; }
    }
}
