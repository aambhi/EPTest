﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class JobAudition
    {
        public JobAudition()
        {
            JobAuditionTalent = new HashSet<JobAuditionTalent>();
            JobMedia = new HashSet<JobMedia>();
            TalentJobHistory = new HashSet<TalentJobHistory>();
            MoveToAudition = new HashSet<JobAuditionTalent>();
            
        }

        public int Id { get; set; }
        public int JobId { get; set; }
        public string Brief { get; set; }
        public string Instruction { get; set; }
        public string ReferenceMedia { get; set; }
        public string Address { get; set; }
        public short? AuditionTypeId { get; set; }
        public short? RoundNumber { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public TimeSpan? StartTime { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public TimeSpan? EndTime { get; set; }

        public virtual ICollection<JobAuditionTalent> JobAuditionTalent { get; set; }
        public virtual ICollection<JobAuditionTalent> MoveToAudition { get; set; }
        public virtual ICollection<JobMedia> JobMedia { get; set; }
        public virtual AuditionType AuditionType { get; set; }
        public virtual ProjectJob Job { get; set; }
        public virtual ICollection<TalentJobHistory> TalentJobHistory { get; set; }
    }
}
