﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class SocialLink
    {
        public SocialLink()
        {
            TalentSocialLink = new HashSet<TalentSocialLink>();
            TalentSocialLink = new HashSet<TalentSocialLink>();
        }

        public short Id { get; set; }
        public string Description { get; set; }
        public string IconImage { get; set; }

        public bool IsTalentRelated { get; set; }
        public bool IsAuxiliaryUserRelated { get; set; }

        public virtual ICollection<TalentSocialLink> TalentSocialLink { get; set; }

        public virtual ICollection<AuxiliaryUserSocialLink> AuxiliaryUserSocialLink { get; set; }
    }
}
