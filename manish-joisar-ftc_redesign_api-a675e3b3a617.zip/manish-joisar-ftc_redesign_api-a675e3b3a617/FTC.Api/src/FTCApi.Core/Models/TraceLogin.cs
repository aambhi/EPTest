﻿using System;

namespace FTCApi.Core.Models
{
    public class TraceLogin
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public DateTime? LogiinTime { get; set; }
        public DateTime? LogoutTime { get; set; }
        public string IpAddress { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Region { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Talent Talent { get; set; }
    }
}
