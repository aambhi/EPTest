﻿using System;

namespace FTCApi.Core.Models
{
    public class WhitelistExclude
    {
        public int Id { get; set; }
        public int? AuxiliaryUserId { get; set; }
        public int? StatusId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
        public virtual Status Status { get; set; }
    }
}
