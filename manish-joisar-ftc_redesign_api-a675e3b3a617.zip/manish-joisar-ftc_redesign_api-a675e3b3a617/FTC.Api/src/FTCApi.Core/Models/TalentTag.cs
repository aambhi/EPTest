﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentTag
    {
        public int Id { get; set; }
        public int TalentId { get; set; }
        public int TagId { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual AuxiliaryUser CreatedByNavigation { get; set; }
        public virtual Tag Tag { get; set; }
        public virtual Talent Talent { get; set; }
        public virtual AuxiliaryUser UpdatedByNavigation { get; set; }
    }
}
