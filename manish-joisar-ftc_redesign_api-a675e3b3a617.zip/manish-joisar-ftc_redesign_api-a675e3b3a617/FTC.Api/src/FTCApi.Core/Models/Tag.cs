﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Tag
    {
        public Tag()
        {
            ProjectJobTag = new HashSet<ProjectJobTag>();
            TalentTag = new HashSet<TalentTag>();
            ProjectJobKeywordTag = new HashSet<ProjectJobKeywordTag>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public int TagCategoryId { get; set; }

        public ICollection<ProjectJobTag> ProjectJobTag { get; set; }
        public ICollection<TalentTag> TalentTag { get; set; }
        public TagCategory TagCategory { get; set; }

        public virtual ICollection<ProjectJobKeywordTag> ProjectJobKeywordTag { get; set; }
    }
}
