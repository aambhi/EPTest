﻿namespace FTCApi.Core.Models
{
    public class ProjectJobEthnicity
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? EthnicityId { get; set; }

        public virtual Ethnicity Ethnicity { get; set; }
        public virtual ProjectJob ProjectJob { get; set; }
    }
}
