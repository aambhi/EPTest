﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class EyeColor
    {
        public EyeColor()
        {
            ProjectJobEyecolor = new HashSet<ProjectJobEyeColor>();
        }
        public int Id { get; set; }
        public string Description { get; set; }
        public string RGB { get; set; }
        public string Status { get; set; }

        public virtual ICollection<ProjectJobEyeColor> ProjectJobEyecolor { get; set; }
        
    }
}
