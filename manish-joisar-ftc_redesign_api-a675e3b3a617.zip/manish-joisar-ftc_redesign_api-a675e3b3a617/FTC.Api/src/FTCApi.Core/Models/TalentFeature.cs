﻿using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class TalentFeature
    {
        public TalentFeature()
        {
            TalentPlanFeature = new HashSet<TalentPlanFeature>();
        }

        public short Id { get; set; }
        public string Desc { get; set; }
        public int ImageCount { get; set; }
        public int VideoCount { get; set; }
        public int AudioCount { get; set; }
        public int ScriptCount { get; set; }

        public virtual ICollection<TalentPlanFeature> TalentPlanFeature { get; set; }
    }
}
