﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentExperience
    {
        public int Id { get; set; }
        public int? InterestCategoryId { get; set; }
        public int? TalentCategoryId { get; set; }
        public string ProjectTitle { get; set; }
        public string Role { get; set; }
        public int? Year { get; set; }
        public int? TalentId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public string ProductionHouse { get; set; }
        public int? SubTalentCategoryId { get; set; }
        public int? ProductionHouseId { get; set; }

        public virtual InterestCategory InterestCategory { get; set; }
        public virtual TalentCategory TalentCategory { get; set; }
        public virtual TalentCategory SubTalentCategory { get; set; }

        public virtual Talent Talent { get; set; }
        public virtual ProductionHouse ProductionHouseNavigation { get; set; }

    }
}
