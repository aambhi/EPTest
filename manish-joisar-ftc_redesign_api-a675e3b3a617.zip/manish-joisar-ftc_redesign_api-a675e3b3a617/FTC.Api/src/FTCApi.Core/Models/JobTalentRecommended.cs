﻿using System;

namespace FTCApi.Core.Models
{
    public class JobTalentRecommended
    {
        public int Id { get; set; }
        public int? JobId { get; set; }
        public int? TalentId { get; set; }
        public short? Order { get; set; }
        public bool? Invited { get; set; }

        public bool? InvitationDeclined { get; set; }

        public short? SortOrderTypeId { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? CreatedOn { get; set; }

        public virtual ProjectJob Job { get; set; }
        public virtual Talent Talent { get; set; }
        public virtual MstSortOrderType SortOrderType { get; set; }
        public virtual AuxiliaryUser CreatedByNavigation { get; set; }

    }
}
