﻿namespace FTCApi.Core.Models
{
    public class Param
    {
        public int Id { get; set; }
        public int ImageCount { get; set; }
        public int VideoCount { get; set; }
        public int AudioCount { get; set; }
        public int ScriptCount { get; set; }
        public bool IsProfilePicRequired { get; set; }
        public int PostLoginRoute { get; set; }

        public int TalentRatingWeightage { get; set; }
        public int ParameterRatingWeightage { get; set; }
        public int FtcRatingWeightage { get; set; }
        public int RecruiterRatingWeightage { get; set; }
        
    }
}
