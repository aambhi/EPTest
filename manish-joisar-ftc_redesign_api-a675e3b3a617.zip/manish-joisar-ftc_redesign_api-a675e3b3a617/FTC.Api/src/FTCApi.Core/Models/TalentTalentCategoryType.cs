﻿namespace FTCApi.Core.Models
{
    public class TalentTalentCategoryType
    {
        public int? TalentCategoryId { get; set; }

        public string Description { get; set; }
     
    }
}
