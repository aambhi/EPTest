﻿using System;

namespace FTCApi.Core.Models
{
    public class TalentCalendar
    {
        public int Id { get; set; }
        public int? TalentId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? FromDateTime { get; set; }
        public DateTime? ToDateTime { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public Talent Talent { get; set; }
    }
}
