﻿namespace FTCApi.Core.Models
{
    public class AuxiliaryUserAssociation
    {
        public int AuxiliaryUserId { get; set; }
        public int AssociationId { get; set; }
        public string MembershipId { get; set; }

        public virtual Association Association { get; set; }
        public virtual AuxiliaryUser AuxiliaryUser { get; set; }
    }
}
