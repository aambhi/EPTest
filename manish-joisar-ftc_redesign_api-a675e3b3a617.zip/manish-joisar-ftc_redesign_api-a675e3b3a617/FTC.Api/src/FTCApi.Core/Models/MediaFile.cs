﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class MediaFile
    {
        public MediaFile()
        {
            ContestSubmissionMedia = new HashSet<ContestSubmissionMedia>();
            ProjectMedia = new HashSet<ProjectMedia>();
            TalentMedia = new HashSet<TalentMedia>();
            JobMedia = new HashSet<JobMedia>();
        }

        public int Id { get; set; }
        public int? FileTypeId { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileMimeType { get; set; }
        
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }

        public int? StatusId { get; set; }

        public bool? IsExternalUrl { get; set; }

        public ICollection<TalentMedia> TalentMedia { get; set; }
        public FileType FileType { get; set; }

        public Status Status { get; set; }

        public virtual ICollection<ProjectMedia> ProjectMedia { get; set; }

        public virtual ICollection<ContestSubmissionMedia> ContestSubmissionMedia { get; set; }
        public virtual ICollection<JobMedia> JobMedia { get; set; }
    }
}
