﻿using System;
using System.Collections.Generic;

namespace FTCApi.Core.Models
{
    public class Talent
    {
        public Talent()
        {
            ContestSubmission = new HashSet<ContestSubmission>();
            TalentAddress = new HashSet<TalentAddress>();
            TalentEthnicity = new HashSet<TalentEthnicity>();
            TalentInterestCategory = new HashSet<TalentInterestCategory>();
            TalentJob = new HashSet<TalentJob>();
            TalentLanguage = new HashSet<TalentLanguage>();
            TalentMedia = new HashSet<TalentMedia>();
            TalentTag = new HashSet<TalentTag>();
            TalentTalentCategory = new HashSet<TalentTalentCategory>();
            TalentToken = new HashSet<TalentToken>();
            TalentAssociation = new HashSet<TalentAssociation>();
            TalentCalendar = new HashSet<TalentCalendar>();
            TalentShareDetail = new HashSet<TalentShareDetail>();
            TalentEducation = new HashSet<TalentEducation>();
            TalentSocialLink = new HashSet<TalentSocialLink>();
            TalentExperience = new HashSet<TalentExperience>();
            TalentTransaction = new HashSet<TalentTransaction>();
            TalentRatingParameter = new HashSet<TalentRatingParameter>();
            TalentRatingInterestCategory = new HashSet<TalentRatingInterestCategory>();
            TalentRatingRmark = new HashSet<TalentRatingRmark>();
            TalentRatingTalentCategory = new HashSet<TalentRatingTalentCategory>();
            RazorPayStaging = new HashSet<RazorPayStaging>();
            JobTalentRecommended = new HashSet<JobTalentRecommended>();
            TalentJobHistory = new HashSet<TalentJobHistory>();
            UserNotification = new HashSet<UserNotification>();
            MessageMesFromTalent = new HashSet<Message>();
            MessageMesToTalent = new HashSet<Message>();
            JobMedia = new HashSet<JobMedia>();
            JobAuditionTalent = new HashSet<JobAuditionTalent>();
            TraceActivity = new HashSet<TraceActivity>();
            TraceLogin = new HashSet<TraceLogin>();
            JobNotes = new HashSet<JobNotes>();
            TalentStatusHistory = new HashSet<TalentStatusHistory>();
            TraceSmsGateway = new HashSet<TraceSmsGateway>();
            TalentSpecialHost = new HashSet<TalentSpecialHost>();
            TraceEmailGateway = new HashSet<TraceEmailGateway>();
        }

        public int Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Gender { get; set; }
        public DateTime? DOB { get; set; }
        public string MobileCountryCode { get; set; }
        public string Mobile { get; set; }
        public short TierId { get; set; }
        public int? UID { get; set; }
        public string WhatsupMobile { get; set; }
        public string GuardianName { get; set; }
        public string GuardianRelation { get; set; }
        public string GuardianMobile { get; set; }
        public string GuardianEmailId { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string WhatsupCountryCode { get; set; }
        public string AuthToken { get; set; }
        public bool? Onboarded { get; set; }
        public short? LastTabNo { get; set; }
        public int? CompletionPercentage { get; set; }
        public bool? TermsConditionAccepted { get; set; }
        public int? StatusId { get; set; }
        public int? PassportCountryId { get; set; }
        public int? RecruiterRatingCount { get; set; }
        public DateTime? PassportExpirationDate { get; set; }
        public string VisaType { get; set; }
        public string VisaYear { get; set; }
        public int? AgencyId { get; set; }
        public DateTime? AgencyStartDate { get; set; }
        public DateTime? AgencyEndDate { get; set; }
        public string AgencyAgentName { get; set; }
        public string AgencyAgentMobileNo { get; set; }
        public string AgencyAgentEmail { get; set; }
        public int? BudgetMin { get; set; }
        public int? BudgetMax { get; set; }
        public string AboutMe { get; set; }
        public int? ViewCount { get; set; }
        public string SharedProfileName { get; set; }
        public string TalentProfileURL { get; set; }
        public float? FtcRating { get; set; }
        public float? OverallRating { get; set; }

        public float? RecruiterRating { get; set; }
        public float? InterestRating { get; set; }
        public string RatingNotes { get; set; }

        public bool? IsProfilePrivate { get; set; }

        public short? DeviceOsId { get; set; }
        public string DeviceRegistrationId { get; set; }

        public int? MobileCountryId { get; set; }
        public int? WhatsupCountryId { get; set; }

        public virtual ICollection<TraceSmsGateway> TraceSmsGateway { get; set; }

        public TalentPhysicalAttribute TalentPhysicalAttribute { get; set; }
        public ICollection<TalentAddress> TalentAddress { get; set; }
        public ICollection<TalentEthnicity> TalentEthnicity { get; set; }
        public ICollection<TalentInterestCategory> TalentInterestCategory { get; set; }
        public ICollection<TalentJob> TalentJob { get; set; }
        public ICollection<TalentLanguage> TalentLanguage { get; set; }
        public ICollection<TalentMedia> TalentMedia { get; set; }
        public ICollection<TalentTag> TalentTag { get; set; }
        public ICollection<TalentTalentCategory> TalentTalentCategory { get; set; }
        public ICollection<TalentToken> TalentToken { get; set; }
        public ICollection<TalentCalendar> TalentCalendar { get; set; }
        public virtual ICollection<TalentShareDetail> TalentShareDetail { get; set; }
        public virtual ICollection<TalentAssociation> TalentAssociation { get; set; }
        public virtual Status Status { get; set; }
        public virtual ICollection<TalentExperience> TalentExperience { get; set; }
        public virtual ICollection<TalentSocialLink> TalentSocialLink { get; set; }
        public virtual ICollection<TalentEducation> TalentEducation { get; set; }

        public virtual ICollection<TalentTransaction> TalentTransaction { get; set; }
        public virtual ICollection<ContestSubmission> ContestSubmission { get; set; }

        public virtual ICollection<TalentRatingParameter> TalentRatingParameter { get; set; }

        public virtual ICollection<TalentRatingInterestCategory> TalentRatingInterestCategory { get; set; }

        public virtual ICollection<TalentRatingRmark> TalentRatingRmark { get; set; }

        public virtual ICollection<TalentRatingTalentCategory> TalentRatingTalentCategory { get; set; }

        public virtual ICollection<RazorPayStaging> RazorPayStaging { get; set; }
        public virtual ICollection<JobTalentRecommended> JobTalentRecommended { get; set; }
        public virtual ICollection<TalentJobHistory> TalentJobHistory { get; set; }
        public virtual ICollection<UserNotification> UserNotification { get; set; }
        public virtual ICollection<Message> MessageMesFromTalent { get; set; }
        public virtual ICollection<Message> MessageMesToTalent { get; set; }
        public virtual ICollection<JobMedia> JobMedia { get; set; }
        public virtual ICollection<JobAuditionTalent> JobAuditionTalent { get; set; }
        public virtual ICollection<JobNotes> JobNotes { get; set; }
        public virtual MstDeviceOs TalentDeviceOs { get; set; }
        public virtual MstTier Tier { get; set; }
        public virtual ICollection<TraceActivity> TraceActivity { get; set; }
        public virtual ICollection<TraceLogin> TraceLogin { get; set; }

        public virtual Country TalentMobileCountry { get; set; }
        public virtual Country TalentWhatsupCountry { get; set; }

        public virtual ICollection<TalentStatusHistory> TalentStatusHistory { get; set; }
        public virtual ICollection<TraceEmailGateway> TraceEmailGateway { get; set; }
        public virtual ICollection<TalentSpecialHost> TalentSpecialHost { get; set; }
    }
}
