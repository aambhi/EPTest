﻿namespace FTCApi.Core.Enums
{
    public enum MstSortOrderTypeEnum
    {
        PushByAdmin = 5,
        Recommended = 10,
        RMark = 15,
        Applied = 100
    }
}
