﻿namespace FTCApi.Core.Enums
{
    public enum RecruiterPlanEnum
    {
        Free = 1,
        Basic,
        Pro
    }
}