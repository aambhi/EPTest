﻿namespace FTCApi.Core.Enums
{
    public enum JobSearchType
    {
        All,
        Applied,
        Matching
    }
}