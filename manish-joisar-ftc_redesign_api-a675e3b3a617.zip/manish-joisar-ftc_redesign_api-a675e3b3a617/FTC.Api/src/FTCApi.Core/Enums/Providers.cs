﻿namespace FTCApi.Core.Enums
{
    public enum Providers
    {
        TATASKY=19,
        DEFAULT=20,
        ZEETV
    }

    public enum SMSGatways
    {
        PHONON = 1,
        TWILIO = 2,        
    }
}
