﻿namespace FTCApi.Core.Enums
{
    public enum UserRole
    {
        SystemAdmin = 1,
        RecruiterAdmin,
        ProjectAdmin,
        JobAdmin,
        TalentAdmin,
        Recruiter,
        SuperAdmin,
        FTCProjectAdmin
    }
}
