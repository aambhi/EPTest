﻿namespace FTCApi.Core.Enums
{
    public enum StatusCode
    {
        Writtenoff,
        Deactivated,
        Cancelled,
        TempSuspension,
        Blacklisted,
        Success,
        NotValidSubId,
        NoPkgDetails,
        SubsciberIdAlreadyInUse,
        Error
    }
}