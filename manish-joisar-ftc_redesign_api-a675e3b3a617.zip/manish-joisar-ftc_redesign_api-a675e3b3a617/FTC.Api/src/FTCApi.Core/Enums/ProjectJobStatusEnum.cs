﻿namespace FTCApi.Core.Enums
{
    public enum ProjectJobStatusEnum
    {
        UnderReview = 1,
        NotSelected = 2,
        SelectedForAudition = 3,
        Shortlisted = 4,
        Cast = 5,
        Invited = 6,
        MoveToLastAuditionStage = 7,
        MoveToUnderReview = 8,
        MoveToShortListed = 9,
        MoveToCasted = 10
    }

    public enum CollabratorFeedbackEnum
    {
        None = 0,
        Yes = 1,
        No = 2
    }
}