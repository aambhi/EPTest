﻿namespace FTCApi.Core.Enums
{
    public enum EndpointType
    {
        RMN,
        SUBSCRIPTION,
        ENDPOINT
    }
}
