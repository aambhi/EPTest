﻿namespace FTCApi.Core.Enums
{
    public enum TransactionTypeEnum
    {
        Buy = 1,
        Upgrade = 2,
        Renewal = 3
    }
}
