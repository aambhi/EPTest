﻿namespace FTCApi.Core.Enums
{
    public enum TalentFeatures
    {
        MediaHosting =1,
        Profileanalysisrecommendation,
        PersonalPortfolio
    }
}
