﻿namespace FTCApi.Core.Enums
{
    public enum SortOrder
    {
        Ascending,
        Descending
    }
}