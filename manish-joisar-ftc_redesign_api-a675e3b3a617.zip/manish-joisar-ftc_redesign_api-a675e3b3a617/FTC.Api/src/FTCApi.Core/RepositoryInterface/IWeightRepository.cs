﻿using FTCApi.Core.Models;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IWeightRepository:IGenericRepository<Weight>
    {
    }
}
