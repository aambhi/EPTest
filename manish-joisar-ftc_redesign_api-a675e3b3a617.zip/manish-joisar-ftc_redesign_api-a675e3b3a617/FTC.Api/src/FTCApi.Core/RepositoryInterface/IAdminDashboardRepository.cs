﻿using FTCApi.Core.Models;
using FTCApi.Dtos.DashboardDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IAdminDashboardRepository : IGenericRepository<Talent>
    {
        Task<ContestStatsDto> GetContestStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin);
        Task<ProjectJobStatsDto> GetProjectJobStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin);
        Task<ProjectStatsDto> GetProjectStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin);
        Task<RecruiterStatsDto> GetRecruiterStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin);
        Task<TalentStatsDto> GetTalentStats();
    }
}
