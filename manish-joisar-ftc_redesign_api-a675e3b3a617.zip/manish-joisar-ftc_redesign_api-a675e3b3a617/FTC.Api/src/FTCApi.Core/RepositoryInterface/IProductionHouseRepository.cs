﻿using FTCApi.Core.Models;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IProductionHouseRepository : IGenericRepository<ProductionHouse>
    {
    }
}