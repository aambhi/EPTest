﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IGenericRepository<T>
    {
        IEnumerable<T> GetAll();

        Task<IEnumerable<T>> GetAllAsync();

        //T Get(int id);

        Task<T> GetAsync(int id);

        T Find(Expression<Func<T, bool>> match);

        Task<T> FindAsync(Expression<Func<T, bool>> match);

        IEnumerable<T> FindAll(Expression<Func<T, bool>> match);

        Task<IEnumerable<T>> FindAllAsync(Expression<Func<T, bool>> match);

        T Add(T t);

        Task<T> AddAsync(T t);

        T Update(T updated);

        Task<T> UpdateAsync(T updated);

        void Delete(T t);

        void RemoveRange(IEnumerable<T> t);

        Task<int> DeleteAsync(T t);

        int Count();

        Task<int> CountAsync();

        Task<int> MaxAsync(Expression<Func<T, int>> match);
    }
}