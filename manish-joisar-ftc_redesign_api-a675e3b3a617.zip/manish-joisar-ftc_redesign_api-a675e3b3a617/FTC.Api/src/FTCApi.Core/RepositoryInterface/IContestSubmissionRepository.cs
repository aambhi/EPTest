﻿using FTCApi.Core.Models;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IContestSubmissionRepository : IGenericRepository<ContestSubmission>
    {
        Task<SearchResult<ContestSubmission>> GetContestSubmissionByType(SearchParameters searchParams, int contestId, string submissionType);
    }
}
