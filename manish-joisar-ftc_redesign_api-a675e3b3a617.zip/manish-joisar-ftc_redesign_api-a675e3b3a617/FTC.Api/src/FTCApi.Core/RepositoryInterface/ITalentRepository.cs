﻿using FTCApi.Core.Models;
using FTCApi.Core.Models.Report;
using FTCApi.Dtos;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ITalentRepository:IGenericRepository<Talent>
    {
        bool ValidateUser(string enteredPassword, string actualPassword);

        Task<TalentRatings> GetTalentRatings(int talentId);
        Task<List<KeyValueDto>> GetTalentRatio();
        Task<List<KeyValueDto>> GetInterestRatio();
        Task<List<KeyValueDto>> GetGenderCount();
        Task<List<KeyValueDto>> GetCountryCount();

        Task<TalentRatingRmarks> GetTalentRmark(int talentId);

        Task<bool> UpdateRatings(TalentRatings talentRatings, int userId);

        Task<bool> UpdateTalentRMark(TalentRatingRmarks talentRatings, int userId);

        Task<SearchResult<Talent>> Search(SearchParameters searchParams, string ConditionType, int userId);

        Task<object> TalentDataReport(SearchParameters searchParams, int userId);

        Task<IQueryable<TalentCsvModel>> TalentDataReportByModel(SearchParameters searchParams, int userId);
    }
}
