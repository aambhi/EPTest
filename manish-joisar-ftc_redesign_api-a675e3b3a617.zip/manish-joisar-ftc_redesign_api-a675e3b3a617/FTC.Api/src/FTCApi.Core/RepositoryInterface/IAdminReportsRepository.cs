﻿using FTCApi.Core.Models;
using FTCApi.Dtos.AdminReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IAdminReportsRepository
    {
        //Task<List<Talent>> GetNewTalents(DailyStats requestParam);
        Task<List<TalentDailyStatsDto>> GetNewTalents(DailyStats requestParam);
    }
}
