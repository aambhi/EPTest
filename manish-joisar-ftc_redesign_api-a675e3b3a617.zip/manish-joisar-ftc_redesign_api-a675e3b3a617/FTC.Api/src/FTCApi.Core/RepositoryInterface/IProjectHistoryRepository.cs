﻿using FTCApi.Core.Models;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IProjectHistoryRepository : IGenericRepository<ProjectHistory>
    {
        int getTotalRenewedMonths(int projectId);
    }
}
