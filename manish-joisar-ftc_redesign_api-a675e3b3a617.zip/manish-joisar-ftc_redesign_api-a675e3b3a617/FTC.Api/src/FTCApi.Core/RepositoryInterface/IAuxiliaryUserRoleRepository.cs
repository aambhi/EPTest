﻿using FTCApi.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IAuxiliaryUserRoleRepository:IGenericRepository<AuxiliaryUserRole>
    {
        Task<bool> CheckAssignedInRole(int userId);
        void CheckUserRole(IEnumerable<AuxiliaryUserRole> userRole, out bool isProjectAdmin, out bool isJobAdmin, out bool isFtcProjectAdmin);
        void CheckUserRole(IEnumerable<AuxiliaryUserRole> userRole, out bool isFtcRecruiterAdmin);
    }
}
