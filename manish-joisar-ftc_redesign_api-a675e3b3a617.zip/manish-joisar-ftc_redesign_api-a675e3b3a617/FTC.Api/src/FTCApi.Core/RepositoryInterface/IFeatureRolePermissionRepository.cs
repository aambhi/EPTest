﻿using FTCApi.Core.Models;
using FTCApi.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IFeatureRolePermissionRepository : IGenericRepository<FeatureRolePermission>
    {
        Task<List<Features>> GetPermissions(int? userId);
    }
}