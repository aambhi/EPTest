﻿using FTCApi.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IAuxiliaryUserAssignedRepository : IGenericRepository<AuxiliaryUserAssigned>
    {
        Task<List<int?>> GetAssignedRecruiters(int userId, bool? checkRole = false);
        Task<Dictionary<int?, bool>> GetAssignedProjects(int userId,int? selectedUserId = 0, bool? checkRole = false);
        Task<Dictionary<int?, bool>> GetAssignedProjectsForJobAmin(int loggedInUserId);
        Task<List<int?>> GetAssignedJobs(int userId, bool? checkRole = false);
    }
}
