﻿using FTCApi.Core.Models;
using FTCApi.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IRecruiterInfoRepository
    {
        Task<AuxiliaryUserDto> GetAuxiliaryUser(int recruiterId);

        Task<AuxiliaryRecruiterDto> GetAuxiliaryRecruiter(int recruiterId);

        Task<AuxiliaryUserDto> SaveAuxiliaryUser(int recruiterId, AuxiliaryUserDto auxiliaryUserDto);

        Task<AuxiliaryRecruiterDto> SaveAuxiliaryRecruiter(int recruiterId, AuxiliaryRecruiterDto auxiliaryRecruiterDto);

        Task<List<AuxiliaryUserExperienceDto>> GetAuxiliaryUserExperiences(int recruiterId);

        Task<List<AuxiliaryUserExperienceDto>> SaveAuxiliaryUserExperiences(int recruiterId, List<AuxiliaryUserExperienceDto> lstAuxiliaryUserExperienceDto);

        Task<List<AuxiliaryUserAwardDto>> GetAuxiliaryUserAwards(int recruiterId);

        Task<List<AuxiliaryUserAwardDto>> SaveAuxiliaryUserAwards(int recruiterId, List<AuxiliaryUserAwardDto> lstAuxiliaryUserAwardDto);

        Task<List<AuxiliaryUserSocialLinkDto>> GetAuxiliaryUserSocialLinks(int recruiterId);

        Task<List<AuxiliaryUserSocialLinkDto>> SaveAuxiliarySocialLinks(int recruiterId, List<AuxiliaryUserSocialLinkDto> lstAuxiliaryUserSocialLinkDto);

        Task<List<AuxiliaryUserAssociationDto>> GetAuxiliaryUserAssociations(int recruiterId);

        Task<List<AuxiliaryUserAssociationDto>> SaveAuxiliaryUserAssociations(int recruiterId, List<AuxiliaryUserAssociationDto> lstAuxiliaryUserAssociationDto);

        Task<List<AuxiliarySecurityQuestionDto>> GetAuxiliarySecurityQuestions(int recruiterId);

        Task<List<AuxiliarySecurityQuestionDto>> SaveAuxiliarySecurityQuestions(int recruiterId, List<AuxiliarySecurityQuestionDto> lstAuxiliarySecurityQuestionDto);

        Task<AuxiliaryUserDto> CreateRecruiter(int userId, AuxiliaryUserDto auxiliaryUserDto);

        Task GetAuxilaryUserCityCountryId(AuxiliaryUserDto auxiliaryUserDto, Address addressModel);

        string RandomString(int length);
    }
}