﻿using FTCApi.Core.Models;
using FTCApi.Dtos;
using FTCApi.Dtos.Projects;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IProjectRepository : IGenericRepository<Project>
    {
        Task<List<Project>> GetAllProjects();

        Task<ManageProjectDto> ManageProject(RequestManageProjectDto manageProjectParam, int recruiterId);

        Task<ProjectSummaryDto> ConvertToProjectSummaryDto(Project project, int projectId, int firstProjectId, List<ProjectJob> listOfProjectJob, int projectJobCount, Dictionary<int?, bool> assignedProjects);

        ProjectJobSummaryDto ConvertToProjectJobSummaryDto(ProjectJob projectJob);

        Task<dynamic> GetProjectByRecruiterId(int recruiterId, string projectName, int userId, int userType);

        Task<dynamic> SearchProjects(string projectName, int userId, int userType);
    }
}