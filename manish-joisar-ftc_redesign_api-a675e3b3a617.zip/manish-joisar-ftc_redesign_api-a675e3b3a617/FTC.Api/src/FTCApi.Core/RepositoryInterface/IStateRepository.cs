﻿namespace FTCApi.Core.RepositoryInterface
{
    //public interface IStateRepository:IGenericRepository<State>
    //{
    //}
}