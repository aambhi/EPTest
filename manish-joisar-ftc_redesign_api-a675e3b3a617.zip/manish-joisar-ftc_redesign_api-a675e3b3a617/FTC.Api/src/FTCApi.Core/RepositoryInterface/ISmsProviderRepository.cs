﻿using FTCApi.Core.Models;
using FTCApi.Dtos.Notification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ISmsProviderRepository : IGenericRepository<MstSmsGateway>
    {
        Task SendSMS(SMSGatewayParam smsGatewayParam);

        Task<TraceEmailGateway> TraceEmail(TraceEmailGateway traceEmailGateway);
    }
}
