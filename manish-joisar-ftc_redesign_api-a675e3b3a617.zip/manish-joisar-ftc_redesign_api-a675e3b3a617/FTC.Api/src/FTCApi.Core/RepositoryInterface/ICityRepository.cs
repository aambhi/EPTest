﻿using FTCApi.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ICityRepository:IGenericRepository<City>
    {
        Task<List<City>> GetCitiesWithCountry();
    }
}
