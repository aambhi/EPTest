﻿using FTCApi.Core.Models;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IBodyTypeRepository:IGenericRepository<BodyType>
    {
    }
}
