﻿using FTCApi.Core.Models;
using FTCApi.Dtos;
using FTCApi.Dtos.SpecialHost;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ITalentInfoRepository
    {
        Task<List<TalentMediaDto>> GetTalentMedias(int talentId);
        Task<TalentMediaDto> ConvertToTalentMediaDto(int talentId, TalentMedia talentMedia);
        Task<List<TalentTalentCategoryDto>> GetTalentTalentCategories(int talentId);
        Task<TalentTalentCategoryDto> ConvertToTalentTalentCategoryDto(TalentTalentCategory talentTalentCategory);
        Task<TalentDto> GetPersonalDetails(int talentId);

        Task<TalentDto> ConvertToTalentDto(Talent talent);

        Task<List<TalentInterestCategoryDto>> GetInterestDetails(int talentId);

        Task<TalentInterestCategoryDto> ConvertToTalentInterestCategoryDto(TalentInterestCategory talentInterestCategory);
        Task<TalentDto> SavePersonalDetail(TalentDto talentDto);
        Task<List<TalentTalentCategoryDto>> SaveTalentTalentCategory(int talentId, List<TalentTalentCategoryDto> lstTalentCategoryDto);
        Task<List<TalentInterestCategoryDto>> SaveTalentInterestCategory(int talentId, List<TalentInterestCategoryDto> lstTalentInterestCategoriesDto);
        Task<List<TalentMediaDto>> SaveTalentMedia(int talentId, List<TalentMediaDto> lstTalentMediaDto);
        Task<PhysicalAttributesDto> SaveTalentPhysicalAttribute(int talentId, PhysicalAttributesDto physicalAttributesDto);
        Talent ConvertToTalentModel(Talent talent, TalentDto talentDto);
        TalentTalentCategory ConvertToTalentCategoryModel(int talentId, TalentTalentCategoryDto talentCategoryDto);
        TalentInterestCategory ConvertToTalentInterestCategoryModel(int talentId, TalentInterestCategoryDto talentInterestCategoryDto);
        TalentMedia ConvertToTalentMediaModel(int talentId, TalentMediaDto talentMediaDto);

        Task<PhysicalAttributesDto> GetPhysicalAttributes(int talentId);
        Task<TalentAddressDto> GetTalentAddressDetails(int talentId);
        Task<List<TalentLanguageDto>> GetTalentLanguages(int talentId);
        Task<List<TalentTagDto>> GetTalentTags(int talentId);
        Task<List<TalentEthnicityDto>> GetTalentEthnicity(int talentId);

        Task<List<TalentEducationDto>> GetTalentEducation(int talentId);

        Task<List<TalentTagDto>> SaveTalentTags(int talentId, List<TalentTagDto> lstTalentTagDto);
        Task<List<TalentLanguageDto>> SaveTalentLanguages(int talentId, List<TalentLanguageDto> lstTalentLanguageDto);

        Task<List<TalentEthnicityDto>> SaveTalentEthnicities(int talentId, List<TalentEthnicityDto> lstTalentEthnicityDto);
        Task<List<TalentExperienceDto>> SaveTalentExperiences(int talentId, List<TalentExperienceDto> lstTalentExperienceDto);
        Task<List<TalentEducationDto>> SaveTalentEducation(int talentId, List<TalentEducationDto> lstTalentEducationDto);
        Task<List<TalentExperienceDto>> GetTalentExperience(int talentId);
        Task<List<TalentAssociationDto>> GetTalentAssociations(int talentId);
        Task<List<TalentAssociationDto>> SaveTalentAssociation(int talentId, List<TalentAssociationDto> lstTalentAssociationDto);
        Task<List<TalentSecurityQuestionDto>> SaveTalentSecurityQuestion(int talentId, List<TalentSecurityQuestionDto> lstTalentSecurityQuestionDto);
        Task<List<TalentSecurityQuestionDto>> GetTalentSecurityQuestions(int talentId);
        Task<TalentAddressDto> SaveTalentAddress(int talentId, TalentAddressDto talentAddressDto);

        Task<List<TalentSocialLinkDto>> GetTalentSocialLink(int talentId);
        Task<string> GetAgencyName(int? agencyId);
        Task<bool> CheckMobileVerified(int talentId);

        Task<int?> CalculatePercentageCompleted(int talentId, TalentInfoDto talentInfoDto);
        Task<List<TalentMediaDto>> GetTalentMediasBySubscription(int talentId);
        Task<Dictionary<string, int>> GetSubscribedMediaCount(int talentId);
        Task<List<TalentSpecialHostDto>> GetTalentSpecialHost(int talentId);
    }
}
