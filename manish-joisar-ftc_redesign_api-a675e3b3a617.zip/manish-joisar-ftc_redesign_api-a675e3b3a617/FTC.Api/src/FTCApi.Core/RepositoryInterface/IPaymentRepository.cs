﻿using FTCApi.Core.Models;
using FTCApi.Dtos.AdminReports;
using FTCApi.Dtos.PaymentDtos;
using Razorpay;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IPaymentRepository : IGenericRepository<TalentPlan>
    {
        Task<List<TalentPlanDto>> GetTalentPlans(int talentId);

        Task<Order> CreateOrder(Credentials credentials, int userId, Dictionary<string, object> data, int userType);

        Task<Payment> CapturePayment(Credentials credentials, PaymentRequest paymentRequest);

        Task<Payment> CaptureRecruiterPayment(Credentials credentials, PaymentRequest paymentRequest);

        Task<TalentPlan> SaveTalentPlan(PlanFeatureDto planFeatureDto, int userId);

        Task<List<TalentPlanFeature>> SaveTalentPlanFeatures(short talentPlanId, PlanFeatureDto planFeatureDto);

        Task<PaymentStatsReport> GetTalentTransactions(DailyStats requestParam, int? talentId = 0);

        Task<PaymentStatsReport> GetRecruiterTransactions(DailyStats requestParam);
    }
}