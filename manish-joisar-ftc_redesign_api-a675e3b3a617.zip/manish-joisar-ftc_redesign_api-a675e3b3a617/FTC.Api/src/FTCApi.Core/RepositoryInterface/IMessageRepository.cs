﻿using FTCApi.Core.Models;
using FTCApi.Dtos.ChatDtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IMessageRepository : IGenericRepository<Message>
    {
        Task<Job> GetTalentAdminMessagesAsync(int talentId);

        Task<Job> GetTalentMessagesAsync(int talentId, int jobId);

        Task<TalentMessages> GetTalentJobListAsync(int talentId);

        Task<Message> SendMessageAsync(MessageDto message);

        Task<Job> GetRecruiterTalentMessageAsync(int recruiterId, int talentId, int jobId);

        Task<RecruiterMessages> GetRecruiterJobListAsync(int recruiterId);

        Task<Job> GetRecruiterAdminMessageAsync(int recruiterId);

        Task<List<RecruiterMessages>> GetAdminRecruiterListAsync(int adminId);

        Task<List<TalentInfo>> GetAdminTalentListAsync(int adminId);

        Task<List<MessageDto>> GetAdminRecruiterMessage(int adminId, int recruiterId);

        Task<List<MessageDto>> GetAdminTalentMessage(int adminId, int talentId);
        Task<dynamic> GetMessageUnreadCount(int userId, int userType);
    }
}