﻿using FTCApi.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IAuxiliaryUserRepository:IGenericRepository<AuxiliaryUser>
    {
        bool ValidateUser(string enteredPassword, string actualPassword);

        Task<List<AuxiliaryUser>> GetAllUsers(int userId);

        Task<List<int>> NotifyListOfAuxiliaryUser(int auxiliaryUserId, int senderId, int? notificationEnum = 0, int? projectid = 0, int? jobId = 0);

        Task<List<int>> NotifyListOfAdmin();
        bool CheckAuthorization(int recruiterId, int loggedInUserId, int? notificationEnum = 0, int? projectId = 0, int? jobId = 0);
    }
}
