﻿using FTCApi.Core.Models;
using FTCApi.Dtos.SpecialHost;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ITalentSpecialHostRepository:IGenericRepository<TalentSpecialHost>
    {        
        TalentSpecialHostDto ConvertToTalentSpecialHostDto(TalentSpecialHost talentSpecialHostDto);
        Task<TalentSpecialHostDto> SaveTalentSpecialHost(TalentSpecialHostDto talentSpecialHostDto,int userId, int userType);
        Task UpdateTalentSpecialHost(TalentSpecialHostDto talentSpecialHostDto, int userId, int userType);
        int GetProviderId(int specialHostId);
    }
}
