﻿using FTCApi.Core.Models;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IProjectJobLanguageRepository : IGenericRepository<ProjectJobLanguage>
    {
    }
}