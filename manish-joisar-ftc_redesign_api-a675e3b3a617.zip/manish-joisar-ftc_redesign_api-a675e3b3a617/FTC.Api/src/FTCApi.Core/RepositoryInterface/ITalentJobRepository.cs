﻿using FTCApi.Core.Models;
using FTCApi.Dtos.JobAuditionsDtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ITalentJobRepository : IGenericRepository<TalentJob>
    {
        Task<SearchResult<TalentJob>> Search(SearchParameters searchParams);
        Task<JobAuditionResults<Auditions>> GetJobAuditions(JobAuditionsRequest jobAuditionsRequest);

        Task<JobAuditionResults<Auditions>> GetJobAuditionRecommended(JobAuditionsRequest jobAuditionsRequest);

        Task<JobAuditionResults<Auditions>> GetJobAuditionInTransit(JobAuditionsRequest jobAuditionsRequest);

        Task<bool> SaveJobAuditionStatus(List<TalentJobAuditionStatus> talentJobs);

        Task<bool> InviteRecommendedJobAuditions(List<JobTalentRecommendedDto> recommendedTalents);

        Task<List<ProjectJobStatusDto>> GetAuditionStatusList(int statusId, int jobId, int? auditionId, bool notSelected);

        Task<ProjectJob> UpdateCollaboratorFeedback(CollabratorFeedback collabratorFeedback);

        Task<JobAuditionResults<Auditions>> GetTalentMatchingTabJobAuditions(JobAuditionsRequest jobAuditionsRequest);

        Task<List<TalentJob>> GetTalentJobsByJobId(JobAuditionsRequest jobAuditionsRequest);

        Task<int> GetTalentRecommendedJobsByJobId(JobAuditionsRequest jobAuditionsRequest);

    }
}
