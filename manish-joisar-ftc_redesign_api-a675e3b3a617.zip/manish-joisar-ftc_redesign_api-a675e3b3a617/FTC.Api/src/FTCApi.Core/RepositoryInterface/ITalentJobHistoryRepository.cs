﻿using FTCApi.Core.Models;

namespace FTCApi.Core.RepositoryInterface
{
    public interface ITalentJobHistoryRepository : IGenericRepository<TalentJobHistory>
    {
    }
}
