﻿using FTCApi.Core.Models;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IHairTypeRepository : IGenericRepository<HairType>
    {
    }
}