﻿using FTCApi.Core.Models;
using FTCApi.Core.Models.Provider;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IProviderRepository : IGenericRepository<ContestProvider>
    {
        Task<ProviderResponse> Authenticate(ProviderDetails providerDetails);

        Task<List<AccountDetail>> GetSubscriptions(string rmn, int contestId, int providerId);

        Task<ProviderResponse> CheckProvider(string subscriberId);
    }
}