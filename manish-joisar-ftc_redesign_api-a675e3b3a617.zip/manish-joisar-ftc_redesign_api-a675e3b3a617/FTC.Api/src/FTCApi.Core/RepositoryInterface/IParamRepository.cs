﻿using FTCApi.Core.Models;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IParamRepository : IGenericRepository<Param>
    {
        Task<Param> GetUserSettings();
    }
}