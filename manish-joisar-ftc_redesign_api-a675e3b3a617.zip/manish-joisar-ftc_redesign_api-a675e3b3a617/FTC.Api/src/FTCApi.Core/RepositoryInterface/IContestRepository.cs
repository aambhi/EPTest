﻿using FTCApi.Core.Models;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IContestRepository: IGenericRepository<Contest>
    {
        Task<Contest> GetContestById(int Id,int userId, int userType);
    }
}
