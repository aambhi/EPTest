﻿using FTCApi.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTCApi.Core.RepositoryInterface
{
    public interface IProjectJobRepository : IGenericRepository<ProjectJob>
    {
        Task<SearchResult<ProjectJob>> Search(SearchParameters searchParams, int jobSearchType, int talentId);

        Task<ProjectJob> GetJobById(int Id, int talentId);

        Task<int> GetJobCountByCondition(int talentId, int conditionType);

        Task<bool> PushFtcRecommendedTalents(int projectId, int jobId, int userId);

        Task<List<ProjectJob>> GetAllJobs(int userId);
    }
}