﻿using Swashbuckle.Swagger.Model;
using Swashbuckle.SwaggerGen.Generator;
using System.Collections.Generic;

namespace FTC.Api.Swagger
{
    public class AddRequiredHeaderParameter : IOperationFilter
    {
        public void Apply(Operation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<IParameter>();
            operation.Parameters.Add(new NonBodyParameter
            {
                Name = "Authorization",
                In = "header",
                Description = "Example: Basic 1fc3245a-5abd-41e3-ba75-d24dccb19d1d",
                Required = false,
                Type = "string"
            });

            operation.Parameters.Add(new NonBodyParameter
            {
                Name = "Role",
                In = "header",
                Description = "whether the logged in user is talent or admin or recruiter",
                Required = false, 
                Type = "integer"
            });
        }

    }
}
