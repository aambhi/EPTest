﻿using Swashbuckle.Swagger.Model;
using Swashbuckle.SwaggerGen.Generator;

namespace FTC.Api.Swagger
{
    public class FileUploadOperation: IOperationFilter
    {
        public void Apply(Operation operation, OperationFilterContext context)
        {
            if (operation.OperationId.ToLower() == "contestuploadcontestmediapost" 
                || operation.OperationId.ToLower() == "contestsavecontestpost"
                || operation.OperationId.ToLower() == "auditionsavemediapost"
                || operation.OperationId.ToLower() == "auditionsaveofflinemediapost"
                || operation.OperationId.ToLower() == "uploadmediapost")
            {
                operation.Parameters.Clear();
                operation.Parameters.Add(new NonBodyParameter
                {
                    Name = "uploadedFile",
                    In = "formData",
                    Description = "Upload File",
                    Required = true,
                    Type = "file"
                });
                operation.Consumes.Add("multipart/form-data");

                #region additional paramters
                operation.Parameters.Add(new NonBodyParameter
                {
                    Name = "Authorization",
                    In = "header",
                    Description = "Example: Basic 1fc3245a-5abd-41e3-ba75-d24dccb19d1d",
                    Required = false,
                    //Default = "Basic 1fc3245a-5abd-41e3-ba75-d24dccb19d1d",
                    Type = "string"
                });

                operation.Parameters.Add(new NonBodyParameter
                {
                    Name = "Role",
                    In = "header",
                    Description = "whether the logged in user is talent or admin or recruiter",
                    Required = false,
                    //Default = 0,               
                    Type = "integer"
                });

                


                operation.Parameters.Add(new NonBodyParameter
                {
                    Name = "ContestId",
                    In = "header",
                    Description = "whether the logged in user is talent or admin or recruiter",
                    Required = false,
                    //Default = 0,               
                    Type = "integer"
                });
                #endregion
            }


        }
    }
}