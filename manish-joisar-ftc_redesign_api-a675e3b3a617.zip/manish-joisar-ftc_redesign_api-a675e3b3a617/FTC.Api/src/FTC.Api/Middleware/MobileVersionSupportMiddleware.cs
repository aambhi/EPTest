﻿using FTC.Api.CommonServices;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Semver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Middleware
{
    public class MobileVersionSupportMiddleware
    {
        readonly RequestDelegate _next;
        private AppSettings _appSettings;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private IMemoryCache _cache;
        private IAppVersionRepository _appVersionRepository;

        private const string ROLE = "Role";
        private const string PLATFORM = "Platform";
        private const string CURRENT_APP_VERSION = "Current-App-Version";

        private const string LATEST_VERSION = "Latest-Version";
        private const string FEATURES = "Features";
        private const string IS_CURRENT_API_VERSION_SUPPORTED = "IsCurrentApiVersionSupported";

        private const string CACHE_KEY = "FTCAppVersion";
        
        public MobileVersionSupportMiddleware(RequestDelegate next,
                                              Microsoft.Extensions.Configuration.IConfiguration configuration,
                                              IMemoryCache memoryCache,
                                              IAppVersionRepository appVersionRepository)
        {
            if (next == null) throw new ArgumentNullException(nameof(next));
            _next = next;

            _configuration = configuration;
            _appSettings = new AppSettings(_configuration);
            _cache = memoryCache;
            _appVersionRepository = appVersionRepository;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            if (httpContext == null) throw new ArgumentNullException(nameof(httpContext));

            bool isCurrentApiVersionSupported = true;

            var userType = Convert.ToInt32(httpContext.Request.Headers[ROLE]);
            if (userType == Convert.ToInt32(LoginUserType.Talent))
            {
                var platform = httpContext.Request.Headers[PLATFORM];
                var currentAppVersion = httpContext.Request.Headers[CURRENT_APP_VERSION];

                if (!string.IsNullOrEmpty(platform) && !string.IsNullOrEmpty(currentAppVersion))
                {
                    var deviceOsId = (short)platform.ToString().ToEnum<DeviceOsEnum>();
                    var currentMobileAppVersion = currentAppVersion.ToString();

                    var appVersions = await GetAppVersions();     // from list from cache
                    var appVersionDetail = GetPlatformAppVersion(deviceOsId, currentMobileAppVersion, appVersions);
                    isCurrentApiVersionSupported = isVersionSupported(appVersionDetail);

                    var latestPlatformVersion = GetLatestPlatformVersion(deviceOsId, appVersions);

                    if (latestPlatformVersion != null)
                    {
                        httpContext.Response.Headers.Add(FEATURES, latestPlatformVersion.Feature);
                        httpContext.Response.Headers.Add(LATEST_VERSION, latestPlatformVersion.Version);
                    }
                }
            }

            httpContext.Response.Headers.Add(IS_CURRENT_API_VERSION_SUPPORTED, isCurrentApiVersionSupported.ToString());

            await _next(httpContext);
        }

        private async Task<IEnumerable<AppVersion>> GetAppVersions()
        {
            var cacheKey = CACHE_KEY;

            dynamic cacheObject;
            
            var appVersions = default(IEnumerable<AppVersion>);

            bool isCacheExist = _cache.TryGetValue(cacheKey, out cacheObject);

            if (!isCacheExist)
            {
                // Key not in cache, so get data.
                appVersions = await _appVersionRepository.GetAllAsync();

                // Set cache options.
                var cacheDuration = new TimeSpan(_appSettings.CacheExpiryHours, _appSettings.CacheExpiryMinutes, _appSettings.CacheExpirySeconds);

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(cacheDuration);         // Keep in cache for this time, reset time if accessed.

                // Save data in cache.
                _cache.Set(cacheKey, JsonConvert.SerializeObject(appVersions), cacheEntryOptions);
            }
            else
            {
                appVersions = JsonConvert.DeserializeObject<IEnumerable<AppVersion>>(cacheObject);
            }

            return appVersions;
        }

        private AppVersion GetPlatformAppVersion(short deviceOsId, string currentAppVersion, IEnumerable<AppVersion> appVersions)
        {
            var platformSupportedVersion = appVersions.FirstOrDefault(x => x.DeviceOsId == deviceOsId && SemVersion.Parse(x.Version) == SemVersion.Parse(currentAppVersion));
            return platformSupportedVersion;
        }

        private AppVersion GetLatestPlatformVersion(short deviceOsId, IEnumerable<AppVersion> appVersions)
        {
            var latestAppVersion = appVersions.LastOrDefault(x => x.DeviceOsId == deviceOsId);
            return latestAppVersion;
        }

        private bool isVersionSupported(AppVersion appVersion)
        {
            if (appVersion != null)
                return appVersion.Permissible;

            return false;
        }
    }
}
