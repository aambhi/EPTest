﻿using FTCApi.Core.RepositoryInterface;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.CommonServices
{
    public class AuthTokenVerify
    {
        private ITalentRepository _talentRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        public AuthTokenVerify(ITalentRepository talentRepository)
        {
            _talentRepository = talentRepository;
        }

        public AuthTokenVerify(IAuxiliaryUserRepository auxiliaryUserRepository)
        {
            _auxiliaryUserRepository = auxiliaryUserRepository;
        }

        public dynamic VerifyAuthToken(string authHeader, int userType)
        {
            //int userId = 0;
            dynamic user = null;

            if (authHeader != null && authHeader.StartsWith("Basic"))
            {
                string authToken = authHeader.Substring("Basic ".Length).Trim();
                if (authToken != null)
                {
                    if (userType == (int)LoginUserType.Recruiter)
                    {
                        var auxiliaryUser =  _auxiliaryUserRepository.FindAsync(x => x.AuthToken == authToken).Result;
                        if (auxiliaryUser != null && (auxiliaryUser.TypeId == (int)LoginUserType.Recruiter))
                        {
                            //userId = auxiliaryUser.Id;
                            user = auxiliaryUser;
                        }
                    }
                    else if (userType == (int)LoginUserType.FTCAdmin)
                    {
                        var auxiliaryUser = _auxiliaryUserRepository.FindAsync(x => x.AuthToken == authToken).Result;
                        if (auxiliaryUser != null &&  auxiliaryUser.TypeId == (int)LoginUserType.FTCAdmin)
                        {
                            //userId = auxiliaryUser.Id;
                            user = auxiliaryUser;
                        }
                    }
                    else
                    {
                        var talent = _talentRepository.FindAsync(x => x.AuthToken == authToken).Result;
                        if (talent != null)
                        {
                            user = talent;
                            //userId = user.Id;
                        }
                    }
                }
            }
            //return userId;
            return user;
        }
    }
}