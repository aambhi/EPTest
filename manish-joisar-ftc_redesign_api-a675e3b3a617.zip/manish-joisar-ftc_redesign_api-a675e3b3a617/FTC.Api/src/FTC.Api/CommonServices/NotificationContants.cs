﻿namespace FTC.Api.CommonServices
{
    public static class NotificationContants
    {
        public const string FullName = "<<fullName>>";

        public const string DomainUrl = "<<domainUrl>>";

        public const string SharedProfileName = "<<sharedProfileName>>";

        public const string Otp = "<<otp>>";

        public const string UniqueId = "<<uniqueId>>";

        public const string NewLine = "<<newLine>>";

        public const string RecruiterPassword = "<<password>>";

        public const string SharedProfileComment = "<<sharedProfileComment>>";

        public const string JobName = "<<jobName>>";

        public const string ProjectName = "<<projectName>>";

        public const string ContestName = "<<contestName>>";


        public const string JobDetailsUrl = "<<jobDetailsUrl>>";

        public const string RoundName = "<<round>>";

        public const string Email = "<<email>>";

        public const string MobileNumber = "<<mobileNumber>>";

        public const string CollaboratorUrl = "<<collaboratorUrl>>";

        public const string TempPrefix = "<<tempPrefix>>";

        public const string DateTimeNow = "<<dateTimeNow>>";

        public const string Message = "<<message>>";

        public const string PaymentAmount = "<<paymentAmount>>";

        public const string TalentCount = "<<talentCount>>";

        public const string RecruiterName = "<<recruiterName>>";

    }
}
