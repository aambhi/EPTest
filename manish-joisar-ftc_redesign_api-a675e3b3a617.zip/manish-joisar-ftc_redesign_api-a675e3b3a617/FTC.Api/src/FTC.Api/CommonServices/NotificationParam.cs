﻿using System.Collections.Generic;

namespace FTC.Api.CommonServices
{
    public class NotificationParam
    {
        public NotificationParam()
        {
            Bcc = new List<string>();
            IsEmailVerifed = true;
            IsMobileVerfied = true;
            SendSmsToAuxiliaryUsers = new List<SendSmsToUsers>();
            SendSmsToTalents = new List<SendSmsToUsers>();
        }
        public int AuxiliaryUserId { get; set; }

        public int TalentId { get; set; }

        public string FullName { get; set; }

        public string DomainUrl { get; set; }

        public string UniqueId { get; set; }

        public string SharedProfileName { get; set; }

        public string MobileCountryCode { get; set; }

        public string Otp { get; set; }

        public string NewLine { get; set; }

        public string Email { get; set; }

        public string MobileNumber { get; set; }
        public string UserPassword { get; set; }
        public List<string> Bcc { get; set; }

        public string SharedProfileComment { get; set; }

        public string ProjectName { get; set; }

        public string JobName { get; set; }

        public string ContestName { get; set; }

        public string RoundName { get; set; }
        public string JobDetailsUrl { get; set; }
        public string CollaboratorUrl { get; set; }
        public short? DeviceOsId { get; set; }
        public string DeviceRegistrationId { get; set; }

        public string TempPrefix { get; set; }

        public bool IsEmailVerifed { get; set; }

        public bool IsMobileVerfied { get; set; }

        public string Message { get; set; }
        public string PaymentAmount { get; set; }

        public string TalentCount { get; set; }

        public string RecruiterName { get; set; }

        public List<SendSmsToUsers> SendSmsToAuxiliaryUsers { get; set; }
        public List<SendSmsToUsers> SendSmsToTalents { get; set; }
    }

    public class SendSmsToUsers
    {
        public int AuxiliaryUserId { get; set; }
        public int TalentId { get; set; }
        public string MobileNumber { get; set; }
        public string MobileCountryCode { get; set; }
    }

}
