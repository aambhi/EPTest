﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FTC.Api.CommonServices
{
    public class AppSettings
    {
        private readonly IConfiguration _configuration;

        public AppSettings(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string DomainUrl
        {
            get
            {
                return GetConfigValue("DomainUrl");
            }
        }

        public string MessageBodyPrefix
        {
            get
            {
                return GetConfigValue("Notification:MessageBodyPrefix");
            }
        }

        public string IconsUrl
        {
            get
            {
                return GetConfigValue("IconsUrl");
            }
        }

        public string S3BaseUrl
        {
            get
            {
                return GetConfigValue("S3Details:BaseUrl");
            }
        }
        public string S3BaseUrlForUser
        {
            get
            {
                return GetConfigValue("S3Details:BaseUrl-User");
            }
        }
        public string S3BaseUrlForContest
        {
            get
            {
                return GetConfigValue("S3Details:BaseUrl-Contest");
            }
        }

        public string S3BucketName
        {
            get
            {
                return GetConfigValue("S3Details:BucketName");
            }
        }
        
        public string S3BucketNameContest
        {
            get
            {
                return GetConfigValue("S3Details:BucketName-Contest");
            }
        }


        public string S3BucketNameUser
        {
            get
            {
                return GetConfigValue("S3Details:BucketName-User");
            }
        }

        public string MediaBasePath
        {
            get
            {
                return GetConfigValue("MediaFiles:BasePath");
            }
        }


        public string SmsId
        {
            get
            {
                return GetConfigValue("SmsSettings:Sid");
            }
        }

        public string SmsToken
        {
            get
            {
                return GetConfigValue("SmsSettings:Token");
            }
        }

        public string SmsBaseUri
        {
            get
            {
                return GetConfigValue("SmsSettings:BaseUri");
            }
        }

        public string SmsRequestUri
        {
            get
            {
                return GetConfigValue("SmsSettings:RequestUri");
            }
        }

        public string SmsFrom
        {
            get
            {
                return GetConfigValue("MediaFiles:From");
            }
        }

        public string GetContestFolder
        {
            get
            {
                return GetConfigValue("Folder:Contest");
            }
        }

        public string GetAuxiliaryFolder
        {
            get
            {
                return GetConfigValue("Folder:AuxiliaryUser");
            }
        }
        public string GetJobFolder
        {
            get
            {
                return GetConfigValue("Folder:Job");
            }
        }
        public string GetAuditionFolder
        {
            get
            {
                return GetConfigValue("Folder:Audition");
            }
        }
        public string GetProjectFolder
        {
            get
            {
                return GetConfigValue("Folder:Project");
            }
        }

        public string GetProjectJobFolder
        {
            get
            {
                return GetConfigValue("Folder:ProjectJob");
            }
        }

        public string GetOnlineRoundFolder
        {
            get
            {
                return GetConfigValue("Folder:OnlineRound");
            }
        }
        

        public string GetTalentFolder
        {
            get
            {
                return GetConfigValue("Folder:Talent");
            }
        }

        public bool IsEmailNotificationEnabled
        {
            get
            {
                return Convert.ToBoolean(GetConfigValue("Notification:isEmailEnabled"));
            }
        }

        public bool IsSmsNotificationEnabled
        {
            get
            {
                return Convert.ToBoolean(GetConfigValue("Notification:isEmailEnabled"));
            }
        }

        public int GetInitialUID
        {
            get
            {
                return Convert.ToInt32(GetConfigValue("InitialUID"));
            }
        }

        public string GetCollaboratorURL
        {
            get
            {
                return GetConfigValue("CollaboratorURL");
            }
        }
        
        private string GetConfigValue(string key)
        {
            return _configuration[key];
        }

        public string GetAutoCompleteCityUrl
        {
            get
            {
                return GetConfigValue("AutoCompleteCityUrl");
            }
        }

        public string CityDetailsUrl
        {
            get
            {
                return GetConfigValue("CityDetailsUrl");
            }
        }

        public string GetTwilioAccount
        {
            get
            {
                return GetConfigValue("twilio:account");
            }
        }

        public string GetTwilioAuthKey
        {
            get
            {
                return GetConfigValue("twilio:authkey");
            }
        }

        
        public string FCMServerId
        {
            get
            {
                return GetConfigValue("PushNotification:ServerId");
            }
        }

        public string FCMServerUri
        {
            get
            {
                return GetConfigValue("PushNotification:ServerUri");
            }
        }

        public string NotificationTitle
        {
            get
            {
                return GetConfigValue("PushNotification:Title");
            }
        }
 
        public string SignedCookieKeyPairId
        {
            get
            {
                return GetConfigValue("SignedCookie:KeyPairId");
            }
        }


        public string SignedCookieFTCDomainName
        {
            get
            {
                return GetConfigValue("SignedCookie:FTCDomainName");
            }
        }

        public string SignedCookieKeyPairFile
        {
            get
            {
                return GetConfigValue("SignedCookie:KeyPairFile");
            }
        }

        public string SignedCookieAllowWildCard
        {
            get
            {
                return GetConfigValue("SignedCookie:AllowWildCard");
            }
        }
        public int ExpireCookieInMinute
        {
            get
            {
                return Convert.ToInt32(GetConfigValue("SignedCookie:ExpireCookieInMinute"));
            }
        }

        public string RazorpayKey
        {
            get
            {
                return GetConfigValue("Razorpay:Key");
            }
        }

        public string RazorpaySecret
        {
            get
            {
                return GetConfigValue("Razorpay:Secret");
            }
        }

        public string MinimumAndroidAppVersionSupport
        {
            get
            {
                return GetConfigValue("MinimumMobileAppVersionSupport:Android");
            }
        }

        public string MinimumIOSAppVersionSupport
        {
            get
            {
                return GetConfigValue("MinimumMobileAppVersionSupport:IOS");
            }
        }

        public List<int> ExcludeTalentCategoryIds
        {
            get
            {
                return _configuration
                                   .GetSection("ExcludeTalentCategoryIds")
                                   .GetChildren()
                                   .Select(x => Convert.ToInt32(x.Value))
                                   .ToList();              
                
            }
        }

        public int CacheExpiryHours
        {
            get
            {
                return Convert.ToInt32(GetConfigValue("CacheExpiry:Hours"));
            }
        }
        public int CacheExpiryMinutes
        {
            get
            {
                return Convert.ToInt32(GetConfigValue("CacheExpiry:Minutes"));
            }
        }
        public int CacheExpirySeconds
        {
            get
            {
                return Convert.ToInt32(GetConfigValue("CacheExpiry:Seconds"));
            }
        }

    }
}


