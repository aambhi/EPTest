﻿using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using Infrastructure.Core.Interfaces;
using Infrastructure.Core.Models;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Api.CommonServices
{
    public class Notification
    {
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private IEmailService _emailService;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private AppSettings _appSettings;
        private ISmsProviderRepository _smsProviderRepository;

        public Notification(Microsoft.Extensions.Configuration.IConfiguration configuration,
            INotificationDetailRepository notificationDetailRepository,
            INotificationHeaderRepository notificationHeaderRepository,
            IUserNotificationRepository userNotificationRepository,
        IEmailService emailService, ISmsProviderRepository smsProviderRepository)
        {
            _configuration = configuration;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _userNotificationRepository = userNotificationRepository;
            _emailService = emailService;
            _appSettings = new AppSettings(_configuration);
            _smsProviderRepository = smsProviderRepository;
        }

        #region Send Notification

        public async Task SendNotification(NotificationEnum notificationDetailType, NotificationParam notificationParam, RequestSendSystemNotificationDto sendSystemNotificationDto)
        {
            try
            {
                var notificationDetails = await _notificationDetailRepository.FindAllAsync(x => x.Type == notificationDetailType.ToString());
                foreach (var notificationDetail in notificationDetails)
                {
                    if ((notificationDetail.NotificationHeaderId == (int)NotificationHeaderEnum.Email) && (notificationDetail.Send) && notificationParam.IsEmailVerifed)
                    {
                        await SendEmail(notificationDetail, notificationParam, sendSystemNotificationDto);
                    }

                    if ((notificationDetail.NotificationHeaderId == (int)NotificationHeaderEnum.SMS)
                        && (notificationDetail.Send)
                        && (!string.IsNullOrEmpty(notificationParam.MobileNumber)
                            || notificationParam.SendSmsToAuxiliaryUsers.Count > 0
                            || notificationParam.SendSmsToTalents.Count > 0))
                    {
                        await SendSmsAsync(notificationDetail, notificationParam);
                    }

                    if ((notificationDetail.NotificationHeaderId == (int)NotificationHeaderEnum.SystemNotification) && (notificationDetail.Send))
                    {
                        await SendSystemNotification(notificationDetail, sendSystemNotificationDto, notificationParam);
                    }

                }
            }
            catch (Exception ex)
            {
                Log.Error("An Error occurred while sending Notification:" + ex);
            }
        }

        #endregion

        #region Email Service

        public async Task SendEmail(NotificationDetail notificationDetail, NotificationParam notificationParam, RequestSendSystemNotificationDto sendSystemNotificationDto)
        {
            var mailBody = string.Empty;
            var success = false;
            MailMessage mailMessage = null;
            var response = string.Empty;
            try
            {
                if (_appSettings.IsEmailNotificationEnabled)
                {
                    mailMessage = new MailMessage();

                    if (!string.IsNullOrEmpty(notificationParam.Email))
                    {
                        mailMessage.ToAddress.Add(notificationParam.Email);
                    }

                    // Incase, if we don't send sendSystemNotificationDto => so, to handle null reference
                    if (sendSystemNotificationDto != null)
                    {
                        if (notificationDetail.SendToAllRole && sendSystemNotificationDto.SendEmailToAuxiliaryUsers.Any())
                        {
                            notificationParam.Bcc.AddRange(sendSystemNotificationDto.SendEmailToAuxiliaryUsers);
                        }

                        // send notification to talent
                        if (notificationDetail.Send && sendSystemNotificationDto.SendEmailToTalents.Any())
                        {
                            notificationParam.Bcc.AddRange(sendSystemNotificationDto.SendEmailToTalents);
                        }
                    }

                    // send mail only if email id exists

                    if (mailMessage.ToAddress.Count > 0 || notificationParam.Bcc.Count > 0)
                    {

                        mailMessage.BccAddress = notificationParam.Bcc;

                        var notificationHeader = await _notificationHeaderRepository.FindAsync(x => x.Type == NotificationTypeEnum.Email.ToString());

                        mailMessage.FromAddress = notificationHeader.FromEmail;

                        mailMessage.Subject = notificationDetail.Subject;

                        mailBody = NotificationDetailBody(notificationDetail, notificationParam);

                        mailMessage.Body = mailBody + notificationHeader.MailFooter;

                        _emailService.SendEmail(mailMessage);
                        success = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while sending an Email:" + ex);
                success = false;
                response = ex.ToString();


            }
            finally
            {
                try
                {
                    if (mailMessage.ToAddress.Count > 0 || notificationParam.Bcc.Count > 0)
                    {
                        //Build SMS gateway parameter object
                        var traceEmailGateway = new TraceEmailGateway
                        {
                            AuxiliaryUserId = notificationParam.AuxiliaryUserId == 0 ? (int?)null : notificationParam.AuxiliaryUserId,
                            TalentId = notificationParam.TalentId == 0 ? (int?)null : notificationParam.TalentId,
                            Message = mailMessage.Body,
                            CreatedOn = DateTime.UtcNow,
                            Email = "To: " + String.Join(",", mailMessage.ToAddress) + " Bcc: " + String.Join(",", mailMessage.BccAddress),
                            Sent = success,
                            EmailResponse = response,
                            EmailRequest = JsonConvert.SerializeObject(mailMessage)

                        };
                        await _smsProviderRepository.TraceEmail(traceEmailGateway);

                    }
                }
                catch (Exception ex)
                {
                    Log.Error("An error occurred while saving email trace:" + ex);
                }
            }
        }

        #endregion

        #region SMS Service
        public async Task SendSmsAsync(NotificationDetail notificationDetail, NotificationParam notificationParam)
        {
            try
            {
                if (_appSettings.IsSmsNotificationEnabled)
                {
                    var notificationHeader = await _notificationHeaderRepository.FindAsync(x => x.Type == NotificationTypeEnum.SMS.ToString());

                    string mailBody = NotificationDetailBody(notificationDetail, notificationParam);

                    SMSGatewayParam smsGatewayParamObject = null;

                    #region Send bulk Sms to Talent
                    if (notificationParam.SendSmsToTalents.Count > 0)
                    {
                        foreach (var sendSmsToTalent in notificationParam.SendSmsToTalents)
                        {
                            await SendSmsToUser(notificationParam, notificationHeader, mailBody, sendSmsToTalent);
                        }
                    }
                    #endregion

                    #region Send bulk Sms  to AuxiliaryUser
                    if (notificationParam.SendSmsToAuxiliaryUsers.Count > 0)
                    {
                        foreach (var sendSmsToAuxiliaryUser in notificationParam.SendSmsToAuxiliaryUsers)
                        {
                            await SendSmsToUser(notificationParam, notificationHeader, mailBody, sendSmsToAuxiliaryUser);
                        }
                    }
                    #endregion

                    #region Send SMS to single user
                    if (!string.IsNullOrEmpty(notificationParam.MobileNumber))
                    {
                        //Build SMS gateway parameter object
                        smsGatewayParamObject = new SMSGatewayParam
                        {
                            AuxiliaryUserId = notificationParam.AuxiliaryUserId,
                            TalentId = notificationParam.TalentId,
                            FromEmail = notificationHeader.FromEmail,
                            Message = mailBody,
                            MobileCountryCode = notificationParam.MobileCountryCode,
                            MobileNumber = notificationParam.MobileCountryCode + notificationParam.MobileNumber
                        };

                        if (string.IsNullOrEmpty(notificationParam.MobileCountryCode) || string.IsNullOrEmpty(notificationParam.MobileNumber))
                        {
                            Log.Error("Mobile:" + notificationParam.MobileNumber + "or mobile country code is not configured");
                        }
                        else
                        {
                            //send sms
                            await _smsProviderRepository.SendSMS(smsGatewayParamObject);
                        }
                    }

                    #endregion

                }
            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while sending SMS: " + ex);
            }
        }

        private async Task SendSmsToUser(NotificationParam notificationParam, NotificationHeader notificationHeader, string mailBody, SendSmsToUsers sendSmsToUser)
        {
            try
            {
                //Build SMS gateway parameter object
                SMSGatewayParam smsGatewayParamObject = new SMSGatewayParam
                {
                    AuxiliaryUserId = sendSmsToUser.AuxiliaryUserId,
                    TalentId = sendSmsToUser.TalentId,
                    FromEmail = notificationHeader.FromEmail,
                    Message = mailBody,
                    MobileCountryCode = sendSmsToUser.MobileCountryCode,
                    MobileNumber = sendSmsToUser.MobileCountryCode + sendSmsToUser.MobileNumber
                };

                if (string.IsNullOrEmpty(sendSmsToUser.MobileCountryCode) || string.IsNullOrEmpty(sendSmsToUser.MobileNumber))
                {
                    Log.Error("Mobile:" + notificationParam.MobileNumber + " or mobile country code is not configured");
                }
                else
                {
                    //send sms 
                    await _smsProviderRepository.SendSMS(smsGatewayParamObject);
                }
            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while sending SMS: " + ex);
            }

        }
        #endregion

        #region Send System Notifications

        public async Task SendSystemNotification(NotificationDetail notificationDetail, RequestSendSystemNotificationDto sendSystemNotificationDto, NotificationParam notificationParam)
        {
            if (sendSystemNotificationDto != null)
            {
                var userNotificationRepository = _userNotificationRepository;

                // for auxiliaryUser
                foreach (var SendNotificationTo in sendSystemNotificationDto.SendNotificationToAuxiliaryUsers)
                {
                    await SaveSystemNotification(notificationDetail, sendSystemNotificationDto, notificationParam, SendNotificationTo, false);
                }

                // for talent
                foreach (var SendNotificationTo in sendSystemNotificationDto.SendNotificationToTalents)
                {
                    await SaveSystemNotification(notificationDetail, sendSystemNotificationDto, notificationParam, SendNotificationTo, true);
                }

                // for system & push notification of list of talents
                foreach (var SendNotificationTo in sendSystemNotificationDto.PushNotifications)
                {
                    await SaveSystemNotification(notificationDetail, sendSystemNotificationDto, notificationParam, SendNotificationTo, true);
                }
            }
        }

        private async Task SaveSystemNotification(NotificationDetail notificationDetail, RequestSendSystemNotificationDto sendSystemNotificationDto, NotificationParam notificationParam, int SendNotificationTo, bool loginUserTypeTalent)
        {
            var userNotification = new UserNotification();
            try
            {
                if (loginUserTypeTalent)
                {
                    userNotification.TalentId = SendNotificationTo;
                }
                else
                {
                    userNotification.AuxiliaryUserId = SendNotificationTo;
                }

                BuildUserNotificationObject(notificationDetail, sendSystemNotificationDto, notificationParam, userNotification);

                userNotification = await _userNotificationRepository.AddAsync(userNotification);

            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while sending System Notification:" + ex);
            }
            if (loginUserTypeTalent)
            {
                await PushNotification(notificationParam, userNotification);
            }
        }

        private async Task SaveSystemNotification(NotificationDetail notificationDetail, RequestSendSystemNotificationDto sendSystemNotificationDto, NotificationParam notificationParam, PushNotification pushNotification, bool loginUserTypeTalent)
        {
            var userNotification = new UserNotification();
            try
            {
                if (loginUserTypeTalent)
                {
                    userNotification.TalentId = pushNotification.UserId;
                }
                else
                {
                    userNotification.AuxiliaryUserId = pushNotification.UserId;
                }

                BuildUserNotificationObject(notificationDetail, sendSystemNotificationDto, notificationParam, userNotification);

                userNotification = await _userNotificationRepository.AddAsync(userNotification);

            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while sending System Notification:" + ex);
            }
            if (loginUserTypeTalent)
            {
                notificationParam.DeviceRegistrationId = pushNotification.DeviceRegistrationId;
                await PushNotification(notificationParam, userNotification);
            }
        }

        private void BuildUserNotificationObject(NotificationDetail notificationDetail, RequestSendSystemNotificationDto sendSystemNotificationDto, NotificationParam notificationParam, UserNotification userNotification)
        {
            try
            {
                // from DB
                //Replace Configurable text from the Notification Description
                userNotification.Text = NotificationDetailBody(notificationDetail, notificationParam);

                if (sendSystemNotificationDto.NotificationReference == NotificationReferenceEnum.Project)
                {
                    userNotification.ProjectId = sendSystemNotificationDto.NotificationReferenceValue;
                }
                else if (sendSystemNotificationDto.NotificationReference == NotificationReferenceEnum.Job)
                {
                    userNotification.JobId = sendSystemNotificationDto.NotificationReferenceValue;
                }
                else if (sendSystemNotificationDto.NotificationReference == NotificationReferenceEnum.ReferenceAuxiliaryUserId)
                {
                    userNotification.ReferenceAuxiliaryUserId = sendSystemNotificationDto.NotificationReferenceValue;
                }
                else
                {
                    userNotification.ContestId = sendSystemNotificationDto.NotificationReferenceValue;
                }

                userNotification.UrlRoute = (short?)sendSystemNotificationDto.UrlRoute;
            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while building system Notification object:" + ex);
            }
        }

        private async Task PushNotification(NotificationParam notificationParam, UserNotification userNotification)
        {
            try
            {
                var registrationId = notificationParam.DeviceRegistrationId;

                if (!string.IsNullOrEmpty(registrationId))
                {
                    Log.Information("Device Type:" + notificationParam.DeviceOsId + " Device Registration ID:" + notificationParam.DeviceRegistrationId);

                    var notification = new FCM.Net.Notification
                    {
                        Title = _appSettings.NotificationTitle,
                        Body = userNotification.Text,
                        Sound = "default"

                    };

                    await PushDeviceNotification(registrationId, notification);
                }
            }
            catch (Exception ex)
            {
                Log.Error("An error occurred while sending Push Notification:" + ex);
            }
        }

        /// <param name="registrationId">todo: describe registrationId parameter on PushDeviceNotification</param>
        /// <param name="notification">todo: describe notification parameter on PushDeviceNotification</param>
        private async Task<string> PushDeviceNotification(string registrationId, FCM.Net.Notification notification)
        {

            //Server Id
            var serverId = _appSettings.FCMServerId;
            var serverUri = _appSettings.FCMServerUri;

            var objNotification = new
            {
                to = registrationId,
                notification = new
                {
                    title = notification.Title,
                    body = notification.Body,
                    sound = notification.Sound
                }
            };

            return await HttpClientHelper.HttpSendAsync(serverUri, objNotification, serverId);
        }

        #endregion


        // Replace Body Content of SMS, EMAIL..
        private string NotificationDetailBody(NotificationDetail notificationDetail, NotificationParam notificationParam)
        {
            return _appSettings.MessageBodyPrefix + notificationDetail.Body.Replace(NotificationContants.FullName, notificationParam.FullName)
                                                                          .Replace(NotificationContants.DomainUrl, _appSettings.DomainUrl)
                                                                          .Replace(NotificationContants.UniqueId, notificationParam.UniqueId)
                                                                          .Replace(NotificationContants.RecruiterPassword, notificationParam.UserPassword)
                                                                          .Replace(NotificationContants.SharedProfileName, notificationParam.SharedProfileName)
                                                                          .Replace(NotificationContants.SharedProfileComment, notificationParam.SharedProfileComment)
                                                                          .Replace(NotificationContants.Otp, notificationParam.Otp)
                                                                          .Replace(NotificationContants.JobName, notificationParam.JobName)
                                                                          .Replace(NotificationContants.JobDetailsUrl, notificationParam.JobDetailsUrl)
                                                                          .Replace(NotificationContants.ProjectName, notificationParam.ProjectName)
                                                                          .Replace(NotificationContants.CollaboratorUrl, notificationParam.CollaboratorUrl)
                                                                          .Replace(NotificationContants.RoundName, notificationParam.RoundName)
                                                                          .Replace(NotificationContants.ContestName, notificationParam.ContestName)
                                                                          .Replace(NotificationContants.Email, notificationParam.Email)
                                                                          .Replace(NotificationContants.MobileNumber, notificationParam.MobileNumber)
                                                                          .Replace(NotificationContants.TempPrefix, notificationParam.TempPrefix)
                                                                          .Replace(NotificationContants.DateTimeNow, DateTime.Now.ToString())
                                                                          .Replace(NotificationContants.Message, notificationParam.Message)
                                                                          .Replace(NotificationContants.PaymentAmount, notificationParam.PaymentAmount)
                                                                          .Replace(NotificationContants.TalentCount, notificationParam.TalentCount)
                                                                          .Replace(NotificationContants.RecruiterName, notificationParam.RecruiterName)
                                                                          .Replace(NotificationContants.NewLine, "%0A");
        }

    }
}
