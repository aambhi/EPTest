﻿namespace FTC.Api.CommonServices
{
    public class UserInfo
    {
        public int userId { get; set; }

        public int userType { get; set; }

        public int? parentId { get; set; }

        public string FullName { get; set; }

        public string ProfileUrl { get; set; }
    }
}
