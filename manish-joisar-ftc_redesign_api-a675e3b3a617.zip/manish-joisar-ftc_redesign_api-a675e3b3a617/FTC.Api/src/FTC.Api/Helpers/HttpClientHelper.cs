﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FTC.Api.Helpers
{
    public class HttpClientHelper
    {

        /// <summary>
        /// This method is use to get data 
        /// </summary>
        /// <param name="uri"></param>
        /// <returns>returns response string</returns>
        public async static Task<string> GetAsync(string uri)
        {
            var responseString = string.Empty;
            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(uri);
                response.EnsureSuccessStatusCode();
                responseString = await response.Content.ReadAsStringAsync();

            }
            return responseString;
        }

        public async static Task<string> HttpSendAsync(string uri, object data, string serverKey)
        {
            var responseString = string.Empty;

            using (var client = new HttpClient())
            {
                var jsonString = JsonConvert.SerializeObject(data);

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("key", "=" + serverKey);

                using (var stringContent = new StringContent(jsonString, Encoding.UTF8, "application/json"))
                {
                    var response = await client.PostAsync(uri, stringContent);

                    if (response.IsSuccessStatusCode)
                    {
                        response.EnsureSuccessStatusCode();
                        responseString = await response.Content.ReadAsStringAsync();
                    }
                }
            }

            return responseString;
        }


        /// <summary>
        /// This method is use to post data 
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="data"></param>
        /// <returns>returns response string</returns>
        public async static Task<string> PostAsync(string uri, object data)
        {
            var responseString = string.Empty;
            using (var client = new HttpClient())
            {
                var jsonInString = JsonConvert.SerializeObject(data);
                using (var stringContent = new StringContent(jsonInString, Encoding.UTF8, "application/json"))
                {
                    var response = await client.PostAsync(uri, stringContent);
                    response.EnsureSuccessStatusCode();
                    responseString = await response.Content.ReadAsStringAsync();
                }
            }
            return responseString;
        }

        public static string GetRealIP(HttpContext context)
        {
            string ipList = context.Request.Headers["X-Real-IP"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            ipList = context.Request.Headers["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            ipList = context.Request.Headers["REMOTE_ADDR"];
            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }
            return context.Connection.RemoteIpAddress.ToString();

        }


    }
}
