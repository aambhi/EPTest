﻿using System.Text.RegularExpressions;

namespace FTC.Api.Helpers
{
    public class RemoveSpecialCharactersHelper
    {
        public static string RemoveSpecialCharacters(string input)
        {
            return Regex.Replace(input, "[^0-9A-Za-z]+", string.Empty);            
        }
    }
}
