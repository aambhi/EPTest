﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    public class JobShareDetailController : Controller
    {
        private IProjectJobRepository _projectJobRepository;
        private IProjectRepository _projectRepository;
        private IJobShareViewDetailRepository _jobShareViewDetailRepository;
        private IJobShareDetailRepository _jobShareDetailRepository;
        private readonly IConfiguration _configuration;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private IEmailService _emailService;

        private AppSettings _appSettings;

        public JobShareDetailController(IProjectJobRepository projectJobRepository,
                                        IProjectRepository projectRepository,
                                        IJobShareViewDetailRepository jobShareViewDetailRepository,
                                        IJobShareDetailRepository jobShareDetailRepository,
                                        IConfiguration configuration,
                                        INotificationHeaderRepository notificationHeaderRepository,
                                        INotificationDetailRepository notificationDetailRepository,
                                        IUserNotificationRepository userNotificationRepository,
                                        IEmailService emailService, ISmsProviderRepository smsProviderRepository)
        {
            _projectJobRepository = projectJobRepository;
            _projectRepository = projectRepository;
            _jobShareDetailRepository = jobShareDetailRepository;
            _configuration = configuration;
            _jobShareViewDetailRepository = jobShareViewDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _notificationDetailRepository = notificationDetailRepository;
            _userNotificationRepository = userNotificationRepository;
            _emailService = emailService;
            _appSettings = new AppSettings(_configuration);
            _smsProviderRepository = smsProviderRepository;
        }

        #region Public Actions

        [HttpPost]
        [Route("shareJobDetails")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> ShareJobDetail([FromBody]JobShareDetailDto jobShareDetailDto, int userId, int userType)
        {
            if (jobShareDetailDto == null)
            {
                return BadRequest();
            }

            // no token is present for the given job => add to in project_Job table
            var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobShareDetailDto.JobId);
            if (projectJob == null)
            {
                return NotFound();
            }

            var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);
            
            if (string.IsNullOrEmpty(projectJob.Token))
            {
                projectJob.Token = Guid.NewGuid().ToString();
                projectJob = await _projectJobRepository.UpdateAsync(projectJob);
            }

            var jobShareDetail = ConvertToJobShareDetailModel(jobShareDetailDto.JobId, jobShareDetailDto);

            jobShareDetail = await _jobShareDetailRepository.AddAsync(jobShareDetail);
            jobShareDetailDto.URL = projectJob.Token;
            
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam
            {
                 AuxiliaryUserId = userId,
                Email = jobShareDetailDto.EmailId,
                ProjectName = project.Name,
                JobName = projectJob.Title,
                CollaboratorUrl = _appSettings.DomainUrl + _appSettings.GetCollaboratorURL + projectJob.Token
                
            };
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            await notification.SendNotification(NotificationEnum.Collaborator, notificationParam, sendSystemNotificationDto);


            return Json(new { jobShareDetail = jobShareDetailDto });
        }


        [HttpGet]
        [Route("shareJobDetails/{jobId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetShareJobDetailToken(int jobId, int userId, int userType)
        {
            var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobId);
            if (projectJob == null)
            {
                return NotFound();
            }
            
            var jobShareDetailURL = _appSettings.DomainUrl + _appSettings.GetCollaboratorURL + projectJob.Token;

            return Json(jobShareDetailURL);
        }

        [HttpPost]
        [Route("shareJobViewDetail")]
        public async Task<IActionResult> SaveShareJobViewDetail([FromBody]RequestJobShareViewDetailDto jobShareViewDetailDto)
        {
            if (jobShareViewDetailDto == null)
            {
                return BadRequest();
            }

            var projectjob = await _projectJobRepository.FindAsync(x => x.Token == jobShareViewDetailDto.Token);
            if (projectjob == null)
            {
                return NotFound();
            }

            var jobShareViewDetail = ConvertJobShareViewDetailModel(jobShareViewDetailDto, projectjob.Id);

            jobShareViewDetail = await _jobShareViewDetailRepository.AddAsync(jobShareViewDetail);

            return Json(jobShareViewDetailDto);
        }

        private JobShareViewDetail ConvertJobShareViewDetailModel(RequestJobShareViewDetailDto jobShareViewDetailDto, int jobId)
        {
            var jobShareViewDetail = new JobShareViewDetail();
            jobShareViewDetail.JobId = jobId;
            jobShareViewDetail.Name = jobShareViewDetailDto.Name;
            jobShareViewDetail.EmailId = jobShareViewDetailDto.EmailId;

            return jobShareViewDetail;
        }

        #endregion

        #region Private Methods

        [NonAction]
        private JobShareDetail ConvertToJobShareDetailModel(int jobId, JobShareDetailDto jobShareDetailDto)
        {
            var jobShareDetail = new JobShareDetail();
            jobShareDetail.JobId = jobId;
            jobShareDetail.EmailIds = jobShareDetailDto.EmailId;
            jobShareDetail.Notes = jobShareDetailDto.Notes;
            return jobShareDetail;
        }

        #endregion
    }
}
