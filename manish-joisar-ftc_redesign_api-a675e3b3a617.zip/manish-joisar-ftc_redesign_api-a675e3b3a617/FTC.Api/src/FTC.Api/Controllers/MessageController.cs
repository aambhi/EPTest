﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.ChatDtos;
using Microsoft.AspNetCore.Mvc;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{

    [Route("[controller]")]
    public class MessageController : Controller
    {

        #region Private Variables

        private IMessageRepository _messageRepository;

        private IAuxiliaryUserRepository _iAuxiliaryUserRepository;
        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="messageRepository"></param>
        public MessageController(IMessageRepository messageRepository, IAuxiliaryUserRepository iAuxiliaryUserRepository)
        {
            _messageRepository = messageRepository;
            _iAuxiliaryUserRepository = iAuxiliaryUserRepository;
        }

        #endregion

        #region Public Actions

        /// <summary>
        ///  This action is use to get messages between talent and recruiter.
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("talent/jobs/{jobId}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetTalentRecruiterMessages(int jobId, int userId)
        {
            var messages = await _messageRepository.GetTalentMessagesAsync(userId, jobId);
            if (messages != null && messages.JobId > 0)
            {
                return Ok(messages);
            }
            else
            {
                return NotFound();
            }
        }

        /// <summary>
        /// This method is use to get unread message and notification count
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("message/unreadcount")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetMessageNotificationCount(int userId, int userType)
        {
            var message  = await _messageRepository.GetMessageUnreadCount(userId, userType);
            return Ok(message);
        }

        /// <summary>
        /// This action is use to get talent job collection
        /// </summary>
        /// <param name="userId">model binding: logged in user id</param>
        /// <returns>returns list of job list</returns>
        [HttpGet]
        [Route("talent/jobs")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetTalentJobList(int userId)
        {
            var talentJobList = await _messageRepository.GetTalentJobListAsync(userId);
            return Ok(talentJobList);
        }

        /// <summary>
        /// This action is use to send messages from talent, recruiror, Admin
        /// </summary>
        /// <param name="message"></param>
        /// <param name="userId">model binding: logged in user id</param>
        /// <param name="userType">model binding: logged in user role</param>
        /// <returns></returns>
        [HttpPost]
        [Route("sendmessage")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin,TalentManager")]
        public async Task<IActionResult> SendMessage(int userId, int userType, [FromBody]MessageDto message)
        {
            if (message == null)
            {
                return BadRequest();
            }
            else
            {
                if (userType == (int)LoginUserType.Talent)
                {
                    message.FromTalentId = userId;
                }
                else
                {
                    message.FromAuxiliaryId = userId;
                }

                if ((message.ToAuxiliaryId ?? 0) == 0 && (message.ToTalentId ?? 0) == 0)
                {

                    return BadRequest(new { message = "Missing 'to' input parameter" });
                }
            }

            var chatMsg = await _messageRepository.SendMessageAsync(message);

            if (chatMsg != null && chatMsg.Id > 0)
            {
                return Ok(new { message = "Message send successfully" });
            }

            return BadRequest();
        }

        /// <summary>
        /// This action is use to get messages between talent and admin
        /// </summary>
        /// <param name="userId">model binding: logged in user id</param>
        /// <returns></returns>
        [HttpGet]
        [Route("talent/admin")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetTalentAdminMessages(int userId)
        {
            var messages = await _messageRepository.GetTalentAdminMessagesAsync(userId);
            if (messages != null && messages.Messages.Any())
            {
                return Ok(messages);
            }
            else
            {
                return NotFound();
            }
        }

        /// <summary>
        /// This action is use to get messages between talent and recruiter
        /// </summary>
        /// <param name="userId">model binding: logged in user id</param>
        /// <param name="jobId">todo: describe jobId parameter on GetRecruiterTalentMessages</param>
        /// <param name="talentId">todo: describe talentId parameter on GetRecruiterTalentMessages</param>
        /// <returns></returns>
        [HttpGet]
        [Route("recruiter/jobs/{jobId}/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetRecruiterTalentMessages(int userId, int jobId, int talentId)
        {
            if (jobId < 1 || talentId < 1)
            {
                return BadRequest(new { message = "input parameter is missing" });
            }

            var messages = await _messageRepository.GetRecruiterTalentMessageAsync(userId, talentId, jobId);

            if (messages != null && messages.Messages.Count > 0)
            {
                return Ok(messages);
            }
            else
            {
                return NotFound();
            }
        }

        /// <summary>
        /// This action is use to get messages between FTC admin and recruiter
        /// </summary>
        /// <param name="userId">model binding: logged in user id</param>
        /// <returns></returns>
        [HttpGet]
        [Route("recruiter/admin")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetRecruiterAdminMessages(int userId)
        {

            var messages = await _messageRepository.GetRecruiterAdminMessageAsync(userId);

            if (messages != null && messages.Messages.Any())
            {
                return Ok(messages);
            }
            else
            {
                return NotFound();
            }
        }


        /// <summary>
        /// This action is use to recruiter job collection
        /// </summary>
        /// <param name="userId">model binding: logged in user id</param>
        /// <returns></returns>
        [HttpGet]
        [Route("recruiter/jobs")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetRecruiterJobList(int userId)
        {
            var messages = await _messageRepository.GetRecruiterJobListAsync(userId);
            return Ok(messages);

        }

        [HttpGet]
        [Route("admin/recruiters")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetAdminRecruiterlist(int userId, UserInfo userInfo)
        {
            var list = await _messageRepository.GetAdminRecruiterListAsync(userId);
            if (list !=null && list.Count > 0)
            {
                dynamic message = new ExpandoObject();
                message.list = list;
                message.Id = userId;
                message.profileUrl = userInfo.ProfileUrl;
                message.totalUnreadMessages = list.AsEnumerable().Sum(o => o.TotalUnreadMessages);
                message.fullName = userInfo.FullName;

                return Ok(message);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("admin/talents")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetAdminTalentlist(int userId, UserInfo userInfo)
        {
            var list = await _messageRepository.GetAdminTalentListAsync(userId);

            if (list !=null && list.Count > 0)
            {
                dynamic message = new ExpandoObject();
                message.list = list;
                message.Id = userId;
                message.profileUrl = userInfo.ProfileUrl;
                message.totalUnreadMessages = list.AsEnumerable().Sum(o => o.TotalUnreadMessages);
                message.fullName = userInfo.FullName;
                return Ok(message);
            }
            else
            {
                return NotFound();
            }
        }


        [HttpGet]
        [Route("admin/recruiters/{recruiterId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetAdminRecruiterMessage(int userId, int recruiterId)
        {
            var messages = await _messageRepository.GetAdminRecruiterMessage(userId, recruiterId);
            if (messages.Count > 0)
            {
                return Ok(messages);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("admin/talents/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetAdminTalentMessage(int userId, int talentId)
        {
            var messages = await _messageRepository.GetAdminTalentMessage(userId, talentId);

            if (messages.Count > 0)
            {
                return Ok(messages);
            }
            else
            {
                return NotFound();
            }
        }

        #endregion
    }
}
