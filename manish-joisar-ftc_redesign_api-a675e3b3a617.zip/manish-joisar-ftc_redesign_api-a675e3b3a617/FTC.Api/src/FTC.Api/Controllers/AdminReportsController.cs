﻿using FTC.Api.Filters;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.AdminReports;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class AdminReportsController : Controller
    {
        private ITalentRepository _talentRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IContestRepository _contestRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        
        private IAdminReportsRepository _adminReportsRepository;

        private const string constantGoogle = "Google";
        private const string constantFaceBook = "Facebook";
        private const string constantSocial = "Social";

        public AdminReportsController(ITalentRepository talentRepository,
                                        IAuxiliaryUserRepository auxiliaryUserRepository,
                                        IContestRepository contestRepository,
                                        IProjectRepository projectRepository,
                                        IProjectJobRepository projectJobRepository,
                                        IAdminReportsRepository adminReportsRepository                                        
                                        )
        {
            _talentRepository = talentRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _contestRepository = contestRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _adminReportsRepository = adminReportsRepository;
        }

        [Route("Talents")]
        [HttpPost]
        public async Task<ActionResult> Talents()
        {
            var countries = _talentRepository.GetCountryCount();
            var talentCategories = _talentRepository.GetTalentRatio();
            var interestCategories = _talentRepository.GetInterestRatio();
            var genderCount = _talentRepository.GetGenderCount();
            return Json(new { TalentCategories = talentCategories, InterestCategories = interestCategories, GenderCount = genderCount, Countries = countries });
        }

        [Route("dailyStats")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        [HttpPost]
        public async Task<IActionResult> GetDailyStats([FromBody]DailyStats requestParam)
        {
            var newTalent = await _adminReportsRepository.GetNewTalents(requestParam);

            var newTalentRespone = newTalent.OrderByDescending(x => x.CreatedOn).GroupBy(x => x.CreatedOn.Date).Select(x => new { Date = x.Key, Count = x.Distinct().Count() }).ToList();

            var newRecruiter = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                    && x.CreatedOn.Date >= requestParam.FromDate.Date && x.CreatedOn.Date <= requestParam.ToDate.Date);
            var newRecruiterRespone = newRecruiter.OrderByDescending(x => x.CreatedOn).GroupBy(x => x.CreatedOn.Date).Select(x => new { Date = x.Key, Count = x.Distinct().Count() }).ToList();

            var contest = await _contestRepository.FindAllAsync(x => x.CreatedOn.Date >= requestParam.FromDate.Date && x.CreatedOn.Date <= requestParam.ToDate.Date);
            var contestRespone = contest.OrderByDescending(x => x.CreatedOn).GroupBy(x => x.CreatedOn.Date).Select(x => new { Date = x.Key, Count = x.Distinct().Count() }).ToList();

            var project = await _projectRepository.FindAllAsync(x => x.CreatedOn.Date >= requestParam.FromDate.Date && x.CreatedOn.Date <= requestParam.ToDate.Date);
            var projectRespone = project.OrderByDescending(x => x.CreatedOn).GroupBy(x => x.CreatedOn.Date).Select(x => new { Date = x.Key, Count = x.Distinct().Count() }).ToList();

            var projectJob = await _projectJobRepository.FindAllAsync(x => x.CreatedOn.Date >= requestParam.FromDate.Date && x.CreatedOn.Date <= requestParam.ToDate.Date);
            var projectJobRespone = projectJob.OrderByDescending(x => x.CreatedOn).GroupBy(x => x.CreatedOn.Date).Select(x => new { Date = x.Key, Count = x.Distinct().Count() }).ToList();

            var profile = await _talentRepository.FindAllAsync(x => x.UpdatedOn.Date >= requestParam.FromDate.Date && x.UpdatedOn.Date <= requestParam.ToDate.Date);
            var profileRespone = profile.OrderByDescending(x => x.CreatedOn).GroupBy(x => x.UpdatedOn.Date).Select(x => new { Date = x.Key, Count = x.Distinct().Count() }).ToList();
                        
            var newTalentRegistrationListRespone = newTalent.OrderByDescending(x => x.CreatedOn)
                                                            .GroupBy(x => x.CreatedOn.Date)
                                                            .Select(x => new
                                                            {
                                                                Date = x.Key,
                                                                Count = x.Distinct().Count(),
                                                                WithUID = x.Distinct().Count(y => y.UID != null),
                                                                WithoutUID = x.Distinct().Count(y => y.UID == null),

                                                                SocialLoginCount = x.Distinct()
                                                                                    .Count(tt => tt.LoginType == constantGoogle
                                                                                                || tt.LoginType == constantSocial
                                                                                                || tt.LoginType == constantFaceBook),

                                                                WithUIDSocialLogin = x.Distinct()
                                                                                      .Count(y => y.UID != null
                                                                                                  && (y.LoginType == constantGoogle
                                                                                                        || y.LoginType == constantSocial
                                                                                                        || y.LoginType == constantFaceBook)),

                                                                WithoutUIDSocialLogin = x.Distinct()
                                                                                         .Count(y => y.UID == null
                                                                                                     && (y.LoginType == constantGoogle
                                                                                                                || y.LoginType == constantSocial
                                                                                                                || y.LoginType == constantFaceBook))
                                                           
                                                            })
                                                            .ToList();

            var allTalentsCount = await _talentRepository.CountAsync();

            var reportSummary = new
            {
                Talent = newTalent.Count(),
                newRecruiter = newRecruiter.Count(),
                contest = contest.Count(),
                project = project.Count(),
                projectJob = projectJob.Count(),
                profile = profile.Count()
            };

            return Json(new
            {
                Talent = newTalentRespone,
                Recruiter = newRecruiterRespone,
                Contest = contestRespone,
                Project = projectRespone,
                ProjectJob = projectJobRespone,
                Profile = profileRespone,
                newTalentRegistrationList = newTalentRegistrationListRespone,
                allTalentsCount = allTalentsCount,
                ReportSummary = reportSummary
            });
        }
    }
}
