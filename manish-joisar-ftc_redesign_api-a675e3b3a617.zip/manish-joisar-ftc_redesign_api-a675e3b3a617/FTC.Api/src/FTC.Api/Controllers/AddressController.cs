﻿using FTCApi.Core.RepositoryInterface;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class AddressController : Controller
    {
        private IAddressRepository _addressRepository;
        public AddressController(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }

        [HttpGet]
        public async Task<ActionResult> Get()
        {
            var address = await _addressRepository.GetAllAsync();
            return Json(address);
        }

    }
}
