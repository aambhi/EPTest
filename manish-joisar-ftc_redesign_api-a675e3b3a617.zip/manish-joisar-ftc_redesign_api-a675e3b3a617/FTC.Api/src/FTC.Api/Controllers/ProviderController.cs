﻿using FTC.Api.Filters;
using FTCApi.Core.Models.Provider;
using FTCApi.Core.RepositoryInterface;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("[controller]")]
    public class ProviderController : Controller
    {
        #region Private Variables

        private IProviderRepository _providerRepository;

        #endregion

        #region Public Action Methods

        /// <summary>
        /// This method is use to authenticate based on SubscriberId.
        /// </summary>
        /// <param name="providerDetails"></param>
        /// <param name="userId">todo: describe userId parameter on AuthenticateAsync</param>
        /// <returns></returns>
        [HttpPost]
        [Route("authenticate")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin,TalentManager")]
        public async Task<IActionResult> AuthenticateAsync(int userId, [FromBody]ProviderDetails providerDetails)
        {
            ProviderResponse response = null;

            if (providerDetails ==null || string.IsNullOrWhiteSpace(providerDetails.SubscriberId))
            {
                return BadRequest();
            }
            providerDetails.TalentId = userId;
            response = await _providerRepository.Authenticate(providerDetails);

            if (response == null)
            {
                return NotFound();
            }
            else
            {
                if (!response.IsValid)
                {
                    return NotFound(response);
                }
            }

            return Ok(response);
        }

        /// <summary>
        /// This method returns list of subscriptions based on rmn number
        /// </summary>
        /// <param name="rmn">todo: describe rmn parameter on GetSubscriptions</param>
        /// <param name="providerId">todo: describe providerId parameter on GetSubscriptions</param>
        /// <param name="contestId">todo: describe contestId parameter on GetSubscriptions</param>
        /// <returns></returns>
        [HttpGet]
        [Route("subscriptions")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin,TalentManager")]
        public async Task<IActionResult> GetSubscriptions(string rmn, int providerId, int contestId)
        {
            if (string.IsNullOrWhiteSpace(rmn))
            {
                return BadRequest();
            }

            var subscriptions = await _providerRepository.GetSubscriptions(rmn, contestId, providerId);

            if (subscriptions==null)
            {
                return NotFound();
            }

            return Ok(subscriptions);
        }

        /// <summary>
        /// This method returns list of subscriptions based on rmn number
        /// </summary>
        /// <param name="providerDetails">todo: describe providerDetails parameter on GetSubscriptions</param>
        /// <param name="userId">todo: describe userId parameter on GetSubscriptions</param>
        /// <returns></returns>
        [HttpPost]
        [Route("subscriptions")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin,TalentManager")]
        public async Task<IActionResult> GetSubscriptions(int userId,[FromBody]ProviderDetails providerDetails)
        {
            if (providerDetails ==null || string.IsNullOrWhiteSpace(providerDetails.rmn))
            {
                return BadRequest();
            }
            providerDetails.TalentId = userId;
            var subscriptions = await _providerRepository.GetSubscriptions(providerDetails.rmn, providerDetails.ContestId, providerDetails.ProviderId);

            if (subscriptions == null)
            {
                return NotFound();
            }

            return Ok(subscriptions);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerDetails"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("dummyProvider")]
        public async Task<IActionResult> DummyProviderAsync([FromBody]ProviderDetails providerDetails)
        {
            ProviderResponse response = null;

            if (providerDetails ==null || string.IsNullOrWhiteSpace(providerDetails.SubscriberId))
            {
                return BadRequest();
            }

            response = await _providerRepository.CheckProvider(providerDetails.SubscriberId);

            return Ok(response);
        }

        #endregion

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="providerRepository"></param>
        public ProviderController(IProviderRepository providerRepository)
        {
            _providerRepository = providerRepository;
        }

        #endregion
    }
}
