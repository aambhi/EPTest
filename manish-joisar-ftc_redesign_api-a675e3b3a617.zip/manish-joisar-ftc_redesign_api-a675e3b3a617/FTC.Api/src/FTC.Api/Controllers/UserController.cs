﻿using FTCApi.Core.RepositoryInterface;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class UserController : Controller
    {
        private IUserRepository _userRepository;
        
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        // GET: api/values
        [HttpGet]
        public async Task<ActionResult> Get()
        {
            var user = await _userRepository.GetAllAsync();
            return Json(user);
        }
    }
}
