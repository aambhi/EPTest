﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class AuxiliaryUserController : Controller
    {
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IRecruiterInfoRepository _recruiterInfoRepository;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private IStatusRepository _statusRepository;
        private IUserRepository _userRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private IEmailService _emailService;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IContestRepository _contestRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private const string constantActivated = "Activated";
        private IContestStatusHistoryRepository _contestStatusHistoryRepository;
        private IAuxiliaryUserStatusHistoryRepository _auxiliaryUserStatusHistoryRepository;

        public AuxiliaryUserController(IAuxiliaryUserRepository auxiliaryUserRepository,
                                       INotificationDetailRepository notificationDetailRepository,
                                       INotificationHeaderRepository notificationHeaderRepository,
                                       IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository,
                                       Microsoft.Extensions.Configuration.IConfiguration configuration,
                                       IRecruiterInfoRepository recruiterInfoRepository,
                                       IUserNotificationRepository userNotificationRepository,
                                       IEmailService emailService,
                                       IUserRepository userRepository, IStatusRepository statusRepository,
                                       IProjectRepository projectRepository,
                                       IProjectJobRepository projectJobRepository,
                                       IContestRepository contestRepository,
                                       IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository, ISmsProviderRepository smsProviderRepository,
                                       IContestStatusHistoryRepository contestStatusHistoryRepository,
                                       IAuxiliaryUserStatusHistoryRepository auxiliaryUserStatusHistoryRepository)
        {
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _statusRepository = statusRepository;
            _userRepository = userRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _recruiterInfoRepository = recruiterInfoRepository;
            _configuration = configuration;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _userNotificationRepository = userNotificationRepository;
            _emailService = emailService;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _contestRepository = contestRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _smsProviderRepository = smsProviderRepository;
            _contestStatusHistoryRepository = contestStatusHistoryRepository;
            _auxiliaryUserStatusHistoryRepository = auxiliaryUserStatusHistoryRepository;
        }


        #region Public Actions

        [HttpPost]
        [Route("GetRecruitersByStatus")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> GetRecruitersByStatus([FromBody]ManageRecruiterDto manageRecruiterDto, int userId)
        {
            int startIndex = (manageRecruiterDto.currentPage > 0) ? ((manageRecruiterDto.currentPage) * manageRecruiterDto.perPageRecords + 1) : manageRecruiterDto.currentPage;
            int endIndex = (manageRecruiterDto.currentPage > 0) ? (startIndex + manageRecruiterDto.perPageRecords) : manageRecruiterDto.perPageRecords;

            // Get Auxiliary user based on status filter
            var response = await GetAuxiliaryUserBasedOnStatus(manageRecruiterDto, userId);

            // apply search filter
            if (!string.IsNullOrEmpty(manageRecruiterDto.searchRecruiterKeyword))
            {
                response = response.Where(x => x.FullName.ToLower().Contains(manageRecruiterDto.searchRecruiterKeyword.ToLower())).ToList();
            }
            //pagination Response
            var totalCount = response.Count();
            response = response.Skip(startIndex - 1)
                                .Take(endIndex - startIndex)
                                .OrderBy(x => x.FullName)
                                .ToList();


            List<AuxiliaryUserSummaryDto> lstAuxiliaryUserSummaryDto = new List<AuxiliaryUserSummaryDto>();
            foreach (var auxiliaryUser in response)
            {
                AuxiliaryUserSummaryDto auxiliaryUserSummaryDto = new AuxiliaryUserSummaryDto();
                auxiliaryUserSummaryDto = await ConvertToAuxiliaryUserSummaryDto(auxiliaryUserSummaryDto, auxiliaryUser);
                lstAuxiliaryUserSummaryDto.Add(auxiliaryUserSummaryDto);
            }

            return Json(new { recruiterData = lstAuxiliaryUserSummaryDto, totalCount = totalCount });

        }

        [HttpGet]
        [Route("userById/{id}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> GetUserById(int id, int userId)
        {
            var user = await _auxiliaryUserRepository.FindAsync(x => x.Id == id);
            if (user != null)
            {
                // check if user is a child of a logged in user than only return data
                var checkAuthorization = user.ParentAuxiliaryUserId == userId;
                if (!checkAuthorization)
                    return Forbid();

                var auxialiryUserDto = await ConvertAuxiliaryUserModelToDto(user);

                return Json(auxialiryUserDto);
            }

            return NotFound();
        }


        private async Task<AuxiliaryUserDto> ConvertAuxiliaryUserModelToDto(AuxiliaryUser user)
        {
            return new AuxiliaryUserDto
            {
                Id = user.Id,
                FullName = user.FullName,
                EmailId = user.EmailId,
                Mobile = user.Mobile,
                StatusId = user.StatusId,
                Projects = GetProjects(user.AuxiliaryUserAssignedUaAuxiliaryUser),
                Jobs = GetJobs(user.AuxiliaryUserAssignedUaAuxiliaryUser),
                Recruiters = await GetRecruiters(user.AuxiliaryUserAssignedUaAuxiliaryUser),
                IsSystemAdmin = user.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.SystemAdmin).Count() > 0,
                IsProjectAdmin = user.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.ProjectAdmin || x.RoleId == (int)UserRole.FTCProjectAdmin).Count() > 0,
                IsTalentAdmin = user.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.TalentAdmin).Count() > 0,
                IsRecruiterAdmin = user.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.RecruiterAdmin).Count() > 0,
                IsJobAdmin = user.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.JobAdmin).Count() > 0,
            };
        }

        private async Task<List<AssignedDto>> GetRecruiters(ICollection<AuxiliaryUserAssigned> auxiliaryUserAssignedUaAuxiliaryUser)
        {
            var assignedJobs = new List<AssignedDto>();
            if (auxiliaryUserAssignedUaAuxiliaryUser != null && auxiliaryUserAssignedUaAuxiliaryUser.Where(x => x.JobId == null && x.ProjectId == null).Count() > 0)
            {
                var recruiters = auxiliaryUserAssignedUaAuxiliaryUser.Where(x => x.JobId == null && x.ProjectId == null).ToList();
                foreach (var recruiter in recruiters)
                {
                    //TODO: need to check the relation and change the code according to that
                    var user = await _auxiliaryUserRepository.FindAsync(x => x.Id == recruiter.AssignedAuxiliaryUserId.Value);
                    assignedJobs.Add(new AssignedDto
                    {
                        Id = recruiter.AssignedAuxiliaryUserId.Value,
                        Description = user.FullName
                    });
                }

            }
            return assignedJobs;
        }

        private List<AssignedDto> GetJobs(ICollection<AuxiliaryUserAssigned> auxiliaryUserAssignedUaAssignedAuxiliaryUser)
        {
            var assignedJobs = new List<AssignedDto>();
            if (auxiliaryUserAssignedUaAssignedAuxiliaryUser != null && auxiliaryUserAssignedUaAssignedAuxiliaryUser.Where(x => x.JobId != null).Count() > 0)
            {
                var jobs = auxiliaryUserAssignedUaAssignedAuxiliaryUser.Where(x => x.JobId != null).ToList();
                foreach (var job in jobs)
                {
                    assignedJobs.Add(new AssignedDto
                    {
                        Id = job.JobId.Value,
                        ProjectId = job.ProjectId.Value,
                        Description = job.Job.Project.Name + '-' + job.Job.Title
                    });
                }

            }
            return assignedJobs;
        }

        private List<AssignedDto> GetProjects(ICollection<AuxiliaryUserAssigned> auxiliaryUserAssignedUaAssignedAuxiliaryUser)
        {
            var assignedProjects = new List<AssignedDto>();
            if (auxiliaryUserAssignedUaAssignedAuxiliaryUser != null && auxiliaryUserAssignedUaAssignedAuxiliaryUser.Where(x => x.JobId == null && x.ProjectId != null).Count() > 0)
            {
                var projects = auxiliaryUserAssignedUaAssignedAuxiliaryUser.Where(x => x.JobId == null && x.ProjectId != null).ToList();
                foreach (var project in projects)
                {
                    assignedProjects.Add(new AssignedDto
                    {
                        Id = project.ProjectId.Value,
                        Description = project.Project.Name
                    });
                }

            }
            return assignedProjects;
        }

        /// <summary>
        /// post job
        /// </summary>
        [HttpPost]
        [Route("userCreate")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin ,Recruiter")]
        public async Task<IActionResult> Post([FromBody]AuxiliaryUserDto auxiliaryUserDto, int userId, int userType)
        {
            if (auxiliaryUserDto == null)
            {
                return BadRequest();
            }
            try
            {
                if (auxiliaryUserDto.Id > 0)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUserDto.Id);
                    auxiliaryUser = await UpdateAuxiliaryUserModel(userId, userType, auxiliaryUser, auxiliaryUserDto);
                    auxiliaryUser.UpdatedBy = userId;
                    auxiliaryUser.UpdatedOn = DateTime.UtcNow;
                    auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
                }
                else
                {
                    auxiliaryUserDto.Password = _recruiterInfoRepository.RandomString(16);
                    var auxiliaryUser = ConvertDtoToModel(auxiliaryUserDto, userId, userType);
                    auxiliaryUser.CreatedBy = userId;
                    auxiliaryUser.CreatedOn = DateTime.UtcNow;
                    var newAuxiliaryUser = await _auxiliaryUserRepository.AddAsync(auxiliaryUser);
                    Notification email = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
                    var notificationParam = new NotificationParam
                    {
                        Email = auxiliaryUser.EmailId,
                        AuxiliaryUserId = auxiliaryUser.Id,
                        FullName = auxiliaryUser.FullName,
                        UserPassword = auxiliaryUserDto.Password, //send the plain password in email
                        MobileCountryCode = auxiliaryUser.MobileCountryCode,
                        MobileNumber = auxiliaryUser.Mobile
                    };
                    var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                    if (userType == (int)LoginUserType.Recruiter)
                    {
                        await email.SendNotification(NotificationEnum.CreateRecruiter, notificationParam, sendSystemNotificationDto);
                    }
                    else
                    {
                        await email.SendNotification(NotificationEnum.CreateAdmin, notificationParam, sendSystemNotificationDto);
                    }

                    auxiliaryUserDto.Id = newAuxiliaryUser.Id;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return new JsonResult(auxiliaryUserDto);
        }

        private async Task<AuxiliaryUser> UpdateAuxiliaryUserModel(int userId, int userType, AuxiliaryUser auxiliaryUser, AuxiliaryUserDto auxiliaryUserDto)
        {
            auxiliaryUser.FullName = auxiliaryUserDto.FullName != null ? auxiliaryUserDto.FullName : auxiliaryUser.FullName;
            auxiliaryUser.EmailId = auxiliaryUserDto.EmailId != null ? auxiliaryUserDto.EmailId : auxiliaryUser.EmailId;
            auxiliaryUser.Mobile = auxiliaryUserDto.Mobile;
            auxiliaryUser.AuxiliaryUserAssignedUaAuxiliaryUser = await getAssignedProjectsAndJobs(userId, auxiliaryUser.AuxiliaryUserAssignedUaAssignedAuxiliaryUser, auxiliaryUserDto);
            auxiliaryUser.AuxiliaryUserRole = GetRoles(auxiliaryUserDto, userType);
            auxiliaryUser.StatusId = auxiliaryUserDto.StatusId;
            if (auxiliaryUserDto.StatusId == (int)StatusEnum.InActive)
                auxiliaryUser.AuthToken = string.Empty;
            return auxiliaryUser;
        }


        private async Task<ICollection<AuxiliaryUserAssigned>> getAssignedProjectsAndJobs(int userId, ICollection<AuxiliaryUserAssigned> auxiliaryUserAssignedUaAssignedAuxiliaryUser, AuxiliaryUserDto auxiliaryUserDto)
        {
            // get all the projectIds from UI
            var projectIds = auxiliaryUserDto.Projects.Select(x => x.Id).ToList();

            //get the jobIds from the UI
            var jobIds = auxiliaryUserDto.Jobs != null ? auxiliaryUserDto.Jobs.Select(x => x.Id).ToList() : null;

            //get the recruiterIDs from UI

            var recruiterIds = auxiliaryUserDto.Recruiters != null ? auxiliaryUserDto.Recruiters.Select(x => x.Id).ToList() : null;

            //get the previous projectIds and Job IDs
            var allAssignedProjectsAndJobs = await _auxiliaryUserAssignedRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryUserDto.Id);
            List<AuxiliaryUserAssigned> assignedProjects = allAssignedProjectsAndJobs.Where(x => x.JobId == null && x.ProjectId != null).ToList();
            List<AuxiliaryUserAssigned> assignedJobs = allAssignedProjectsAndJobs.Where(x => x.JobId != null && x.ProjectId != null).ToList();
            List<AuxiliaryUserAssigned> assignedRecruiters = allAssignedProjectsAndJobs.Where(x => x.JobId == null && x.ProjectId == null).ToList();

            //for projects
            if (assignedProjects != null && assignedProjects.Count() > 0)
            {
                var projectsToBeDeleted = assignedProjects.Where(x => !projectIds.Contains(x.ProjectId.Value));

                foreach (var projectToBDeleted in projectsToBeDeleted.ToList())
                {
                    assignedProjects.RemoveAll(x => x.Id == projectToBDeleted.Id);
                }
            }

            if (projectIds != null && projectIds.Count > 0)
            {
                foreach (var projectId in projectIds)
                {
                    var project = assignedProjects.Where(x => x.ProjectId == projectId).FirstOrDefault();
                    if (project == null)
                    {
                        var projectDto = auxiliaryUserDto.Projects.Where(x => x.Id == projectId).FirstOrDefault();

                        AuxiliaryUserAssigned userAssigned = new AuxiliaryUserAssigned();
                        userAssigned.AuxiliaryUserId = auxiliaryUserDto.Id;
                        userAssigned.AssignedAuxiliaryUserId = projectDto.RecruiterId > 0 ? projectDto.RecruiterId : userId; // if admin updates use RecruiterId else logged in user id
                        userAssigned.ProjectId = projectDto.Id;
                        assignedProjects.Add(userAssigned);
                    }

                }
            }

            //same for jobs
            if (assignedJobs != null && assignedJobs.Count() > 0)
            {
                var jobsToBeDeleted = assignedJobs.Where(x => !jobIds.Contains(x.JobId.Value));

                foreach (var jobToBeDeleted in jobsToBeDeleted.ToList())
                {
                    assignedJobs.RemoveAll(x => x.Id == jobToBeDeleted.Id);
                }
            }

            if (jobIds != null && jobIds.Count > 0)
            {
                foreach (var jobId in jobIds)
                {
                    var job = assignedJobs.Where(x => x.JobId == jobId).FirstOrDefault();
                    if (job == null)
                    {
                        AuxiliaryUserAssigned userAssigned = new AuxiliaryUserAssigned();
                        userAssigned.AuxiliaryUserId = auxiliaryUserDto.Id;
                        userAssigned.AssignedAuxiliaryUserId = userId;
                        userAssigned.JobId = auxiliaryUserDto.Jobs.Where(x => x.Id == jobId).FirstOrDefault().Id;
                        userAssigned.ProjectId = auxiliaryUserDto.Jobs.Where(x => x.Id == jobId).FirstOrDefault().ProjectId;
                        assignedJobs.Add(userAssigned);
                    }

                }
            }

            //same for recruiters
            if (assignedRecruiters != null && assignedRecruiters.Count() > 0)
            {
                var recruitersToBeDeleted = assignedRecruiters.Where(x => !recruiterIds.Contains(x.AssignedAuxiliaryUserId.Value));

                foreach (var recruiterToBeDeleted in recruitersToBeDeleted.ToList())
                {
                    assignedRecruiters.RemoveAll(x => x.Id == recruiterToBeDeleted.Id);
                }
            }

            if (recruiterIds != null && recruiterIds.Count > 0)
            {
                foreach (var recruiterId in recruiterIds)
                {
                    var recruiter = assignedRecruiters.Where(x => x.AssignedAuxiliaryUserId == recruiterId).FirstOrDefault();
                    if (recruiter == null)
                    {
                        AuxiliaryUserAssigned userAssigned = new AuxiliaryUserAssigned();
                        userAssigned.AuxiliaryUserId = auxiliaryUserDto.Id;
                        userAssigned.AssignedAuxiliaryUserId = recruiterId;
                        assignedJobs.Add(userAssigned);
                    }
                    else if (recruiter.Id != 0)
                    {
                        assignedJobs.Add(recruiter);
                    }

                }
            }

            //merge both list and return
            assignedProjects.AddRange(assignedJobs);

            return assignedProjects;
        }

        private AuxiliaryUser ConvertDtoToModel(AuxiliaryUserDto auxiliaryUserDto, int userId, int userType)
        {
            return new AuxiliaryUser
            {
                FullName = auxiliaryUserDto.FullName,
                EmailId = auxiliaryUserDto.EmailId,
                Mobile = auxiliaryUserDto.Mobile,
                ParentAuxiliaryUserId = userId,
                TypeId = userType,
                StatusId = (int)StatusEnum.Active,
                AuxiliaryUserAssignedUaAuxiliaryUser = getAssignedUsers(auxiliaryUserDto, userId),
                Password = BCrypt.Net.BCrypt.HashPassword(auxiliaryUserDto.Password, BCrypt.Net.BCrypt.GenerateSalt()),//need to change this
                AuxiliaryUserRole = GetRoles(auxiliaryUserDto, userType),
                AuxiliaryUserToken = new List<AuxiliaryUserToken>() { new AuxiliaryUserToken { Email = constantActivated, SMS = constantActivated } }
            };

        }

        private ICollection<AuxiliaryUserRole> GetRoles(AuxiliaryUserDto auxiliaryUserDto, int userType)
        {
            var assignedRoles = new List<AuxiliaryUserRole>();

            if (auxiliaryUserDto.IsSystemAdmin == true)
            {
                assignedRoles.Add(new AuxiliaryUserRole
                {
                    RoleId = (int)UserRole.SystemAdmin,
                    CreatedOn = DateTime.Now,

                });
            }
            if (auxiliaryUserDto.IsTalentAdmin == true)
            {
                assignedRoles.Add(new AuxiliaryUserRole
                {
                    RoleId = (int)UserRole.TalentAdmin,
                    CreatedOn = DateTime.Now,

                });
            }
            if (auxiliaryUserDto.IsRecruiterAdmin == true)
            {
                assignedRoles.Add(new AuxiliaryUserRole
                {
                    RoleId = (int)UserRole.RecruiterAdmin,
                    CreatedOn = DateTime.Now,

                });
            }
            if (auxiliaryUserDto.IsProjectAdmin == true)
            {
                assignedRoles.Add(new AuxiliaryUserRole
                {
                    RoleId = userType == 1 ? (int)UserRole.ProjectAdmin : (int)UserRole.FTCProjectAdmin,
                    CreatedOn = DateTime.Now,

                });
            }

            if (auxiliaryUserDto.IsJobAdmin == true)
            {
                assignedRoles.Add(new AuxiliaryUserRole
                {
                    RoleId = (int)UserRole.JobAdmin,
                    CreatedOn = DateTime.Now,
                });
            }
            return assignedRoles;
        }

        private ICollection<AuxiliaryUserAssigned> getAssignedUsers(AuxiliaryUserDto auxiliaryUserDto, int userId)
        {
            //get all selected project first 
            var assignedUsers = new List<AuxiliaryUserAssigned>();

            if (auxiliaryUserDto.Projects != null && auxiliaryUserDto.Projects.Count > 0)
            {
                foreach (var project in auxiliaryUserDto.Projects)
                {
                    assignedUsers.Add(new AuxiliaryUserAssigned
                    {
                        AssignedAuxiliaryUserId = project.RecruiterId != 0 ? project.RecruiterId : userId,
                        CreatedOn = DateTime.Now,
                        ProjectId = project.Id
                    });
                }
            }

            //get all the selected jobs
            if (auxiliaryUserDto.Jobs != null && auxiliaryUserDto.Jobs.Count > 0)
            {
                foreach (var job in auxiliaryUserDto.Jobs)
                {
                    assignedUsers.Add(new AuxiliaryUserAssigned
                    {
                        AssignedAuxiliaryUserId = userId,
                        CreatedOn = DateTime.Now,
                        ProjectId = job.ProjectId,
                        JobId = job.Id

                    });
                }
            }

            //get all the selected recruiters
            if (auxiliaryUserDto.Recruiters != null && auxiliaryUserDto.Recruiters.Count > 0)
            {
                foreach (var recruiter in auxiliaryUserDto.Recruiters)
                {
                    assignedUsers.Add(new AuxiliaryUserAssigned
                    {
                        AssignedAuxiliaryUserId = recruiter.Id,
                        CreatedOn = DateTime.Now
                    });
                }
            }

            return assignedUsers;
        }

        [Route("verifyrecruiters")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> VerifyRecruiters([FromBody]List<int> recruiterIds, int userId)
        {
            foreach (var recruiterId in recruiterIds)
            {
                var recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == recruiterId);
                if (recruiter != null)
                {
                    recruiter.Verified = true;
                    recruiter.VerifiedOn = DateTime.UtcNow;
                    recruiter.VerifiedBy = userId;
                    recruiter.StatusId = (int)StatusEnum.Active;
                    recruiter = await _auxiliaryUserRepository.UpdateAsync(recruiter);

                    #region Send Notification

                    await NotifyRecruiterVerification(userId, recruiter);

                    #endregion
                }
                else
                {
                    return BadRequest(new { error = "false" });
                }
            }
            return Ok(new { verified = "true" });
        }

        private async Task NotifyRecruiterVerification(int userId, AuxiliaryUser recruiter)
        {
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                FullName = recruiter.FullName,
                AuxiliaryUserId = userId
            };
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto()
            {
                // Notify to Only FTC Su,Sys,RA
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(userId, userId),
                NotificationReference = NotificationReferenceEnum.ReferenceAuxiliaryUserId,
                NotificationReferenceValue = recruiter.Id,
                UrlRoute = ViewNotificationEnumDto.EditRecruiter
            };

            // send email to recruiter also
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Add(recruiter.Id);


            // Send Email to list of Auxiliary Users When a Recruiter is Verified
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            await notification.SendNotification(NotificationEnum.VerifyRecruiter, notificationParam, sendSystemNotificationDto);
        }

        [Route("getAxiliaryUsers")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<ActionResult> GetAuxiliaryUsers(int userId)
        {
            var auxiliaryUsers = await _auxiliaryUserRepository.GetAllUsers(userId);
            var auxiliaryUserDtoList = ConvertToAuxiliaryUserDto(auxiliaryUsers);
            return Json(auxiliaryUserDtoList);
        }



        /// <summary>
        /// Block Recruiter by admin
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("block/{id}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> BlockAuxiliaryUser(int id, UserInfo userInfo)
        {
            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == id);

            if (auxiliaryUser == null)
            {
                return NotFound();
            }

            if (auxiliaryUser.StatusId == (int)StatusEnum.Blocked)
            {
                auxiliaryUser.StatusId = (int)StatusEnum.Verified;
                auxiliaryUser.Verified = true;
            }
            else
            {
                auxiliaryUser.StatusId = (int)StatusEnum.Blocked;
                auxiliaryUser.AuthToken = "";

                //find all project, job, contest - & change status to block
                var projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == id);
                foreach (var project in projects)
                {
                    project.StatusId = (int)StatusEnum.Close;
                    await _projectRepository.UpdateAsync(project);
                }

                if (projects != null)
                {
                    var lstProjectId = projects.Select(x => x.Id).ToList();

                    var jobs = await _projectJobRepository.FindAllAsync(x => lstProjectId.Contains(x.ProjectId));
                    foreach (var job in jobs)
                    {
                        job.StatusId = (int)StatusEnum.Close;
                        await _projectJobRepository.UpdateAsync(job);
                    }
                }

                var contests = await _contestRepository.FindAllAsync(x => x.AuxiliaryUserId == id);
                foreach (var contest in contests)
                {
                    contest.StatusId = (int)StatusEnum.Close;
                    await _contestRepository.UpdateAsync(contest);
                }

            }

            auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);

            #region AuxiliaryUserStatusHistory [Recruiter: block, unblock] Verifed and Blocked By Whom

            var auxiliaryUserStatusHistory = new AuxiliaryUserStatusHistory()
            {
                CreatedBy = userInfo.userId,
                AuxiliaryUserId = auxiliaryUser.Id,
                StatusId = auxiliaryUser.StatusId
            };

            await _auxiliaryUserStatusHistoryRepository.AddAsync(auxiliaryUserStatusHistory);

            #endregion

            return Json(new { Id = auxiliaryUser.Id, fullName = auxiliaryUser.FullName, StatusId = (StatusEnum)auxiliaryUser.StatusId });
        }

        [Route("validateUserAgainstProjects/{projectIds}/{auxiliaryUserId}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter")]
        //here we are using id instead of userid as userid we are getting from filter and id we are getting from screen.
        public async Task<List<ProjectValidityDto>> ValidateUserAgainstProject(string projectIds, int auxiliaryUserId)
        {
            var separated = projectIds.Split(new char[] { ',' });
            List<int> Ids = separated.Select(s => int.Parse(s)).ToList();
            var projectValidityDtoList = new List<ProjectValidityDto>();

            foreach (var projectId in Ids)
            {
                var project = await _projectRepository.FindAsync(x => x.Id == projectId);
                if (project != null && project.Plan != null)
                {
                    //total users allowed
                    var totalUsers = project.Plan.NumberOfUsers;
                    //number of users created
                    var numberOfUsersCreated = await _auxiliaryUserAssignedRepository.FindAllAsync(x => x.ProjectId == projectId && x.AuxiliaryUserId != auxiliaryUserId && x.AuxiliaryUserId != null);
                    if (totalUsers <= numberOfUsersCreated.Count())
                    {
                        ProjectValidityDto projectValidityDto = new ProjectValidityDto
                        {
                            Id = project.Id,
                            ProjectName = project.Name,
                            TotalUsers = project.Plan.NumberOfUsers.Value,
                            NumberOfUsersCreated = numberOfUsersCreated.Count()
                        };
                        projectValidityDtoList.Add(projectValidityDto);
                    }
                }
            }
            return projectValidityDtoList;
        }

        #endregion

        #region Private Methods

        private List<AuxiliaryUserDto> ConvertToAuxiliaryUserDto(List<AuxiliaryUser> auxiliaryUsers)
        {
            List<AuxiliaryUserDto> auxiliaryUserDtoList = new List<AuxiliaryUserDto>();
            foreach (var auxiliaryUser in auxiliaryUsers)
            {
                auxiliaryUserDtoList.Add(new AuxiliaryUserDto()
                {
                    Id = auxiliaryUser.Id,
                    FullName = auxiliaryUser.FullName,
                    StatusId = auxiliaryUser.StatusId,
                    CreatedOn = auxiliaryUser.CreatedOn,
                    Roles = getRoles(auxiliaryUser)
                });
            }
            return auxiliaryUserDtoList;
        }

        private string getRoles(AuxiliaryUser auxiliaryUser)
        {
            var roles = new List<string>();

            if (auxiliaryUser.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.SystemAdmin).Count() > 0)
                roles.Add("System Admin");

            if (auxiliaryUser.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.ProjectAdmin || x.RoleId == (int)UserRole.FTCProjectAdmin).Count() > 0)
                roles.Add("Project Admin");

            if (auxiliaryUser.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.JobAdmin).Count() > 0)
                roles.Add("Job Admin");

            if (auxiliaryUser.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.TalentAdmin).Count() > 0)
                roles.Add("Talent Admin");

            if (auxiliaryUser.AuxiliaryUserRole.Where(x => x.RoleId == (int)UserRole.RecruiterAdmin).Count() > 0)
                roles.Add("Recruiter Admin");

            return string.Join(",", roles);
        }

        [NonAction]
        private async Task<IEnumerable<AuxiliaryUser>> GetAuxiliaryUserBasedOnStatus(ManageRecruiterDto manageRecruiterDto, int userId)
        {
            //var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);

            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin, isFtcRecruiterAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);


            var lstAuxiliaryUser = new List<AuxiliaryUser>();
            if (isFtcProjectAdmin || isFtcRecruiterAdmin)
            {
                var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);
                var auxiliaryUserResponse = await _auxiliaryUserRepository.FindAllAsync(x => assignedRecruiters.Contains(x.Id)
                                                                                            && x.TypeId == (int)LoginUserType.Recruiter
                                                                                            && x.ParentAuxiliaryUserId == null);
                lstAuxiliaryUser = auxiliaryUserResponse.ToList();
            }
            else
            {
                var auxiliaryUserResponse = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter && x.ParentAuxiliaryUserId == null);
                lstAuxiliaryUser = auxiliaryUserResponse.ToList();
            }

            if (manageRecruiterDto.status != RecruiterStatusEnum.All)
            {
                //auxiliaryUserResponse = auxiliaryUserResponse.Where(x => assignedRecruiters.Contains(x.Id) && x.TypeId == (int)LoginUserType.Recruiter);                
                if (manageRecruiterDto.status == RecruiterStatusEnum.NotVerified)
                {
                    lstAuxiliaryUser = lstAuxiliaryUser.Where(x => x.Verified == false).ToList();
                }
                else
                {
                    lstAuxiliaryUser = lstAuxiliaryUser.Where(x => x.Verified == true).ToList();
                }
            }

            return lstAuxiliaryUser;
        }

        [NonAction]
        private async Task<AuxiliaryUserSummaryDto> ConvertToAuxiliaryUserSummaryDto(AuxiliaryUserSummaryDto auxiliaryUserSummaryDto, AuxiliaryUser auxiliaryUser)
        {
            auxiliaryUserSummaryDto.Id = auxiliaryUser.Id;
            auxiliaryUserSummaryDto.FullName = auxiliaryUser.FullName;
            auxiliaryUserSummaryDto.CreatedOn = auxiliaryUser.CreatedOn;
            auxiliaryUserSummaryDto.UpdatedOn = auxiliaryUser.UpdatedOn;
            auxiliaryUserSummaryDto.Verified = auxiliaryUser.Verified;
            auxiliaryUserSummaryDto.VerifiedBy = auxiliaryUser.VerifiedBy;
            auxiliaryUserSummaryDto.TypeId = auxiliaryUser.TypeId;
            auxiliaryUserSummaryDto.StatusId = auxiliaryUser.StatusId;
            auxiliaryUserSummaryDto.IsBlocked = (auxiliaryUser.StatusId == (int)StatusEnum.Blocked) ? true : false;

            if (auxiliaryUser.StatusId != null)
            {
                var statusResponse = await _statusRepository.FindAsync(x => x.Id == auxiliaryUser.StatusId);
                auxiliaryUserSummaryDto.StatusDescription = (statusResponse != null) ? statusResponse.Description : "";
            }



            return auxiliaryUserSummaryDto;
        }
        #endregion
    }

    public class ProjectValidityDto
    {
        public int Id { get; set; }
        public string ProjectName { get; set; }
        public int TotalUsers { get; set; }
        public int NumberOfUsersCreated { get; set; }
    }
}
