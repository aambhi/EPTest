﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.DashboardDtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.JobAuditionsDtos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    public class RecuiterDashboardController : Controller
    {
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private ITalentJobRepository _talentJobRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;

        public RecuiterDashboardController(IAuxiliaryUserRepository auxiliaryUserRepository,
                                            IProjectRepository projectRepository,
                                            IProjectJobRepository projectJobRepository,
                                            ITalentJobRepository talentJobRepository,
                                            IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
                                            IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository)
        {
            _projectRepository = projectRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _projectJobRepository = projectJobRepository;
            _talentJobRepository = talentJobRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
        }

        #region Public Actions
        [HttpGet]
        [Route("recruiter/dashboard")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter")]
        public async Task<IActionResult> GetDashboardSummary(UserInfo userInfo)
        {
            int recruiterId = userInfo.userId;


            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);


            IEnumerable<Project> projects = default(IEnumerable<Project>);

            Dictionary<int?, bool> assignedProjects = default(Dictionary<int?, bool>);

            // GET projects of the logged in user as well as the parent recruiter if any
            if (isJobAdmin)
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjectsForJobAmin(userInfo.userId);
                projects = await _projectRepository.FindAllAsync(x => assignedProjects.ContainsKey(x.Id));
            }
            else
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId);
                projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId || assignedProjects.ContainsKey(x.Id));
            }


            if (projects.Count() == 0)
            {
                return NotFound();
            }
            var lstProjectId = projects.Select(p => p.Id).ToList();
            var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userInfo.userId);

            IEnumerable<ProjectJob> projectJobs = default(IEnumerable<ProjectJob>);
            if (isJobAdmin)
            {
                projectJobs = await _projectJobRepository.FindAllAsync(x => assignedProjectJobs.Contains(x.Id));
            }
            else
            {
                projectJobs = await _projectJobRepository.FindAllAsync(x => lstProjectId.Contains(x.ProjectId) || assignedProjectJobs.Contains(x.Id));
            }



            //create a reponse structure
            var recruiterDashboardSummary = new RecruiterDashboardSummaryDto();
            recruiterDashboardSummary = ConvertToDashboardSummaryDto(projects, projectJobs, recruiterDashboardSummary);

            // order based on createdOn date
            // TOP 3 recent images only
            projects = projects.OrderByDescending(x => x.CreatedOn).Take(3);

            var recentProjectImages = new List<ProjectImageDto>();
            foreach (var project in projects)
            {
                var projectImageDto = new ProjectImageDto();
                projectImageDto.ProjectId = project.Id;
                projectImageDto.Image = project.Image;
                projectImageDto.ProjectName = project.Name;
                recentProjectImages.Add(projectImageDto);
            }
            recruiterDashboardSummary.RecentProjectImages = recentProjectImages;

            return Ok(new { recruiterDashboardSummary = recruiterDashboardSummary });

        }

        [HttpPost]
        [Route("recruiter/dashboard/projects")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter")]
        public async Task<IActionResult> GetDashboardProjects([FromBody]RequestProjectParamDto requestProjectParams, UserInfo userInfo)
        {
            int recruiterId = userInfo.userId;

            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);



            Dictionary<int?, bool> assignedProjects = default(Dictionary<int?, bool>);

            IEnumerable<Project> projects = default(IEnumerable<Project>);
            if (isJobAdmin)
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjectsForJobAmin(userInfo.userId);
                projects = await _projectRepository.FindAllAsync(x => assignedProjects.ContainsKey(x.Id));
            }
            else
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId);
                projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId || assignedProjects.ContainsKey(x.Id));
            }


            var lstProjects = projects.ToList();

            #region  Search the given project or Get projects for the recruiter
            if (!string.IsNullOrEmpty(requestProjectParams.SearchProject))
            {
                lstProjects = lstProjects.Where(x => x.Name.ToLower().Contains(requestProjectParams.SearchProject.ToLower())).ToList();
            }
            #endregion

            if (lstProjects.Count == 0)
            {
                return NotFound();
            }

            int startIndex = (requestProjectParams.ProjectCurrentPage > 0) ? ((requestProjectParams.ProjectCurrentPage) * requestProjectParams.ProjectPerPageRecords + 1) : requestProjectParams.ProjectCurrentPage;
            int endIndex = (requestProjectParams.ProjectCurrentPage > 0) ? (startIndex + requestProjectParams.ProjectPerPageRecords) : requestProjectParams.ProjectPerPageRecords;

            var totalProjectCount = lstProjects.Count();
            lstProjects = lstProjects.OrderBy(x => x.Name).Skip(startIndex - 1).Take(endIndex - startIndex).ToList();



            var lstRecruiterProjectSummaryDto = new List<ProjectSummaryDto>();
            var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userInfo.userId);

            foreach (var project in lstProjects)
            {
                var recruiterProjectSummaryDto = new ProjectSummaryDto();
                recruiterProjectSummaryDto.ProjectId = project.Id;
                recruiterProjectSummaryDto.ProjectName = project.Name;

                IEnumerable<ProjectJob> projectJob = default(IEnumerable<ProjectJob>);
                if (isJobAdmin)
                {
                    projectJob = await _projectJobRepository.FindAllAsync(x => assignedProjectJobs.Contains(x.Id));
                }
                else
                {
                    projectJob = await _projectJobRepository.FindAllAsync(x => x.ProjectId == project.Id || assignedProjectJobs.Contains(x.Id));  //query proj job with proId and get its status
                }


                //var projectJob = await _projectJobRepository.FindAllAsync(x => x.ProjectId == project.Id || assignedProjectJobs.Contains(x.Id)); 

                if (projectJob != null)
                {
                    recruiterProjectSummaryDto.ActiveJobs = projectJob.Where(x => x.StatusId == (int)StatusEnum.Active && x.EndDate >= DateTime.Now.Date).Count();
                    recruiterProjectSummaryDto.ClosedJobs = projectJob.Where(x => x.StatusId == (int)StatusEnum.Close || x.EndDate < DateTime.Now.Date).Count();
                    recruiterProjectSummaryDto.UnderVerification = projectJob.Where(x => x.StatusId == (int)StatusEnum.Draft && x.EndDate >= DateTime.Now.Date).Count();
                }

                lstRecruiterProjectSummaryDto.Add(recruiterProjectSummaryDto);
            }

            #region Jobs Statistics
            var lstProjectJobSummaryDto = new List<ProjectJobSummaryDto>();


            var projectId = lstProjects.First().Id;

            //var projectJobResponse = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId || assignedProjectJobs.Contains(x.Id));

            // show list of jobs for the first project in the list only if he has rights for it
            var lstProjectJobs = new List<ProjectJob>();

            if (isJobAdmin)
            {
                var projectJobResponse = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId && assignedProjectJobs.Contains(x.Id));
                lstProjectJobs = projectJobResponse.ToList();
            }
            else
            {
                var projectJobResponse = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId);
                lstProjectJobs = projectJobResponse.ToList();
            }





            int startIndexProjectJob = (requestProjectParams.ProjectJobCurrentPage > 0) ? ((requestProjectParams.ProjectJobCurrentPage) * requestProjectParams.ProjectJobPerPageRecords + 1) : requestProjectParams.ProjectJobCurrentPage;
            int endIndexProjectJob = (requestProjectParams.ProjectJobCurrentPage > 0) ? (startIndexProjectJob + requestProjectParams.ProjectJobPerPageRecords) : requestProjectParams.ProjectJobPerPageRecords;


            var totalProjectJobCount = lstProjectJobs.Count();
            lstProjectJobs = lstProjectJobs.OrderBy(x => x.Title).Skip(startIndexProjectJob - 1).Take(endIndexProjectJob - startIndexProjectJob).ToList();


            foreach (var projectJobSummary in lstProjectJobs)
            {
                var projectJobSummaryDto = new ProjectJobSummaryDto();
                projectJobSummaryDto.Id = projectJobSummary.Id;
                projectJobSummaryDto.Title = projectJobSummary.Title;
                projectJobSummaryDto.StatusDescription = ((StatusEnum)projectJobSummary.StatusId).ToString();
                projectJobSummaryDto.StatusId = (StatusEnum)projectJobSummary.StatusId;

                var talentJob = await _talentJobRepository.FindAllAsync(x => x.JobId == projectJobSummary.Id);
                if (talentJob != null)
                {
                    projectJobSummaryDto.UnderReview = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.UnderReview).Count();
                    projectJobSummaryDto.NotSelected = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.NotSelected).Count();
                    projectJobSummaryDto.SelectedForAudition = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition).Count();
                    projectJobSummaryDto.Shortlisted = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.Shortlisted).Count();
                    projectJobSummaryDto.Casted = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.Cast).Count();

                }

                // Find REcommended count for each job
                // jobAuditionsRequest -> jobId
                var jobAuditionsRequest = new JobAuditionsRequest()
                {
                    JobId = projectJobSummary.Id
                };
                projectJobSummaryDto.Recommended = await _talentJobRepository.GetTalentRecommendedJobsByJobId(jobAuditionsRequest);

                lstProjectJobSummaryDto.Add(projectJobSummaryDto);
            }

            #endregion


            return Ok(new { projects = lstRecruiterProjectSummaryDto, projectJobs = lstProjectJobSummaryDto, ProjectsCount = totalProjectCount, ProjectJobsCount = totalProjectJobCount });


        }

        [HttpPost]
        [Route("recruiter/dashboard/projects/{projectId}/jobs")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter")]
        public async Task<IActionResult> GetJobsByProjectId(int projectId, [FromBody]RequestProjectJobParamDto requestProjectJobParams, int userId)
        {
            int recruiterId = userId;

            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);

            var project = await _projectRepository.FindAsync(x => x.Id == projectId);
            if (project == null)
            {
                return NotFound();
            }

            var lstProjectJobs = new List<ProjectJob>();

            #region search - based on project job name => else get  projectJobs by Id
            if (!string.IsNullOrEmpty(requestProjectJobParams.SearchProjectJob))
            {
                if (isJobAdmin)
                {
                    var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userId, false);
                    var projectJobs = await _projectJobRepository.FindAllAsync(x => x.Title.ToLower().Contains(requestProjectJobParams.SearchProjectJob.ToLower())
                                                                            && assignedProjectJobs.Contains(x.Id));
                    lstProjectJobs = projectJobs.ToList();
                }
                else
                {
                    var projectJobs = await _projectJobRepository.FindAllAsync(x => x.Title.ToLower().Contains(requestProjectJobParams.SearchProjectJob.ToLower()));
                    lstProjectJobs = projectJobs.ToList();
                }


            }
            else
            {
                if (isJobAdmin)
                {
                    var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userId, false);
                    // get only jobs which are assigned to him
                    var projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId && assignedProjectJobs.Contains(x.Id));
                    lstProjectJobs = projectJobs.ToList();
                }
                else
                {
                    var projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId);
                    lstProjectJobs = projectJobs.ToList();
                }
            }
            #endregion

            if (lstProjectJobs == null || lstProjectJobs.Count == 0)
            {
                return NotFound();
            }

            int startIndex = (requestProjectJobParams.CurrentPage > 0) ? ((requestProjectJobParams.CurrentPage) * requestProjectJobParams.PerPageRecords + 1) : requestProjectJobParams.CurrentPage;
            int endIndex = (requestProjectJobParams.CurrentPage > 0) ? (startIndex + requestProjectJobParams.PerPageRecords) : requestProjectJobParams.PerPageRecords;

            var totalProjectJobCount = lstProjectJobs.Count();
            lstProjectJobs = lstProjectJobs.OrderBy(x => x.Title).Skip(startIndex - 1).Take(endIndex - startIndex).ToList();



            var lstProjectJobSummaryDto = new List<ProjectJobSummaryDto>();
            foreach (var projectJob in lstProjectJobs)
            {
                var projectJobSummaryDto = new ProjectJobSummaryDto();
                projectJobSummaryDto.Id = projectJob.Id;
                projectJobSummaryDto.Title = projectJob.Title;
                //projectJobSummaryDto.StatusDescription = ((StatusEnum)projectJob.StatusId).ToString();
                projectJobSummaryDto.StatusDescription = (projectJob.EndDate < DateTime.Now.Date) ? (StatusEnum.Close).ToString() : ((StatusEnum)projectJob.StatusId).ToString();
                projectJobSummaryDto.StatusId = (projectJob.EndDate < DateTime.Now.Date) ? StatusEnum.Close : (StatusEnum)projectJob.StatusId;

                var talentJob = await _talentJobRepository.FindAllAsync(x => x.JobId == projectJob.Id);
                if (talentJob != null)
                {
                    projectJobSummaryDto.UnderReview = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.UnderReview).Count();
                    projectJobSummaryDto.NotSelected = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.NotSelected).Count();
                    projectJobSummaryDto.SelectedForAudition = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition).Count();
                    projectJobSummaryDto.Shortlisted = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.Shortlisted).Count();
                    projectJobSummaryDto.Casted = talentJob.Where(x => x.StatusId == (int)ProjectJobStatusEnum.Cast).Count();
                }

                // Find REcommended count for each job
                // jobAuditionsRequest -> jobId
                var jobAuditionsRequest = new JobAuditionsRequest()
                {
                    JobId = projectJob.Id
                };
                projectJobSummaryDto.Recommended = await _talentJobRepository.GetTalentRecommendedJobsByJobId(jobAuditionsRequest);

                lstProjectJobSummaryDto.Add(projectJobSummaryDto);
            }

            return Ok(new { projectJobs = lstProjectJobSummaryDto, totalProjectJobCount = totalProjectJobCount });

        }
        #endregion

        #region Private Methods
        [NonAction]
        private RecruiterDashboardSummaryDto ConvertToDashboardSummaryDto(IEnumerable<Project> projects, IEnumerable<ProjectJob> projectJobs, RecruiterDashboardSummaryDto recruiterDashboardSummary)
        {
            recruiterDashboardSummary.Project.Active = projects.Where(x => x.StatusId == (int)StatusEnum.Active && x.EndDate >= DateTime.Now.Date).Count();
            recruiterDashboardSummary.Project.Closed = projects.Where(x => x.StatusId == (int)StatusEnum.Close || x.EndDate < DateTime.Now.Date).Count();
            recruiterDashboardSummary.Project.UnderVerification = projects.Where(x => x.StatusId == (int)StatusEnum.Draft && x.EndDate >= DateTime.Now.Date).Count();
            recruiterDashboardSummary.Project.Verified = projects.Where(x => x.StatusId == (int)StatusEnum.Verified && x.EndDate >= DateTime.Now.Date).Count();
            
            recruiterDashboardSummary.Project.TotalCount = projects.Count();
            
            recruiterDashboardSummary.ProjectJob.Active = projectJobs.Where(x => x.StatusId == (int)StatusEnum.Active && x.EndDate >= DateTime.Now.Date).Count();
            recruiterDashboardSummary.ProjectJob.Closed = projectJobs.Where(x => x.StatusId == (int)StatusEnum.Close || x.EndDate < DateTime.Now.Date).Count();
            recruiterDashboardSummary.ProjectJob.Draft = projectJobs.Where(x => x.StatusId == (int)StatusEnum.Draft && x.EndDate >= DateTime.Now.Date).Count();
            recruiterDashboardSummary.ProjectJob.TotalCount = projectJobs.Count();
            
            return recruiterDashboardSummary;
        }
        #endregion

    }
}