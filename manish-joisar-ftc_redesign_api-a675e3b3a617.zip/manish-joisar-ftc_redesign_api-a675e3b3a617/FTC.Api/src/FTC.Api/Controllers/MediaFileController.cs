﻿using FTCApi.Core.RepositoryInterface;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    [Route("api/[controller]")]
    public class MediaFileController : Controller
    {
        private IMediaFileRepository _mediaFileRepository;
        public MediaFileController(IMediaFileRepository mediaFileRepository)
        {
            _mediaFileRepository = mediaFileRepository;
        }

        [HttpGet]
        public async Task<ActionResult> Get()
        {
            var mediaFile = await _mediaFileRepository.GetAllAsync();
            return Json(mediaFile);
        }
    }
}
