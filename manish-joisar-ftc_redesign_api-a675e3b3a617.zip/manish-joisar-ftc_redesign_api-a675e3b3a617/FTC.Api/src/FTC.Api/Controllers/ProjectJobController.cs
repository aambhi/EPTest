﻿using AutoMapper;
using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.JobAuditionsDtos;
using FTCApi.Dtos.Notification;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    /// <summary>
    /// Project Job Controller
    /// </summary>
    public class ProjectJobController : Controller
    {
        private ITalentRepository _talentRepository;
        private ITalentTokenRepository _talentTokenRepository;
        private ITalentJobRepository _talentJobRepository;
        private ITalentTalentCategoryRepository _talentTalentCategoryRepository;
        private IProjectJobRepository _projectJobRepository;
        private ITalentCategoryRepository _talentCategoryRepository;
        private IInterestCategoryRepository _interestCategoryRepository;
        private IProjectJobStatusRepository _projectJobStatusRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IAuxiliaryRecruiterRepository _auxiliaryRecruiterRepository;
        private IProjectJobLocationRepository _projectJobLocationRepository;
        private IProjectJobLanguageRepository _projectJobLanguageRepository;
        private IProjectJobSkinColorRepository _projectJobSkinColorRepository;
        private IProjectJobEyeColorRepository _projectJobEyeColorRepository;
        private IProjectJobHairColorRepository _projectJobHairColorRepository;
        private IProjectJobTagRepository _projectJobTagRepository;
        private IProjectJobSubTalentRepository _projectJobSubTalentRepository;
        private IProjectJobBodyTypeRepository _projectJobBodyTypeRepository;
        private IProjectJobEthnicityRepository _projectJobEthnicityRepository;
        private IProjectLocationRepository _projectLocationRepository;
        private ITagRepository _tagRepository;
        private IProjectRepository _projectRepository;
        private ISkinColorRepository _skinColorRepository;
        private IEyeColorRepository _eyeColorRepository;
        private IHairColorRepository _hairColorRepository;
        private IHairLengthRepository _hairLengthRepository;
        private IHairTypeRepository _hairTypeRepository;
        private IHeightRepository _heightRepository;
        private IWeightRepository _weightRepository;
        private IChestSizeRepository _chestSizeRepository;
        private IWaistSizeRepository _waistSizeRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;
        private ILanguageRepository _languageRepository;
        private IEmailService _emailService;
        private IRecruiterPlanRepository _recruiterPlanRepository;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private static IMapper _mapper;
        private IFileService _fileService;
        private AppSettings _appSettings;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private IJobAuditionRepository _jobAuditionRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private IJobAuditionTalentRepository _jobAuditionTalentRepository;
        private IJobTalentRecommendedRepository _jobTalentRecommendedRepository;
        private IProjectJobStatusHistoryRepository _projectJobStatusHistoryRepository;
        private ITalentJobSpecialHostRepository _talentJobSpecialHostRepository;


        private const string constantActivated = "Activated";

        public ProjectJobController(ITalentRepository talentRepository, ITalentTokenRepository talentTokenRepository,
                                    ITalentJobRepository talentJobRepository, ITalentTalentCategoryRepository talentTalentCategoryRepository,
                                    IProjectJobRepository projectJobRepository, ITalentCategoryRepository talentCategoryRepository,
                                    IProjectJobStatusRepository projectJobStatusRepository, IProjectJobLocationRepository projectJobLocationRepository,
                                    IAuxiliaryUserRepository auxiliaryUserRepository, IAuxiliaryRecruiterRepository auxiliaryRecruiterRepository,
                                    IProjectRepository projectRepository, ICityRepository cityRepository, ICountryRepository countryRepository,
                                    IProjectJobLanguageRepository projectJobLanguageRepository, ILanguageRepository languageRepository,
                                    IInterestCategoryRepository interestCategoryRepository, IProjectJobTagRepository projectJobTagRepository,
                                    ITagRepository tagRepository, ISkinColorRepository skinColorRepository, IEyeColorRepository eyeColorRepository,
                                    IHairColorRepository hairColorRepository, IHairLengthRepository hairLengthRepository, IHairTypeRepository hairTypeRepository, IProjectJobEthnicityRepository projectJobEthnicityRepository,
                                    IProjectJobSkinColorRepository projectJobSkinColorRepository, IProjectJobEyeColorRepository projectJobEyeColorRepository, IProjectJobSubTalentRepository projectJobSubTalentRepository,
                                    IProjectJobHairColorRepository projectJobHairColorRepository, IChestSizeRepository chestSizeRepository, IProjectJobBodyTypeRepository projectJobBodyTypeRepository,
                                    IWaistSizeRepository waistSizeRepository, IEmailService emailService, Microsoft.Extensions.Configuration.IConfiguration configuration, IRecruiterPlanRepository recruiterPlanRepository,
                                    INotificationHeaderRepository notificationHeaderRepository, INotificationDetailRepository notificationDetailRepository, IFileService fileService,
                                    IUserNotificationRepository userNotificationRepository,
                                    IHeightRepository heightRepository, IWeightRepository weightRepository, IJobAuditionRepository jobAuditionRepository, ISmsProviderRepository smsProviderRepository,
                                    IJobAuditionTalentRepository jobAuditionTalentRepository, IJobTalentRecommendedRepository jobTalentRecommendedRepository,
                                    IProjectJobStatusHistoryRepository projectJobStatusHistoryRepository,
                                    ITalentJobSpecialHostRepository talentJobSpecialHostRepository)


        {
            _talentRepository = talentRepository;
            _talentTokenRepository = talentTokenRepository;
            _talentJobRepository = talentJobRepository;
            _talentTalentCategoryRepository = talentTalentCategoryRepository;
            _projectJobRepository = projectJobRepository;
            _talentCategoryRepository = talentCategoryRepository;
            _projectJobStatusRepository = projectJobStatusRepository;
            _projectJobLocationRepository = projectJobLocationRepository;
            _projectJobLanguageRepository = projectJobLanguageRepository;
            _projectJobSkinColorRepository = projectJobSkinColorRepository;
            _projectJobEyeColorRepository = projectJobEyeColorRepository;
            _projectJobHairColorRepository = projectJobHairColorRepository;
            _projectJobSubTalentRepository = projectJobSubTalentRepository;
            _projectJobTagRepository = projectJobTagRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _auxiliaryRecruiterRepository = auxiliaryRecruiterRepository;
            _interestCategoryRepository = interestCategoryRepository;
            _projectJobEthnicityRepository = projectJobEthnicityRepository;
            _projectJobBodyTypeRepository = projectJobBodyTypeRepository;
            _projectRepository = projectRepository;
            _tagRepository = tagRepository;
            _skinColorRepository = skinColorRepository;
            _eyeColorRepository = eyeColorRepository;
            _hairColorRepository = hairColorRepository;
            _hairLengthRepository = hairLengthRepository;
            _hairTypeRepository = hairTypeRepository;
            _chestSizeRepository = chestSizeRepository;
            _waistSizeRepository = waistSizeRepository;
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;
            _languageRepository = languageRepository;
            _emailService = emailService;
            _configuration = configuration;
            _recruiterPlanRepository = recruiterPlanRepository;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _heightRepository = heightRepository;
            _weightRepository = weightRepository;
            _fileService = fileService;
            _userNotificationRepository = userNotificationRepository;
            _jobAuditionRepository = jobAuditionRepository;
            _jobAuditionTalentRepository = jobAuditionTalentRepository;
            _jobTalentRecommendedRepository = jobTalentRecommendedRepository;
            _projectJobStatusHistoryRepository = projectJobStatusHistoryRepository;
            _talentJobSpecialHostRepository = talentJobSpecialHostRepository;
            _appSettings = new AppSettings(_configuration);
            _smsProviderRepository = smsProviderRepository;
        }

        static ProjectJobController()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Talent, TalentDto>();
                cfg.CreateMap<TalentDto, Talent>();
                cfg.CreateMap<SearchParametersDto, SearchParameters>();
                cfg.CreateMap<SearchResult<ProjectJob>, SearchResultDto<ProjectJobDto>>();
            });
            _mapper = config.CreateMapper();
        }

        #region Public Actions
        /// <summary>
        /// searchJob
        /// </summary>
        [HttpPost]
        [Route("job/search/{jobSearchType}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> searchJob([FromBody]SearchParametersDto searchParams, int jobSearchType, int userId, int userType)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var projectJob = await _projectJobRepository.Search(search, jobSearchType, userId);
            if (projectJob != null)
            {
                if (userType == (int)LoginUserType.Talent && (jobSearchType == (int)JobSearchType.Applied))
                {
                    foreach (var job in projectJob.Results)
                        job.TalentJob = job.TalentJob.Where(x => x.TalentId == userId).ToList();
                }

                var projectJobStatusNotSelected = _projectJobStatusRepository.Find(x => x.Id == (int)ProjectJobStatusEnum.NotSelected);
                var jobAudition = _jobAuditionRepository.GetAll();
                var jobAuditionTalent = _jobAuditionTalentRepository.FindAll(x => x.TalentId == userId && x.MovedToNextStage == false && x.NotSelected == false);
                var jobTalentRecommended = _jobTalentRecommendedRepository.FindAll(x => x.TalentId == userId && x.Invited == true);

                var results = projectJob.Results.Select(p => new
                {
                    id = p.Id,
                    title = p.Title,
                    description = p.Description,
                    gender = p.Gender,
                    minAge = p.MinAge,
                    maxAge = p.MaxAge,
                    createdOn = p.CreatedOn,
                    startDate = p.StartDate,
                    endDate = p.EndDate,
                    projectName = p.Project.Name,
                    profileURL = p.Project.AuxiliaryUser != null ? p.Project.AuxiliaryUser.ProfileURL : "",
                    city = p.ProjectJobLocation.Count() > 0 ? string.Join(", ", p.ProjectJobLocation.Select(x => x.City.CityDescription).ToList()) : "",

                    talentJobStatus = (p.TalentJob.Where(x => x.TalentId == userId).Select(x => x.TalentId).Contains(userId)) ?
                                        ((p.EndDate < DateTime.UtcNow.Date || p.StatusId == (int)StatusEnum.Close) && p.TalentJob.FirstOrDefault(x => x.TalentId == userId).Status.Id != (int)ProjectJobStatusEnum.Cast) ?
                                        new ProjectJobStatus { Description = "Closed", RGB = _configuration["Close_RGB"] } :
                                        (p.TalentJob.FirstOrDefault(x => x.TalentId == userId).NotSelected == true ? new ProjectJobStatus { Description = projectJobStatusNotSelected.Description, RGB = projectJobStatusNotSelected.RGB } : (p.TalentJob.FirstOrDefault(x => x.TalentId == userId).Status))
                                        : ((p.EndDate < DateTime.UtcNow.Date || p.StatusId == (int)StatusEnum.Close) ? new ProjectJobStatus { Description = "Closed", RGB = _configuration["Close_RGB"] } : null),
                    isJobClosed = (p.EndDate < DateTime.UtcNow.Date || p.StatusId == (int)StatusEnum.Close),
                    isApplied = p.TalentJob.Where(x => x.TalentId == userId).Select(x => x.TalentId).Contains(userId) ? true : false,

                    isSelectedForAudition = (p.TalentJob.Where(x => x.TalentId == userId).Select(x => x.TalentId).Contains(userId)) ?
                                            ((p.EndDate < DateTime.UtcNow.Date || p.StatusId == (int)StatusEnum.Close) && p.TalentJob.FirstOrDefault(x => x.TalentId == userId).Status.Id != (int)ProjectJobStatusEnum.Cast) ? false :
                                            (((p.TalentJob.FirstOrDefault(x => x.TalentId == userId).SelectedForAudition ?? false) && p.TalentJob.FirstOrDefault(x => x.TalentId == userId).NotSelected == false) ||
                                             (jobAuditionTalent.Where(jat => jobAudition.Where(ja => ja.JobId == p.Id).Select(ja => ja.Id).Contains((int)jat.JobAuditionId)).Select(jat => jat.TalentId).Contains(userId)))
                                            : false,
                    isFeaturedJob = p.IsFeaturedJob,
                    isjobTalentInvited = jobTalentRecommended.Select(jtr => jtr.JobId).Contains(p.Id),
                    isJobInvitationDeclined = jobTalentRecommended.Select(jtr => jtr.JobId).Contains(p.Id) ? jobTalentRecommended.Where(x => x.JobId == p.Id).FirstOrDefault().InvitationDeclined : false
                });

                return Json(new
                {
                    Results = results,
                    TotalResults = projectJob.TotalResults,
                    Previous = projectJob.Previous,
                    Next = projectJob.Next
                });
            }
            return BadRequest();
        }

        [HttpPut]
        [Route("publishJob/{id}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> publishJob(int id, UserInfo userInfo)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            try
            {
                var job = await _projectJobRepository.GetJobById(id, userInfo.userId);
                var updatedJob = default(ProjectJob);
                if (job != null)
                {
                    var isPublished = await _projectJobRepository.PushFtcRecommendedTalents(job.ProjectId, job.Id, userInfo.userId);
                    job.StatusId = (int)StatusEnum.Active;//set to published
                    job.UpdatedOn = DateTime.UtcNow;
                    updatedJob = await _projectJobRepository.UpdateAsync(job);

                    // Add projectJobStatusHistory - When Job is published and by whom
                    var projectJobStatusHistory = new ProjectJobStatusHistory()
                    {
                        CreatedBy = userInfo.userId,
                        StatusId = updatedJob.StatusId,
                        JobId = updatedJob.Id
                    };

                    projectJobStatusHistory = await _projectJobStatusHistoryRepository.AddAsync(projectJobStatusHistory);
                }

                #region Send Notification [system & Email & Sms]
                await NotifyJobPublish(userInfo, job, updatedJob);
                #endregion

                return new JsonResult(new { status = true });
            }
            catch (Exception ex)
            {
                Log.Error("Error while sending notification" + ex);
                throw ex;
            }
        }

        private async Task NotifyJobPublish(UserInfo userInfo, ProjectJob job, ProjectJob updatedJob)
        {
            var project = await _projectRepository.FindAsync(x => x.Id == updatedJob.ProjectId);
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                JobName = job.Title,
                AuxiliaryUserId = userInfo.userId
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = job.Id,
                UrlRoute = ViewNotificationEnumDto.EditProjectJob
            };

            // Send Email to Auxiliary Users when a Job is Published
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.JobPublished, project.Id, job.Id);
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            await notification.SendNotification(NotificationEnum.JobPublished, notificationParam, sendSystemNotificationDto);
        }

        [HttpPut]
        [Route("endJob/{id}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> endJob(int id, UserInfo userInfo)
        {
            if (id == 0)
            {
                return BadRequest();
            }

            var job = await _projectJobRepository.GetJobById(id, userInfo.userId);
            job.StatusId = (int)StatusEnum.Close;//set to closed
            job.UpdatedOn = DateTime.UtcNow;
            job.UpdatedBy = userInfo.userId;
            var updatedJob = await _projectJobRepository.UpdateAsync(job);

            var projectJobStatusHistory = new ProjectJobStatusHistory()
            {
                CreatedBy = userInfo.userId,
                JobId = job.Id,
                StatusId = job.StatusId
            };
            projectJobStatusHistory = await _projectJobStatusHistoryRepository.AddAsync(projectJobStatusHistory);

            #region Send System Notification

            await NotifyJobClose(userInfo, job);

            #endregion

            return new JsonResult(updatedJob);
        }

        private async Task NotifyJobClose(UserInfo userInfo, ProjectJob job)
        {
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                JobName = job.Title
            };
            var project = await _projectRepository.FindAsync(x => x.Id == job.ProjectId);
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.JobClose, project.Id, job.Id),
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = job.Id,
                UrlRoute = ViewNotificationEnumDto.EditProjectJob
            };

            // Send Email to Auxiliary Users when a Job is Published
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.JobClose, project.Id, job.Id);
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            await notification.SendNotification(NotificationEnum.JobClose, notificationParam, sendSystemNotificationDto);
        }

        [HttpGet]
        [Route("job/{id}")]
        [AuthorizeTokenFilter(validate: false, role: "Talent,FTCAdmin,Recruiter")]
        public async Task<IActionResult> Get(int id, int userId, int userType)
        {
            var job = await _projectJobRepository.GetJobById(id, userId);
            if (job != null)
            {
                if (userType == (int)LoginUserType.Talent)
                {
                    job.TalentJob = job.TalentJob.Where(x => x.TalentId == userId).ToList();
                }
                var jobNationality = await _countryRepository.FindAsync(x => x.Id == job.NationalityId);
                if (jobNationality != null)
                {
                    job.JobNationality = jobNationality;
                }

                bool isApplied = job.TalentJob.Where(x => x.TalentId == userId).Count() > 0 ? true : false;
                var projectJobStatusNotSelected = _projectJobStatusRepository.Find(x => x.Id == (int)ProjectJobStatusEnum.NotSelected);
                var jobAudition = _jobAuditionRepository.FindAll(x => x.JobId == id);
                var jobAuditionTalent = _jobAuditionTalentRepository.FindAll(x => x.TalentId == userId && jobAudition.Select(ja => ja.Id).Contains((int)x.JobAuditionId) && x.MovedToNextStage == false && x.NotSelected == false).Select(x => x.TalentId).Contains(userId);
                var jobTalentRecommended = _jobTalentRecommendedRepository.Find(x => x.TalentId == userId && x.JobId == id && x.Invited == true);

                var result = new
                {
                    id = job.Id,
                    title = job.Title,
                    description = job.Description,
                    gender = job.Gender,
                    minAge = job.MinAge,
                    maxAge = job.MaxAge,
                    createdOn = job.CreatedOn,
                    startDate = job.StartDate,
                    endDate = job.EndDate,
                    projectName = job.Project.Name,
                    profileURL = job.Project.AuxiliaryUser != null ? job.Project.AuxiliaryUser.ProfileURL : "",
                    city = job.ProjectJobLocation.Count() > 0 ? string.Join(", ", job.ProjectJobLocation.Select(x => x.City.CityDescription.Trim()).ToList()) : "",
                    interestCategory = job.Project.Interest != null ? job.Project.Interest.Description : "",
                    isSelectedForAudition = (isApplied == true) ? (((job.EndDate < DateTime.UtcNow.Date || job.StatusId == (int)StatusEnum.Close) && job.TalentJob.FirstOrDefault().Status.Id != (int)ProjectJobStatusEnum.Cast) ? false :
                                            (((job.TalentJob.FirstOrDefault().SelectedForAudition ?? false) && job.TalentJob.FirstOrDefault().NotSelected == false) || jobAuditionTalent))
                                            : false,
                    talentJobStatus = (isApplied == true) ? (((job.EndDate < DateTime.UtcNow.Date || job.StatusId == (int)StatusEnum.Close) &&
                                                                job.TalentJob.FirstOrDefault().Status.Id != (int)ProjectJobStatusEnum.Cast) ? new { id = 0, rgb = _configuration["RGB"], description = "Closed" } :
                                                            (job.TalentJob.FirstOrDefault().NotSelected == true ? (new { id = projectJobStatusNotSelected.Id, rgb = projectJobStatusNotSelected.RGB, description = projectJobStatusNotSelected.Description }) :
                                                            (new { id = job.TalentJob.FirstOrDefault().Status.Id, rgb = job.TalentJob.FirstOrDefault().Status.RGB, description = job.TalentJob.FirstOrDefault().Status.Description }))) :
                                        ((job.EndDate < DateTime.UtcNow.Date || job.StatusId == (int)StatusEnum.Close) ? new { id = 0, rgb = _configuration["RGB"], description = "Closed" } : null),
                    isJobClosed = (job.EndDate < DateTime.UtcNow.Date || job.StatusId == (int)StatusEnum.Close),
                    isFeaturedJob = job.IsFeaturedJob,
                    isjobTalentInvited = jobTalentRecommended != null ? jobTalentRecommended.Invited : false,
                    isJobInvitationDeclined = jobTalentRecommended != null ? jobTalentRecommended.InvitationDeclined : false,
                    isPublishedJob = (job.StatusId == (int)StatusEnum.Active),
                    hairLengthId = job.HairLengthId,
                    hairLength = job.HairLength,
                    hairTypeId = job.HairTypeId,
                    hairType = job.HairType,
                    hairColor = job.ProjectJobHairColor.Count() > 0 ? string.Join(", ", job.ProjectJobHairColor.Select(x => x.HairColor.Description.Trim()).ToList()) : "",
                    eyeColor = job.ProjectJobEyecolor.Count() > 0 ? string.Join(", ", job.ProjectJobEyecolor.Select(x => x.EyeColor.Description.Trim()).ToList()) : "",
                    skinColor = job.ProjectJobSkinColor.Count() > 0 ? string.Join(", ", job.ProjectJobSkinColor.Select(x => x.SkinColor.Description.Trim()).ToList()) : "",
                    language = job.ProjectJobLanguage.Count() > 0 ? string.Join(", ", job.ProjectJobLanguage.Select(x => x.Language.Description.Trim()).ToList()) : "",
                    tag = job.ProjectJobTag.Count() > 0 ? string.Join(", ", job.ProjectJobTag.Select(x => x.Tag.Name.Trim()).ToList()) : "",
                    minHeightId = job.MinHeightId,
                    maxHeightId = job.MaxHeightId,
                    minHeight = job.MinHeight,
                    maxHeight = job.MaxHeight,
                    minWeightId = job.MinWeightId,
                    maxWeightId = job.MaxWeightId,
                    minWeight = job.MinWeight,
                    maxWeight = job.MaxWeight,
                    minChestSizeId = job.MinChestSizeId,
                    maxChestSizeId = job.MaxChestSizeId,
                    minChestSize = job.MinChestSize,
                    maxChestSize = job.MaxChestSize,
                    minWaistSizeId = job.MinWaistSizeId,
                    maxWaistSizeId = job.MaxWaistSizeId,
                    minWaistSize = job.MinWaistSize,
                    maxWaistSize = job.MaxWaistSize,
                    headshotRequired = job.HeadshotRequired,
                    sideprofileRequired = job.SideprofileRequired,
                    introvideoRequired = job.IntrovideoRequired,
                    associationRequired = job.AssociationRequired,
                    passportRequired = job.PassportRequired,
                    referenceMedia = job.ReferenceMedia,
                    experienceRequired = job.ExperienceRequired,
                    castRequired = job.CastRequired,
                    nationalityId = job.NationalityId,
                    jobNationality = job.JobNationality != null ? job.JobNationality.Nationality : "",
                    mediaFiletypeId = job.MediaFiletypeId
                };
                return Json(new { job = result, isApplied = isApplied });
            }
            return BadRequest();
        }

        [HttpGet]
        [Route("projectJob/{id}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> GetJob(int id, int userId)
        {
            var job = await _projectJobRepository.GetJobById(id, userId);
            if (job != null)
            {
                var jobDto = await ConvertProjectJobModelToProjectJobDto(job);
                //get the projectDetails First
                var project = await _projectRepository.FindAsync(x => x.Id == job.ProjectId);
                if (project != null)
                {
                    var checkAuthorization = _auxiliaryUserRepository.CheckAuthorization(project.AuxiliaryUserId, userId, (int)NotificationEnum.JobCreation, job.ProjectId, job.Id);
                    if (!checkAuthorization)
                        return Forbid();

                    //get the plan from the plan id
                    var plan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
                    jobDto.TotalNumberOfJobs = plan.RoleCount.Value;
                    jobDto.isPaid = project.IsPaid;
                }
                // get all jobs based on project id
                var jobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == job.ProjectId);
                if (jobs != null)
                {
                    jobDto.NumberOfJobsCreated = jobs.Sum(x => x.NumberOfRole).Value;
                }
                jobDto.ProjectStartDate = job.Project.StartDate;
                jobDto.ProjectEndDate = job.Project.EndDate;

                return Json(jobDto);
            }

            return NotFound();
        }

        /// <summary>
        /// post job
        /// </summary>
        [HttpPost]
        [Route("job/create")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> Post([FromBody]ProjectJobDto projectJobDto, UserInfo userInfo)
        {
            if (projectJobDto == null)
            {
                return BadRequest();
            }
            try
            {
                if (projectJobDto.Id > 0)
                {
                    var projectJob = await _projectJobRepository.GetJobById((int)projectJobDto.Id, userInfo.userId);
                    projectJob = await UpdateProjectJobModel(projectJob, projectJobDto);
                    projectJob.UpdatedBy = userInfo.userId;
                    projectJob.UpdatedOn = DateTime.UtcNow;
                    projectJob = await _projectJobRepository.UpdateAsync(projectJob);
                }
                else
                {
                    var projectJob = ConvertToProjectJobModel(projectJobDto);
                    projectJob.CreatedBy = userInfo.userId;
                    projectJob.CreatedOn = DateTime.UtcNow;
                    var newProjectJob = await _projectJobRepository.AddAsync(projectJob);
                    projectJobDto.Id = newProjectJob.Id;

                    var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
                    var notificationParam = new NotificationParam()
                    {
                        JobName = projectJob.Title,
                        AuxiliaryUserId = userInfo.userId
                    };

                    var project = await _projectRepository.FindAsync(x => x.Id == newProjectJob.ProjectId);
                    var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                    {
                        SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.JobCreation, project.Id),
                        NotificationReference = NotificationReferenceEnum.Job,
                        NotificationReferenceValue = newProjectJob.Id,
                        UrlRoute = ViewNotificationEnumDto.EditProjectJob
                    };

                    // Send Email to Auxiliary Users when a Job is Created
                    var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                    sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                    // list with params to send sms
                    notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                    {
                        AuxiliaryUserId = x.Id,
                        MobileCountryCode = x.MobileCountryCode,
                        MobileNumber = x.Mobile
                    }).ToList();

                    await notification.SendNotification(NotificationEnum.JobCreation, notificationParam, sendSystemNotificationDto);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return new JsonResult(projectJobDto);
        }

        private dynamic GetMasterAttributeModel(List<SelectDto> selectDto, MasterModel modelType)
        {
            switch (modelType)
            {
                case MasterModel.BodyType:
                    var projectJobBodytypes = new List<ProjectJobBodytype>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectJobBodytype = new ProjectJobBodytype
                            {
                                BodytypeId = item.Id
                            };
                            projectJobBodytypes.Add(projectJobBodytype);
                        }
                    }
                    return projectJobBodytypes;

                case MasterModel.EyeColor:
                    var projectEyeColors = new List<ProjectJobEyeColor>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectEyeColor = new ProjectJobEyeColor
                            {
                                EyecolorId = item.Id
                            };
                            projectEyeColors.Add(projectEyeColor);
                        }
                    }
                    return projectEyeColors;

                case MasterModel.HairColor:
                    var projectHairColors = new List<ProjectJobHairColor>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectHairColor = new ProjectJobHairColor
                            {
                                HaircolorId = item.Id
                            };
                            projectHairColors.Add(projectHairColor);
                        }
                    }
                    return projectHairColors;

                case MasterModel.SkinColor:
                    var projectSkinColors = new List<ProjectJobSkinColor>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectSkinColor = new ProjectJobSkinColor
                            {
                                SkinColorId = item.Id
                            };
                            projectSkinColors.Add(projectSkinColor);
                        }
                    }
                    return projectSkinColors;

                case MasterModel.Ethnicity:
                    var projectEthnicities = new List<ProjectJobEthnicity>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectJobEthnicity = new ProjectJobEthnicity
                            {
                                EthnicityId = item.Id
                            };
                            projectEthnicities.Add(projectJobEthnicity);
                        }
                    }
                    return projectEthnicities;

                case MasterModel.SubTalent:
                    var projectSubTalents = new List<ProjectJobSubTalent>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectSubTalent = new ProjectJobSubTalent
                            {
                                JobSubTalentId = item.Id
                            };
                            projectSubTalents.Add(projectSubTalent);
                        }
                    }
                    return projectSubTalents;

                case MasterModel.Language:
                    var projectJobLanguages = new List<ProjectJobLanguage>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectJobLanguage = new ProjectJobLanguage
                            {
                                LanguageId = item.Id
                            };
                            projectJobLanguages.Add(projectJobLanguage);
                        }
                    }
                    return projectJobLanguages;

                case MasterModel.Location:
                    var projectJobLocations = new List<ProjectJobLocation>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectJobLocation = new ProjectJobLocation
                            {
                                CityId = item.Id
                            };
                            projectJobLocations.Add(projectJobLocation);
                        }
                    }
                    return projectJobLocations;

                case MasterModel.PerformingSkill:
                    var projectJobTags = new List<ProjectJobTag>();
                    if (selectDto != null)
                    {
                        foreach (var item in selectDto)
                        {
                            var projectJobTag = new ProjectJobTag
                            {
                                TagId = item.Id
                            };
                            projectJobTags.Add(projectJobTag);
                        }
                    }
                    return projectJobTags;

                default:
                    return null;
            }

        }

        /// <summary>
        /// put job
        /// </summary>
        [HttpPut]
        [Route("job/update/{id}")]
        public async Task<IActionResult> Put(int id, [FromBody]ProjectJobDto projectJobDto)
        {
            if (projectJobDto == null)
            {
                return BadRequest();
            }
            var job = await _projectJobRepository.FindAsync(x => x.Id == id);
            if (job != null)
            {
                var projectJob = _mapper.Map<ProjectJobDto, ProjectJob>(projectJobDto);
                var newProjectJob = await _projectJobRepository.UpdateAsync(projectJob);
                var newProjectJobDto = _mapper.Map<ProjectJob, ProjectJobDto>(newProjectJob);
                return new JsonResult(newProjectJobDto);
            }
            return NotFound();
        }

        /// <summary>
        /// getjobstatus
        /// </summary>
        [HttpGet]
        [Route("job/getjobstatus")]
        public async Task<IActionResult> GetJobStatus()
        {
            var jobStatus = await _projectJobStatusRepository.FindAllAsync(x => x.Description != null);
            if (jobStatus != null)
                return Json(jobStatus.Select(j => new { j.Id, j.Description }).OrderBy(j => j.Description).ToList());

            return NotFound();
        }

        /// <summary>
        /// gettalentcategory
        /// </summary>
        [HttpGet]
        [Route("job/gettalentcategory")]
        public async Task<IActionResult> GetTalentCategory()
        {
            var talent = await _talentCategoryRepository.FindAllAsync(x => x.StatusId == (int)StatusEnum.Active && x.ParentId == null);
            if (talent != null)
                return Json(talent.Select(tc => new { tc.Id, tc.Description }).OrderBy(tc => tc.Description).ToList());
            return NotFound();
        }

        /// <summary>
        /// getinterestcategory
        /// </summary>
        [HttpGet]
        [Route("job/getinterestcategory")]
        public async Task<IActionResult> GetInterestCategory()
        {
            var interest = await _interestCategoryRepository.FindAllAsync(x => x.StatusId == (int)StatusEnum.Active);
            if (interest != null)
                return Json(interest.Select(ic => new { ic.Id, ic.Description }).OrderBy(ic => ic.Description).ToList());
            return NotFound();
        }

        /// <summary>
        /// getrecruiter
        /// </summary>
        [HttpGet]
        [Route("job/getrecruiter")]
        public async Task<IActionResult> GetRecruiter()
        {
            var recruiter = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter && x.StatusId != (int)StatusEnum.Blocked && x.ParentAuxiliaryUserId == null);
            if (recruiter != null)
                return Json(recruiter.Select(x => new { x.Id, x.FullName }).OrderBy(x => x.FullName).ToList());

            return NotFound();
        }

        /// <summary>
        /// getproject
        /// </summary>
        [HttpGet]
        [Route("job/getproject")]
        public async Task<IActionResult> GetProject()
        {
            var project = await _projectRepository.FindAllAsync(x => x.StatusId == (int)StatusEnum.Active);
            if (project != null)
                return Json(project.Select(p => new { p.Id, p.Name }).OrderBy(p => p.Name).ToList());

            return NotFound();
        }

        /// <summary>
        /// getjoblocation
        /// </summary>
        [HttpGet]
        [Route("job/getjoblocation")]
        public async Task<IActionResult> GetJobLocation()
        {
            var location = await _cityRepository.GetAllAsync();
            if (location != null)
                return Json(location.OrderBy(l => l.CityCountryId).ThenBy(l => l.CityDescription).Select(l => new { l.CityId, l.CityDescription }).ToList());

            return NotFound();
        }

        /// <summary>
        /// PostTalentJob
        /// </summary>
        [HttpPost]
        [Route("job/apply")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> PostTalentJob([FromBody]TalentJobDto talentJobDto, int userId)
        {
            if (talentJobDto == null)
            {
                return BadRequest();
            }

            var job = await _projectJobRepository.FindAsync(x => x.Id == talentJobDto.JobId);
            if (job != null)
            {
                if (job.StatusId != (int)StatusEnum.Close)
                {
                    talentJobDto.TalentId = userId;
                    var talentJob = new TalentJob
                    {
                        JobId = talentJobDto.JobId,
                        TalentId = talentJobDto.TalentId,
                        StatusId = Convert.ToInt32(ProjectJobStatusEnum.UnderReview)
                    };

                    var newTalentJob = await _talentJobRepository.FindAsync(c => c.JobId == talentJobDto.JobId && c.TalentId == talentJobDto.TalentId);

                    if (newTalentJob == null)
                    {
                        newTalentJob = await _talentJobRepository.AddAsync(talentJob);
                    }

                    // add a record in TalentJobSpecialHost table
                    await _talentJobSpecialHostRepository.AddTalentJobSpecialHost((int)talentJobDto.TalentId, newTalentJob.Id);

                    var jobStatus = await _projectJobStatusRepository.FindAsync(x => x.Id == newTalentJob.StatusId);
                    if (jobStatus != null)
                        newTalentJob.Status = jobStatus;
                    return new JsonResult(newTalentJob);
                }
                else
                {
                    return new JsonResult(new { isJobClosed = true });
                }
            }
            return NotFound();
        }

        /// <summary>
        /// DeclineJobInvitation
        /// </summary>
        [HttpPost]
        [Route("job/declineJobInvitation/{jobId}/{isInvitationDeclined}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> DeclineJobInvitation(int jobId, bool isInvitationDeclined, int userId)
        {
            if (string.IsNullOrEmpty(jobId.ToString()))
            {
                return BadRequest();
            }

            var job = await _projectJobRepository.FindAsync(x => x.Id == jobId);
            if (job != null)
            {
                var jobTalentRecommended = await _jobTalentRecommendedRepository.FindAsync(x => x.JobId == jobId && x.TalentId == userId && x.Invited == true);
                if (jobTalentRecommended != null)
                {
                    jobTalentRecommended.InvitationDeclined = isInvitationDeclined;

                    var updatedJobTalentRecommended = await _jobTalentRecommendedRepository.UpdateAsync(jobTalentRecommended);
                    return new JsonResult(updatedJobTalentRecommended);
                }
            }
            return NotFound();
        }

        /// <summary>
        /// projectjob/GetprojectJobSummary : GET
        /// </summary>
        [HttpGet]
        [Route("projectJobSummary/{talentCategoryId}/{noOfJobs:int?}")]
        public async Task<IActionResult> GetprojectJobSummary(LoginEnum.TalentCategory talentCategoryId, int noOfJobs = 3)
        {
            List<ProjectJob> lstProjectJobSummary = new List<ProjectJob>();
            if (talentCategoryId == LoginEnum.TalentCategory.Others)
            {                
                var excludeTalentcategoryIds = _appSettings.ExcludeTalentCategoryIds;

                var lstProjectJobSummaryResponse = await _projectJobRepository.GetAllAsync();

                var lstOtherJobSummaryResponse = lstProjectJobSummaryResponse.Where(x => !excludeTalentcategoryIds.Contains((int)x.TalentCategoryId)
                                                            && x.StatusId == (int)StatusEnum.Active);
                lstProjectJobSummary = lstOtherJobSummaryResponse.ToList();
            }
            else
            {
                var lstProjectJobSummaryResponse = await _projectJobRepository.FindAllAsync(x => x.TalentCategoryId == (int)talentCategoryId
                                                           && x.StatusId == (int)StatusEnum.Active);

                lstProjectJobSummary = lstProjectJobSummaryResponse.ToList();
            }


            lstProjectJobSummary = lstProjectJobSummary.OrderByDescending(x => x.CreatedOn).ToList().Take(noOfJobs).ToList();

            List<ProjectJobSummaryDto> lstProjectJobSummaryDto = new List<ProjectJobSummaryDto>();
            {
                foreach (var projectJobSummary in lstProjectJobSummary)
                {
                    ProjectJobSummaryDto projectJobSummaryDto = new ProjectJobSummaryDto();
                    projectJobSummaryDto = await ConvertToProjectJobSummaryDto(projectJobSummaryDto, projectJobSummary);
                    lstProjectJobSummaryDto.Add(projectJobSummaryDto);
                }
            }
            lstProjectJobSummaryDto = lstProjectJobSummaryDto.OrderByDescending(x => x.EndDate).ToList();

            return Json(new { ProjectJobSummary = lstProjectJobSummaryDto });
        }

        /// <summary>
        /// get jobcount summary
        /// </summary>
        [HttpGet]
        [Route("job/jobcountsummary")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetJobCountSummary(int userId)
        {
            var alljobs = _projectJobRepository.GetJobCountByCondition(userId, (int)JobSearchType.All);
            var appliedjobs = _projectJobRepository.GetJobCountByCondition(userId, (int)JobSearchType.Applied);
            var matchingjobs = _projectJobRepository.GetJobCountByCondition(userId, (int)JobSearchType.Matching);
            await Task.WhenAll(alljobs, appliedjobs, matchingjobs);
            return Json(new { alljobs = alljobs.Result, appliedjobs = appliedjobs.Result, matchingjobs = matchingjobs.Result });
        }

        /// <summary>
        /// This action is use to get job auditions based on status.
        /// </summary>
        /// <param name="jobAuditionsRequest"></param>
        /// <param name="userType">todo: describe userType parameter on GetJobAudition</param>
        /// <returns></returns>
        [HttpPost]
        [Route("jobauditions/talent")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetJobAudition(int userType, [FromBody]JobAuditionsRequest jobAuditionsRequest)
        {
            if (jobAuditionsRequest == null)
            {
                return BadRequest();
            }

            //This check login user is FTC admin and requested audition talents for matching tab
            if (userType == (int)LoginUserType.FTCAdmin && jobAuditionsRequest.IsMatchingTab)
            {
                var jobAuditions = await _talentJobRepository.GetTalentMatchingTabJobAuditions(jobAuditionsRequest);
                return Ok(jobAuditions);
            }
            else
            {
                var jobAuditions = await _talentJobRepository.GetJobAuditions(jobAuditionsRequest);
                return Ok(jobAuditions);
            }
        }

        [HttpPost]
        [Route("jobauditions/collaborator")]
        public async Task<IActionResult> GetCollaboratorShortlistedTalents([FromBody]JobAuditionsRequest jobAuditionsRequest)
        {
            if (jobAuditionsRequest == null && string.IsNullOrEmpty(jobAuditionsRequest.Token))
            {
                return BadRequest();
            }

            //Get job details based on token number.
            var jobData = _projectJobRepository.FindAll(g => g.Token == jobAuditionsRequest.Token).Select(g => new { ProjectName = _projectRepository.FindAll(p => p.Id == g.ProjectId).Select(p => p.Name).First(), JobName = g.Title, JobId = g.Id, JobDetails = g.Description });

            if (jobData == null || !jobData.Any())
            {
                return NotFound();
            }
            var job = jobData.First();
            jobAuditionsRequest.JobId = job.JobId;
            jobAuditionsRequest.StatusId = (int)ProjectJobStatusEnum.Shortlisted;
            jobAuditionsRequest.NotSelected = false;

            //Get list of shortlisted talents for collabrator feedback 
            var jobAuditions = await _talentJobRepository.GetJobAuditions(jobAuditionsRequest);
            jobAuditions.JobTitle = job.JobName;
            jobAuditions.JobDetails = job.JobDetails;
            jobAuditions.Project = job.ProjectName;
            jobAuditions.JobId = job.JobId;

            return Ok(jobAuditions);

        }

        [HttpGet]
        [Route("jobauditions/status/list")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetAuditionStatusList(int statusId, int jobId, int auditionId, bool notSelected)
        {
            if (statusId == 0 || (statusId == (int)ProjectJobStatusEnum.SelectedForAudition && jobId == 0))
            {
                return BadRequest();
            }
            var auditionStatusList = await _talentJobRepository.GetAuditionStatusList(statusId, jobId, auditionId, notSelected);
            return Ok(auditionStatusList);
        }

        /// <summary>
        /// This action is use to update talent job audition status 
        /// </summary>
        /// <param name="talentJobs"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("jobauditions/talent/saveauditionstatus")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SaveJobAuditionStatus(int userId, [FromBody]List<TalentJobAuditionStatus> talentJobs)
        {
            if (talentJobs == null || !talentJobs.Any())
            {
                return BadRequest();
            }

            //var requestObjectStatus = talentJobs.First().StatusId;


            var moveTalentsFromNotSelected = talentJobs.Where(x => (x.StatusId == (int)ProjectJobStatusEnum.MoveToUnderReview)).ToList();
            //|| x.StatusId == (int)ProjectJobStatusEnum.MoveToLastAuditionStage
            //|| x.StatusId == (int)ProjectJobStatusEnum.MoveToShortListed
            //|| x.StatusId == (int)ProjectJobStatusEnum.MoveToCasted))

            var status = await _talentJobRepository.SaveJobAuditionStatus(talentJobs);

            if (status)
            {
                if (talentJobs != null)
                {
                    if (talentJobs.Count > 0)
                    {
                        var talentJobInfo = talentJobs.FirstOrDefault();

                        var projectJob = await _projectJobRepository.FindAsync(x => x.Id == talentJobInfo.JobId);
                        var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

                        short? roundNumber = 0;
                        if (talentJobInfo.AuditionId != null || talentJobInfo.AuditionId > 0)
                        {
                            roundNumber = _jobAuditionRepository.Find(c => c.JobId == talentJobInfo.JobId && c.Id == talentJobInfo.AuditionId).RoundNumber;
                        }


                        var jobDetailsUrl = Path.Combine(_appSettings.DomainUrl, "jobs", "job-details", talentJobInfo.JobId.ToString());

                        foreach (TalentJobAuditionStatus talentJob in talentJobs)
                        {
                            if ((talentJob.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition && (talentJob.AuditionId != null || talentJob.AuditionId > 0)) && talentJob.NotSelected == false)
                            {
                                await SendSelectedRoundStatus(talentJob.TalentId, (int)talentJob.JobId, userId, jobDetailsUrl, roundNumber, projectJob.Title, project);                                
                            }
                        }
                        if ((talentJobInfo.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition && (talentJobInfo.AuditionId != null || talentJobInfo.AuditionId > 0)) && talentJobInfo.NotSelected == false)
                        {
                            // Notify Auxiliary User
                            await NotifyAuxiliaryuserJobSelectedAuditionStatus((int)talentJobInfo.JobId, userId, jobDetailsUrl, talentJobs.Count, roundNumber, projectJob.Title, project);
                        }

                    }

                }

                var notSelectedTalents = talentJobs.Where(x => x.NotSelected == true && x.TalentId != null);
                var lstNotSelectedTalent = notSelectedTalents.Select(x => (int)x.TalentId).ToList();

                ProjectJob job = null;

                var toAuditionSelection = talentJobs.Where(x => x.NotSelected == false
                                                                        && x.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition
                                                                        && (x.AuditionId == null || x.AuditionId == 0)
                                                                        && x.TalentId != null);

                var lstToAuditionSelection = toAuditionSelection.Select(x => (int)x.TalentId).ToList();

                var toShortlisted = talentJobs.Where(x => x.NotSelected == false
                                                                && x.StatusId == (int)ProjectJobStatusEnum.Shortlisted
                                                                && x.TalentId != null);

                var lstToShortlisted = toShortlisted.Select(x => (int)x.TalentId).ToList();


                var listMoveFromNotSelected = moveTalentsFromNotSelected.Select(c => (int)c.TalentId).ToList();

                //logic for notification when talent move from not selected to selected => in case of under Review, Shortlisted and casted.
                if (listMoveFromNotSelected != null && listMoveFromNotSelected.Count() > 0)
                {
                    var moveTalentFromNotSelected = moveTalentsFromNotSelected.First();
                    job = await _projectJobRepository.FindAsync(x => x.Id == moveTalentFromNotSelected.JobId);

                    await AuditionStagesNotification(userId, job.Id, job.ProjectId, job.Title, listMoveFromNotSelected, NotificationEnum.TalentReconsideredForAudition);
                    await AuditionStagesNotificationAuxiliaryUser(userId, job.Id, job.ProjectId, job.Title, listMoveFromNotSelected, NotificationEnum.TalentReconsideredForAuditionAdmin);
                }

                if (lstNotSelectedTalent.Count() > 0)
                {
                    var notSelectedTalent = notSelectedTalents.First();
                    job = await _projectJobRepository.FindAsync(x => x.Id == notSelectedTalent.JobId);
                    await AuditionStagesNotification(userId, job.Id, job.ProjectId, job.Title, lstNotSelectedTalent, NotificationEnum.JobNotSelectedAuditionStatus);
                    await AuditionStagesNotificationAuxiliaryUser(userId, job.Id, job.ProjectId, job.Title, lstNotSelectedTalent, NotificationEnum.JobNotSelectedAuditionStatusAdmin);
                }

                if (lstToAuditionSelection.Count() > 0)
                {
                    var auditionSelection = toAuditionSelection.First();
                    job = await _projectJobRepository.FindAsync(x => x.Id == auditionSelection.JobId);
                    await AuditionStagesNotification(userId, job.Id, job.ProjectId, job.Title, lstToAuditionSelection, NotificationEnum.AuditionSelectionStage);
                    await AuditionStagesNotificationAuxiliaryUser(userId, job.Id, job.ProjectId, job.Title, lstToAuditionSelection, NotificationEnum.AuditionSelectionStageAdmin);
                }

                if (lstToShortlisted.Count() > 0)
                {
                    var shortlisted = toShortlisted.First();
                    job = await _projectJobRepository.FindAsync(x => x.Id == shortlisted.JobId);
                    await AuditionStagesNotification(userId, job.Id, job.ProjectId, job.Title, lstToShortlisted, NotificationEnum.Shortlisted);
                    await AuditionStagesNotificationAuxiliaryUser(userId, job.Id, job.ProjectId, job.Title, lstToShortlisted, NotificationEnum.ShortlistedAdmin);
                }

                return Ok(new { message = "Talent job audition status updated successfully" });
            }

            return Json("Save Job Audition Status Failed");
        }

        private async Task AuditionStagesNotification(int userId, int jobId, int projectId, string jobTitle, List<int> lstTalent, NotificationEnum auditionStage)
        {
            var notificationParam = new NotificationParam();
            notificationParam.JobName = jobTitle;

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                // --- instead push notification object list is passed
                //SendNotificationToTalents = lstTalent,                
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.ApplyJob
            };

            var talents = await _talentRepository.FindAllAsync(x => lstTalent.Contains(x.Id));

            // send emails to talent
            sendSystemNotificationDto.SendEmailToTalents = talents.Select(x => x.Email).ToList();

            // send sms to talents
            notificationParam.SendSmsToTalents = talents.Select(x => new SendSmsToUsers
            {
                TalentId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            sendSystemNotificationDto.PushNotifications = talents.Select(x => new PushNotification
            {
                UserId = x.Id,
                DeviceOsId = x.DeviceOsId,
                DeviceRegistrationId = x.DeviceRegistrationId
            }).ToList();

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(auditionStage, notificationParam, sendSystemNotificationDto);
        }

        private async Task AuditionStagesNotificationAuxiliaryUser(int userId, int jobId, int projectId, string jobTitle, List<int> lstTalent, NotificationEnum auditionStage)
        {
            var notificationParam = new NotificationParam()
            {
                JobName = jobTitle,
                TalentCount = lstTalent.Count.ToString(),
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAdmin(),
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.ApplyJob
            };

            var project = await _projectRepository.FindAsync(x => x.Id == projectId);
            notificationParam.ProjectName = project.Name;

            // NotificationEnum.JobCastingFinal - send email to FTC PA & R PA as well along with RA & Ftc Admin
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userId, (int)NotificationEnum.JobCastingFinal, jobId);

            // Send Email and SMS to Admin's
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));

            var recruiter = auxiliaryUsers.FirstOrDefault(x => x.Id == project.AuxiliaryUserId);

            if (recruiter != null)
            { 
                notificationParam.RecruiterName = recruiter.FullName;
            }
            else
            { 
                recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
                notificationParam.RecruiterName = recruiter.FullName;
            }



            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(auditionStage, notificationParam, sendSystemNotificationDto);
        }

        /// <summary>
        /// This action is use to 
        /// </summary>
        /// <param name="recommendedTalents"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("jobauditions/talent/invite")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> InviteRecommendedJobAuditions(int userId, [FromBody]List<JobTalentRecommendedDto> recommendedTalents)
        {
            if (!recommendedTalents.Any())
            {
                return BadRequest();
            }

            var status = await _talentJobRepository.InviteRecommendedJobAuditions(recommendedTalents);

            if (status)
            {
                if (recommendedTalents.Any())
                {
                    var recommendedTalent = recommendedTalents.FirstOrDefault();
                    var projectJob = await _projectJobRepository.FindAsync(x => x.Id == recommendedTalent.JobId);
                    var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

                    var jobDetailsUrl = Path.Combine(_appSettings.DomainUrl, "jobs", "job-details", recommendedTalent.JobId.ToString());

                    foreach (var talent in recommendedTalents)
                    {
                        // Invite talents
                        await SendJobInvitationToApply(talent.TalentId, talent.JobId ?? 0, userId, jobDetailsUrl, projectJob.Title, project);
                    }

                    // Notify Auxiliaryuser about Talents Invited for Jobs
                    await NotifyAuxiliaryUserJobInvitationToApply((int)recommendedTalent.JobId, userId, jobDetailsUrl, recommendedTalents.Count, projectJob.Title, project);
                }

                return Ok(new { message = "Recommended talents invited successfully" });
            }
            return NotFound();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="castedTalents"></param>
        /// <returns></returns>                      
        [HttpPost]
        [Route("jobauditions/talent/casted/email")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SendJobAuditionCasted(int userId, [FromBody]List<TalentJobAuditionStatus> castedTalents)
        {
            if (!castedTalents.Any())
            {
                return BadRequest();
            }

            if (castedTalents.Any())
            {
                var castedTalent = castedTalents.FirstOrDefault();
                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == castedTalent.JobId);
                var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

                var jobDetailsUrl = Path.Combine(_appSettings.DomainUrl, "jobs", "job-details", castedTalent.JobId.ToString());

                foreach (var talent in castedTalents)
                {
                    // Notify talent about JobAuditionCasted
                    await SendCastedEmail(talent.TalentId, userId, (int)talent.JobId, jobDetailsUrl, projectJob.Title, project);
                }

                // Notify {Email, SMS, system notify} Auxiliary user about talents JobAuditionCasted
                await NotifyAuxiliaryUserJobAuditionCasted(userId, (int)castedTalent.JobId, castedTalents.Count, jobDetailsUrl, projectJob.Title, project);
            }
            return Ok(new { message = "Email has been sent sucessfully to casted talent." });
        }


        /// <summary>
        /// This action is use to 
        /// </summary>
        /// <param name="recommendedTalents"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("jobauditions/talent/invite/email")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SendJobInvitation(int userId, [FromBody]List<JobTalentRecommendedDto> recommendedTalents)
        {
            if (!recommendedTalents.Any())
            {
                return BadRequest();
            }

            if (recommendedTalents.Any())
            {

                var recommendedTalent = recommendedTalents.FirstOrDefault();
                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == recommendedTalent.JobId);
                var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

                var jobDetailsUrl = Path.Combine(_appSettings.DomainUrl, "jobs", "job-details", recommendedTalent.JobId.ToString());

                foreach (var talent in recommendedTalents)
                {
                    await SendJobInvitationToApply(talent.TalentId, talent.JobId ?? 0, userId, jobDetailsUrl, projectJob.Title, project);
                }

                // Notify Auxiliaryuser about Talents Invited for Jobs
                await NotifyAuxiliaryUserJobInvitationToApply((int)recommendedTalent.JobId, userId, jobDetailsUrl, recommendedTalents.Count, projectJob.Title, project);
            }
            return Ok(new { message = "Email has been sent sucessfully to invited talent." });
        }

        /// <summary>
        /// This action is use to get recommended talents for job auditions
        /// </summary>
        /// <param name="jobAuditionsRequest">todo: describe jobAuditionsRequest parameter on GetJobAuditionRecommended</param>
        /// <returns></returns>
        [HttpPost]
        [Route("jobauditions/talent/recommended")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetJobAuditionRecommended([FromBody]JobAuditionsRequest jobAuditionsRequest)
        {
            if (jobAuditionsRequest == null)
            {
                return BadRequest();
            }

            var jobAuditionRecommended = await _talentJobRepository.GetJobAuditionRecommended(jobAuditionsRequest);
            return Ok(jobAuditionRecommended);

        }

        /// <summary>
        /// This action is use to get intransit talents for job auditions
        /// </summary>
        /// <param name="jobAuditionsRequest"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("jobauditions/talent/intransit")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetJobAuditionInTransit([FromBody]JobAuditionsRequest jobAuditionsRequest)
        {
            if (jobAuditionsRequest == null)
            {
                return BadRequest();
            }

            var jobAuditionInTransit = await _talentJobRepository.GetJobAuditionInTransit(jobAuditionsRequest);
            return Ok(jobAuditionInTransit);
        }

        [HttpPost]
        [Route("jobauditions/collaborator/feedback")]
        public async Task<IActionResult> UpdateCollaboratorFeedback([FromBody]CollabratorFeedback collabratorFeedback)
        {
            if (collabratorFeedback == null && !collabratorFeedback.TalentJobs.Any())
            {
                return BadRequest();
            }

            var projectJob = await _talentJobRepository.UpdateCollaboratorFeedback(collabratorFeedback);

            if (projectJob != null)
            {
                #region Send Notification to Admin & Recruiter

                await NotifyRecruiterCollaboratorsFeedback(collabratorFeedback, projectJob);

                #endregion

                return Ok(new { message = "Collaborator feedback updated successfully" });
            }

            return NotFound();
        }

        private async Task NotifyRecruiterCollaboratorsFeedback(CollabratorFeedback collabratorFeedback, ProjectJob projectJob)
        {
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                JobName = projectJob.Title,
                Message = collabratorFeedback.FeedbackMessage
            };

            var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = projectJob.Id,
                UrlRoute = ViewNotificationEnumDto.EditProjectJob
            };

            // send to all those user - like job publish
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, project.AuxiliaryUserId, (int)NotificationEnum.CollaboratorFeedback, project.Id, projectJob.Id);
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Add(project.AuxiliaryUserId);

            await notification.SendNotification(NotificationEnum.CollaboratorFeedback, notificationParam, sendSystemNotificationDto);
        }

        [Route("job/saveJobBanner")]
        [HttpPost]
        public async Task<IActionResult> SaveJobBanner([FromHeader]int jobId, IFormFile file)
        {
            if (file != null)
            {
                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobId);
                if (!string.IsNullOrEmpty(projectJob.ReferenceMedia))
                {
                    await _fileService.DeleteAsync(projectJob.ReferenceMedia.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                }
                projectJob.ReferenceMedia = await UploadJobImage(file, projectJob.Id, projectJob.ProjectId);
                projectJob = await _projectJobRepository.UpdateAsync(projectJob);
                return Json(projectJob.ReferenceMedia);
            }
            return null;
        }


        [Route("job/removeJobBanner/{jobId}")]
        [HttpDelete]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> RemoveJobBanner(int jobId)
        {
            var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobId);
            if (projectJob == null)
            {
                return NoContent();
            }
            if (!string.IsNullOrEmpty(projectJob.ReferenceMedia))
            {
                await _fileService.DeleteAsync(projectJob.ReferenceMedia.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
            }
            projectJob.ReferenceMedia = string.Empty;
            projectJob = await _projectJobRepository.UpdateAsync(projectJob);
            return Json(new { result = "success" });
        }


        [HttpGet]
        [Route("job/{jobId}/featureJob/{isFeatured}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> SetFeaturedJob(int jobId, bool isFeatured)
        {
            var job = await _projectJobRepository.FindAsync(x => x.Id == jobId);
            if (job == null)
            {
                return NotFound();
            }
            job.IsFeaturedJob = isFeatured;
            job = await _projectJobRepository.UpdateAsync(job);

            return Json(job);
        }

        #endregion

        #region Private methods
        [NonAction]
        private async Task<ProjectJobDto> ConvertProjectJobModelToProjectJobDto(ProjectJob job)
        {
            return new ProjectJobDto
            {
                Id = job.Id,
                ProjectId = job.ProjectId,
                ProjectName = job.Project.Name,
                Title = job.Title,
                TalentCategoryId = job.TalentCategoryId.Value,
                TalentCategory = job.JobTalentCategory.Description,
                IsCastingRequired = job.CastRequired.Value,
                Gender = job.Gender,
                NationalityId = job.NationalityId.HasValue ? job.NationalityId.Value : (int?)null,
                Nationality = job.NationalityId.HasValue ? await getNationalityById(job.NationalityId.Value) : string.Empty,
                NumberOfRoles = job.NumberOfRole.HasValue ? job.NumberOfRole.Value : (short?)null,
                MinAge = job.MinAge.Value,
                MaxAge = job.MaxAge.Value,
                MinBudget = job.MinBudget.HasValue ? job.MinBudget.Value : 1,
                MaxBudget = job.MaxBudget.HasValue ? job.MaxBudget.Value : 200,
                isBudgetNotDefined = job.MinBudget == null ? true : false,
                StartDate = job.StartDate.Value,
                EndDate = job.EndDate.Value,
                IsExperienceRequired = job.ExperienceRequired.Value,
                IsHeadshotRequired = job.HeadshotRequired.Value,
                IsSideProfileRequired = job.SideprofileRequired.Value,
                IsIntroVideoRequired = job.IntrovideoRequired.Value,
                AuditionMediaType = job.MediaFiletypeId.Value,
                Description = job.Description,
                ReferenceMedia = job.ReferenceMedia,
                Keywords = job.Keywords,
                Project = ConvertToProjectDto(job.Project),
                IsAssociationUnion = job.AssociationRequired.Value,
                IsPassportRequired = job.PassportRequired.Value,
                MinHeight = job.MinHeightId.HasValue ? getHeightbyId(job.MinHeightId) : 47,
                MaxHeight = job.MaxHeightId.HasValue ? getHeightbyId(job.MaxHeightId) : 87,
                isHeightNotDefined = job.MinHeightId == null ? true : false,
                MinWeight = job.MinWeightId.HasValue ? getWeightbyId(job.MinWeightId) : 39,
                MaxWeight = job.MaxWeightId.HasValue ? getWeightbyId(job.MaxWeightId) : 120,
                isWeightNotDefined = job.MinWeightId == null ? true : false,
                MinChest = job.MinChestSizeId.HasValue ? getChestSizebyId(job.MinChestSizeId) : 28,
                MaxChest = job.MaxChestSizeId.HasValue ? getChestSizebyId(job.MaxChestSizeId) : 48,
                isChestNotDefined = job.MinChestSizeId == null ? true : false,
                EyeColors = GetSelectDtoFromModel(job.ProjectJobEyecolor, MasterModel.EyeColor),
                HairColors = GetSelectDtoFromModel(job.ProjectJobHairColor, MasterModel.HairColor),
                SkinColors = GetSelectDtoFromModel(job.ProjectJobSkinColor, MasterModel.SkinColor),
                BodyTypes = GetSelectDtoFromModel(job.ProjectJobBodytype, MasterModel.BodyType),
                Ethnicities = GetSelectDtoFromModel(job.ProjectJobEthnicity, MasterModel.Ethnicity),
                Languages = GetSelectDtoFromModel(job.ProjectJobLanguage, MasterModel.Language),
                SubTalents = GetSelectDtoFromModel(job.ProjectJobSubTalent, MasterModel.SubTalent),
                PerformingSkills = GetSelectDtoFromModel(job.ProjectJobTag, MasterModel.PerformingSkill),
                Locations = await ConvertToLocationDto(job.Id),
                JobStatus = job.StatusId.Value,
            };
        }

        [NonAction]
        private ProjectDto ConvertToProjectDto(Project project)
        {
            return new ProjectDto
            {
                Id = project.Id,
                Name = project.Name,
                StartDate = project.StartDate,
                EndDate = project.EndDate,
                EventDate = project.EventDate,
                PlanId = project.PlanId,
                CastingRequired = project.CastingRequired,
                IsPaid = project.IsPaid,
                StatusId = project.StatusId,
            };
        }

        private int? getChestSizebyId(int? chestSizeId)
        {
            var chestSize = _chestSizeRepository.Find(x => x.Id == chestSizeId);
            if (chestSize != null)
            {
                return (int)chestSize.Inches;
            }
            return null;
        }

        private int? getWeightbyId(int? weightId)
        {
            var weight = _weightRepository.Find(x => x.Id == weightId);
            if (weight != null)
            {
                return weight.Kgs;
            }
            return null;
        }

        private int? getHeightbyId(int? heightId)
        {
            var height = _heightRepository.Find(x => x.Id == heightId);
            if (height != null)
            {
                return (int)height.Inches.Value;
            }
            return null;
        }

        [NonAction]
        private async Task<string> getNationalityById(int countryId)
        {
            var country = await _countryRepository.FindAsync(x => x.Id == countryId);
            return country.Nationality;
        }

        [NonAction]
        private async Task<List<SelectDto>> ConvertToLocationDto(int jobId)
        {
            List<SelectDto> locations = new List<SelectDto>();
            var jobLocations = await _projectJobLocationRepository.FindAllAsync(x => x.JobId == jobId);
            if (jobLocations != null)
            {
                foreach (var jobLocation in jobLocations)
                {
                    SelectDto location = new SelectDto();
                    location.Id = jobLocation.CityId.Value;
                    var country = await _countryRepository.FindAsync(x => x.Id == jobLocation.City.CityCountryId);
                    var city = await _cityRepository.FindAsync(x => x.CityId == jobLocation.CityId);
                    location.Description = city.CityDescription + ',' + country.Name;
                    locations.Add(location);
                }
            }
            return locations;
        }
        [NonAction]
        private List<SelectDto> GetSelectDtoFromModel(dynamic model, MasterModel modelType)
        {
            switch (modelType)
            {
                case MasterModel.BodyType:
                    var bodyTypes = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.BodyType.Id,
                                Description = item.BodyType.Description
                            };
                            bodyTypes.Add(selectDto);
                        }
                    }
                    return bodyTypes;

                case MasterModel.EyeColor:
                    var eyeColors = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.EyeColor.Id,
                                Description = item.EyeColor.Description
                            };
                            eyeColors.Add(selectDto);
                        }
                    }
                    return eyeColors;

                case MasterModel.HairColor:
                    var hairColors = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.HairColor.Id,
                                Description = item.HairColor.Description
                            };
                            hairColors.Add(selectDto);
                        }
                    }
                    return hairColors;

                case MasterModel.SkinColor:
                    var skinColors = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.SkinColor.Id,
                                Description = item.SkinColor.Description
                            };
                            skinColors.Add(selectDto);
                        }
                    }
                    return skinColors;

                case MasterModel.Ethnicity:
                    var ehtnicities = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.Ethnicity.Id,
                                Description = item.Ethnicity.Description
                            };
                            ehtnicities.Add(selectDto);
                        }
                    }
                    return ehtnicities;

                case MasterModel.SubTalent:
                    var subTalents = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.TalentCategory.Id,
                                Description = item.TalentCategory.Description
                            };
                            subTalents.Add(selectDto);
                        }
                    }
                    return subTalents;

                case MasterModel.Language:
                    var languages = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.Language.Id,
                                Description = item.Language.Description
                            };
                            languages.Add(selectDto);
                        }
                    }
                    return languages;

                case MasterModel.PerformingSkill:
                    var performingSkills = new List<SelectDto>();
                    if (model != null)
                    {
                        foreach (var item in model)
                        {
                            var selectDto = new SelectDto
                            {
                                Id = item.Tag.Id,
                                Description = item.Tag.Name
                            };
                            performingSkills.Add(selectDto);
                        }
                    }
                    return performingSkills;

                default:
                    return null;
            }
        }
        [NonAction]
        private async Task<ProjectJob> UpdateProjectJobModel(ProjectJob projectJob, ProjectJobDto projectJobDto)
        {
            projectJob.Title = projectJobDto.Title;
            projectJob.TalentCategoryId = projectJobDto.TalentCategoryId;
            projectJob.CastRequired = projectJobDto.IsCastingRequired;
            projectJob.Gender = projectJobDto.Gender;
            projectJob.NationalityId = projectJobDto.NationalityId;
            projectJob.NumberOfRole = projectJobDto.NumberOfRoles;
            projectJob.MinAge = projectJobDto.MinAge;
            projectJob.MaxAge = projectJobDto.MaxAge;
            projectJob.MinBudget = projectJobDto.isBudgetNotDefined == true ? null : projectJobDto.MinBudget;
            projectJob.MaxBudget = projectJobDto.isBudgetNotDefined == true ? null : projectJobDto.MaxBudget;
            projectJob.StartDate = projectJobDto.StartDate;
            projectJob.EndDate = projectJobDto.EndDate;
            projectJob.ExperienceRequired = projectJobDto.IsExperienceRequired;
            projectJob.HeadshotRequired = projectJobDto.IsHeadshotRequired;
            projectJob.SideprofileRequired = projectJobDto.IsSideProfileRequired;
            projectJob.IntrovideoRequired = projectJobDto.IsIntroVideoRequired;
            projectJob.MediaFiletypeId = projectJobDto.AuditionMediaType;
            projectJob.Description = projectJobDto.Description;
            projectJob.Keywords = projectJobDto.Keywords;
            projectJob.AssociationRequired = projectJobDto.IsAssociationUnion;
            projectJob.PassportRequired = projectJobDto.IsPassportRequired;
            projectJob.MinHeightId = projectJobDto.isHeightNotDefined == true ? null : getHeightId(projectJobDto.MinHeight);
            projectJob.MaxHeightId = projectJobDto.isHeightNotDefined == true ? null : getHeightId(projectJobDto.MaxHeight);
            projectJob.MinWeightId = projectJobDto.isWeightNotDefined == true ? null : getWeightId(projectJobDto.MinWeight);
            projectJob.MaxWeightId = projectJobDto.isWeightNotDefined == true ? null : getWeightId(projectJobDto.MaxWeight);
            projectJob.MinChestSizeId = projectJobDto.isChestNotDefined == true ? null : getChestSizeId(projectJobDto.MinChest);
            projectJob.MaxChestSizeId = projectJobDto.isChestNotDefined == true ? null : getChestSizeId(projectJobDto.MaxChest);
            projectJob.ProjectJobSubTalent = await getSubTalentsForJobUpdate(projectJob.Id, projectJob.ProjectJobSubTalent, projectJobDto);
            projectJob.ProjectJobLanguage = await getLanguagesForJobUpdate(projectJob.Id, projectJob.ProjectJobLanguage, projectJobDto);
            projectJob.ProjectJobBodytype = await getBodyTypeForJobUpdate(projectJob.Id, projectJob.ProjectJobBodytype, projectJobDto);
            projectJob.ProjectJobEyecolor = await getEyeColorsForJobUpdate(projectJob.Id, projectJob.ProjectJobEyecolor, projectJobDto);
            projectJob.ProjectJobHairColor = await getHairColorsForJobUpdate(projectJob.Id, projectJob.ProjectJobHairColor, projectJobDto);
            projectJob.ProjectJobSkinColor = await getSkinColorsForJobUpdate(projectJob.Id, projectJob.ProjectJobSkinColor, projectJobDto);
            projectJob.ProjectJobEthnicity = await getEthnicitiesForJobUpdate(projectJob.Id, projectJob.ProjectJobEthnicity, projectJobDto);
            projectJob.ProjectJobLocation = await getLocationsForJobUpdate(projectJob.Id, projectJob.ProjectJobLocation, projectJobDto);
            projectJob.ProjectJobTag = await getProjectJobTagsForJobUpdate(projectJob.Id, projectJob.ProjectJobTag, projectJobDto);
            return projectJob;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobEthnicity>> getEthnicitiesForJobUpdate(int id, ICollection<ProjectJobEthnicity> projectJobEthnicity, ProjectJobDto projectJobDto)
        {
            var ethnicityIds = projectJobDto.Ethnicities.Select(x => x.Id).ToList();
            //get the previous city ids
            var allEthnicities = await _projectJobEthnicityRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobEthnicity> projectJobEthnicities = allEthnicities.ToList();

            if (projectJobEthnicities != null && projectJobEthnicities.Count() > 0)
            {
                var ethnicitiesToBeDeleted = projectJobEthnicities.Where(x => !ethnicityIds.Contains(x.EthnicityId.Value));

                foreach (var ethnicityToBeDeleted in ethnicitiesToBeDeleted.ToList())
                {
                    projectJobEthnicities.RemoveAll(x => x.Id == ethnicityToBeDeleted.Id);
                }
            }

            if (ethnicityIds != null && ethnicityIds.Count > 0)
            {
                foreach (var ethnicityId in ethnicityIds)
                {
                    var ethnicity = projectJobEthnicities.Where(x => x.EthnicityId == ethnicityId).FirstOrDefault();
                    if (ethnicity == null)
                    {
                        ProjectJobEthnicity projectEthnicity = new ProjectJobEthnicity();
                        projectEthnicity.JobId = id;
                        projectEthnicity.EthnicityId = projectJobDto.Ethnicities.Where(x => x.Id == ethnicityId).FirstOrDefault().Id;
                        projectJobEthnicities.Add(projectEthnicity);
                    }

                }
            }
            return projectJobEthnicities;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobBodytype>> getBodyTypeForJobUpdate(int id, ICollection<ProjectJobBodytype> projectJobBodytype, ProjectJobDto projectJobDto)
        {
            var bodyTypeIds = projectJobDto.BodyTypes.Select(x => x.Id).ToList();
            //get the previous city ids
            var allBodyTypes = await _projectJobBodyTypeRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobBodytype> projectJobBodyTypes = allBodyTypes.ToList();

            if (projectJobBodyTypes != null && projectJobBodyTypes.Count() > 0)
            {
                var typesToBeDeleted = projectJobBodyTypes.Where(x => !bodyTypeIds.Contains(x.BodytypeId.Value));

                foreach (var typeToBeDeleted in typesToBeDeleted.ToList())
                {
                    projectJobBodyTypes.RemoveAll(x => x.Id == typeToBeDeleted.Id);
                }
            }

            if (bodyTypeIds != null && bodyTypeIds.Count > 0)
            {
                foreach (var bodyTypeId in bodyTypeIds)
                {
                    var bodyType = projectJobBodyTypes.Where(x => x.BodytypeId == bodyTypeId).FirstOrDefault();
                    if (bodyType == null)
                    {
                        ProjectJobBodytype projectBodyType = new ProjectJobBodytype();
                        projectBodyType.JobId = id;
                        projectBodyType.BodytypeId = projectJobDto.BodyTypes.Where(x => x.Id == bodyTypeId).FirstOrDefault().Id;
                        projectJobBodyTypes.Add(projectBodyType);
                    }

                }
            }
            return projectJobBodyTypes;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobTag>> getProjectJobTagsForJobUpdate(int id, ICollection<ProjectJobTag> projectJobTag, ProjectJobDto projectJobDto)
        {
            var tagIds = projectJobDto.PerformingSkills.Select(x => x.Id).ToList();
            //get the previous city ids
            var allTags = await _projectJobTagRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobTag> projectJobTags = allTags.ToList();

            if (projectJobTags != null && projectJobTags.Count() > 0)
            {
                var tagsToBeDeleted = projectJobTags.Where(x => !tagIds.Contains(x.TagId.Value));

                foreach (var tagToBeDeleted in tagsToBeDeleted.ToList())
                {
                    projectJobTags.RemoveAll(x => x.Id == tagToBeDeleted.Id);
                }
            }

            if (tagIds != null && tagIds.Count > 0)
            {
                foreach (var tagId in tagIds)
                {
                    var tag = projectJobTags.Where(x => x.TagId == tagId).FirstOrDefault();
                    if (tag == null)
                    {
                        ProjectJobTag projectTag = new ProjectJobTag();
                        projectTag.JobId = id;
                        projectTag.TagId = projectJobDto.PerformingSkills.Where(x => x.Id == tagId).FirstOrDefault().Id;
                        projectJobTags.Add(projectTag);
                    }

                }
            }
            return projectJobTags;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobSkinColor>> getSkinColorsForJobUpdate(int id, ICollection<ProjectJobSkinColor> projectJobSkinColor, ProjectJobDto projectJobDto)
        {
            var skinColorIds = projectJobDto.SkinColors.Select(x => x.Id).ToList();
            //get the previous city ids
            var allSkinColors = await _projectJobSkinColorRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobSkinColor> projectJobSkinColors = allSkinColors.ToList();

            if (projectJobSkinColors != null && projectJobSkinColors.Count() > 0)
            {
                var skinColorsToBeDeleted = projectJobSkinColors.Where(x => !skinColorIds.Contains(x.SkinColorId.Value));

                foreach (var skinColorToBeDeleted in skinColorsToBeDeleted.ToList())
                {
                    projectJobSkinColors.RemoveAll(x => x.Id == skinColorToBeDeleted.Id);
                }
            }

            if (skinColorIds != null && skinColorIds.Count > 0)
            {
                foreach (var skinColorId in skinColorIds)
                {
                    var skinColor = projectJobSkinColors.Where(x => x.SkinColorId == skinColorId).FirstOrDefault();
                    if (skinColor == null)
                    {
                        ProjectJobSkinColor projectSkinColor = new ProjectJobSkinColor();
                        projectSkinColor.JobId = id;
                        projectSkinColor.SkinColorId = projectJobDto.SkinColors.Where(x => x.Id == skinColorId).FirstOrDefault().Id;
                        projectJobSkinColors.Add(projectSkinColor);
                    }

                }
            }
            return projectJobSkinColors;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobHairColor>> getHairColorsForJobUpdate(int id, ICollection<ProjectJobHairColor> projectJobHairColor, ProjectJobDto projectJobDto)
        {
            var hairColorIds = projectJobDto.HairColors.Select(x => x.Id).ToList();
            //get the previous city ids
            var allHairColors = await _projectJobHairColorRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobHairColor> projectJobHairColors = allHairColors.ToList();

            if (projectJobHairColors != null && projectJobHairColors.Count() > 0)
            {
                var hairColorsToBeDeleted = projectJobHairColors.Where(x => !hairColorIds.Contains(x.HaircolorId.Value));

                foreach (var hairColorToBeDeleted in hairColorsToBeDeleted.ToList())
                {
                    projectJobHairColors.RemoveAll(x => x.Id == hairColorToBeDeleted.Id);
                }
            }

            if (hairColorIds != null && hairColorIds.Count > 0)
            {
                foreach (var hairColorId in hairColorIds)
                {
                    var eyeColor = projectJobHairColors.Where(x => x.HaircolorId == hairColorId).FirstOrDefault();
                    if (eyeColor == null)
                    {
                        ProjectJobHairColor projectHairColor = new ProjectJobHairColor();
                        projectHairColor.JobId = id;
                        projectHairColor.HaircolorId = projectJobDto.HairColors.Where(x => x.Id == hairColorId).FirstOrDefault().Id;
                        projectJobHairColors.Add(projectHairColor);
                    }

                }
            }
            return projectJobHairColors;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobEyeColor>> getEyeColorsForJobUpdate(int id, ICollection<ProjectJobEyeColor> projectJobEyecolor, ProjectJobDto projectJobDto)
        {
            //get all the cityids from ui
            var eyeColorIds = projectJobDto.EyeColors.Select(x => x.Id).ToList();
            //get the previous city ids
            var allEyeColors = await _projectJobEyeColorRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobEyeColor> projectJobEyeColors = allEyeColors.ToList();

            if (projectJobEyeColors != null && projectJobEyeColors.Count() > 0)
            {
                var eyeColorsToBeDeleted = projectJobEyeColors.Where(x => !eyeColorIds.Contains(x.EyecolorId.Value));

                foreach (var eyeColorToBeDeleted in eyeColorsToBeDeleted.ToList())
                {
                    projectJobEyeColors.RemoveAll(x => x.Id == eyeColorToBeDeleted.Id);
                }
            }

            if (eyeColorIds != null && eyeColorIds.Count > 0)
            {
                foreach (var eyeColorId in eyeColorIds)
                {
                    var eyeColor = projectJobEyeColors.Where(x => x.EyecolorId == eyeColorId).FirstOrDefault();
                    if (eyeColor == null)
                    {
                        ProjectJobEyeColor projectEyeColor = new ProjectJobEyeColor();
                        projectEyeColor.JobId = id;
                        projectEyeColor.EyecolorId = projectJobDto.EyeColors.Where(x => x.Id == eyeColorId).FirstOrDefault().Id;
                        projectJobEyeColors.Add(projectEyeColor);
                    }

                }
            }
            return projectJobEyeColors;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobLanguage>> getLanguagesForJobUpdate(int id, ICollection<ProjectJobLanguage> projectJobLanguage, ProjectJobDto projectJobDto)
        {
            //get all the cityids from ui
            var languageIds = projectJobDto.Languages.Select(x => x.Id).ToList();
            //get the previous city ids
            var allLanguages = await _projectJobLanguageRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobLanguage> projectJobLanguages = allLanguages.ToList();

            if (projectJobLanguages != null && projectJobLanguages.Count() > 0)
            {
                var languagesToBeDeleted = projectJobLanguages.Where(x => !languageIds.Contains(x.LanguageId.Value));

                foreach (var languageToBDeleted in languagesToBeDeleted.ToList())
                {
                    projectJobLanguages.RemoveAll(x => x.Id == languageToBDeleted.Id);
                }
            }

            if (languageIds != null && languageIds.Count > 0)
            {
                foreach (var languageId in languageIds)
                {
                    var language = projectJobLanguages.Where(x => x.LanguageId == languageId).FirstOrDefault();
                    if (language == null)
                    {
                        ProjectJobLanguage projectLanguage = new ProjectJobLanguage();
                        projectLanguage.JobId = id;
                        projectLanguage.LanguageId = projectJobDto.Languages.Where(x => x.Id == languageId).FirstOrDefault().Id;
                        projectJobLanguages.Add(projectLanguage);
                    }

                }
            }
            return projectJobLanguages;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobSubTalent>> getSubTalentsForJobUpdate(int id, ICollection<ProjectJobSubTalent> projectJobSubTalent, ProjectJobDto projectJobDto)
        {
            //get all the cityids from ui
            var talentIds = projectJobDto.SubTalents.Select(x => x.Id).ToList();
            //get the previous city ids
            var allSubTalents = await _projectJobSubTalentRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobSubTalent> projectJobSubTalents = allSubTalents.ToList();

            if (projectJobSubTalents != null && projectJobSubTalents.Count() > 0)
            {
                var subTalentsToBeDeleted = projectJobSubTalents.Where(x => !talentIds.Contains(x.JobSubTalentId.Value));

                foreach (var talentToBDeleted in subTalentsToBeDeleted.ToList())
                {
                    projectJobSubTalents.RemoveAll(x => x.Id == talentToBDeleted.Id);
                }
            }

            if (talentIds != null && talentIds.Count > 0)
            {
                foreach (var talentId in talentIds)
                {
                    var talent = projectJobSubTalents.Where(x => x.JobSubTalentId == talentId).FirstOrDefault();
                    if (talent == null)
                    {
                        ProjectJobSubTalent projectJobTalent = new ProjectJobSubTalent();
                        projectJobTalent.JobId = id;
                        projectJobTalent.JobSubTalentId = projectJobDto.SubTalents.Where(x => x.Id == talentId).FirstOrDefault().Id;
                        projectJobSubTalents.Add(projectJobTalent);
                    }

                }
            }
            return projectJobSubTalents;
        }

        [NonAction]
        private async Task<ICollection<ProjectJobLocation>> getLocationsForJobUpdate(int id, ICollection<ProjectJobLocation> jobLocations, ProjectJobDto projectJobDto)
        {
            //get all the cityids from ui
            var cityIds = projectJobDto.Locations.Select(x => x.Id).ToList();
            //get the previous city ids
            var allJobLocations = await _projectJobLocationRepository.FindAllAsync(x => x.JobId == id);
            List<ProjectJobLocation> projectJobLocations = allJobLocations.ToList();

            if (projectJobLocations != null && projectJobLocations.Count() > 0)
            {
                var locationsToBeDeleted = projectJobLocations.Where(x => !cityIds.Contains(x.CityId.Value));

                foreach (var locationToBDeleted in locationsToBeDeleted.ToList())
                {
                    projectJobLocations.RemoveAll(x => x.Id == locationToBDeleted.Id);
                }
            }

            if (cityIds != null && cityIds.Count > 0)
            {
                foreach (var cityId in cityIds)
                {
                    var city = projectJobLocations.Where(x => x.CityId == cityId).FirstOrDefault();
                    if (city == null)
                    {
                        ProjectJobLocation projectJobLocation = new ProjectJobLocation();
                        projectJobLocation.JobId = id;
                        projectJobLocation.CityId = projectJobDto.Locations.Where(x => x.Id == cityId).FirstOrDefault().Id;
                        projectJobLocations.Add(projectJobLocation);
                    }

                }
            }
            return projectJobLocations;
        }


        [NonAction]
        private ProjectJob ConvertToProjectJobModel(ProjectJobDto projectJobDto)
        {
            return new ProjectJob
            {
                ProjectId = projectJobDto.ProjectId,
                Title = projectJobDto.Title,
                TalentCategoryId = projectJobDto.TalentCategoryId,
                CastRequired = projectJobDto.IsCastingRequired,
                Gender = projectJobDto.Gender,
                NationalityId = projectJobDto.NationalityId,
                NumberOfRole = projectJobDto.NumberOfRoles,
                MinAge = projectJobDto.MinAge,
                MaxAge = projectJobDto.MaxAge,
                MinBudget = projectJobDto.isBudgetNotDefined == true ? null : projectJobDto.MinBudget,
                MaxBudget = projectJobDto.isBudgetNotDefined == true ? null : projectJobDto.MaxBudget,
                StartDate = projectJobDto.StartDate,
                EndDate = projectJobDto.EndDate,
                ExperienceRequired = projectJobDto.IsExperienceRequired,
                HeadshotRequired = projectJobDto.IsHeadshotRequired,
                SideprofileRequired = projectJobDto.IsSideProfileRequired,
                IntrovideoRequired = projectJobDto.IsIntroVideoRequired,
                MediaFiletypeId = projectJobDto.AuditionMediaType,
                Description = projectJobDto.Description,
                Keywords = projectJobDto.Keywords,
                AssociationRequired = projectJobDto.IsAssociationUnion,
                PassportRequired = projectJobDto.IsPassportRequired,
                MinHeightId = projectJobDto.isHeightNotDefined == true ? null : getHeightId(projectJobDto.MinHeight),
                MaxHeightId = projectJobDto.isHeightNotDefined == true ? null : getHeightId(projectJobDto.MaxHeight),
                MinWeightId = projectJobDto.isWeightNotDefined == true ? null : getWeightId(projectJobDto.MinWeight),
                MaxWeightId = projectJobDto.isWeightNotDefined == true ? null : getWeightId(projectJobDto.MaxWeight),
                MinChestSizeId = projectJobDto.isChestNotDefined == true ? null : getChestSizeId(projectJobDto.MinChest),
                MaxChestSizeId = projectJobDto.isChestNotDefined == true ? null : getChestSizeId(projectJobDto.MaxChest),
                ProjectJobSubTalent = GetMasterAttributeModel(projectJobDto.SubTalents, MasterModel.SubTalent),
                ProjectJobLanguage = GetMasterAttributeModel(projectJobDto.Languages, MasterModel.Language),
                ProjectJobBodytype = GetMasterAttributeModel(projectJobDto.BodyTypes, MasterModel.BodyType),
                ProjectJobEyecolor = GetMasterAttributeModel(projectJobDto.EyeColors, MasterModel.EyeColor),
                ProjectJobHairColor = GetMasterAttributeModel(projectJobDto.HairColors, MasterModel.HairColor),
                ProjectJobSkinColor = GetMasterAttributeModel(projectJobDto.SkinColors, MasterModel.SkinColor),
                ProjectJobEthnicity = GetMasterAttributeModel(projectJobDto.Ethnicities, MasterModel.Ethnicity),
                ProjectJobLocation = GetMasterAttributeModel(projectJobDto.Locations, MasterModel.Location),
                ProjectJobTag = GetMasterAttributeModel(projectJobDto.PerformingSkills, MasterModel.PerformingSkill),
            };

        }

        private int? getHeightId(int? heightInInches)
        {
            if (heightInInches <= 12)
            {
                heightInInches = 12;
            }
            else if (heightInInches > 12 && heightInInches <= 24)
            {
                heightInInches = 24;
            }
            else if (heightInInches > 24 && heightInInches <= 36)
            {
                heightInInches = 36;
            }

            var height = _heightRepository.Find(x => x.Inches == heightInInches);
            if (height != null)
            {
                return height.Id;
            }
            return null;
        }

        private int? getWeightId(int? weightInKg)
        {

            if (weightInKg <= 10)
            {
                weightInKg = 10;
            }
            else if (weightInKg > 10 && weightInKg <= 20)
            {
                weightInKg = 20;
            }
            else if (weightInKg > 20 && weightInKg <= 30)
            {
                weightInKg = 30;
            }

            var weight = _weightRepository.Find(x => x.Kgs == weightInKg);
            if (weight != null)
            {
                return weight.Id;
            }
            return null;
        }

        private int? getChestSizeId(int? chestSizeInInches)
        {
            var chest = _chestSizeRepository.Find(x => x.Inches == chestSizeInInches);
            if (chest != null)
            {
                return chest.Id;
            }
            return null;
        }

        [NonAction]
        private async Task<ProjectJobSummaryDto> ConvertToProjectJobSummaryDto(ProjectJobSummaryDto projectJobSummaryDto, ProjectJob projectJobSummary)
        {
            projectJobSummaryDto.Id = projectJobSummary.Id;
            projectJobSummaryDto.Title = projectJobSummary.Title;
            projectJobSummaryDto.Description = projectJobSummary.Description;
            projectJobSummaryDto.TalentCategoryId = projectJobSummary.TalentCategoryId;
            projectJobSummaryDto.EndDate = projectJobSummary.EndDate;
            projectJobSummaryDto.MinAge = projectJobSummary.MinAge;
            projectJobSummaryDto.MaxAge = projectJobSummary.MaxAge;

            // fetch job location for the JOB
            var projectJobLocations = await _projectJobLocationRepository.FindAllAsync(x => x.JobId == projectJobSummary.Id);
            if (projectJobLocations != null)
            {
                foreach (var projectJobLocation in projectJobLocations)
                {
                    var cityResponse = await _cityRepository.FindAsync(x => x.CityId == projectJobLocation.CityId);
                    projectJobSummaryDto.CityId.Add((int)projectJobLocation.CityId);
                    projectJobSummaryDto.CityName.Add(cityResponse.CityDescription);
                }
            }

            projectJobSummaryDto.ProjectId = projectJobSummary.ProjectId;
            var projectResponse = await _projectRepository.FindAsync(x => x.Id == projectJobSummary.ProjectId);
            projectJobSummaryDto.ProjectName = (projectResponse != null) ? projectResponse.Name : "";

            var auxiliaryUserResponse = await _auxiliaryUserRepository.FindAsync(x => x.Id == projectResponse.AuxiliaryUserId);
            projectJobSummaryDto.RecruiterName = (auxiliaryUserResponse != null) ? auxiliaryUserResponse.FullName : "";
            projectJobSummaryDto.ProfileUrl = (auxiliaryUserResponse != null) ? auxiliaryUserResponse.ProfileURL : "";

            return projectJobSummaryDto;

        }

        [NonAction]
        private async Task SendCastedEmail(int? talentId, int userId, int jobId, string jobDetailsUrl, string projectJobTitle, Project project)
        {
            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);

            //This call will update email sent status. 
            await UpdateTalentJobEmailSentStatus(talentId, jobId);

            var notificationParam = new NotificationParam
            {
                TalentId = talent.Id,
                Bcc = new List<string> { talent.Email },
                MobileCountryCode = talent.MobileCountryCode,
                MobileNumber = talent.Mobile,
                FullName = talent.FullName,
                ProjectName = project.Name,
                JobName = projectJobTitle,
                DeviceOsId = talent.DeviceOsId,
                DeviceRegistrationId = talent.DeviceRegistrationId,
                JobDetailsUrl = jobDetailsUrl,
                IsEmailVerifed = talentToken.Email == constantActivated ? true : false,           // send email only if Email is verified
            };

            //send email notification
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToTalents = new List<int> { talent.Id },
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.ApplyJob
            };

            //set notification configuration
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(NotificationEnum.JobAuditionCasted, notificationParam, sendSystemNotificationDto);


        }

        [NonAction]
        private async Task NotifyAuxiliaryUserJobAuditionCasted(int userId, int jobId, int castedTalentsCount, string jobDetailsUrl, string projectJobTitle, Project project)
        {
            var notificationParam = new NotificationParam
            {
                ProjectName = project.Name,
                JobName = projectJobTitle,
                JobDetailsUrl = jobDetailsUrl,
                TalentCount = castedTalentsCount.ToString()
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userId, (int)NotificationEnum.JobCastingFinal, project.Id, jobId),
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.ApplyJob
            };

            // Send Email to list of Auxiliary Users
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));

            // Before fetching the recruiter name check if it already exists in the auxiliaryUsers list & if not, go fetch
            var recruiter = auxiliaryUsers.FirstOrDefault(x => x.Id == project.AuxiliaryUserId);            

            if (recruiter != null)
            {
                notificationParam.RecruiterName = recruiter.FullName;
            }
            else
            {
                recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
                notificationParam.RecruiterName = recruiter.FullName;
            }

            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            //set notification configuration
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(NotificationEnum.JobAuditionCastedAdmin, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private async Task UpdateTalentJobEmailSentStatus(int? talentId, int jobId)
        {
            var talentJob = await _talentJobRepository.FindAsync(c => c.TalentId == talentId && c.JobId == jobId);
            if (talentJob != null)
            {
                talentJob.EmailSent = true;
                await _talentJobRepository.UpdateAsync(talentJob);
            }
        }

        [NonAction]
        private async Task SendJobInvitationToApply(int? talentId, int jobId, int userId, string jobDetailsUrl, string projectJobTitle, Project project)
        {
            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);

            var notificationParam = new NotificationParam
            {
                TalentId = talent.Id,
                Bcc = new List<string> { talent.Email },
                MobileCountryCode = talent.MobileCountryCode,
                MobileNumber = talent.Mobile,
                FullName = talent.FullName,
                ProjectName = project.Name,
                JobName = projectJobTitle,
                DeviceOsId = talent.DeviceOsId,
                DeviceRegistrationId = talent.DeviceRegistrationId,
                JobDetailsUrl = jobDetailsUrl,
                IsEmailVerifed = talentToken.Email == constantActivated ? true : false,           // send email only if Email is verified
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userId),
                SendNotificationToTalents = new List<int> { talent.Id },
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.JobDetails
            };

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(NotificationEnum.JobInvitationToApply, notificationParam, sendSystemNotificationDto);

        }

        [NonAction]
        private async Task NotifyAuxiliaryUserJobInvitationToApply(int jobId, int userId, string jobDetailsUrl, int talentCount, string projectJobTitle, Project project)
        {
            var notificationParam = new NotificationParam
            {
                ProjectName = project.Name,
                JobName = projectJobTitle,
                JobDetailsUrl = jobDetailsUrl,
                TalentCount = talentCount.ToString()
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userId),
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.JobDetails
            };

            // Send Email to list of Auxiliary Users
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));

            // Before fetching the recruiter name check if it already exists in the auxiliaryUsers list & if not, go fetch
            var recruiter = auxiliaryUsers.FirstOrDefault(x => x.Id == project.AuxiliaryUserId);
           
            if (recruiter != null)
            {
                notificationParam.RecruiterName = recruiter.FullName;
            }
            else
            {
                recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
                notificationParam.RecruiterName = recruiter.FullName;
            }

            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(NotificationEnum.JobInvitationToApplyAdmin, notificationParam, sendSystemNotificationDto);
        }

        private static string FormatRoundTabText(int? roundNumber)
        {
            var text = "Offline";

            if (roundNumber.HasValue && roundNumber.Value > 0)
            {
                text = string.Format("Online Round {0}", Convert.ToString(roundNumber));
            }
            return text;
        }

        private async Task SendSelectedRoundStatus(int? talentId, int jobId, int userId, string jobDetailsUrl, short? roundNumber, string projectJobName, Project project)
        {
            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);

            var notificationParam = new NotificationParam
            {
                TalentId = talent.Id,
                Bcc = new List<string> { talent.Email },
                FullName = talent.FullName,
                MobileCountryCode = talent.MobileCountryCode,
                MobileNumber = talent.Mobile,
                RoundName = FormatRoundTabText(roundNumber),
                ProjectName = project.Name,
                JobName = projectJobName,
                DeviceOsId = talent.DeviceOsId,
                DeviceRegistrationId = talent.DeviceRegistrationId,
                JobDetailsUrl = jobDetailsUrl,
                IsEmailVerifed = talentToken.Email == constantActivated ? true : false,           // send email only if Email is verified
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToTalents = new List<int> { talent.Id },
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.ApplyJob
            };

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(NotificationEnum.JobSelectedAuditionStatus, notificationParam, sendSystemNotificationDto);
        }

        private async Task NotifyAuxiliaryuserJobSelectedAuditionStatus(int jobId, int userId, string jobDetailsUrl, int talentCount, short? roundNumber, string projectJobName, Project project)
        {
            var notificationParam = new NotificationParam
            {
                RoundName = FormatRoundTabText(roundNumber),
                ProjectName = project.Name,
                JobName = projectJobName,
                JobDetailsUrl = jobDetailsUrl,
                TalentCount = talentCount.ToString()
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userId),
                NotificationReference = NotificationReferenceEnum.Job,
                NotificationReferenceValue = jobId,
                UrlRoute = ViewNotificationEnumDto.ApplyJob
            };

            // Send Email to list of Auxiliary Users
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));

            // Before fetching the recruiter name check if it already exists in the auxiliaryUsers list & if not, go fetch
            var recruiter = auxiliaryUsers.FirstOrDefault(x => x.Id == project.AuxiliaryUserId);
            
            if (recruiter != null)
            {
                notificationParam.RecruiterName = recruiter.FullName;
            }
            else
            {
                recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
                notificationParam.RecruiterName = recruiter.FullName;
            }

            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            await notification.SendNotification(NotificationEnum.JobSelectedAuditionStatusAdmin, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private async Task<string> UploadJobImage(IFormFile file, int projectJobId, int? projectId)
        {
            if (file != null && file.Length > 0)
            {
                string targetPath = _appSettings.MediaBasePath;
                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);
                var project = await _projectRepository.FindAsync(x => x.Id == projectId);
                var recruiterId = project.AuxiliaryUserId;
                string savedPath;
                savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetAuxiliaryFolder + recruiterId.ToString() + "/" + _appSettings.GetProjectFolder + projectId.ToString() + "/" + _appSettings.GetProjectJobFolder + projectJobId.ToString()), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);

                savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);
                return UserAccessiblePath(savedPath, _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
            }
            return null;
        }

        [NonAction]
        private string CreateUniqueFileName(string fileName)
        {
            int idx = fileName.LastIndexOf('.');
            //get filename
            string name = fileName.Substring(0, idx);
            //name = name.Trim().Replace(" ", string.Empty);
            name = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(name);
            //get extention
            string extenstion = fileName.Substring(idx + 1);

            return name + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "." + extenstion;
        }

        [NonAction]
        private string ApplicationAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is FileService)
            {
                return filePath.ToApplicationAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToApplicationAccessibleS3Path(baseURL, bucketName);
            }
            return filePath;
        }

        [NonAction]
        private string UserAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is Infrastructure.FileService)
            {
                return filePath.ToUserAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToUserAccessibleS3Path(bucketName, baseURL);
            }

            return filePath;
        }

        #endregion

    }

    /// <summary>
    /// for MasterModel talent attribute
    /// </summary>
    public enum MasterModel
    {
        BodyType,
        EyeColor,
        HairColor,
        SkinColor,
        Ethnicity,
        SubTalent,
        Language,
        Location,
        PerformingSkill
    }
}