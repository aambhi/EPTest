﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    public class AdminDashboardController : Controller
    {
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IRecruiterInfoRepository _recruiterInfoRepository;
        private ITalentRepository _talentRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IContestRepository _contestRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private IAdminDashboardRepository _adminDashboardRepository;

        public AdminDashboardController(IAuxiliaryUserRepository auxiliaryUserRepository,
                                        ITalentRepository talentRepository,
                                        IProjectRepository projectRepository,
                                        IProjectJobRepository projectJobRepository,
                                        IContestRepository contestRepository,
                                        IRecruiterInfoRepository recruiterInfoRepository, 
                                        IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository, 
                                        IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
                                        IAdminDashboardRepository adminDashboardRepository)
        {
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _recruiterInfoRepository = recruiterInfoRepository;
            _talentRepository = talentRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _contestRepository = contestRepository;
            _recruiterInfoRepository = recruiterInfoRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _adminDashboardRepository = adminDashboardRepository;
        }


        #region Public Actions

        [HttpGet]
        [Route("admin/dashboard")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetAdminDashboardSummary(UserInfo userInfo)
        {
            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin, isFtcRecruiterAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);

            //Talent Graph
            var talentStatsDto = await _adminDashboardRepository.GetTalentStats();

            //Recruiter graph
            var recruiterStatsDto = await _adminDashboardRepository.GetRecruiterStats(userInfo.userId, isFtcProjectAdmin, isFtcRecruiterAdmin);

            //project graph
            var projectStatsDto = await _adminDashboardRepository.GetProjectStats(userInfo.userId, isFtcProjectAdmin, isFtcRecruiterAdmin);

            //Job graph
            var projectJobStatsDto = await _adminDashboardRepository.GetProjectJobStats(userInfo.userId, isFtcProjectAdmin, isFtcRecruiterAdmin);

            // contest graph
            var contestStatsDto = await _adminDashboardRepository.GetContestStats(userInfo.userId, isFtcProjectAdmin, isFtcRecruiterAdmin);

            return Json(new
            {
                talentStats = talentStatsDto,
                recruiterStats = recruiterStatsDto,
                projectStats = projectStatsDto,
                projectJobStats = projectJobStatsDto,
                contestStats = contestStatsDto
            });
        }

        //same endpoint can be used for recruiter & Admin to get Banner Information of the logged in user..instead of requesting the whole profile of the recruiter
        [HttpGet]
        [Route("adminProfileSummary")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetAdminProfile(UserInfo userInfo)
        {
            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == userInfo.userId);

            var auxiliaryUserHeaderDto = new AuxiliaryUserHeaderDto();
            auxiliaryUserHeaderDto = await ConvertToAuxiliaryUserDto(auxiliaryUserHeaderDto, auxiliaryUser);

            return Json(new { auxiliaryUserHeader = auxiliaryUserHeaderDto });
        }

        #endregion

        #region Private methods

        private async Task<AuxiliaryUserHeaderDto> ConvertToAuxiliaryUserDto(AuxiliaryUserHeaderDto auxiliaryUserHeaderDto, AuxiliaryUser auxiliaryUser)
        {

            auxiliaryUserHeaderDto.EmailId = auxiliaryUser.EmailId;
            auxiliaryUserHeaderDto.FullName = auxiliaryUser.FullName;
            auxiliaryUserHeaderDto.TypeId = auxiliaryUser.TypeId;
            auxiliaryUserHeaderDto.ParentAuxiliaryUserId = auxiliaryUser.ParentAuxiliaryUserId;

            auxiliaryUserHeaderDto.ProfileURL = auxiliaryUser.ProfileURL;


            if (auxiliaryUser.ParentAuxiliaryUserId != null)
            {
                var parentAuxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUser.ParentAuxiliaryUserId);
                auxiliaryUserHeaderDto.RecruiterFullName = parentAuxiliaryUser != null ? parentAuxiliaryUser.FullName : "";
            }

            return auxiliaryUserHeaderDto;
        }

        #endregion
    }
}
