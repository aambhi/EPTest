﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class TalentInfoController : Controller
    {
        private ITalentInfoRepository _talentInfoRepository;
        private ITalentRepository _talentRepository;
        private ITalentTokenRepository _talentTokenRepository;
        private ITalentTransactionRepository _talentTransactionRepository;
        private ITalentTransactionDetailRepository _talentTransactionDetailRepository;
        private ITalentPlanFeatureRepository _talentPlanFeatureRepository;
        private ITalentFeatureRepository _talentFeatureRepository;
        private ITalentPlanRepository _talentPlanRepository;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private AppSettings _appSettings;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IEmailService _emailService;
        private IUserNotificationRepository _userNotificationRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private ITalentStatusHistoryRepository _talentStatusHistoryRepository;

        public TalentInfoController(ITalentInfoRepository talentInfoRepository,
                                        ITalentRepository talentRepository,
                                        ITalentTokenRepository talentTokenRepository,
                                        ITalentTransactionRepository talentTransactionRepository,
                                        ITalentTransactionDetailRepository talentTransactionDetailRepository,
                                        ITalentPlanFeatureRepository talentPlanFeatureRepository,
                                        ITalentFeatureRepository talentFeatureRepository,
                                        ITalentPlanRepository talentPlanRepository,
                                        INotificationDetailRepository notificationDetailRepository,
                                INotificationHeaderRepository notificationHeaderRepository,
                                IEmailService emailService,
                                IUserNotificationRepository userNotificationRepository,
                                IAuxiliaryUserRepository auxiliaryUserRepository,
                                        Microsoft.Extensions.Configuration.IConfiguration configuration, ISmsProviderRepository smsProviderRepository,
                                        ITalentStatusHistoryRepository talentStatusHistoryRepository)
        {

            _talentInfoRepository = talentInfoRepository;
            _talentRepository = talentRepository;
            _talentTokenRepository = talentTokenRepository;
            _talentTransactionRepository = talentTransactionRepository;
            _talentTransactionDetailRepository = talentTransactionDetailRepository;
            _talentPlanFeatureRepository = talentPlanFeatureRepository;
            _talentFeatureRepository = talentFeatureRepository;
            _talentPlanRepository = talentPlanRepository;

            _configuration = configuration;

            _emailService = emailService;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _userNotificationRepository = userNotificationRepository;
            _appSettings = new AppSettings(_configuration);
            _smsProviderRepository = smsProviderRepository;
            _talentStatusHistoryRepository = talentStatusHistoryRepository;
        }


        #region Public Actions

        [Route("profile/{id:int?}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin,Recruiter")]
        public async Task<ActionResult> GetProfile(UserInfo userInfo, int userId, int userType, int? id = 0)
        {
            //take the auth token ...validate it..and find its corresponding talent id
            //use that talent id to fetch talent related data            

            int talentId = userId;
            if ((id > 0 && userType == (int)LoginUserType.FTCAdmin) || (id > 0 && userType == (int)LoginUserType.Recruiter))
            {
                talentId = (int)id;
            }

            //my profile Dto to be returned which contains all other Dto's
            TalentInfoDto talentInfoDto = new TalentInfoDto();
            talentInfoDto.Talent = await _talentInfoRepository.GetPersonalDetails(talentId);
            // fetch talent's address
            talentInfoDto.TalentAddress = await _talentInfoRepository.GetTalentAddressDetails(talentId);
            // Get Interest Details                //fetch talent'sInterest
            talentInfoDto.TalentInterestCategories = await _talentInfoRepository.GetInterestDetails(talentId);
            talentInfoDto.TalentTalentCategories = await _talentInfoRepository.GetTalentTalentCategories(talentId);
            talentInfoDto.PhysicalAttributes = await _talentInfoRepository.GetPhysicalAttributes(talentId);
            talentInfoDto.TalentMedias = await _talentInfoRepository.GetTalentMediasBySubscription(talentId);
            talentInfoDto.TalentTags = await _talentInfoRepository.GetTalentTags(talentId);
            talentInfoDto.TalentLanguages = await _talentInfoRepository.GetTalentLanguages(talentId);
            talentInfoDto.TalentEthnicity = await _talentInfoRepository.GetTalentEthnicity(talentId);
            talentInfoDto.TalentExperience = await _talentInfoRepository.GetTalentExperience(talentId);
            talentInfoDto.TalentEducation = await _talentInfoRepository.GetTalentEducation(talentId);
            talentInfoDto.TalentAssociations = await _talentInfoRepository.GetTalentAssociations(talentId);
            talentInfoDto.TalentSecurityQuestions = await _talentInfoRepository.GetTalentSecurityQuestions(talentId);
            talentInfoDto.TalentSocialLink = await _talentInfoRepository.GetTalentSocialLink(talentId);
            talentInfoDto.TalentSpecialHost = await _talentInfoRepository.GetTalentSpecialHost(talentId);

            return Json(talentInfoDto);

        }

        [HttpGet]
        [Route("media/{talentId:int?}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<IActionResult> GetTalentMedia(UserInfo userInfo, int? talentId = 0)
        {

            talentId = (userInfo.userType == (int)LoginUserType.FTCAdmin) ? talentId : userInfo.userId;

            var talentMedia = await _talentInfoRepository.GetTalentMedias((int)talentId);
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            dictionary = await _talentInfoRepository.GetSubscribedMediaCount((int)talentId);
            int subscribedImageCount = dictionary["ImageCount"];
            int subscribedVideoCount = dictionary["VideoCount"];
            int subscribedAudioCount = dictionary["AudioCount"];
            int subscribedScriptCount = dictionary["ScriptCount"];
            return Ok(new
            {
                talentMedias = talentMedia,
                ImageCount = subscribedImageCount,
                VideoCount = subscribedVideoCount,
                AudioCount = subscribedAudioCount,
                ScriptCount = subscribedScriptCount
            });

        }

        [Route("sharedprofile")]
        [HttpGet]
        public async Task<ActionResult> SharedProfileDetail([FromQuery]string sharedName = "", [FromQuery]int? talentId = 0)
        {
            if (string.IsNullOrEmpty(sharedName) && talentId == 0)
            {
                return BadRequest();
            }

            Talent talent = null;
            if (talentId > 0)
            {
                talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            }
            else
            {
                talent = await _talentRepository.FindAsync(x => x.SharedProfileName.ToLower() == sharedName.ToLower());
            }

            if (talent != null)
            {

                //my profile Dto to be returned which contains all other Dto's
                TalentInfoDto talentInfoDto = new TalentInfoDto();

                // find talent data                  //map talent data to TalentDto
                // map TalentDto to ProfileDto property
                talentInfoDto.Talent = await _talentInfoRepository.GetPersonalDetails(talent.Id);

                bool? isMobileVerified = await _talentInfoRepository.CheckMobileVerified(talent.Id);
                talentInfoDto.Talent.IsMobileVerified = isMobileVerified;

                talentInfoDto.Talent.AgencyName = await _talentInfoRepository.GetAgencyName(talentInfoDto.Talent.AgencyId);

                // fetech talent's address
                talentInfoDto.TalentAddress = await _talentInfoRepository.GetTalentAddressDetails(talent.Id);

                // Get Interest Details                //fetch talent'sInterest
                talentInfoDto.TalentInterestCategories = await _talentInfoRepository.GetInterestDetails(talent.Id);

                talentInfoDto.TalentTalentCategories = await _talentInfoRepository.GetTalentTalentCategories(talent.Id);

                talentInfoDto.PhysicalAttributes = await _talentInfoRepository.GetPhysicalAttributes(talent.Id);

                talentInfoDto.TalentMedias = await _talentInfoRepository.GetTalentMedias(talent.Id);

                talentInfoDto.TalentTags = await _talentInfoRepository.GetTalentTags(talent.Id);
                talentInfoDto.TalentLanguages = await _talentInfoRepository.GetTalentLanguages(talent.Id);
                talentInfoDto.TalentEthnicity = await _talentInfoRepository.GetTalentEthnicity(talent.Id);

                talentInfoDto.TalentExperience = await _talentInfoRepository.GetTalentExperience(talent.Id);
                talentInfoDto.TalentEducation = await _talentInfoRepository.GetTalentEducation(talent.Id);


                talentInfoDto.TalentAssociations = await _talentInfoRepository.GetTalentAssociations(talent.Id);
                talentInfoDto.TalentSecurityQuestions = await _talentInfoRepository.GetTalentSecurityQuestions(talent.Id);

                talentInfoDto.TalentSocialLink = await _talentInfoRepository.GetTalentSocialLink(talent.Id);

                await IncreaseViewCount(talent);

                return Json(talentInfoDto);
            }
            else
            {
                return NotFound("Talent not found");
            }


        }

        [HttpPost]
        [Route("SaveTalentProfile")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<IActionResult> SaveProfile([FromBody]TalentInfoDto talentInfoDto, int userId, int userType)
        {
            int talentId = userId;
            if (userType == (int)LoginUserType.FTCAdmin)
            {
                talentId = talentInfoDto.Talent.Id;

                #region add TalentStatusHistory when admin updates any talent data
                await AddTalentStatusHistory(userId, talentId);
                #endregion

            }
            // find talent data   to get mobile no
            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);

            // set UID if it is not set - for the first time after filling personal details from UI for above 18 age. Also if DOB is not entered don't generate UID
            if (talent.UID == null && talentInfoDto.Talent.DOB!=null)
            {
                // if talent's Age is below 18 and he/she has not entered guardian details then don't generate UID else generate
                if (!(IsBelowEighteen(talentInfoDto.Talent.DOB) && string.IsNullOrEmpty(talentInfoDto.Talent.GuardianMobile)))
                {
                    var maxUID = await _talentRepository.MaxAsync(x => x.UID.Value);
                    talent.UID = (maxUID > 0) ? (maxUID + 1) : _appSettings.GetInitialUID;
                }
            }

            if (talentInfoDto.Talent.SendSms)
            {
                await SendAndSaveOTP(talentId, talentInfoDto.Talent.Mobile, talentInfoDto.Talent.MobileCountryCode, talent.DeviceOsId, talent.DeviceRegistrationId);
            }

            await ChangeInEmailId(talentInfoDto.Talent.Email, talent);

            var personalDetails = await _talentInfoRepository.SavePersonalDetail(talentInfoDto.Talent);
            var lstTalentCategories = await _talentInfoRepository.SaveTalentTalentCategory(talentId, talentInfoDto.TalentTalentCategories);
            var lstTalentInterest = await _talentInfoRepository.SaveTalentInterestCategory(talentId, talentInfoDto.TalentInterestCategories);
            var lstTalentPhysicalAttributes = await _talentInfoRepository.SaveTalentPhysicalAttribute(talentId, talentInfoDto.PhysicalAttributes);
            var lstTalentLanguages = await _talentInfoRepository.SaveTalentLanguages(talentId, talentInfoDto.TalentLanguages);
            var lstTalentTags = await _talentInfoRepository.SaveTalentTags(talentId, talentInfoDto.TalentTags);
            var lstTalentEthnicities = await _talentInfoRepository.SaveTalentEthnicities(talentId, talentInfoDto.TalentEthnicity);
            var lstTalentExperience = await _talentInfoRepository.SaveTalentExperiences(talentId, talentInfoDto.TalentExperience);
            var lstTalentEducation = await _talentInfoRepository.SaveTalentEducation(talentId, talentInfoDto.TalentEducation);
            var lstTalentAssociation = await _talentInfoRepository.SaveTalentAssociation(talentId, talentInfoDto.TalentAssociations);
            var lstTalentSecurityQuestions = await _talentInfoRepository.SaveTalentSecurityQuestion(talentId, talentInfoDto.TalentSecurityQuestions);
            var talentAddress = await _talentInfoRepository.SaveTalentAddress(talentId, talentInfoDto.TalentAddress);

            talentInfoDto.Talent = personalDetails;
            talentInfoDto.TalentTalentCategories = lstTalentCategories;
            talentInfoDto.TalentInterestCategories = lstTalentInterest;
            talentInfoDto.PhysicalAttributes = lstTalentPhysicalAttributes;
            talentInfoDto.TalentLanguages = lstTalentLanguages;
            talentInfoDto.TalentTags = lstTalentTags;
            talentInfoDto.TalentEthnicity = lstTalentEthnicities;
            talentInfoDto.TalentExperience = lstTalentExperience;
            talentInfoDto.TalentEducation = lstTalentEducation;
            talentInfoDto.TalentAssociations = lstTalentAssociation;
            talentInfoDto.TalentSecurityQuestions = lstTalentSecurityQuestions;
            talentInfoDto.TalentAddress = talentAddress;

            int? percentageCompleted = await _talentInfoRepository.CalculatePercentageCompleted(talentId, talentInfoDto);
            talentInfoDto.Talent.CompletionPercentage = percentageCompleted;

            return Json(talentInfoDto);
        }
        

        private async Task AddTalentStatusHistory(int userId, int talentId)
        {
            var talentStatusHistory = new TalentStatusHistory()
            {
                CreatedBy = userId,
                CreatedOn = DateTime.Now,
                TalentId = talentId,
                FeatureId = (int)AuthorizationFeaturesEnum.TalentOnboarding
            };

            await _talentStatusHistoryRepository.AddAsync(talentStatusHistory);
        }

        private async Task ChangeInEmailId(string newEmail, Talent talent)
        {
            if (newEmail != talent.Email)
            {
                var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);
                talentToken.Email = Guid.NewGuid().ToString();

                talentToken = await _talentTokenRepository.UpdateAsync(talentToken);

                Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                var notificationParam = new NotificationParam
                {
                    Email = newEmail,
                    FullName = talent.FullName,
                    UniqueId = talentToken.Email,
                    TalentId = talent.Id,
                    DeviceOsId = talent.DeviceOsId,
                    DeviceRegistrationId = talent.DeviceRegistrationId
                };

                var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                await notification.SendNotification(NotificationEnum.ChangeinEmailTalent, notificationParam, sendSystemNotificationDto);
            }
        }

        [HttpGet]
        [Route("IsSharedProfileValid/{talentFeatureDescription}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> IsSharedProfileValid(TalentFeatures talentFeatureDescription, int userId)
        {
            int talentId = userId;
            var talentTransactions = await _talentTransactionRepository.FindAllAsync(x => x.TalentId == talentId);
            List<TalentTransactionDetail> lstTalentTransactionDetail = new List<TalentTransactionDetail>();
            List<TalentTransactionDetailDto> lstTalentTransactionDetailDto = new List<TalentTransactionDetailDto>();
            foreach (var talentTransaction in talentTransactions)
            {
                // var talentTransactionDetail = await _talentTransactionDetailRepository.FindAsync(x => x.TalentTransactionId == talentTransaction.Id && x.EndDate > DateTime.Now);


                var talentTransactionDetail = await _talentTransactionDetailRepository.FindAllAsync(x => x.TalentTransactionId == talentTransaction.Id && x.EndDate > DateTime.Now);
                if (talentTransactionDetail != null)
                {
                    // there are multiple transaction for talent - on each upgrade a new entry is added...pick the latest plan
                    var latestTalentTransactionDetail = talentTransactionDetail.OrderByDescending(x => x.Id).FirstOrDefault();
                    var talentTransactionDetailDto = ConvertToTalentTransactionDetailDto(latestTalentTransactionDetail);
                    lstTalentTransactionDetail.Add(latestTalentTransactionDetail);
                    lstTalentTransactionDetailDto.Add(talentTransactionDetailDto);

                }

                if (talentTransactionDetail != null)
                {

                }
            }
            if (lstTalentTransactionDetail.Count > 0)
            {
                foreach (var talentTransactionDetail in lstTalentTransactionDetail)
                {
                    ResponseSharedProfileDto responseSharedProfileDto = new ResponseSharedProfileDto();
                    TalentPlanFeature talentPlanFeature = new TalentPlanFeature();
                    if (talentFeatureDescription == TalentFeatures.PersonalPortfolio)
                    {
                        talentPlanFeature = await _talentPlanFeatureRepository.FindAsync(x => x.TalentPlanId == talentTransactionDetail.TalentPlanId && x.TalentFeatureId == (Int32)TalentFeatures.PersonalPortfolio);
                        var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
                        responseSharedProfileDto.TalentSharedProfileName = talent.SharedProfileName;

                        responseSharedProfileDto.IsSharedProfileValid = true;
                    }
                    else if (talentFeatureDescription == TalentFeatures.MediaHosting)
                    {
                        talentPlanFeature = await _talentPlanFeatureRepository.FindAsync(x => x.TalentPlanId == talentTransactionDetail.TalentPlanId && x.TalentFeatureId == (Int32)TalentFeatures.MediaHosting);
                        responseSharedProfileDto.IsMediaHostingValid = true;

                    }
                    if (talentPlanFeature != null)
                    {
                        var talentPlanFeatureDto = ConvertTalentPlanFeatureDto(talentPlanFeature);
                        TalentTransactionDto talentTransactionDto = new TalentTransactionDto
                        {
                            TalentId = talentId,
                            EndDate = talentTransactionDetail.EndDate,
                            TalentTransactionDetailsDto = lstTalentTransactionDetailDto,
                            TalentPlanFeatureDto = talentPlanFeatureDto
                        };
                        var talentPlan = await _talentPlanRepository.FindAsync(x => x.Id == talentPlanFeatureDto.TalentPlanId);
                        talentTransactionDto.TalentPlanDto = ConvertToPlanDto(talentPlan);


                        var talentFeature = await _talentFeatureRepository.FindAsync(x => x.Id == talentPlanFeatureDto.TalentFeatureId);
                        talentTransactionDto.TalentFeaturesDto = ConvertToFeatureDto(talentFeature, talentPlanFeature);

                        responseSharedProfileDto.TalentTransactionDto = talentTransactionDto;
                        return Ok(new { responseSharedProfileDto });
                    }
                }
            }
            return NotFound();


        }

        #endregion

        #region Private Methods

        [NonAction]
        private bool IsBelowEighteen(DateTime? dateOfBirth)
        {
            if (dateOfBirth != null)
            {
                var years = DateTime.Now.Year - dateOfBirth.Value.Year;
                //get the date of the birthday this year
                var birthdayThisYear = dateOfBirth.Value.AddYears(years);
                //if the birthday hasn't passed yet this year we need years - 1
                var age = birthdayThisYear > DateTime.Now ? years - 1 : years;

                if (age < 18)
                    return true;
            }

            return false;
        }



        [NonAction]
        private TalentFeatureDto ConvertToFeatureDto(TalentFeature talentFeature, TalentPlanFeature talentPlanFeature)
        {
            TalentFeatureDto talentFeatureDto = new TalentFeatureDto
            {
                Id = talentFeature.Id,
                Desc = talentFeature.Desc,

                ImageCount = talentPlanFeature.ImageCount,
                VideoCount = talentPlanFeature.VideoCount,
                AudioCount = talentPlanFeature.AudioCount,
                ScriptCount = talentPlanFeature.ScriptCount
            };
            return talentFeatureDto;
        }

        [NonAction]
        private TalentPlanDto ConvertToPlanDto(TalentPlan talentPlan)
        {
            var talentPlanDto = new TalentPlanDto
            {
                Id = talentPlan.Id,
                Brief = talentPlan.Brief,
                Name = talentPlan.Name,
                Description = talentPlan.Description,
                Period = talentPlan.Period,
                Amount = talentPlan.Amount
            };
            return talentPlanDto;
        }

        [NonAction]
        private TalentPlanFeaturesDto ConvertTalentPlanFeatureDto(TalentPlanFeature talentTransactionDetail)
        {
            var talentPlanFeaturesDto = new TalentPlanFeaturesDto
            {
                Id = talentTransactionDetail.Id,
                TalentPlanId = talentTransactionDetail.TalentPlanId,
                TalentFeatureId = talentTransactionDetail.TalentFeatureId
            };
            return talentPlanFeaturesDto;
        }

        [NonAction]
        private TalentTransactionDetailDto ConvertToTalentTransactionDetailDto(TalentTransactionDetail talentTransactionDetail)
        {
            var talentTransactionDetailDto = new TalentTransactionDetailDto
            {
                Id = talentTransactionDetail.Id,
                TalentTransactionId = talentTransactionDetail.TalentTransactionId,
                TalentPlanId = talentTransactionDetail.TalentPlanId,
                EndDate = talentTransactionDetail.EndDate
            };
            return talentTransactionDetailDto;
        }

        [NonAction]
        public async Task IncreaseViewCount(Talent talent)
        {
            talent.ViewCount = talent.ViewCount + 1;
            await _talentRepository.UpdateAsync(talent);

        }

        [NonAction]
        private string GenerateOTP()
        {
            int otp = new Random().Next(100000, 999999);
            return Convert.ToString(otp);

        }

        [NonAction]
        private async Task SendAndSaveOTP(int talentId, string mobile, string mobileCountryCode, short? deviceOsId, string deviceRegistrationId)
        {
            string newOTP = GenerateOTP();
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);
            talentToken.SMS = newOTP;
            talentToken.Mobile1 = newOTP;
            talentToken = await _talentTokenRepository.UpdateAsync(talentToken);
            
            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            var notificationParam = new NotificationParam
            {
                TalentId = talentId,
                MobileNumber = mobile,
                MobileCountryCode = mobileCountryCode,
                Otp = newOTP,
                DeviceOsId = deviceOsId,
                DeviceRegistrationId = deviceRegistrationId
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            await notification.SendNotification(NotificationEnum.WelcomeTalent, notificationParam, sendSystemNotificationDto);
        }
        #endregion

    }
}
