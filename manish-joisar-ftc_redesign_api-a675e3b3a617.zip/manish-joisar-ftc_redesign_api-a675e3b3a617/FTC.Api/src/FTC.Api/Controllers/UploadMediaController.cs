﻿using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class UploadMediaController : Controller
    {
        private IFileService _fileService;
        private IConfiguration _configuration;
        private ITalentRepository _talentRepository;
        private ITalentMediaRepository _talentMediaRepository;
        private IMediaFileRepository _mediaFileRepository;
        private IFileTypeRepository _fileTypeRepository;
        private ITalentSocialLinkRepository _talentSocialLinkRepository;
        private ITalentInfoRepository _talentInfoRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;

        private AppSettings _appSettings;

        public UploadMediaController(IFileService fileService,
                                     IConfiguration configuration,
                                     ITalentRepository talentRepository,
                                     ITalentMediaRepository talentMediaRepository,
                                     IMediaFileRepository mediaFileRepository,
                                     ITalentSocialLinkRepository talentSocialLinkRepository,
                                     IFileTypeRepository fileTypeRepository,
                                     ITalentInfoRepository talentInfoRepository,
                                     IAuxiliaryUserRepository auxiliaryUserRepository)
        {
            _fileService = fileService;
            _configuration = configuration;
            _talentRepository = talentRepository;
            _talentMediaRepository = talentMediaRepository;
            _mediaFileRepository = mediaFileRepository;
            _talentSocialLinkRepository = talentSocialLinkRepository;
            _fileTypeRepository = fileTypeRepository;
            _talentInfoRepository = talentInfoRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _appSettings = new AppSettings(_configuration);
        }


        #region Public Actions
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> UploadResource([FromHeader]TalentMediaDto mediaDto, IFormFile file, UserInfo userInfo, int? RecruiterId = 0, int? talentId = 0)
        {
            int? completionPercentage = 0;
            int userId = userInfo.userId;
            if (talentId > 0)
            {
                userId = (int)talentId;
            }

            if (file != null && file.Length > 0 && !(bool)mediaDto.IsExternalUrl)
            {
                string targetPath = _appSettings.MediaBasePath;
                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);
                string savedPath;

                if (userInfo.userType == (int)LoginUserType.Talent || (userInfo.userType == (int)LoginUserType.FTCAdmin && talentId > 0))
                {
                    mediaDto.TalentId = userId;

                    if ((int)mediaDto.FileTypeId == (int)LoginEnum.FileType.Video)
                    {
                        savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetTalentFolder + userId.ToString()), _appSettings.S3BucketName, _appSettings.S3BaseUrl);
                    }
                    else
                    {
                        savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetTalentFolder + userId.ToString()), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
                    }
                }
                else
                {
                    if (RecruiterId > 0 && userInfo.userType == (int)LoginUserType.FTCAdmin)
                    {
                        userId = (int)RecruiterId;
                    }
                    savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetAuxiliaryFolder + userId.ToString()), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
                }

                var stopWatch = Stopwatch.StartNew();
                LogInformationAsWarning($"Uploading file: {fileName}, fileSize: {file.Length} for {userInfo.userType} - {userInfo.userId} ...");

                savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);

                stopWatch.Stop();
                LogInformationAsWarning($"Upload of file: {fileName}, fileSize: {file.Length} completed Successfully for {userInfo.userType} - {userInfo.userId} in {stopWatch.Elapsed.TotalMilliseconds}");


                mediaDto.FileName = fileName;
                if ((int)mediaDto.FileTypeId == (int)LoginEnum.FileType.Video)
                {
                    mediaDto.FilePath = UserAccessiblePath(savedPath, _appSettings.S3BucketName, _appSettings.S3BaseUrl);
                }
                else
                {
                    mediaDto.FilePath = UserAccessiblePath(savedPath, _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
                }


                string mime = MimeKit.MimeTypes.GetMimeType(fileName);

                mediaDto.FileMimeType = mime;

            }
            // check if file is not present and external url is also not present
            else if (string.IsNullOrEmpty(mediaDto.FilePath))
            {
                // if an external url was saved and then deleted => delete the record
                var talentMedia = await _talentMediaRepository.FindAsync(x => x.Flag == ((int)FlagType.OnBoardingExternalURL).ToString() && x.TalentId == userId);
                if (talentMedia != null)
                {
                    var mediaFile = await _mediaFileRepository.FindAsync(x => x.Id == talentMedia.MediaFileId);
                    await _mediaFileRepository.DeleteAsync(mediaFile);
                    await _talentMediaRepository.DeleteAsync(talentMedia);
                }
            }
            else
            {
                mediaDto.FileMimeType = "Link";
                mediaDto.FileName = mediaDto.FilePath.Substring(mediaDto.FilePath.LastIndexOf('=') + 1);
            }

            if ((int)mediaDto.Flag != (int)LoginEnum.FlagType.ProfileImage)
            {
                if (mediaDto.FilePath != null)
                {
                    if (IsNotGeneralMediaFile(mediaDto.Flag))
                    {
                        completionPercentage = await CalculateCompletionPercentageAfterUpload(userId);
                    }

                    var mediaFile = await _mediaFileRepository.AddAsync(ConvertToMediaFileDto(mediaDto));
                    if ((int)mediaDto.Flag == (int)LoginEnum.FlagType.OnBoardingVideo)
                    {
                        var talentMedia = await _talentMediaRepository.FindAsync(x => x.TalentId == userId && x.Flag == ((int)LoginEnum.FlagType.OnBoardingExternalURL).ToString());
                        if (talentMedia != null)
                        {
                            await _talentMediaRepository.DeleteAsync(talentMedia);
                        }
                    }

                    TalentMedia talentMediaModel = new TalentMedia();
                    if (IsNotGeneralMediaFile(mediaDto.Flag))
                    {
                        talentMediaModel = await _talentMediaRepository.FindAsync(x => x.TalentId == userId && x.Flag == ((int)mediaDto.Flag).ToString());
                    }
                    if (talentMediaModel != null && IsNotGeneralMediaFile(mediaDto.Flag))
                    {
                        var mediaFileModel = await _mediaFileRepository.FindAsync(x => x.Id == talentMediaModel.MediaFileId);

                        talentMediaModel = await _talentMediaRepository.UpdateAsync(ConvertToTalentMediaDto(userId, mediaFile.Id, mediaDto, talentMediaModel));
                        mediaDto.Id = talentMediaModel.Id;

                        if ((int)mediaDto.Flag != ((int)LoginEnum.FlagType.OnBoardingExternalURL))
                        {
                            if ((int)mediaDto.FileTypeId == (int)LoginEnum.FileType.Video)
                            {
                                await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrl, _appSettings.S3BucketName));
                            }
                            else
                            {
                                await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                            }
                        }

                        await _mediaFileRepository.DeleteAsync(mediaFileModel);
                    }
                    else
                    {
                        TalentMedia talentMedia = new TalentMedia();
                        talentMedia = await _talentMediaRepository.AddAsync(ConvertToTalentMediaDto(userId, mediaFile.Id, mediaDto, talentMedia));
                        mediaDto.Id = talentMedia.Id;
                    }
                }
                else
                {
                    completionPercentage = await CalculateCompletionPercentageAfterDelete(userId);
                }
            }
            else
            {
                if (userInfo.userType == (int)LoginUserType.Talent || talentId > 0)
                {
                    var talentModel = await _talentRepository.FindAsync(x => x.Id == userId);
                    if (!string.IsNullOrEmpty(talentModel.TalentProfileURL))
                    {
                        if(talentModel.TalentProfileURL.Contains(_appSettings.S3BaseUrlForUser))
                            await _fileService.DeleteAsync(talentModel.TalentProfileURL.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                    }
                    talentModel.TalentProfileURL = mediaDto.FilePath;
                    talentModel = await _talentRepository.UpdateAsync(talentModel);
                }
                else
                {
                    var recruiterModel = await _auxiliaryUserRepository.FindAsync(x => x.Id == userId);
                    if (!string.IsNullOrEmpty(recruiterModel.ProfileURL))
                    {
                        await _fileService.DeleteAsync(recruiterModel.ProfileURL.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                    }
                    recruiterModel.ProfileURL = mediaDto.FilePath;
                    recruiterModel = await _auxiliaryUserRepository.UpdateAsync(recruiterModel);
                }
            }
            return Ok(new { percentage = completionPercentage, talentMedias = mediaDto });

        }

        [HttpPost]
        [Route("deleteonboardingvideo/{talentId:int?}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<ActionResult> DeleteVideo(UserInfo userInfo, int? talentId = 0)
        {
            talentId = (userInfo.userType == (int)LoginUserType.FTCAdmin) ? talentId : userInfo.userId;

            int? completionPercentage = 0;
            var talentMedia = await _talentMediaRepository.FindAsync(x => x.TalentId == talentId && x.Flag == ((int)FlagType.OnBoardingVideo).ToString());
            if (talentMedia != null)
            {
                var mediaFileModel = await _mediaFileRepository.FindAsync(x => x.Id == talentMedia.MediaFileId);
                await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrl, _appSettings.S3BucketName));
                await _talentMediaRepository.DeleteAsync(talentMedia);
                await _mediaFileRepository.DeleteAsync(mediaFileModel);

                completionPercentage = await CalculateCompletionPercentageAfterDelete((int)talentId);
            }
            return Ok(new { percentage = completionPercentage });

        }

        [HttpDelete]
        [Route("deletetalentmedia/{talentMediaId}/{isMediaTypeVideo:bool?}/{talentId:int?}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<ActionResult> TalentMedia(UserInfo userInfo, int talentMediaId, bool isMediaTypeVideo = false, int? talentId = 0)
        {
            int? completionPercentage = 0;
            talentId = (userInfo.userType == (int)LoginUserType.FTCAdmin) ? talentId : userInfo.userId;

            var talentMedia = await _talentMediaRepository.FindAsync(x => x.TalentId == talentId && x.Id == talentMediaId);
            if (talentMedia != null)
            {
                var mediaFileModel = await _mediaFileRepository.FindAsync(x => x.Id == talentMedia.MediaFileId);
                if (mediaFileModel == null)
                {
                    return NotFound();
                }

                if (mediaFileModel.FileMimeType != "Link")
                {
                    if (isMediaTypeVideo)
                    {
                        await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrl, _appSettings.S3BucketName));
                    }
                    else
                    {
                        await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                    }
                }

                await _talentMediaRepository.DeleteAsync(talentMedia);
                await _mediaFileRepository.DeleteAsync(mediaFileModel);

                completionPercentage = await CalculateCompletionPercentageAfterDelete(talentId ?? 0);
                return Ok(new { percentage = completionPercentage, response = "Deleted successfully" });
            }
            return NotFound();

        }

        [HttpPost]
        [Route("SaveTalentSocialLink/{talentId:int?}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<ActionResult> SaveTalentSocialLink([FromBody]List<TalentSocialLinkDto> lstTalentSocialLinkDto, UserInfo userInfo, int? talentId = 0)
        {
            int? completionPercentage = 0;
            talentId = (userInfo.userType == (int)LoginUserType.FTCAdmin) ? talentId : userInfo.userId;

            var talentSocialLinks = await _talentSocialLinkRepository.FindAllAsync(x => x.TalentId == talentId);

            if (lstTalentSocialLinkDto.Count() > 0 && talentSocialLinks.Count() == 0)
            {
                completionPercentage = await CalculateCompletionPercentageAfterUpload(talentId ?? 0);
            }
            else if (talentSocialLinks.Count() > 0 && lstTalentSocialLinkDto.Count() == 0)
            {
                completionPercentage = await CalculateCompletionPercentageAfterDelete(talentId ?? 0);
                completionPercentage -= 10;
                var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
                talent.CompletionPercentage = completionPercentage;
                talent = await _talentRepository.UpdateAsync(talent);
            }
            else
            {
                completionPercentage = _talentRepository.FindAsync(x => x.Id == talentId).Result.CompletionPercentage;
            }

            // Add and update social link
            foreach (var talentSocialLinkDto in lstTalentSocialLinkDto)
            {
                var talentSocialLink = talentSocialLinks.FirstOrDefault(x => x.SocialLinkId == talentSocialLinkDto.SocialLinkId);
                if (talentSocialLink == null)
                {
                    TalentSocialLink talentSocialLinkModel = new TalentSocialLink();
                    talentSocialLinkModel = ConvertToTalentSocialLink((int)talentId, talentSocialLinkModel, talentSocialLinkDto);
                    talentSocialLinkModel = await _talentSocialLinkRepository.AddAsync(talentSocialLinkModel);
                }
                else
                {
                    talentSocialLink = ConvertToTalentSocialLink((int)talentId, talentSocialLink, talentSocialLinkDto);
                    talentSocialLink = await _talentSocialLinkRepository.UpdateAsync(talentSocialLink);
                }
            }

            // Delete Remaining Social Link
            var talentSocialLinkDtoIds = lstTalentSocialLinkDto.Select(x => x.SocialLinkId).ToList();
            var talentSocialLinkIds = talentSocialLinks.Where(x => !talentSocialLinkDtoIds.Contains(x.SocialLinkId));
            foreach (var talentSocialLink in talentSocialLinkIds)
            {
                await _talentSocialLinkRepository.DeleteAsync(talentSocialLink);
            }

            //return Json(lstTalentSocialLinkDto);

            //var newTalentSocialLinks = await _talentSocialLinkRepository.FindAllAsync(x => x.TalentId == talentId);
            //if (talentSocialLinks.Count() > 0 && newTalentSocialLinks.Count() == 0) //TO Delete existing social links
            //{
            //    completionPercentage = await CalculateCompletionPercentageAfterDelete(talentId ?? 0);
            //    completionPercentage -= 10;
            //}
            //else if (talentSocialLinks.Count() == 0 && newTalentSocialLinks.Count() > 0) //TO add new social links
            //{
            //    completionPercentage = await CalculateCompletionPercentageAfterUpload(talentId ?? 0);
            //    completionPercentage += 10;
            //}
            //else
            //{
            //    completionPercentage = _talentRepository.FindAsync(x => x.Id == talentId).Result.CompletionPercentage;
            //}
            return Json(new { percentage = completionPercentage, lstTalentSocialLinkDto = lstTalentSocialLinkDto });
        }

        #endregion

        #region Private Methods
        [NonAction]
        private async Task<int?> CalculateCompletionPercentageAfterUpload(int userId)
        {
            List<LoginEnum.FlagType> idList = new List<LoginEnum.FlagType>();
            idList.Add(LoginEnum.FlagType.OnBoardingAudio);
            idList.Add(LoginEnum.FlagType.OnBoardingExternalURL);
            idList.Add(LoginEnum.FlagType.OnBoardingFull);
            idList.Add(LoginEnum.FlagType.OnBoardingHeadShot);
            idList.Add(LoginEnum.FlagType.OnBoardingLeftSide);
            idList.Add(LoginEnum.FlagType.OnBoardingRightSide);
            idList.Add(LoginEnum.FlagType.OnBoardingScript);
            idList.Add(LoginEnum.FlagType.OnBoardingVideo);
            var savedTalentMedia = await _talentInfoRepository.GetTalentMedias(userId);
            savedTalentMedia = savedTalentMedia.Where(t => idList.Contains(t.Flag)).ToList();

            var savedTalentSocialLink = await _talentInfoRepository.GetTalentSocialLink(userId);

            var talent = await _talentRepository.FindAsync(x => x.Id == userId);

            int? completionPercentage = 0;

            if (savedTalentMedia.Count > 0 || savedTalentSocialLink.Count > 0)
            {
                completionPercentage = talent.CompletionPercentage;
            }
            else
            {
                completionPercentage = talent.CompletionPercentage + 10;
            }
            talent.CompletionPercentage = completionPercentage;
            talent = await _talentRepository.UpdateAsync(talent);

            return completionPercentage;

        }

        [NonAction]
        private async Task<int?> CalculateCompletionPercentageAfterDelete(int userId)
        {
            List<LoginEnum.FlagType> idList = new List<LoginEnum.FlagType>();
            idList.Add(LoginEnum.FlagType.OnBoardingAudio);
            idList.Add(LoginEnum.FlagType.OnBoardingExternalURL);
            idList.Add(LoginEnum.FlagType.OnBoardingFull);
            idList.Add(LoginEnum.FlagType.OnBoardingHeadShot);
            idList.Add(LoginEnum.FlagType.OnBoardingLeftSide);
            idList.Add(LoginEnum.FlagType.OnBoardingRightSide);
            idList.Add(LoginEnum.FlagType.OnBoardingScript);
            idList.Add(LoginEnum.FlagType.OnBoardingVideo);
            var savedTalentMedia = await _talentInfoRepository.GetTalentMedias(userId);
            savedTalentMedia = savedTalentMedia.Where(t => idList.Contains(t.Flag)).ToList();

            var savedTalentSocialLink = await _talentInfoRepository.GetTalentSocialLink(userId);

            var talent = await _talentRepository.FindAsync(x => x.Id == userId);

            int? completionPercentage = 0;

            if (savedTalentMedia.Count > 0 || savedTalentSocialLink.Count > 0)
            {
                completionPercentage = talent.CompletionPercentage;
            }
            else
            {
                completionPercentage = talent.CompletionPercentage - 10;
            }
            talent.CompletionPercentage = completionPercentage;
            talent = await _talentRepository.UpdateAsync(talent);

            return completionPercentage;

        }

        //create a fileName based => FileName + DateTime + Extn
        [NonAction]
        private string CreateUniqueFileName(string fileName)
        {
            int idx = fileName.LastIndexOf('.');
            //get filename
            string name = fileName.Substring(0, idx);
            //name = name.Trim().Replace(" ", string.Empty);
            name = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(name);
            //get extention
            string extenstion = fileName.Substring(idx + 1);

            return name + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "." + extenstion;
        }

        [NonAction]
        private string ApplicationAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is FileService)
            {
                return filePath.ToApplicationAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToApplicationAccessibleS3Path(baseURL, bucketName);
            }
            return filePath;
        }

        [NonAction]
        private string UserAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is Infrastructure.FileService)
            {
                return filePath.ToUserAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToUserAccessibleS3Path(bucketName, baseURL);
            }

            return filePath;
        }

        [NonAction]
        private MediaFile ConvertToMediaFileDto(TalentMediaDto talentMediaDto)
        {
            MediaFile mediaFile = new MediaFile();

            mediaFile.FileName = talentMediaDto.FileName;
            mediaFile.FilePath = talentMediaDto.FilePath;
            mediaFile.FileTypeId = (int)talentMediaDto.FileTypeId;
            mediaFile.FileMimeType = talentMediaDto.FileMimeType;
            mediaFile.IsExternalUrl = talentMediaDto.IsExternalUrl;


            return mediaFile;
        }


        [NonAction]
        private TalentMedia ConvertToTalentMediaDto(int userId, int mediaFileId, TalentMediaDto talentMediaDto, TalentMedia talentMedia)
        {
            talentMedia.TalentId = userId;
            talentMedia.MediaFileId = mediaFileId;
            talentMedia.Flag = ((int)talentMediaDto.Flag).ToString();



            return talentMedia;
        }

        [NonAction]
        private TalentSocialLink ConvertToTalentSocialLink(int talentId, TalentSocialLink talentSocialLinkModel, TalentSocialLinkDto talentSocialLinkDto)
        {
            talentSocialLinkModel.TalentId = talentId;
            talentSocialLinkModel.SocialLinkId = talentSocialLinkDto.SocialLinkId;
            talentSocialLinkModel.Link = talentSocialLinkDto.Link;
            return talentSocialLinkModel;
        }

        [NonAction]
        private bool IsNotGeneralMediaFile(FlagType flag)
        {
            if ((int)flag != ((int)LoginEnum.FlagType.GeneralImages) && (int)flag != ((int)LoginEnum.FlagType.GeneralVideos)
                        && (int)flag != ((int)LoginEnum.FlagType.GeneralScripts) && (int)flag != ((int)LoginEnum.FlagType.GeneralAudios))
            {
                return true;
            }
            return false;
        }

        [NonAction]
        private void LogInformationAsWarning(string message)
        {
            Serilog.Log.Warning("[Information] " + message);
        }

        #endregion
    }
}
