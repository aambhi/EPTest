﻿using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.JobAuditionsDtos;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    public class JobAuditionController : Controller
    {
        private AppSettings _appSettings;
        private readonly IConfiguration _configuration;
        private IFileService _fileService;
        private IJobAuditionRepository _jobAuditionRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IJobNotesRepository _jobNotesRepository;
        private ITalentJobRepository _talentJobRepository;
        private IParamRepository _paramRepository;
        private ITalentRepository _talentRepository;
        private IJobTalentRecommendedRepository _jobTalentRecommendedRepository;

        public JobAuditionController(IConfiguration configuration,
                                    IFileService fileService,
                                    IJobAuditionRepository jobAuditionRepository,
                                    IProjectRepository projectRepository,
                                    IProjectJobRepository projectJobRepository,
                                    IJobNotesRepository jobNotesRepository,
                                    ITalentJobRepository talentJobRepository,
                                    IParamRepository paramRepository,
                                    ITalentRepository talentRepository,
                                    IJobTalentRecommendedRepository jobTalentRecommendedRepository)
        {
            _fileService = fileService;
            _configuration = configuration;
            _jobAuditionRepository = jobAuditionRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _jobNotesRepository = jobNotesRepository;
            _talentJobRepository = talentJobRepository;
            _paramRepository = paramRepository;
            _talentRepository = talentRepository;
            _jobTalentRecommendedRepository = jobTalentRecommendedRepository;
            _appSettings = new AppSettings(_configuration);
        }

        #region Public Actions

        [HttpPost]
        [Route("jobAudition/{jobId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> CreateJobAudition(int jobId, [FromBody]JobAuditionDto jobAuditionDto)
        {
            if (jobAuditionDto == null)
            {
                return BadRequest();
            }
            #region Update existing Round
            if (jobAuditionDto.Id > 0)
            {
                var jobAuditionResponse = await _jobAuditionRepository.FindAsync(x => x.Id == jobAuditionDto.Id);

                if (jobAuditionResponse == null)
                {
                    return NotFound();
                }

                var jobAuditionUpdate = ConvertToJobAuditionModelEdit(jobAuditionResponse, jobAuditionDto);
                jobAuditionUpdate = await _jobAuditionRepository.UpdateAsync(jobAuditionUpdate);

                return Json(ConvertToJobAuditionDto(jobAuditionUpdate));
            }
            #endregion

            // find job audition for given jobId if any present
            var lstjobAudition = await _jobAuditionRepository.FindAllAsync(x => x.JobId == jobId);

            int offlineRoundCount = 0;
            int onlineRoundCount = 0;

            if (lstjobAudition != null)
            {
                offlineRoundCount = lstjobAudition.Where(x => x.AuditionTypeId == (int)AuditionTypeEnum.Offline).Count();
                if (offlineRoundCount > 0 && jobAuditionDto.AuditionTypeId == AuditionTypeEnum.Offline)
                {
                    // Update if already exist

                    return Json(new { jobAudition = lstjobAudition, message = "jobAudition with offline round already exist, only one offline round can be created per Job" });
                }
                onlineRoundCount = lstjobAudition.Where(x => x.AuditionTypeId == (int)AuditionTypeEnum.Online).Count();
            }

            if (jobAuditionDto.AuditionTypeId == AuditionTypeEnum.Online)
            {
                #region 

                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobId);
                var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);
                if (onlineRoundCount > 0)
                {
                    jobAuditionDto.RoundNumber = (short)(lstjobAudition.Max(x => x.RoundNumber) + 1);
                }
                else
                {
                    jobAuditionDto.RoundNumber = 1;
                }
                #endregion
            }

            var jobAudition = ConvertToJobAuditionModel(jobId, jobAuditionDto);

            jobAudition = await _jobAuditionRepository.AddAsync(jobAudition);
            return Json(ConvertToJobAuditionDto(jobAudition));
        }

        [HttpPost]
        [Route("uploadJobAuditionMedia")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> UploadMedia([FromHeader]int jobId, int roundNumber, IFormFile file)
        {
            //upload media as well
            if (file != null && file.Length > 0)
            {
                var jobAudition = await _jobAuditionRepository.FindAsync(x => x.JobId == jobId && x.RoundNumber == roundNumber);
                if (jobAudition == null)
                {
                    return NotFound();
                }
                if (!string.IsNullOrEmpty(jobAudition.ReferenceMedia))
                {
                    await _fileService.DeleteAsync(jobAudition.ReferenceMedia.Replace(_appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser));
                }

                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobId);
                var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

                string targetPath = _appSettings.MediaBasePath;
                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);

                string savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetAuxiliaryFolder + project.AuxiliaryUserId.ToString() + "/" + _appSettings.GetProjectFolder + projectJob.ProjectId.ToString() + "/" + _appSettings.GetProjectJobFolder + jobId.ToString() + "/" + _appSettings.GetOnlineRoundFolder + roundNumber), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);

                savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);
                jobAudition.ReferenceMedia = UserAccessiblePath(savedPath, _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
                jobAudition = await _jobAuditionRepository.UpdateAsync(jobAudition);

                return Json(jobAudition.ReferenceMedia);
            }
            else
            {
                return BadRequest();
            }
        }


        [Route("removeJobAuditionMedia/{jobId}/{roundNumber}")]
        [HttpDelete]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> RemoveAuditionMedia(int jobId, int roundNumber)
        {
            var jobAudition = await _jobAuditionRepository.FindAsync(x => x.JobId == jobId && x.RoundNumber == roundNumber);
            if (jobAudition == null)
            {
                return NoContent();
            }
            if (!string.IsNullOrEmpty(jobAudition.ReferenceMedia))
            {
                await _fileService.DeleteAsync(jobAudition.ReferenceMedia.Replace(_appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser));
            }
            jobAudition.ReferenceMedia = string.Empty;
            jobAudition = await _jobAuditionRepository.UpdateAsync(jobAudition);

            return Json(new { result = "success" });
        }

        [HttpPost]
        [Route("jobAudition/{id}/update")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> UpdateJobAudition(int id, [FromBody]JobAuditionDto jobAuditionDto)
        {
            if (jobAuditionDto == null)
            {
                return BadRequest();
            }

            var jobAuditionResponse = await _jobAuditionRepository.FindAsync(x => x.Id == id);

            if (jobAuditionResponse == null)
            {
                return NotFound();
            }

            var jobAudition = ConvertToJobAuditionModel(jobAuditionResponse.JobId, jobAuditionDto);
            jobAudition = await _jobAuditionRepository.UpdateAsync(jobAudition);

            return Json(ConvertToJobAuditionDto(jobAudition));
        }

        [HttpGet]
        [Route("jobAudition/getTalentNotesByJobId/{jobId}/{talentId}")]
        public async Task<IActionResult> GetTalentNotesByJobId(int jobId, int talentId)
        {
            var jobNotes = await _jobNotesRepository.FindAllAsync(x => x.JobId == jobId && x.TalentId == talentId);
            var talentJob = await _talentJobRepository.FindAsync(x => x.JobId == jobId && x.TalentId == talentId);
            return Ok(new { jobNotes = jobNotes, rating = talentJob.Rating });
        }


        [HttpPost]
        [Route("jobauditions/saveTalentNotesByJobId")]
        public async Task<IActionResult> SaveTalentNotesByJobId([FromBody]JobNotesDto jobNotesDto)
        {
            if (jobNotesDto.JobId == 0 || jobNotesDto.TalentId == 0 || string.IsNullOrWhiteSpace(jobNotesDto.Notes))
            {
                return BadRequest();
            }
            else
            {
                JobNotes jobNotes = new JobNotes();
                jobNotes.JobId = jobNotesDto.JobId;
                jobNotes.TalentId = jobNotesDto.TalentId;
                jobNotes.Notes = jobNotesDto.Notes;
                jobNotes.CreatedOn = DateTime.UtcNow;
                jobNotes = await _jobNotesRepository.AddAsync(jobNotes);
                var talentJob = await _talentJobRepository.FindAsync(x => x.JobId == jobNotesDto.JobId && x.TalentId == jobNotesDto.TalentId);
                if (talentJob != null)
                {
                    talentJob.Rating = jobNotesDto.Rating;
                    talentJob = await _talentJobRepository.UpdateAsync(talentJob);
                }
                double? averageRecruiterRating;
                var lstTalentJob = await _talentJobRepository.FindAllAsync(x => x.TalentId == jobNotes.TalentId && x.Rating > 0);
                if (lstTalentJob != null)
                {
                    averageRecruiterRating = lstTalentJob.Sum(x => x.Rating) / lstTalentJob.Count();
                }
                else
                {
                    averageRecruiterRating = 0;
                }
                var talent = await _talentRepository.FindAsync(x => x.Id == jobNotes.TalentId);
                var param = await _paramRepository.GetAllAsync();
                var ftcPercent = param.FirstOrDefault().FtcRatingWeightage;
                var recruiterPercent = param.FirstOrDefault().RecruiterRatingWeightage;
                var overAllRating = ((talent.FtcRating == null ? 0 : talent.FtcRating * ftcPercent) + (averageRecruiterRating * recruiterPercent)) / 100;
                talent.RecruiterRating = (float)averageRecruiterRating;
                talent.OverallRating = (float)overAllRating;
                talent.RecruiterRatingCount = lstTalentJob.Count();
                talent = await _talentRepository.UpdateAsync(talent);
                return Ok(new { jobNotes = jobNotes, rating = talentJob.Rating });
            }
        }

        [HttpGet]
        [Route("jobAudition/{id}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> JobAuditionRoundById(int id)
        {
            var jobAudition = await _jobAuditionRepository.FindAsync(x => x.Id == id);

            if (jobAudition == null)
            {
                return NotFound();
            }
            return Json(ConvertToJobAuditionDto(jobAudition));
        }

        [HttpPost]
        [Route("jobAudition/stats")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> ProjectJobSummary([FromBody]JobAuditionsRequest jobAuditionsRequest)
        {
            var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobAuditionsRequest.JobId);

            if (projectJob == null)
            {
                return NotFound();
            }
            var projectJobSummaryDto = new ProjectJobSummaryDto
            {
                Id = projectJob.Id,
                Title = projectJob.Title,
                StatusDescription = ((StatusEnum)projectJob.StatusId).ToString(),
                StatusId = (StatusEnum)projectJob.StatusId
            };

            var talentJob = await _talentJobRepository.GetTalentJobsByJobId(jobAuditionsRequest);

            if (talentJob != null)
            {
                projectJobSummaryDto.UnderReview = talentJob.Count(x => x.StatusId == (int)ProjectJobStatusEnum.UnderReview);
                projectJobSummaryDto.NotSelected = talentJob.Count(x => x.StatusId == (int)ProjectJobStatusEnum.NotSelected);
                projectJobSummaryDto.SelectedForAudition = talentJob.Count(x => x.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition);
                projectJobSummaryDto.Shortlisted = talentJob.Count(x => x.StatusId == (int)ProjectJobStatusEnum.Shortlisted);
                projectJobSummaryDto.Casted = talentJob.Count(x => x.StatusId == (int)ProjectJobStatusEnum.Cast);
            }

            projectJobSummaryDto.Recommended = await _talentJobRepository.GetTalentRecommendedJobsByJobId(jobAuditionsRequest);

            return Json(new { projectJobSummary = projectJobSummaryDto });
        }

        #endregion

        #region Private Methods

        [NonAction]
        private JobAuditionDto ConvertToJobAuditionDto(JobAudition jobAudition)
        {
            var jobAuditiondto = new JobAuditionDto();
            jobAuditiondto.Id = jobAudition.Id;
            jobAuditiondto.JobId = jobAudition.JobId;
            jobAuditiondto.Brief = jobAudition.Brief;
            jobAuditiondto.Instruction = jobAudition.Instruction;
            jobAuditiondto.Address = jobAudition.Address;
            jobAuditiondto.AuditionTypeId = (AuditionTypeEnum)jobAudition.AuditionTypeId;
            jobAuditiondto.ReferenceMedia = jobAudition.ReferenceMedia;
            jobAuditiondto.StartDate = jobAudition.StartDate;
            jobAuditiondto.EndDate = jobAudition.EndDate;
            jobAuditiondto.RoundNumber = jobAudition.RoundNumber;
            jobAuditiondto.StartTime = jobAudition.StartTime;
            jobAuditiondto.EndTime = jobAudition.EndTime;
            return jobAuditiondto;
        }


        [NonAction]
        private JobAudition ConvertToJobAuditionModel(int jobId, JobAuditionDto jobAuditionDto)
        {
            var jobAudition = new JobAudition();
            jobAudition.JobId = jobId; //TODO: chk or is it jobAuditionDto.jobId
            jobAudition.Brief = jobAuditionDto.Brief;
            jobAudition.Instruction = jobAuditionDto.Instruction;
            jobAudition.Address = jobAuditionDto.Address;
            jobAudition.AuditionTypeId = (short)jobAuditionDto.AuditionTypeId;
            jobAudition.StartDate = jobAuditionDto.StartDate;
            jobAudition.EndDate = jobAuditionDto.EndDate;
            jobAudition.RoundNumber = jobAuditionDto.RoundNumber;
            jobAudition.StartTime = jobAuditionDto.StartTime;
            jobAudition.EndTime = jobAuditionDto.EndTime;
            jobAudition.ReferenceMedia = jobAuditionDto.ReferenceMedia;

            return jobAudition;
        }

        [NonAction]
        private JobAudition ConvertToJobAuditionModelEdit(JobAudition jobAudition, JobAuditionDto jobAuditionDto)
        {
            jobAudition.JobId = (int)jobAuditionDto.JobId; //TODO: chk or is it jobAuditionDto.jobId
            jobAudition.Brief = jobAuditionDto.Brief;
            jobAudition.Instruction = jobAuditionDto.Instruction;
            jobAudition.Address = jobAuditionDto.Address;
            jobAudition.AuditionTypeId = (short)jobAuditionDto.AuditionTypeId;
            jobAudition.StartDate = jobAuditionDto.StartDate;
            jobAudition.EndDate = jobAuditionDto.EndDate;
            //jobAudition.RoundNumber = jobAuditionDto.RoundNumber;
            jobAudition.StartTime = jobAuditionDto.StartTime;
            jobAudition.EndTime = jobAuditionDto.EndTime;
            // jobAudition.ReferenceMedia = jobAuditionDto.ReferenceMedia;

            return jobAudition;
        }

        [NonAction]
        private string CreateUniqueFileName(string fileName)
        {
            int idx = fileName.LastIndexOf('.');
            //get filename
            string name = fileName.Substring(0, idx);
            //name = name.Trim().Replace(" ", string.Empty);
            name = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(name);
            //get extention
            string extenstion = fileName.Substring(idx + 1);

            return name + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "." + extenstion;
        }

        [NonAction]
        private string ApplicationAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is FileService)
            {
                return filePath.ToApplicationAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToApplicationAccessibleS3Path(baseURL, bucketName);
            }
            return filePath;
        }

        [NonAction]
        private string UserAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is Infrastructure.FileService)
            {
                return filePath.ToUserAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToUserAccessibleS3Path(bucketName, baseURL);
            }

            return filePath;
        }

        #endregion
    }
}
