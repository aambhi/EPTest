﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FTC.Api.Filters;
using FTCApi.Dtos.AdminReports;
using FTCApi.Core.RepositoryInterface;

namespace FTC.Api.Controllers
{

    public class PaymentReportController : Controller
    {

        private ITalentTransactionRepository _talentTransactionRepository;
        private ITalentTransactionDetailRepository _talentTransactionDetailRepository;
        private ITalentPlanRepository _talentPlanRepository;
        private IAuxiliaryRecruiterTransactionRepository _auxiliaryRecruiterTransactionRepository;
        private IRecruiterPlanRepository _recruiterPlanRepository;
        private ITalentRepository _talentRepository;
        private IProjectRepository _projectRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IPaymentRepository _paymentRepository;

        public PaymentReportController(ITalentTransactionRepository talentTransactionRepository,
                                        ITalentTransactionDetailRepository talentTransactionDetailRepository,
                                        ITalentPlanRepository talentPlanRepository,
                                        IAuxiliaryRecruiterTransactionRepository auxiliaryRecruiterTransactionRepository,
                                        IRecruiterPlanRepository recruiterPlanRepository,
                                        ITalentRepository talentRepository,
                                        IAuxiliaryUserRepository auxiliaryUserRepository,
                                        IProjectRepository projectRepository,
                                        IPaymentRepository paymentRepository)
        {
            _talentTransactionRepository = talentTransactionRepository;
            _talentTransactionDetailRepository = talentTransactionDetailRepository;
            _talentPlanRepository = talentPlanRepository;
            _auxiliaryRecruiterTransactionRepository = auxiliaryRecruiterTransactionRepository;
            _recruiterPlanRepository = recruiterPlanRepository;
            _talentRepository = talentRepository;
            _projectRepository = projectRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _paymentRepository = paymentRepository;
        }


        [Route("adminReports/paymentStats")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        [HttpPost]
        public async Task<IActionResult> GetDailyPaymentStats([FromBody]DailyStats requestParam)
        {
            #region Code - before refactoring
            /*
            var talentTransactions = await _talentTransactionRepository.FindAllAsync(x => x.CreatedOn.Date >= requestParam.FromDate.Date
                                                                                            && x.CreatedOn.Date <= requestParam.ToDate.Date);

            talentTransactions = talentTransactions.OrderByDescending(x => x.CreatedOn);

            float totalAmount = 0;

            var lstTalentPaymentStats = new List<PaymentStats>();
            foreach (var talentTransaction in talentTransactions)
            {
                var talentTransactionDetails = await _talentTransactionDetailRepository.FindAllAsync(x => x.TalentTransactionId == talentTransaction.Id);
                foreach (var talentTransactionDetail in talentTransactionDetails)
                {
                    var talentPlan = await GetPlan(talentTransactionDetail.TalentPlanId);
                    var paymentStats = new PaymentStats()
                    {
                        Name = await GetTalentName(talentTransaction.TalentId),
                        PlanName = talentPlan.Name,
                        PurchaseDate = talentTransaction.CreatedOn,
                        ExpiryDate = talentTransactionDetail.EndDate,
                        Amount = talentPlan.Amount
                    };
                    totalAmount += (float)talentPlan.Amount;
                    lstTalentPaymentStats.Add(paymentStats);
                }
            }

            var totalTalentAmount = totalAmount;
            totalAmount = 0;


            var auxiliaryUserTransactions = await _auxiliaryRecruiterTransactionRepository.FindAllAsync(x => x.CreatedOn.Date >= requestParam.FromDate.Date
                                                                                            && x.CreatedOn.Date <= requestParam.ToDate.Date);

            auxiliaryUserTransactions = auxiliaryUserTransactions.OrderByDescending(x => x.CreatedOn);
            var lstRecruiterPaymentStats = new List<PaymentStats>();
            foreach (var auxiliaryUserTransaction in auxiliaryUserTransactions)
            {
                var project = await _projectRepository.FindAsync(x => x.Id == auxiliaryUserTransaction.ProjectId);
                var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == (project.PlanId ?? 0));
                var paymentStats = new PaymentStats()
                {
                    PurchaseDate = auxiliaryUserTransaction.CreatedOn,
                    Amount = auxiliaryUserTransaction.Amount,
                    PlanName = (recruiterPlan != null) ? recruiterPlan.Name : "",
                    Name = await GetRecruiterName(project.AuxiliaryUserId),
                    ProjectName = project.Name,
                    ExpiryDate = auxiliaryUserTransaction.CreatedOn.AddMonths((recruiterPlan != null) ? (int)recruiterPlan.ManageContract : 0)
                };
                totalAmount += (float)auxiliaryUserTransaction.Amount;
                lstRecruiterPaymentStats.Add(paymentStats);
            }

            var totalRecruiterAmount = totalAmount;
            totalAmount = totalTalentAmount + totalRecruiterAmount;

            return Json(new { talent = lstTalentPaymentStats, recruiter = lstRecruiterPaymentStats, totalAmount = totalAmount, totalTalentAmount = totalTalentAmount, totalRecruiterAmount = totalRecruiterAmount });
            
            */
            #endregion

            #region Refactored Optimised Code
            var talentTransactions = await _paymentRepository.GetTalentTransactions(requestParam);

            var talentPaymentStats = talentTransactions.TalentPaymentStats;
            var totalTalentAmount = talentTransactions.TotalAmount;

            var auxiliaryUserTransactions = await _paymentRepository.GetRecruiterTransactions(requestParam);
            var lstRecruiterPaymentStats = auxiliaryUserTransactions.RecruiterPaymentStats;
            var totalRecruiterAmount = auxiliaryUserTransactions.TotalAmount;


            return Json(new
            {
                talent = talentPaymentStats,
                recruiter = lstRecruiterPaymentStats,
                totalAmount = totalTalentAmount + totalRecruiterAmount,
                totalTalentAmount = totalTalentAmount,
                totalRecruiterAmount = totalRecruiterAmount
            });
            #endregion
        }

        [HttpPost]
        [Route("talentReports/paymentStats")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> TalentPaymentStats([FromBody]DailyStats requestParam, int userId)
        {
            var talentTransactions = await _paymentRepository.GetTalentTransactions(requestParam, userId);

            var talentPaymentStats = talentTransactions.TalentPaymentStats;
            var totalTalentAmount = talentTransactions.TotalAmount;

            #region Old Code
            /*
            var talentTransactions = await _talentTransactionRepository.FindAllAsync(x => x.TalentId == userId
                                                                                            && x.CreatedOn.Date >= requestParam.FromDate.Date
                                                                                            && x.CreatedOn.Date <= requestParam.ToDate.Date);

            talentTransactions = talentTransactions.OrderByDescending(x => x.CreatedOn);

            float totalAmount = 0;

            var lstTalentPaymentStats = new List<PaymentStats>();
            foreach (var talentTransaction in talentTransactions)
            {
                var talentTransactionDetails = await _talentTransactionDetailRepository.FindAllAsync(x => x.TalentTransactionId == talentTransaction.Id);
                foreach (var talentTransactionDetail in talentTransactionDetails)
                {
                    var talentPlan = await GetPlan(talentTransactionDetail.TalentPlanId);

                    var paymentStats = new PaymentStats()
                    {
                        Name = await GetTalentName(talentTransaction.TalentId),
                        PlanName = talentPlan.Name,
                        PurchaseDate = talentTransaction.CreatedOn,
                        ExpiryDate = talentTransactionDetail.EndDate,
                        Amount = talentPlan.Amount
                    };
                    totalAmount += (float)talentTransaction.Amount;
                    lstTalentPaymentStats.Add(paymentStats);
                }
            }
            return Json(new { talent = lstTalentPaymentStats, totalAmount = totalAmount });
            */
            #endregion

            return Json(new { talent = talentPaymentStats, totalAmount = totalTalentAmount });
        }

        [HttpPost]
        [Route("recruiterReports/paymentStats")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> RecruiterPaymentStats([FromBody]DailyStats requestParam, int userId)
        {
            var projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == userId);
            var lstProject = projects.Select(x => x.Id);

            var auxiliaryUserTransactions = await _auxiliaryRecruiterTransactionRepository.FindAllAsync(x => lstProject.Contains(x.ProjectId)
                                                                                                            && x.CreatedOn.Date >= requestParam.FromDate.Date
                                                                                                            && x.CreatedOn.Date <= requestParam.ToDate.Date);

            float totalAmount = 0;


            auxiliaryUserTransactions = auxiliaryUserTransactions.OrderByDescending(x => x.CreatedOn);
            var lstRecruiterPaymentStats = new List<PaymentStats>();
            var lstProjects = projects.ToList();

            foreach (var auxiliaryUserTransaction in auxiliaryUserTransactions)
            {
                var project = lstProjects.Find(x => x.Id == auxiliaryUserTransaction.ProjectId);
                var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == (auxiliaryUserTransaction.PlanId ?? 0));
                var paymentStats = new PaymentStats()
                {
                    PurchaseDate = auxiliaryUserTransaction.CreatedOn,
                    Amount = auxiliaryUserTransaction.Amount,
                    PlanName = (recruiterPlan != null) ? recruiterPlan.Name : "",
                    Name = await GetRecruiterName(project.AuxiliaryUserId),
                    ProjectName = project.Name,
                    ExpiryDate = auxiliaryUserTransaction.CreatedOn.AddMonths((recruiterPlan != null) ? (int)recruiterPlan.ManageContract : 0)
                };
                totalAmount += (float)auxiliaryUserTransaction.Amount;
                lstRecruiterPaymentStats.Add(paymentStats);
            }

            return Json(new { recruiter = lstRecruiterPaymentStats, totalAmount = totalAmount });
        }

        #region Private Methods
        private async Task<string> GetRecruiterName(int? auxiliaryUserId)
        {
            var recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUserId);
            return (recruiter != null) ? recruiter.FullName : "";
        }

        private async Task<string> GetRecruiterPlanName(int? planId)
        {
            var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == (planId ?? 0));
            return (recruiterPlan != null) ? recruiterPlan.Name : "";
        }

        private async Task<dynamic> GetPlan(short talentPlanId)
        {
            var talentPlan = await _talentPlanRepository.FindAsync(x => x.Id == talentPlanId);
            //return (talentPlan != null) ? talentPlan.Name : "";
            return talentPlan;
        }

        private async Task<string> GetTalentName(int talentId)
        {
            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            return (talent != null) ? talent.FullName : "";
        }

        #endregion
    }
}
