﻿using AutoMapper;
using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.Models.Provider;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using FTCApi.Dtos.SpecialHost;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class ContestController : Controller
    {
        private IFileService _fileService;
        private IContestRepository _contestRepository;
        private IContestResultRepository _contestResultRepository;
        private IContestSubmissionRepository _contestSubmissionRepository;
        private IContestSubmissionMediaRepository _contestSubmissionMediaRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private ITalentRepository _talentRepository;
        private IContestSpecialHostRepository _contestSpecialHostRepository;
        private static IMapper _mapper;
        private IAuxiliaryRecruiterRepository _auxiliaryRecruiterRepository;
        private IFileTypeRepository _fileTypeRepository;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private IMediaFileRepository _mediaFileRepository;
        private IProviderRepository _providerRepository;
        private IContestProviderRepository _contestProviderRepository;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IEmailService _emailService;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private AppSettings _appSettings;
        private ITalentTokenRepository _talentTokenRepository;
        private IContestStatusHistoryRepository _contestStatusHistoryRepository;
        private ITalentSpecialHostRepository _talentSpecialHostRepository;
        private const string constantActivated = "Activated";

        public ContestController(IContestRepository contestRepository,
            IContestResultRepository contestResultRepository,
            IContestSubmissionRepository contestSubmissionRepository,
            IContestSubmissionMediaRepository contestSubmissionMediaRepository,
            IAuxiliaryRecruiterRepository auxiliaryRecruiterRepository,
            IFileTypeRepository fileTypeRepository,
            IFileService fileService,
            IAuxiliaryUserRepository auxiliaryUserRepository,
            ITalentRepository talentRepository,
            IContestSpecialHostRepository contestSpecialHostRepository,
            IMediaFileRepository mediaFileRepository,
            IProviderRepository providerRepository,
            INotificationHeaderRepository notificationHeaderRepository,
            INotificationDetailRepository notificationDetailRepository,
            IUserNotificationRepository userNotificationRepository,
            IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
            IEmailService emailService,
            IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository,
        Microsoft.Extensions.Configuration.IConfiguration configuration,
        IContestProviderRepository contestProviderRepository,
        ISmsProviderRepository smsProviderRepository,
        ITalentTokenRepository talentTokenRepository,
        ITalentSpecialHostRepository talentSpecialHostRepository,
        IContestStatusHistoryRepository contestStatusHistoryRepository)
        {
            _contestRepository = contestRepository;
            _contestResultRepository = contestResultRepository;
            _contestSubmissionRepository = contestSubmissionRepository;
            _contestSubmissionMediaRepository = contestSubmissionMediaRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _talentRepository = talentRepository;
            _auxiliaryRecruiterRepository = auxiliaryRecruiterRepository;
            _fileService = fileService;
            _configuration = configuration;
            _contestSpecialHostRepository = contestSpecialHostRepository;
            _mediaFileRepository = mediaFileRepository;
            _fileTypeRepository = fileTypeRepository;
            _providerRepository = providerRepository;
            _appSettings = new AppSettings(_configuration);
            _contestProviderRepository = contestProviderRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _notificationDetailRepository = notificationDetailRepository;
            _userNotificationRepository = userNotificationRepository;
            _emailService = emailService;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _smsProviderRepository = smsProviderRepository;
            _talentTokenRepository = talentTokenRepository;
            _contestStatusHistoryRepository = contestStatusHistoryRepository;
            _talentSpecialHostRepository = talentSpecialHostRepository;
        }

        static ContestController()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<SearchParametersDto, SearchParameters>();
                cfg.CreateMap<SearchResult<Contest>, SearchResultDto<ContestDto>>();
            });
            _mapper = config.CreateMapper();
        }

        #region Public Actions

        /// <summary>
        /// Get All Contest and Filter contest
        /// </summary>
        /// <remarks>
        /// In Request, Note that the ContestLabel is an ENUM and not a string. 
        /// </remarks>
        /// <param name="searchParams"></param>
        /// <returns>New Created Todo Item</returns>
        /// <response code="205">Returns the newly created item</response>        
        /// <response code="401">If the item is null</response>
        [HttpPost]
        [ProducesResponseType(typeof(ContestDto), 200)]
        [Route("Search")]
        [AuthorizeTokenFilter(validate: false, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> Search([FromBody]ContestSearchParametersDto searchParams, int userId, int userType)
        {
            //use start and end index
            int startIndex = (searchParams.CurrentPage > 0) ? ((searchParams.CurrentPage) * searchParams.PerPageRecords + 1) : searchParams.CurrentPage;
            int endIndex = (searchParams.CurrentPage > 0) ? (startIndex + searchParams.PerPageRecords) : searchParams.PerPageRecords;

            List<Contest> lstContest = new List<Contest>();

            #region User is Logged In Show NonSubmitted Contest
            if (searchParams.IsToBeValidated)
            {
                if (userType == (int)LoginUserType.Recruiter)
                {
                    var contests = await _contestRepository.FindAllAsync(x => x.AuxiliaryUserId == userId);
                    lstContest = contests.ToList();
                }
                else if (userType == (int)LoginUserType.Talent)
                {
                    var contests = await _contestRepository.FindAllAsync(x => (x.StatusId == (int)StatusEnum.Published)
                                                                        || (x.StatusId == (int)StatusEnum.Close));

                    //all contest
                    if (searchParams.ContestLabel != ContestLabel.All)
                    {
                        // Submitted contest
                        if (searchParams.ContestLabel == ContestLabel.Submitted)
                        {
                            var submittedContest = await _contestSubmissionRepository.FindAllAsync(x => x.TalentId == userId);
                            contests = contests.Where(x => submittedContest.Any(c => c.ContestId == x.Id));
                        }
                        //Not Submitted Contest as default
                        else
                        {
                            var submittedContest = await _contestSubmissionRepository.FindAllAsync(x => x.TalentId == userId);
                            contests = contests.Where(x => !submittedContest.Any(c => c.ContestId == x.Id));
                        }
                    }

                    lstContest = contests.ToList();
                }
                else
                {
                    // user is admin
                    var contests = await _contestRepository.FindAllAsync(x => x.AuxiliaryUserId == searchParams.RecruiterId.First());

                    // top filter for manageContest page .. admin has a filter All, Verfied & Not verfied
                    //Note: "ContestLabel" is a different  filter than "ContestStatusEnum"
                    if (searchParams.Status != ContestStatusEnum.All)
                    {
                        if (searchParams.Status == ContestStatusEnum.Verified)
                        {
                            contests = contests.Where(x => x.StatusId == (int)StatusEnum.Verified || x.StatusId == (int)StatusEnum.Published);
                        }
                        else
                        {
                            contests = contests.Where(x => x.StatusId == (int)StatusEnum.New || x.StatusId == (int)StatusEnum.Draft);
                        }
                    }
                    lstContest = contests.ToList();
                }

            }
            #endregion

            #region If User is not logged in Show all Contest
            else
            {
                var contests = await _contestRepository.FindAllAsync(x => (x.StatusId == (int)StatusEnum.Published)
                                                                            || (x.StatusId == (int)StatusEnum.Close));
                lstContest = contests.ToList();
            }
            #endregion

            #region Filter Contest based on filter params

            if (!string.IsNullOrEmpty(searchParams.SearchContestKeyword))
            {
                lstContest = lstContest.Where(x => x.Name.ToLower().Contains(searchParams.SearchContestKeyword.ToLower())).ToList();
            }

            if (lstContest.Count() > 0 && searchParams.RecruiterId.Count > 0)
            {
                lstContest = lstContest.Where(x => (searchParams.RecruiterId).Contains(x.AuxiliaryUserId)).ToList();
            }
            //response is filtered is a contest type id is provided
            if (lstContest.Count() > 0 && searchParams.ContestTypeId.Count > 0)
            {
                lstContest = lstContest.Where(x => (searchParams.ContestTypeId).Contains(x.ContestTypeId)).ToList();
            }
            #endregion

            //pagination Response
            var totalCount = lstContest.Count();
            lstContest = lstContest.OrderByDescending(x => x.CreatedOn)
                                    .Skip(startIndex - 1)
                                    .Take(endIndex - startIndex).ToList();

            List<ContestDto> lstContestDto = await ConvertToListContestDto(lstContest);

            return Json(new { contests = lstContestDto, totalCount = totalCount });
            #region
            //return Json(lstContest);

            //if (status.ToString() == ((int)StatusEnum.All).ToString())
            //{
            //    var contests = await _contestRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId);
            //    List<ContestDto> lstContestDto = new List<ContestDto>();
            //    foreach (var contest in contests)
            //    {
            //        ContestDto contestDto = new ContestDto();
            //        contestDto = await ConvertToContestDto(contestDto, contest);
            //        lstContestDto.Add(contestDto);
            //    }
            //    return Json(lstContestDto);
            //}
            //else
            //{
            //    var contests = await _contestRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId && x.StatusId == (int)status);
            //    List<ContestDto> lstContestDto = new List<ContestDto>();
            //    foreach (var contest in contests)
            //    {
            //        ContestDto contestDto = new ContestDto();
            //        contestDto = await ConvertToContestDto(contestDto, contest);
            //        lstContestDto.Add(contestDto);
            //    }
            //    return Json(lstContestDto);
            //}
            #endregion
        }

        [Route("manageContest")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> ManageContest([FromBody]ManageContestSearchParamDto searchParams, UserInfo userInfo)
        {
            if (userInfo.userType == (int)(LoginUserType.Recruiter))
            {
                #region user is a Recruiter

                var contests = await _contestRepository.FindAllAsync(x => x.AuxiliaryUserId == userInfo.userId);

                #region ContestStatus Filter - All, verified, New

                if (searchParams.Status != ContestStatusEnum.All)
                {
                    if (searchParams.Status == ContestStatusEnum.Verified)
                    {
                        contests = contests.Where(x => (x.StatusId == (int)StatusEnum.Verified)
                                                                    || (x.StatusId == (int)StatusEnum.Published));
                        //|| (x.StatusId == (int)StatusEnum.Close)  //contest is verified and closed
                    }
                    else
                    {
                        contests = contests.Where(x => x.StatusId == (int)StatusEnum.New || x.StatusId == (int)StatusEnum.Draft);
                    }
                }
                #endregion

                #region Search Contest Or else find all contest of the logged in user
                //Global search if filter is applied
                if (!string.IsNullOrEmpty(searchParams.SearchContestKeyword))
                {
                    var searchContestKeyword = searchParams.SearchContestKeyword.ToLower();
                    contests = contests.Where(x => x.Name.ToLower().Contains(searchContestKeyword));
                }

                #endregion

                #region pagination
                var lstContest = contests.ToList();

                // Pagination for contest 
                int contestStartIndex = (searchParams.CurrentContestPage > 0) ? ((searchParams.CurrentContestPage) * searchParams.PerPageContestRecords + 1) : searchParams.CurrentContestPage;
                int contestEndIndex = (searchParams.CurrentContestPage > 0) ? (contestStartIndex + searchParams.PerPageContestRecords) : searchParams.PerPageContestRecords;


                var totalContestCount = lstContest.Count();
                lstContest = lstContest.OrderByDescending(x => x.CreatedOn)
                    .Skip(contestStartIndex - 1)
                    .Take(contestEndIndex - contestStartIndex)
                    .ToList();

                #endregion

                #region Response - ManageContestDto
                List<ContestDto> lstContestDto = await ConvertToListContestDto(lstContest);

                List<ManageContestDto> lstManageContestDto = new List<ManageContestDto>();
                ManageContestDto manageContestDto = new ManageContestDto();
                manageContestDto.AuxiliaryUserId = userInfo.userId;
                manageContestDto.AuxiliaryUserName = userInfo.FullName;
                manageContestDto.Contests.TotalContestCount = totalContestCount;
                manageContestDto.Contests.ContestData = lstContestDto;
                lstManageContestDto.Add(manageContestDto);

                #endregion

                return Json(new { ManageRecruiterContest = lstManageContestDto, totalCount = 1 });
                #endregion

            }
            else if (userInfo.userType == (int)(LoginUserType.FTCAdmin))
            {
                #region user is an Admin
                int recruiterStartIndex = (searchParams.CurrentRecruiterPage > 0) ? ((searchParams.CurrentRecruiterPage) * searchParams.PerPageRecruiterRecords + 1) : searchParams.CurrentRecruiterPage;
                int recruiterEndIndex = (searchParams.CurrentRecruiterPage > 0) ? (recruiterStartIndex + searchParams.PerPageRecruiterRecords) : searchParams.PerPageRecruiterRecords;

                int contestStartIndex = (searchParams.CurrentContestPage > 0) ? ((searchParams.CurrentContestPage) * searchParams.PerPageContestRecords + 1) : searchParams.CurrentContestPage;
                int contestEndIndex = (searchParams.CurrentContestPage > 0) ? (contestStartIndex + searchParams.PerPageContestRecords) : searchParams.PerPageContestRecords;


                // Get the list of recruiter whose contest exists in Ascending order based on the recruiter's name

                bool isFtcRecruiterAdmin;
                var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
                _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);

                IEnumerable<Contest> allContest = default(IEnumerable<Contest>);
                if (isFtcRecruiterAdmin)
                {
                    var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userInfo.userId);
                    allContest = await _contestRepository.FindAllAsync(x => assignedRecruiters.Contains(x.AuxiliaryUserId));
                }
                else
                {
                    allContest = await _contestRepository.GetAllAsync();
                }





                #region ContestStatus Filter - All, verified, New

                if (searchParams.Status != ContestStatusEnum.All)
                {
                    if (searchParams.Status == ContestStatusEnum.Verified)
                    {
                        allContest = allContest.Where(x => (x.StatusId == (int)StatusEnum.Verified)
                                                                    || (x.StatusId == (int)StatusEnum.Published));
                        //|| (x.StatusId == (int)StatusEnum.Close)  //contest is verified and closed
                    }
                    else
                    {
                        allContest = allContest.Where(x => x.StatusId == (int)StatusEnum.New || x.StatusId == (int)StatusEnum.Draft);
                    }
                }
                #endregion


                //group all by each recruiter
                var lstDistinctAuxiliaryUserContest = allContest.Select(x => x.AuxiliaryUserId).Distinct().ToList();

                //TODO
                var auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => lstDistinctAuxiliaryUserContest.Contains(x.Id));
                var lstAuxiliaryUserId = auxiliaryUser.OrderBy(x => x.FullName).Select(x => x.Id).ToList();
                lstDistinctAuxiliaryUserContest = lstAuxiliaryUserId;


                List<Contest> lstContest = new List<Contest>();


                #region Search Contest
                //Global search if filter is applied
                if (!string.IsNullOrEmpty(searchParams.SearchRecruiterKeyword))
                {
                    var searchRecruiterKeyword = searchParams.SearchRecruiterKeyword.ToLower();
                    var lstAuxiliaryUser = allContest.Select(x => new { x.AuxiliaryUserId, AuxiliaryUserName = x.AuxiliaryUser.FullName }).Distinct().ToList();
                    var lstAuxiliaryUserSearch = lstAuxiliaryUser.Where(x => x.AuxiliaryUserName.ToLower().Contains(searchRecruiterKeyword)).Distinct().ToList();

                    //pagination Response
                    var totalRecruiterCount = lstAuxiliaryUserSearch.Count();
                    lstAuxiliaryUserSearch = lstAuxiliaryUserSearch.OrderBy(x => x.AuxiliaryUserName).Skip(recruiterStartIndex - 1).Take(recruiterEndIndex - recruiterStartIndex).ToList();

                    return Json(new { ManageRecruiterContest = lstAuxiliaryUserSearch, totalCount = totalRecruiterCount });
                }
                #endregion
                else
                {
                    allContest = allContest.OrderBy(x => lstDistinctAuxiliaryUserContest.IndexOf(x.AuxiliaryUserId));

                    if (searchParams.RecruiterId > 0)
                    {
                        // from this list find the recuiterId from the request & Fill in the contest for that recuiter
                        lstContest = allContest.Where(x => x.AuxiliaryUserId == searchParams.RecruiterId).ToList();

                        lstDistinctAuxiliaryUserContest = lstDistinctAuxiliaryUserContest.Where(x => x == searchParams.RecruiterId).ToList();

                        //search if filter is applied -- inner search
                        if (!string.IsNullOrEmpty(searchParams.SearchContestKeyword))
                        {
                            lstContest = lstContest.Where(x => x.Name.ToLower().Contains(searchParams.SearchContestKeyword.ToLower())).ToList();
                        }
                    }
                    else
                    {
                        // if no recruiter id is passed => means fetch the first recruiter in the list and display its contest
                        lstContest = allContest.Where(x => x.AuxiliaryUserId == lstDistinctAuxiliaryUserContest.First()).ToList();

                    }

                    #region Pagination
                    //pagination Response for recruiter
                    var totalRecruiterCount = lstDistinctAuxiliaryUserContest.Count();
                    lstDistinctAuxiliaryUserContest = lstDistinctAuxiliaryUserContest.Skip(recruiterStartIndex - 1).Take(recruiterEndIndex - recruiterStartIndex).ToList();

                    // Pagination for contest 
                    var totalContestCount = lstContest.Count();

                    lstContest = lstContest.OrderByDescending(x => x.CreatedOn)
                                            .Skip(contestStartIndex - 1)
                                            .Take(contestEndIndex - contestStartIndex)
                                            .ToList();

                    #endregion

                    #region Contest Response DTO
                    List<ContestDto> lstContestByRecruiterIdDto = await ConvertToListContestDto(lstContest);

                    List<ManageContestDto> lstManageContestDto = new List<ManageContestDto>();
                    foreach (var distinctAuxiliaryUserContest in lstDistinctAuxiliaryUserContest)
                    {
                        ManageContestDto manageContestDto = new ManageContestDto();
                        manageContestDto = await ConvertToManageContestDto(manageContestDto, lstContestByRecruiterIdDto, distinctAuxiliaryUserContest, lstDistinctAuxiliaryUserContest.First(), totalContestCount);

                        lstManageContestDto.Add(manageContestDto);
                    }
                    #endregion

                    return Json(new { ManageRecruiterContest = lstManageContestDto, totalCount = totalRecruiterCount });

                }
                #endregion
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("publishedContest/{recruiterId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetAllPublishedContest(int recruiterId, UserInfo userInfo)
        {
            var userId = (userInfo.userType == (int)LoginUserType.FTCAdmin) ? recruiterId : userInfo.userId;
            // fetch response which are marked as published or closed
            var response = await _contestRepository.FindAllAsync(x => (x.StatusId == System.Convert.ToInt32(StatusEnum.Published) || x.StatusId == System.Convert.ToInt32(StatusEnum.Close)) && x.AuxiliaryUserId == userId);
            if (response != null)
            {
                return Json(response);
            }

            return NotFound();
        }

        [Route("filterContest")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> FilterContest([FromBody]FilterContestDto filterContestDto, int userId)
        {
            // fetch response which are marked as published
            var response = await _contestRepository.FindAllAsync(x => x.StatusId == System.Convert.ToInt32(StatusEnum.Published));

            //response is filtered is a recruiter id is provided
            if (response.Count() > 0 && filterContestDto.RecruiterId.Count > 0)
            {
                response = response.Where(x => (filterContestDto.RecruiterId).Contains(x.AuxiliaryUserId));
            }
            //response is filtered is a contest type id is provided
            if (response.Count() > 0 && filterContestDto.ContestTypeId.Count > 0)
            {
                response = response.Where(x => (filterContestDto.ContestTypeId).Contains(x.ContestTypeId));
            }

            //now if the user is logged in, get the list of all contest id for that talent..these are the contest he has "Submitted"

            if (userId == 0)
            {
                int talentId = userId;

                //fetch participated contest

                var submittedContest = await _contestSubmissionRepository.FindAllAsync(x => x.TalentId == talentId);
                response = response.Where(x => !submittedContest.Any(c => c.ContestId == x.Id));
                
                //fetch  contest other than participated => not applied
                if (filterContestDto.TalentContest == LoginEnum.ContestLabel.Submitted)
                {
                    //Non Submitted
                    response = response.Where(x => submittedContest.Any(c => c.ContestId == x.Id));
                }

            }
            return Json(response);
        }

        /// <summary>
        /// Get Contest by Id 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("detail/{id}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetContestDetail(int id, int userId, int userType)
        {
            var response = new Contest();
            List<EndPointDto> endpoint = new List<EndPointDto>();
            
            response = await _contestRepository.FindAsync(x => x.Id == id);
            endpoint = await GetEndPoint(id, response.AuxiliaryUserId);

            if (response != null)
            {
                var checkAuthorization = _auxiliaryUserRepository.CheckAuthorization(response.AuxiliaryUserId, userId, (int)NotificationEnum.ContestApproval);
                if (!checkAuthorization)
                    return Forbid();

                ContestDto contestDto = new ContestDto();
                contestDto = await ConvertToContestDto(contestDto, response);
                contestDto.EndPointList = endpoint;
                return Json(contestDto);
            }

            return NotFound();
        }

        [Route("enterContest/{contestId}/{currentPage}/{perPageRecords}")]
        [AuthorizeTokenFilter(validate: false, role: "Talent,Recruiter,FTCAdmin")]
        [HttpGet]
        public async Task<ActionResult> EnterContest(int contestId, int currentPage, int perPageRecords, int userId, int userType)
        {

            int startIndex = (currentPage > 0) ? ((currentPage) * perPageRecords + 1) : currentPage;
            int endIndex = (currentPage > 0) ? (startIndex + perPageRecords) : perPageRecords;


            Contest enterContestResponse = new Contest();


            bool isParticipant = false;


            if (userId > 0)
            {

                if (userType == (int)LoginUserType.Talent)
                {
                    int talentId = userId;
                    var contestParticipant = await _contestSubmissionRepository.FindAsync(x => x.ContestId == contestId && x.TalentId == talentId);
                    if (contestParticipant != null)
                    {
                        isParticipant = true;
                    }
                    // fetch contest which are marked as published for the given contestID
                    var enterContestResponseByStatus = await _contestRepository.FindAsync(x => (x.StatusId == System.Convert.ToInt32(StatusEnum.Published)
                                                                                || x.StatusId == System.Convert.ToInt32(StatusEnum.Close))
                                                                                && x.Id == contestId);

                    if (enterContestResponseByStatus == null)
                    {
                        return NotFound();
                    }

                    enterContestResponse = enterContestResponseByStatus;

                }
                else
                {
                    // user is recruiter or admin
                    var enterContestResponseById = await _contestRepository.FindAsync(x => x.Id == contestId);
                    if (enterContestResponseById == null)
                    {
                        return NotFound();
                    }
                    enterContestResponse = enterContestResponseById;
                }

            }
            else
            {
                // fetch contest which are marked as published for the given contestID
                var enterContestResponseByStatus = await _contestRepository.FindAsync(x => (x.StatusId == System.Convert.ToInt32(StatusEnum.Published)
                                                                            || x.StatusId == System.Convert.ToInt32(StatusEnum.Close))
                                                                            && x.Id == contestId);

                if (enterContestResponseByStatus == null)
                {
                    return NotFound();
                }

                enterContestResponse = enterContestResponseByStatus;

            }
            
            //fetch recruiter banner image
            var auxiliaryRecruiterResponse = await _auxiliaryRecruiterRepository.FindAsync(x => x.AuxiliaryId == enterContestResponse.AuxiliaryUserId);

            // other contest by that recruiter
            List<Contest> relatedContestByRecruiter = new List<Contest>();
            var relatedContestByRecruiterResponse = await _contestRepository.FindAllAsync(x => (x.StatusId == System.Convert.ToInt32(StatusEnum.Published)
                                                                                || x.StatusId == System.Convert.ToInt32(StatusEnum.Close))
                                                                                && x.AuxiliaryUserId == enterContestResponse.AuxiliaryUserId
                                                                                && x.EndDate > System.DateTime.Now.Date);

            relatedContestByRecruiter = relatedContestByRecruiterResponse.ToList();

            //exclude the Enter Contest
            relatedContestByRecruiter = relatedContestByRecruiter.Where(x => x.Id != enterContestResponse.Id).ToList();


            List<ContestResult> lstContestResult = new List<ContestResult>();
            // if  the winners are published
            if (enterContestResponse.WinnerPublished)
            {
                //for winners result
                // find all the submission for input contest
                var contestSubmission = await _contestSubmissionRepository.FindAllAsync(x => x.ContestId == contestId);
                var contestSubmissionId = contestSubmission.Select(x => x.Id).ToList();

                //find the results of the contest
                var lstContestResultResponse = await _contestResultRepository.FindAllAsync(x => contestSubmissionId.Contains(x.ContestSubmissionId));
                lstContestResult = lstContestResultResponse.ToList();
            }

            //Contest Special Host
            var contestSpecialHostResponse = await _contestSpecialHostRepository.FindAsync(x => x.AuxiliaryUserId == enterContestResponse.AuxiliaryUserId);

            //Response
            ContestDto enterContestDto = new ContestDto();
            enterContestDto = await ConvertToContestDto(enterContestDto, enterContestResponse);

            if (string.IsNullOrEmpty(enterContestResponse.TempBannerImage))
            {
                enterContestDto.ContestBannerImage = (auxiliaryRecruiterResponse != null) ? auxiliaryRecruiterResponse.ContestBannerImage : "";
            }
            else
            {
                enterContestDto.ContestBannerImage = enterContestResponse.TempBannerImage;
            }

            //pagination Response
            var totalCount = relatedContestByRecruiter.Count();
            relatedContestByRecruiter = relatedContestByRecruiter.OrderByDescending(x => x.CreatedOn)
                                                                .Skip(startIndex - 1)
                                                                .Take(endIndex - startIndex)
                                                                .ToList();


            List<ContestDto> lstRelatedContestDto = await ConvertToListContestDto(relatedContestByRecruiter);

            List<ContestWinnersDto> lstContestWinnersDto = new List<ContestWinnersDto>();
            {
                foreach (var contestResult in lstContestResult)
                {
                    ContestWinnersDto contestWinnersDto = new ContestWinnersDto();
                    contestWinnersDto = await ConvertToContestResultDto(contestWinnersDto, contestResult);
                    lstContestWinnersDto.Add(contestWinnersDto);
                }
            }

            lstContestWinnersDto = lstContestWinnersDto.OrderBy(x => x.ContestRank).ToList();

            ContestSpecialHostDto contestSpecialHostDto = new ContestSpecialHostDto();
            if (contestSpecialHostResponse != null)
            {
                contestSpecialHostDto = await ConvertToContestSpecialHostDto(contestSpecialHostDto, contestSpecialHostResponse);
            }
            return Json(new
            {
                enterContestResponse = enterContestDto,
                isParticipant = isParticipant,
                otherContest = lstRelatedContestDto,
                contestWinners = lstContestWinnersDto,
                contestSpecialHost = contestSpecialHostDto,
                totalCount = totalCount
            });
        }

        /// <summary>
        /// get contest by contestId
        /// </summary>
        [HttpGet]
        [Route("{id}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> Get(int id, UserInfo userInfo)
        {
            var contest = await _contestRepository.GetContestById(id, userInfo.userId, userInfo.userType);
            if (contest != null)
            {
                return Json(new { contest = contest });
            }

            return NotFound();
        }

        /// <summary>
        /// get applied contest submissions
        /// </summary>
        [HttpPost]
        [Route("getsubmissions/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetSubmissions([FromBody]SearchParametersDto searchParams, int contestId)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var submissions = await _contestSubmissionRepository.GetContestSubmissionByType(search, contestId, "submitted");
            if (submissions != null)
                return new JsonResult(submissions);

            return NotFound();
        }

        /// <summary>
        /// get selected contest submissions
        /// </summary>
        [HttpPost]
        [Route("getselectedentries/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetSelectedSubmissions([FromBody]SearchParametersDto searchParams, int contestId)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var submissions = await _contestSubmissionRepository.GetContestSubmissionByType(search, contestId, "selected");
            if (submissions != null)
                return new JsonResult(submissions);

            return NotFound();
        }

        /// <summary>
        /// get contest winners from submissions
        /// </summary>
        [HttpPost]
        [Route("getwinners/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetWinnersSubmissions([FromBody]SearchParametersDto searchParams, int contestId)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var submissions = await _contestSubmissionRepository.GetContestSubmissionByType(search, contestId, "winners");
            if (submissions != null)
                return new JsonResult(submissions);

            return NotFound();
        }

        /// <summary>
        /// PutTalentSubmission Select entry
        /// </summary>
        [HttpPut]
        [Route("selectentry/{id}/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> PutSelectTalentSubmission(int id, int contestId)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            var contestSubmission = await _contestSubmissionRepository.FindAsync(x => x.Id == id && x.ContestId == contestId);
            if (contestSubmission != null)
            {
                contestSubmission.Selected = true;
                contestSubmission.UpdatedOn = DateTime.UtcNow;
                var updatedContestSubmission = await _contestSubmissionRepository.UpdateAsync(contestSubmission);
                return new JsonResult(updatedContestSubmission);
            }
            return NotFound();
        }

        /// <summary>
        /// TalentSubmission remove entry
        /// </summary>
        [HttpPut]
        [Route("removeentry/{id}/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> PutUnSelectTalentSubmission(int id, int contestId)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            var deleteResult = await DeleteContestResult(id);
            var contestSubmission = await _contestSubmissionRepository.FindAsync(x => x.Id == id && x.ContestId == contestId);
            if (contestSubmission != null)
            {
                contestSubmission.Selected = false;
                contestSubmission.UpdatedOn = DateTime.UtcNow;
                var updatedContestSubmission = await _contestSubmissionRepository.UpdateAsync(contestSubmission);
                return new JsonResult(updatedContestSubmission);
            }
            return NotFound();
        }

        /// <summary>
        /// post add rank
        /// </summary>
        [HttpPost]
        [Route("addrank/{id}/{contestId}/{rank}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> AddRankToSubmission(int id, int contestId, short rank)
        {
            if (id == 0)
            {
                return BadRequest();
            }

            var contestResult = await _contestResultRepository.FindAsync(x => x.ContestSubmissionId == id);
            if (contestResult != null)  //update
            {
                contestResult.ContestRank = rank;
                var updatedContestResult = await _contestResultRepository.UpdateAsync(contestResult);
                return new JsonResult(updatedContestResult);
            }
            else  //create
            {
                var contestSubmission = await _contestSubmissionRepository.FindAsync(x => x.Id == id && x.ContestId == contestId);
                ContestResult resultRank = new ContestResult()
                {
                    ContestSubmissionId = contestSubmission.Id,
                    ContestRank = rank
                };
                var newContestResult = await _contestResultRepository.AddAsync(resultRank);
                return new JsonResult(newContestResult);
            }
        }

        /// <summary>
        /// post remove rank
        /// </summary>
        [HttpPost]
        [Route("removerank/{id}/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> RemoveRankOfSubmission(int id, int contestId)
        {
            if (id == 0)        //id:submissionId
            {
                return BadRequest();
            }
            var result = await DeleteContestResult(id);
            return new JsonResult(result);
        }

        [Route("getbannerimageofrecruiter")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetBannerImageOfRecruiter(int recruiterId, int userId)
        {
            string profileURl;

            if (recruiterId == 0)
            {
                var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == userId);
                profileURl = auxiliaryUser.ProfileURL;
            }
            else
            {
                var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == recruiterId);
                profileURl = auxiliaryUser.ProfileURL;
            }

            return Ok(new { profileURl = profileURl });
        }

        [HttpPost]
        [Route("verifycontest")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> VerifyContest([FromBody]RequestVerifyContestDto requestVerifyContestDto, UserInfo userInfo)
        {
            var contest = await _contestRepository.FindAsync(x => x.Id == requestVerifyContestDto.ContestId);
            if (contest != null)
            {
                contest.StatusId = (int)StatusEnum.Verified;
                contest.VerifiedOn = DateTime.UtcNow;
                contest.VerifiedBy = userInfo.userId;
                contest = await _contestRepository.UpdateAsync(contest);
                await UpdateRecruiterBannerImage(contest);

                #region Send Notification - Email, SMS, System
                await NotifyContestVerification(userInfo, contest);
                #endregion
            }
            return Ok(new { verified = "true" });

        }

        /// <summary>
        /// post publish contest
        /// </summary>
        [HttpPost]
        [Route("publishcontest/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> PublishWinnerAndCloseContest(int contestId, int userId, int userType)
        {
            if (contestId == 0)
            {
                return BadRequest();
            }

            var contest = await _contestRepository.FindAsync(x => x.Id == contestId);
            if (contest != null)
            {
                contest.StatusId = System.Convert.ToInt32(StatusEnum.Close);
                contest.WinnerPublished = true;
                contest.UpdatedOn = DateTime.UtcNow;
                var response = await _contestRepository.UpdateAsync(contest);

                #region Add ContestStatusHistory When a Winner is published
                // Add Entry of the changed status [Winner is published] & by Whom
                if (contest.StatusId == (int)StatusEnum.Close)
                {
                    var contestStatusHistory = new ContestStatusHistory()
                    {
                        CreatedBy = userId,
                        ContestId = contest.Id,
                        StatusId = contest.StatusId
                    };
                    contestStatusHistory = await _contestStatusHistoryRepository.AddAsync(contestStatusHistory);
                }
                #endregion

                #region Send Notification to published winners
                var search = new SearchParameters();
                var submissions = await _contestSubmissionRepository.GetContestSubmissionByType(search, contestId, "winners");
                var lstWinners = submissions.Results.Select(x => (int)x.TalentId).ToList();

                // Notify Talents [Email, SMS, SystemNotification, PushNotification]
                await NotifyContestWinners(contestId, userId, contest, lstWinners);

                // Notify AuxiliaryUser
                await NotifyAuxiliaryUserContestWinners(contestId, userId, contest, lstWinners);

                #endregion

                return Json(response);
            }

            return NotFound();
        }

        private async Task NotifyContestWinners(int contestId, int userId, Contest contest, List<int> lstWinners)
        {
            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            NotificationParam notificationParam = new NotificationParam()
            {
                AuxiliaryUserId = userId,
                ContestName = contest.Name
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto()
            {
                NotificationReference = NotificationReferenceEnum.Contest,
                NotificationReferenceValue = contestId,
                UrlRoute = ViewNotificationEnumDto.WinnerManagement
            };

            // find list of talent Names and Email Id  // send email list here
            if (lstWinners.Count > 0)
            {
                var talentToken = await _talentTokenRepository.FindAllAsync(x => lstWinners.Contains((int)x.TalentId) && x.Email == constantActivated);
                var lstEmailVerifiedTalent = talentToken.Select(x => x.TalentId);
                if (lstEmailVerifiedTalent.Count() > 0)
                {
                    var talents = await _talentRepository.FindAllAsync(x => lstEmailVerifiedTalent.Contains(x.Id));
                    sendSystemNotificationDto.SendEmailToTalents = talents.Select(x => x.Email).ToList();
                }
            }
            
            var talentWinners = await _talentRepository.FindAllAsync(x => lstWinners.Contains(x.Id));

            notificationParam.SendSmsToTalents = talentWinners.Select(x => new SendSmsToUsers
            {
                TalentId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            sendSystemNotificationDto.PushNotifications = talentWinners.Select(x => new PushNotification
            {
                UserId = x.Id,
                DeviceOsId = x.DeviceOsId,
                DeviceRegistrationId = x.DeviceRegistrationId
            }).ToList();

            await notification.SendNotification(NotificationEnum.WinnerManagement, notificationParam, sendSystemNotificationDto);
        }

        private async Task NotifyAuxiliaryUserContestWinners(int contestId, int userId, Contest contest, List<int> lstWinners)
        {
            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            NotificationParam notificationParam = new NotificationParam()
            {
                AuxiliaryUserId = userId,
                ContestName = contest.Name,
                TalentCount = lstWinners.Count.ToString()
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userId, (int)NotificationEnum.WinnerManagement),
                NotificationReference = NotificationReferenceEnum.Contest,
                NotificationReferenceValue = contestId,
                UrlRoute = ViewNotificationEnumDto.WinnerManagement,
            };

            // Send Email to list of Auxiliary Users 
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            
            var recruiter = auxiliaryUsers.FirstOrDefault(x => x.Id == contest.AuxiliaryUserId);

            // Before fetching the recruiter name check if it already exists in the auxiliaryUsers list & if not, go fetch

            if (recruiter != null)
            {
                notificationParam.RecruiterName = recruiter.FullName;
            }
            else
            {
                recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == contest.AuxiliaryUserId);
                notificationParam.RecruiterName = recruiter.FullName;
            }

            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            await notification.SendNotification(NotificationEnum.WinnerManagementAdmin, notificationParam, sendSystemNotificationDto);
        }

        /// <summary>
        /// post end contest
        /// </summary>
        [HttpPost]
        [Route("endcontest/{contestId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> EndContest(int contestId, UserInfo userInfo)
        {
            if (contestId == 0)
            {
                return BadRequest();
            }
            var contest = await _contestRepository.FindAsync(x => x.Id == contestId);
            if (contest != null)
            {
                contest.StatusId = System.Convert.ToInt32(StatusEnum.Close);
                contest.UpdatedBy = userInfo.userId;
                contest.UpdatedOn = DateTime.UtcNow;
                var response = await _contestRepository.UpdateAsync(contest);

                var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
                var notificationParam = new NotificationParam()
                {
                    ContestName = contest.Name,
                    AuxiliaryUserId = userInfo.userId
                };
                var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                {
                    SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.ContestClose),
                    NotificationReference = NotificationReferenceEnum.Contest,
                    NotificationReferenceValue = contest.Id,
                    UrlRoute = ViewNotificationEnumDto.EditContest
                };
                await notification.SendNotification(NotificationEnum.ContestClose, notificationParam, sendSystemNotificationDto);

                return Json(response);
            }

            return NotFound();
        }

        /// <summary>
        /// Upload Contest Media
        /// </summary>
        /// <param name="contestSubmissionDto"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        [Route("uploadContestMedia")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> UploadContestMedia([FromHeader]ContestSubmissionDto contestSubmissionDto, IFormFile file, int userId, int userType)
        {
            int talentId = userId;

            #region Check if provider Authenticattion is required or not. If So, authenticate it

            var contestValidation = await _contestRepository.FindAsync(x => x.Id == (int)contestSubmissionDto.ContestId);
            if (contestValidation.ValidationRequired == true)
            {
                #region Authenticate the provider
                // /Provider/Authenticate
                ProviderDetails providerDetails = new ProviderDetails();
                //providerDetails.SubscriberId = string.IsNullOrEmpty(contestSubmissionDto.Value1) ? contestSubmissionDto.Value2 : contestSubmissionDto.Value1;
                providerDetails.SubscriberId = (contestSubmissionDto.ContestSpecialHost == ContestSpecialHostEnum.TataSky) ? contestSubmissionDto.Value2 : contestSubmissionDto.Value1;

                providerDetails.TalentId = talentId;
                providerDetails.ContestId = (int)contestSubmissionDto.ContestId;
                var contestById = await _contestRepository.FindAsync(x => x.Id == contestSubmissionDto.ContestId);
                providerDetails.ProviderId = contestById.AuxiliaryUserId;
                var providerResponse = await _providerRepository.Authenticate(providerDetails);

                if (providerResponse == null)
                {
                    return BadRequest();
                }
                else
                {
                    if (!providerResponse.IsValid)
                    {
                        return BadRequest(providerResponse = providerResponse);
                    }
                }
                #endregion
            }
            #endregion

            #region Check if the talent has already participated

            // Check if the talent has already participated
            var contestParticipant = await _contestSubmissionRepository.FindAsync(x => x.ContestId == contestSubmissionDto.ContestId
                                                                                    && x.TalentId == talentId);
            if (contestParticipant != null)
            {
                return BadRequest(new { isParticipant = true });
            }
            #endregion

            if (file != null && file.Length > 0)
            {
                #region upload the contest media
                string targetPath = _appSettings.MediaBasePath;

                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);

                string savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, userId.ToString()), _appSettings.S3BucketNameContest, _appSettings.S3BaseUrlForContest);

                var stopWatch = Stopwatch.StartNew();
                LogInformationAsWarning($"Uploading file: {fileName}, fileSize: {file.Length} for  {userId} ...");

                savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);

                stopWatch.Stop();
                LogInformationAsWarning($"Upload of file: {fileName}, fileSize: {file.Length} completed Successfully for  {userId} in {stopWatch.Elapsed.TotalMilliseconds}");


                MediaFile mediaFile = new MediaFile();

                mediaFile.FileTypeId = contestSubmissionDto.FileTypeId;
                mediaFile.FileName = fileName;
                mediaFile.FilePath = UserAccessiblePath(savedPath, _appSettings.S3BucketNameContest, _appSettings.S3BaseUrlForContest);

                string mime = MimeKit.MimeTypes.GetMimeType(fileName);
                mediaFile.FileMimeType = mime;

                mediaFile.IsExternalUrl = false;

                mediaFile = await _mediaFileRepository.AddAsync(mediaFile);

                #endregion

                #region save info related to contestSubmission

                string ipAddress = HttpContext.Connection.RemoteIpAddress.ToString();
                contestSubmissionDto.IpAddress = ipAddress;

                // save contest related information for the talent
                ContestSubmission contestSubmission = new ContestSubmission();
                contestSubmission = await ConvertToContestSubmission(contestSubmission, contestSubmissionDto);
                contestSubmission.TalentId = userId;

                contestSubmission = await _contestSubmissionRepository.AddAsync(contestSubmission);

                #endregion

                #region save contestMedia ID & Submission ID
                ContestSubmissionMedia contestSubmissionMedia = new ContestSubmissionMedia();
                contestSubmissionMedia.ContestSubmissionId = contestSubmission.Id;
                contestSubmissionMedia.MediaFileId = mediaFile.Id;
                contestSubmissionMedia = await _contestSubmissionMediaRepository.AddAsync(contestSubmissionMedia);
                #endregion

                #region Save TataSky Acting adda details in Onboarding
                if (contestSubmissionDto.ContestSpecialHost == ContestSpecialHostEnum.TataSky)
                {
                    await SaveTalentSpecialHost(contestSubmissionDto, userId, userType);
                }
                #endregion

                return Ok(new { success = "Success" });
            }

            return BadRequest();

        }

        private async Task SaveTalentSpecialHost(ContestSubmissionDto contestSubmissionDto, int userId, int userType)
        {
            var talentSpecialHostDto = new TalentSpecialHostDto()
            {
                TalentId = userId,
                RMN = contestSubmissionDto.Value1,
                SubscriberNumber = string.IsNullOrEmpty(contestSubmissionDto.Value1) ? string.Empty : contestSubmissionDto.Value2,
                SubscriberIdText = string.IsNullOrEmpty(contestSubmissionDto.Value1) ? contestSubmissionDto.Value2 : string.Empty,
                StatusId = (int)StatusEnum.Active,
                SpecialHostId = (short)contestSubmissionDto.ContestSpecialHost
            };

            // Make previous record Inactive
            await _talentSpecialHostRepository.UpdateTalentSpecialHost(talentSpecialHostDto, userId, userType);

            // Add new record of TS Acting adda..to make it available during onboarding
            await _talentSpecialHostRepository.SaveTalentSpecialHost(talentSpecialHostDto, userId, userType);
        }

        /// <summary>
        /// Save Contest
        /// </summary>
        /// <param name="contestDto"></param>
        /// <param name="AssestsFile"></param>
        /// <param name="BannerFile"></param>
        /// <param name="ThumbnailFile"></param>
        /// <returns></returns>
        [Route("saveContest")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SaveContest([FromHeader]ContestDto contestDto, IFormFile AssestsFile, IFormFile BannerFile, IFormFile ThumbnailFile, UserInfo userInfo)
        {
            Contest contest = new Contest();
            if (contestDto.AuxiliaryUserId == 0)
            {
                contestDto.AuxiliaryUserId = userInfo.userId;
            }

            if (contestDto.Id > 0)
            {
                contest = await _contestRepository.FindAsync(x => x.Id == contestDto.Id);
                contest = ConvertToContestModel(userInfo.userId, contestDto, contest);
                contest = await _contestRepository.UpdateAsync(contest);
                await SaveEndPoint(contestDto.endpointJson, contestDto.AuxiliaryUserId, contestDto.Id);
            }
            else
            {
                if (contestDto.ContestBannerImage == null && BannerFile == null)
                {
                    var recruiter = await _auxiliaryRecruiterRepository.FindAsync(x => x.AuxiliaryId == contestDto.AuxiliaryUserId);
                    if (recruiter != null)
                    {
                        if (recruiter.ContestBannerImage != null)
                        {
                            contest.TempBannerImage = recruiter.ContestBannerImage;
                            contestDto.ContestBannerImage = recruiter.ContestBannerImage;
                        }
                    }
                }
                contest = ConvertToContestModel(userInfo.userId, contestDto, contest);
                contest = await _contestRepository.AddAsync(contest);

                #region Send Notification - Email, SMS, System Notification

                await NotifyContestCreation(userInfo, contest);

                #endregion

                contestDto.Id = contest.Id;
            }
            if (AssestsFile != null)
            {
                if (!string.IsNullOrEmpty(contest.Assets))
                {
                    await _fileService.DeleteAsync(contest.Assets.Replace(_appSettings.S3BaseUrlForContest, _appSettings.S3BucketNameContest));
                }
                contest.Assets = await UploadContest(AssestsFile, contestDto.AuxiliaryUserId, ContestImages.Assest, contest.Id);
                contestDto.Assets = contest.Assets;
            }
            if (ThumbnailFile != null)
            {
                if (!string.IsNullOrEmpty(contest.Thumbnail))
                {
                    await _fileService.DeleteAsync(contest.Thumbnail.Replace(_appSettings.S3BaseUrlForContest, _appSettings.S3BucketNameContest));
                }
                contest.Thumbnail = await UploadContest(ThumbnailFile, contestDto.AuxiliaryUserId, ContestImages.Thumbnail, contest.Id);
                contestDto.Thumbnail = contest.Thumbnail;
            }
            if (BannerFile != null)
            {
                if (!string.IsNullOrEmpty(contest.TempBannerImage))
                {
                    await _fileService.DeleteAsync(contest.TempBannerImage.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                }
                contest.TempBannerImage = await UploadContest(BannerFile, contestDto.AuxiliaryUserId, ContestImages.Banner, contest.Id);
                contestDto.ContestBannerImage = contest.TempBannerImage;
            }
            contest = await _contestRepository.UpdateAsync(contest);
            if (contestDto.AuxiliaryUserId != userInfo.userId)
            {
                await UpdateRecruiterBannerImage(contest);
            }

            return Json(contestDto);

        }

        [Route("UpdateContestStatus")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> UpdateContestStatus([FromBody]UpdateContestStatusDto updateContestStatusDto, int userId)
        {
            if (updateContestStatusDto.ContestId == 0)
            {
                return BadRequest();
            }
            var contest = await _contestRepository.FindAsync(x => x.Id == updateContestStatusDto.ContestId);
            if (contest == null)
            {
                return NotFound();
            }
            var auxiliaryUserId = await _auxiliaryUserRepository.FindAsync(x => x.Id == contest.AuxiliaryUserId);
            if ((bool)!auxiliaryUserId.Verified && updateContestStatusDto.Status == StatusEnum.Published)
            {
                return Ok(new { isStausUpdated = "false", isAuxiliaryUserVerified = false });
            }

            if (updateContestStatusDto.Status == StatusEnum.Verified)
            {
                await UpdateRecruiterBannerImage(contest);
            }

            // If a draft contest is ended... statusId should be discard rather than close as close contest are displayed to talent
            if ((updateContestStatusDto.Status == StatusEnum.Close)
                && (contest.StatusId == (int)StatusEnum.Draft || contest.StatusId == (int)StatusEnum.Verified))
            {
                contest.StatusId = (int)StatusEnum.Discard;
            }
            else
            {
                contest.StatusId = (int)updateContestStatusDto.Status;
            }
            //contest.UpdatedBy = userId;
            contest.UpdatedOn = DateTime.UtcNow;
            contest = await _contestRepository.UpdateAsync(contest);

            #region Add ContestStatusHistory When Contest is Published and Closed
            // Add Entry of the changed status [Publish & Close] & by Whom
            if (contest.StatusId == (int)StatusEnum.Published || contest.StatusId == (int)StatusEnum.Close)
            {
                var contestStatusHistory = new ContestStatusHistory()
                {
                    CreatedBy = userId,
                    ContestId = contest.Id,
                    StatusId = contest.StatusId
                };
                contestStatusHistory = await _contestStatusHistoryRepository.AddAsync(contestStatusHistory);
            }
            #endregion

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                ContestName = contest.Name
            };
            await NotifyContestStatusChange(userId, contest, notification, notificationParam);

            return Ok(new { isStausUpdated = "true", isAuxiliaryUserVerified = auxiliaryUserId.Verified });
        }

        #endregion

        #region Private Methods

        [NonAction]
        private void LogInformationAsWarning(string message)
        {
            Serilog.Log.Warning("[Information] " + message);
        }

        [NonAction]
        private async Task NotifyContestCreation(UserInfo userInfo, Contest contest)
        {
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                ContestName = contest.Name,
                AuxiliaryUserId = userInfo.userId
            };
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.ContestCreation),
                NotificationReference = NotificationReferenceEnum.Contest,
                NotificationReferenceValue = contest.Id,
                UrlRoute = ViewNotificationEnumDto.EditContest
            };

            // Send Email to list of Auxiliary Users When a Contest is Created
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            await notification.SendNotification(NotificationEnum.ContestCreation, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private async Task NotifyContestVerification(UserInfo userInfo, Contest contest)
        {
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                ContestName = contest.Name,
                AuxiliaryUserId = userInfo.userId
            };
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                NotificationReference = NotificationReferenceEnum.Contest,
                NotificationReferenceValue = contest.Id,
                UrlRoute = ViewNotificationEnumDto.EditContest
            };
            // send Email when the Contest is Verified
            sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.ContestApproval);
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();

            await notification.SendNotification(NotificationEnum.ContestApproval, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private async Task NotifyContestStatusChange(int userId, Contest contest, Notification notification, NotificationParam notificationParam)
        {
            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            sendSystemNotificationDto.NotificationReference = NotificationReferenceEnum.Contest;
            sendSystemNotificationDto.NotificationReferenceValue = contest.Id;
            sendSystemNotificationDto.UrlRoute = ViewNotificationEnumDto.EditContest;


            if (contest.StatusId == (int)StatusEnum.Verified)
            {
                sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userId, (int)NotificationEnum.ContestApproval);

                // Send Email to list of Auxiliary Users When a Contest is verifed
                var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                // list with params to send sms
                notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                {
                    AuxiliaryUserId = x.Id,
                    MobileCountryCode = x.MobileCountryCode,
                    MobileNumber = x.Mobile
                }).ToList();


                await notification.SendNotification(NotificationEnum.ContestApproval, notificationParam, sendSystemNotificationDto);
            }
            else if (contest.StatusId == (int)StatusEnum.Published)
            {
                sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userId, (int)NotificationEnum.ContestPublish);

                // Send Email to list of Auxiliary Users When a Contest is verifed
                var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                // list with params to send sms
                notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                {
                    AuxiliaryUserId = x.Id,
                    MobileCountryCode = x.MobileCountryCode,
                    MobileNumber = x.Mobile
                }).ToList();

                await notification.SendNotification(NotificationEnum.ContestPublish, notificationParam, sendSystemNotificationDto);
            }
            else if (contest.StatusId == (int)StatusEnum.Close)
            {
                sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser(contest.AuxiliaryUserId, userId, (int)NotificationEnum.ContestClose);

                // Send Email to list of Auxiliary Users When a Contest is verifed
                var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                // list with params to send sms
                notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                {
                    AuxiliaryUserId = x.Id,
                    MobileCountryCode = x.MobileCountryCode,
                    MobileNumber = x.Mobile
                }).ToList();


                await notification.SendNotification(NotificationEnum.ContestClose, notificationParam, sendSystemNotificationDto);
            }
        }

        [NonAction]
        private async Task UpdateRecruiterBannerImage(Contest contest)
        {
            var auxiliaryRecruiter = await _auxiliaryRecruiterRepository.FindAsync(x => x.AuxiliaryId == contest.AuxiliaryUserId);
            if (auxiliaryRecruiter != null)
            {
                if (!string.IsNullOrEmpty(auxiliaryRecruiter.ContestBannerImage) && auxiliaryRecruiter.ContestBannerImage != contest.TempBannerImage)
                {
                    await _fileService.DeleteAsync(auxiliaryRecruiter.ContestBannerImage.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                }
                auxiliaryRecruiter.ContestBannerImage = contest.TempBannerImage;
                auxiliaryRecruiter = await _auxiliaryRecruiterRepository.UpdateAsync(auxiliaryRecruiter);
            }
        }

        [NonAction]
        private async Task<List<ContestDto>> ConvertToListContestDto(List<Contest> lstContest)
        {
            List<ContestDto> lstContestDto = new List<ContestDto>();
            foreach (var contest in lstContest)
            {
                ContestDto contestDto = new ContestDto();
                contestDto = await ConvertToContestDto(contestDto, contest);
                lstContestDto.Add(contestDto);
            }

            return lstContestDto;
        }

        [NonAction]
        private async Task<ManageContestDto> ConvertToManageContestDto(ManageContestDto manageContestDto, List<ContestDto> lstContestByRecruiterIdDto, int distinctAuxiliaryUserContest, int recruiterId, int totalContestCount)
        {
            manageContestDto.AuxiliaryUserId = distinctAuxiliaryUserContest;

            var auxiliaryuser = await _auxiliaryUserRepository.FindAsync(x => x.Id == distinctAuxiliaryUserContest);
            manageContestDto.AuxiliaryUserName = (auxiliaryuser != null) ? auxiliaryuser.FullName : "";

            if (recruiterId == distinctAuxiliaryUserContest)
            {
                manageContestDto.Contests.TotalContestCount = totalContestCount;
                manageContestDto.Contests.ContestData = lstContestByRecruiterIdDto;

            }
            else
                manageContestDto.Contests = null;

            return manageContestDto;
        }


        [NonAction]
        public Contest ConvertToContestModel(int userId, ContestDto contestDto, Contest contest)
        {
            contest.Name = contestDto.Name;
            contest.Title = contestDto.Title;
            contest.ShortDetail = contestDto.ShortDetail;
            contest.Description = contestDto.Description;
            contest.StartDate = contestDto.StartDate;
            contest.EndDate = contestDto.EndDate;

            contest.Packages = contestDto.Packages;

            contest.Order = contestDto.Order;
            contest.Gratification = contestDto.Gratification;

            contest.PrivateKey = contestDto.PrivateKey;
            contest.NumberPosition = contestDto.NumberPosition;
            contest.MediaFileTypeId = contestDto.MediaFileTypeId;
            contest.VerifiedBy = contestDto.VerifiedBy;
            contest.CreativeDirection = contestDto.CreativeDirection;
            contest.IdentificationLabel = contestDto.IdentificationLabel;
            contest.ValidationRequired = contestDto.ValidationRequired;
            contest.WinnerPublished = contestDto.WinnerPublished;

            contest.TermsAndConditions = contestDto.TermsAndConditions;
            contest.ContestTypeId = contestDto.ContestTypeId;
            contest.EngagementLink = contestDto.EngagementLink;
            contest.TextColor = contestDto.TextColor;
            if (contestDto.AuxiliaryUserId != 0)
            {
                contest.AuxiliaryUserId = contestDto.AuxiliaryUserId;
            }
            else
            {
                contest.AuxiliaryUserId = userId;
            }
            contest.CreatedBy = userId;
            return contest;
        }

        [NonAction]
        public async Task<ContestDto> ConvertToContestDto(ContestDto contestDto, Contest contest)
        {
            contestDto.Id = contest.Id;
            contestDto.Name = contest.Name;
            contestDto.Title = contest.Title;
            contestDto.ShortDetail = contest.ShortDetail;
            contestDto.Description = contest.Description;
            contestDto.StartDate = contest.StartDate;
            contestDto.EndDate = contest.EndDate;
            contestDto.AuxiliaryUserId = contest.AuxiliaryUserId;
            contestDto.Thumbnail = contest.Thumbnail;
            contestDto.Packages = contest.Packages;
            contestDto.StatusId = contest.StatusId;
            contestDto.Order = contest.Order;
            contestDto.Gratification = contest.Gratification;
            contestDto.PrivateKey = contest.PrivateKey;
            contestDto.NumberPosition = contest.NumberPosition;
            contestDto.MediaFileTypeId = contest.MediaFileTypeId;
            contestDto.VerifiedBy = contest.VerifiedBy;
            contestDto.CreativeDirection = contest.CreativeDirection;
            contestDto.IdentificationLabel = contest.IdentificationLabel;
            contestDto.ValidationRequired = contest.ValidationRequired;
            contestDto.WinnerPublished = contest.WinnerPublished;
            contestDto.Assets = contest.Assets;
            contestDto.TermsAndConditions = contest.TermsAndConditions;
            contestDto.ContestTypeId = contest.ContestTypeId;
            contestDto.EngagementLink = contest.EngagementLink;
            contestDto.CreatedOn = contest.CreatedOn;
            contestDto.TextColor = contest.TextColor;

            contestDto.ContestBannerImage = contest.TempBannerImage;

            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == contest.AuxiliaryUserId);
            contestDto.AuxiliaryUserName = (auxiliaryUser != null) ? auxiliaryUser.FullName : "";

            var fileTypeResponse = await _fileTypeRepository.FindAsync(x => x.Id == contest.MediaFileTypeId);

            if (fileTypeResponse != null)
            {
                contestDto.FileExtension = fileTypeResponse.AllowedExtensions;
                contestDto.FileIcon = fileTypeResponse.Icon;
            }
            return contestDto;
        }

        [NonAction]
        private async Task<ContestSubmission> ConvertToContestSubmission(ContestSubmission contestSubmission, ContestSubmissionDto contestSubmissionDto)
        {
            contestSubmission.ContestId = contestSubmissionDto.ContestId;
            contestSubmission.Value1 = contestSubmissionDto.Value1;
            contestSubmission.Value2 = contestSubmissionDto.Value2;
            contestSubmission.IpAddress = contestSubmissionDto.IpAddress;
            contestSubmission.ParticipatedDate = DateTime.Now;
            return contestSubmission;
        }

        [NonAction]
        private async Task<ContestSpecialHostDto> ConvertToContestSpecialHostDto(ContestSpecialHostDto contestSpecialHostDto, ContestSpecialHost contestSpecialHostResponse)
        {
            contestSpecialHostDto.Id = contestSpecialHostResponse.Id;
            contestSpecialHostDto.AuxiliaryUserId = contestSpecialHostResponse.AuxiliaryUserId;
            contestSpecialHostDto.Name = contestSpecialHostResponse.Name;

            return contestSpecialHostDto;
        }

        [NonAction]
        private async Task<ContestWinnersDto> ConvertToContestResultDto(ContestWinnersDto contestWinnersDto, ContestResult contestWinner)
        {
            contestWinnersDto.ContestRank = contestWinner.ContestRank;
            contestWinnersDto.ContestSubmissionId = contestWinner.ContestSubmissionId;

            var contestSubmissionResponse = await _contestSubmissionRepository.FindAsync(x => x.Id == contestWinner.ContestSubmissionId);
            contestWinnersDto.TalentId = contestSubmissionResponse.TalentId;

            var talentResponse = await _talentRepository.FindAsync(x => x.Id == contestSubmissionResponse.TalentId);

            contestWinnersDto.UID = (int)talentResponse.UID;
            contestWinnersDto.TalentProfileURL = talentResponse.TalentProfileURL;

            return contestWinnersDto;
        }

        [NonAction]
        private async Task<ContestSubmissionDto> ConvertToContestSubmissionDto(ContestSubmissionDto contestSubmissionDto, ContestSubmission contestSubmission)
        {
            contestSubmissionDto.Id = contestSubmission.Id;
            contestSubmissionDto.TalentId = contestSubmission.TalentId;
            contestSubmissionDto.ContestId = contestSubmission.ContestId;

            contestSubmissionDto.Value1 = contestSubmission.Value1;
            contestSubmissionDto.Value2 = contestSubmission.Value2;
            contestSubmissionDto.ParticipatedDate = contestSubmission.ParticipatedDate;

            contestSubmissionDto.IpAddress = contestSubmission.IpAddress;
            contestSubmissionDto.CreatedOn = contestSubmission.CreatedOn;
            contestSubmissionDto.UpdatedOn = contestSubmission.UpdatedOn;

            contestSubmissionDto.ApiResponse = contestSubmission.ApiResponse;
            contestSubmissionDto.Selected = contestSubmission.Selected;

            return contestSubmissionDto;
        }

        [NonAction]
        private async Task SaveEndPoint(string endpointJson, int recruiterId, int contestId)
        {
            var providerWithContestId = await _contestProviderRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.ContestId == contestId);
            if (providerWithContestId != null)
            {
                var endPointList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(endpointJson, typeof(List<EndPointDto>));
                endpointJson = JsonConvert.SerializeObject(endPointList);
                providerWithContestId.Endpoint = endpointJson;
                providerWithContestId = await _contestProviderRepository.UpdateAsync(providerWithContestId);
            }
            else
            {
                var contestProviderWithoutContestId = await _contestProviderRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.ContestId == null);
                if (contestProviderWithoutContestId != null)
                {
                    var endPointList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(endpointJson, typeof(List<EndPointDto>));
                    endpointJson = JsonConvert.SerializeObject(endPointList);

                    var myDeserializedObjList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(contestProviderWithoutContestId.Endpoint, typeof(List<EndPointDto>));
                    var existingEndpoint = JsonConvert.SerializeObject(myDeserializedObjList);

                    if (existingEndpoint != endpointJson)
                    {
                        ContestProvider contestProvider = new ContestProvider();
                        contestProvider.AuxiliaryUserId = recruiterId;
                        contestProvider.Endpoint = endpointJson;
                        contestProvider.ContestId = contestId;
                        contestProvider = await _contestProviderRepository.AddAsync(contestProvider);
                    }
                }
                else
                {
                    ContestProvider contestProvider = new ContestProvider();
                    var endPointList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(endpointJson, typeof(List<EndPointDto>));
                    endpointJson = JsonConvert.SerializeObject(endPointList);
                    contestProvider.AuxiliaryUserId = recruiterId;
                    contestProvider.Endpoint = endpointJson;
                    contestProvider = await _contestProviderRepository.AddAsync(contestProvider);
                }
            }
        }

        [NonAction]
        private async Task<List<EndPointDto>> GetEndPoint(int contestId, int recruiterId)
        {
            List<EndPointDto> myDeserializedObjList = new List<EndPointDto>();
            var contestProviderWithContestId = await _contestProviderRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.ContestId == contestId);
            if (contestProviderWithContestId == null)
            {
                var contestProviderWithoutContestId = await _contestProviderRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.ContestId == null);
                if (contestProviderWithoutContestId == null)
                {
                    var specialHost = await _contestSpecialHostRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId);
                    if (specialHost != null)
                    {
                        myDeserializedObjList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(specialHost.Parameters, typeof(List<EndPointDto>));
                    }
                    else
                    {
                        myDeserializedObjList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject("[{'key': 'ENDPOINT','value': ''}]", typeof(List<EndPointDto>));
                    }
                }
                else
                {
                    myDeserializedObjList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(contestProviderWithoutContestId.Endpoint, typeof(List<EndPointDto>));
                }
            }
            else
            {
                myDeserializedObjList = (List<EndPointDto>)Newtonsoft.Json.JsonConvert.DeserializeObject(contestProviderWithContestId.Endpoint, typeof(List<EndPointDto>));
            }
            return myDeserializedObjList;
        }

        [NonAction]
        private string CreateUniqueFileName(string fileName)
        {
            int idx = fileName.LastIndexOf('.');
            //get filename
            string name = fileName.Substring(0, idx);
            //name = name.Trim().Replace(" ", string.Empty);
            name = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(name);
            //get extention
            string extenstion = fileName.Substring(idx + 1);

            return name + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "." + extenstion;
        }

        [NonAction]
        private string ApplicationAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is FileService)
            {
                return filePath.ToApplicationAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToApplicationAccessibleS3Path(baseURL, bucketName);
            }
            return filePath;
        }

        [NonAction]
        private string UserAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is Infrastructure.FileService)
            {
                return filePath.ToUserAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToUserAccessibleS3Path(bucketName, baseURL);
            }

            return filePath;
        }

        [NonAction]
        private async Task<string> UploadContest(IFormFile file, int recruiterId, ContestImages FlagContestImage, int contestId)
        {
            if (file != null && file.Length > 0)
            {
                string targetPath = _appSettings.MediaBasePath;
                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);
                string savedPath;
                if ((int)FlagContestImage == (int)ContestImages.Banner)
                {
                    savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetAuxiliaryFolder + recruiterId.ToString()), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);

                    savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);
                    return UserAccessiblePath(savedPath, _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
                }
                else
                {
                    savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetContestFolder + contestId.ToString()), _appSettings.S3BucketNameContest, _appSettings.S3BaseUrlForContest);

                    savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);
                    return UserAccessiblePath(savedPath, _appSettings.S3BucketNameContest, _appSettings.S3BaseUrlForContest);
                }

            }
            return null;
        }

        /// <summary>
        /// RemoveContestResult
        /// </summary>
        [NonAction]
        public async Task<int> DeleteContestResult(int contestSubmissionId)
        {
            var resultRank = await _contestResultRepository.FindAsync(x => x.ContestSubmissionId == contestSubmissionId);
            if (resultRank != null)
            {
                var result = await _contestResultRepository.DeleteAsync(resultRank);
                return result;
            }
            return 0;
        }

        #endregion
    }
}
