﻿using AutoMapper;
using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.Models.Report;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using FTCApi.Dtos.SpecialHost;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;
using Serilog;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class TalentController : Controller
    {
        private ITalentRepository _talentRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private ITalentTokenRepository _talentTokenRepository;
        private static IMapper _mapper;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private IEmailService _emailService;
        private ISecurityQuestionRepository _securityQuestionRepository;
        private ITalentSecurityQuestionRepository _talentSecurityQuestionRepository;
        private ITalentShareDetailRepository _talentShareDetailRepository;
        private IAuxiliaryUserTokenRepository _auxiliaryUserTokenRepository;
        private IAuxiliaryUserAddressRepository _auxiliaryUserAddressRepository;
        private AppSettings _appSettings;
        private ITalentInfoRepository _talentInfoRepository;
        private ITalentInterestCategoryRepository _talentInterestCategoryRepository;
        private IInterestCategoryRepository _interestCategoryRepository;
        private ITalentTalentCategoryRepository _talentTalentCategoryRepository;
        private ITalentCategoryRepository _talentCategoryRepository;
        private ITagCategoryRepository _tagCategoryRepository;
        private ITalentTagRepository _talentTagRepository;
        private ITagRepository _tagRepository;
        private ITierRepository _tierRepository;
        private ITalentAddressRepository _talentAddressRepository;
        private IAddressRepository _addressRepository;
        private ICountryRepository _countryRepository;
        private ICityRepository _cityRepository;
        private ITalentRatingRmarksRepository _talentRatingRmarksRepository;
        private ITalentEthnicityRepository _talentEthnicityRepository;
        private IEthnicityRepository _ethnicityRepository;
        private ITalentLanguageRepository _talentLanguageRepository;
        private ILanguageRepository _languageRepository;
        private ITalentAssociationRepository _talentAssociationRepository;
        private ITalentEducationRepository _talentEducationRepository;
        private ITalentExperienceRepository _talentExperienceRepository;
        private ITalentPhysicalAttributeRepository _talentPhysicalAttributeRepository;
        private IHeightRepository _heightRepository;
        private IWeightRepository _weightRepository;
        private IChestSizeRepository _chestSizeRepository;
        private IWaistSizeRepository _waistSizeRepository;
        private IBodyTypeRepository _bodyTypeRepository;
        private ISkinColorRepository _skinColorRepository;
        private IEyeColorRepository _eyeColorRepository;
        private IHairColorRepository _hairColorRepository;
        private IHairLengthRepository _hairLengthRepository;
        private IHairTypeRepository _hairTypeRepository;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private IJobTalentRecommendedRepository _jobTalentRecommendedRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private ITraceLoginRepository _traceLoginRepository;
        private IRecruiterInfoRepository _recruiterInfoRepository;
        private IAuxiliarySecurityQuestionRepository _auxiliarySecurityQuestionRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private ITalentStatusHistoryRepository _talentStatusHistoryRepository;
        private ITalentSpecialHostRepository _talentSpecialHostRepository;
        private IParamRepository _paramRepository;


        private const string constantActivated = "Activated";
        private const string constantWebsite = "Website";

        public TalentController(ITalentRepository talentRepository, ITalentTokenRepository talentTokenRepository, Microsoft.Extensions.Configuration.IConfiguration configuration, IEmailService emailService,
                                ISecurityQuestionRepository securityQuestionRepository, ITalentSecurityQuestionRepository talentSecurityQuestionRepository, ITalentShareDetailRepository talentShareDetailRepository,
                                IAuxiliaryUserRepository auxiliaryUserRepository, IAuxiliaryUserAddressRepository auxiliaryUserAddressRepository, INotificationDetailRepository notificationDetailRepository,
                                INotificationHeaderRepository notificationHeaderRepository, IAuxiliaryUserTokenRepository auxiliaryUserTokenRepository, ITalentInfoRepository talentInfoRepository,
                                IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository, IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository, IUserNotificationRepository userNotificationRepository,
                                IJobTalentRecommendedRepository jobTalentRecommendedRepository, ITalentInterestCategoryRepository talentInterestCategoryRepository, IInterestCategoryRepository interestCategoryRepository,
                                ITalentTalentCategoryRepository talentTalentCategoryRepository, ITalentCategoryRepository talentCategoryRepository,
                                ITagCategoryRepository tagCategoryRepository, ITalentTagRepository talentTagRepository, ITagRepository tagRepository, ITierRepository tierRepository,
                                ITalentAddressRepository talentAddressRepository, IAddressRepository addressRepository, ICountryRepository countryRepository, ICityRepository cityRepository,
                                ITalentRatingRmarksRepository talentRatingRmarksRepository, ITalentEthnicityRepository talentEthnicityRepository, IEthnicityRepository ethnicityRepository,
                                ITalentLanguageRepository talentLanguageRepository, ILanguageRepository languageRepository, ITalentAssociationRepository talentAssociationRepository,
                                ITalentEducationRepository talentEducationRepository, ITalentExperienceRepository talentExperienceRepository,
                                ITalentPhysicalAttributeRepository talentPhysicalAttributeRepository, IHeightRepository heightRepository, IWeightRepository weightRepository,
                                IChestSizeRepository chestSizeRepository, IWaistSizeRepository waistSizeRepository, IBodyTypeRepository bodyTypeRepository, ISkinColorRepository skinColorRepository,
                                IEyeColorRepository eyeColorRepository, IHairColorRepository hairColorRepository, IHairLengthRepository hairLengthRepository, IHairTypeRepository hairTypeRepository,
                                ITraceLoginRepository traceLoginRepository, IAuxiliarySecurityQuestionRepository auxiliarySecurityQuestionRepository, IRecruiterInfoRepository recruiterInfoRepository,
                                ISmsProviderRepository smsProviderRepository,
                                ITalentStatusHistoryRepository talentStatusHistoryRepository,
                                ITalentSpecialHostRepository talentSpecialHostRepository,
                                IParamRepository paramRepository)
        {
            _configuration = configuration;
            _emailService = emailService;
            _talentRepository = talentRepository;
            _talentTokenRepository = talentTokenRepository;
            _securityQuestionRepository = securityQuestionRepository;
            _talentSecurityQuestionRepository = talentSecurityQuestionRepository;
            _talentShareDetailRepository = talentShareDetailRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _auxiliaryUserTokenRepository = auxiliaryUserTokenRepository;
            _auxiliaryUserAddressRepository = auxiliaryUserAddressRepository;
            _talentInfoRepository = talentInfoRepository;
            _talentInterestCategoryRepository = talentInterestCategoryRepository;
            _interestCategoryRepository = interestCategoryRepository;
            _talentTalentCategoryRepository = talentTalentCategoryRepository;
            _talentCategoryRepository = talentCategoryRepository;
            _tagCategoryRepository = tagCategoryRepository;
            _talentTagRepository = talentTagRepository;
            _tagRepository = tagRepository;
            _tierRepository = tierRepository;
            _talentAddressRepository = talentAddressRepository;
            _addressRepository = addressRepository;
            _countryRepository = countryRepository;
            _cityRepository = cityRepository;
            _talentRatingRmarksRepository = talentRatingRmarksRepository;
            _talentEthnicityRepository = talentEthnicityRepository;
            _ethnicityRepository = ethnicityRepository;
            _talentLanguageRepository = talentLanguageRepository;
            _languageRepository = languageRepository;
            _talentAssociationRepository = talentAssociationRepository;
            _talentEducationRepository = talentEducationRepository;
            _talentExperienceRepository = talentExperienceRepository;
            _talentPhysicalAttributeRepository = talentPhysicalAttributeRepository;
            _heightRepository = heightRepository;
            _weightRepository = weightRepository;
            _chestSizeRepository = chestSizeRepository;
            _waistSizeRepository = waistSizeRepository;
            _bodyTypeRepository = bodyTypeRepository;
            _skinColorRepository = skinColorRepository;
            _eyeColorRepository = eyeColorRepository;
            _hairColorRepository = hairColorRepository;
            _hairLengthRepository = hairLengthRepository;
            _hairTypeRepository = hairTypeRepository;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _userNotificationRepository = userNotificationRepository;
            _jobTalentRecommendedRepository = jobTalentRecommendedRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _traceLoginRepository = traceLoginRepository;
            _recruiterInfoRepository = recruiterInfoRepository;
            _auxiliarySecurityQuestionRepository = auxiliarySecurityQuestionRepository;
            _talentStatusHistoryRepository = talentStatusHistoryRepository;
            _talentSpecialHostRepository = talentSpecialHostRepository;
            _paramRepository = paramRepository;
            _appSettings = new AppSettings(_configuration);
            _smsProviderRepository = smsProviderRepository;
        }

        static TalentController()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Talent, TalentDto>();
                cfg.CreateMap<TalentDto, Talent>();
                cfg.CreateMap<AuxiliaryUser, AuxiliaryUserDto>();
                cfg.CreateMap<AuxiliaryUserDto, AuxiliaryUser>();
                cfg.CreateMap<SearchParametersDto, SearchParameters>();
                cfg.CreateMap<SearchResult<Talent>, SearchResultDto<TalentDto>>();
            });
            _mapper = config.CreateMapper();
        }

        #region Commented code: Test for phonon and twilio
        private List<OtpUserData> GetSMSSingleUser()
        {
            var listOtpUserData = new List<OtpUserData>();

            var otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "jayant",
                MobileNumber = 9820955150
            };
            listOtpUserData.Add(otpUserData);

            return listOtpUserData;
        }

        private List<OtpUserData> GetLoalSMSUsers()
        {
            List<OtpUserData> listOtpUserData = new List<OtpUserData>();

            var otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Pranav",
                MobileNumber = 9821114663
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Manish",
                MobileNumber = 9820955150
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Photon Support",
                MobileNumber = 7574848669
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Ketan",
                MobileNumber = 9870053826

            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Rasheema",
                MobileNumber = 9820106940
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Koel Gupta",
                MobileNumber = 9167241295
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Zoha Shaikh",
                MobileNumber = 9867682102
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Nihir Jain",
                MobileNumber = 7045868642
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Swapnil Mishra",
                MobileNumber = 9969757696
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Kunwar Siddharth Daape",
                MobileNumber = 8433888185
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Komal Aggrawal",
                MobileNumber = 9167744850
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Varsha Singh",
                MobileNumber = 7738116266
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Jitendra Kumar",
                MobileNumber = 9466790290
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Rohit Sharma",
                MobileNumber = 9930978754
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Priyanka Jethwa ",
                MobileNumber = 8369482078
            };

            listOtpUserData.Add(otpUserData);

            return listOtpUserData;
        }

        private List<OtpUserData> GetSMSInternationUsers()
        {
            List<OtpUserData> listOtpUserData = new List<OtpUserData>();
            //International Numbers
            var otpUserData = new OtpUserData
            {
                CountryCode = "44",
                Email = "jayant.ingale@yopmail.com",
                FullName = "United Kingdom",
                MobileNumber = 7397081339
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "40",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Romania",
                MobileNumber = 701245644
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "33",
                Email = "jayant.ingale@yopmail.com",
                FullName = "France",
                MobileNumber = 752961556
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "34",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Spain",
                MobileNumber = 631752947
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "31",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Netherlands",
                MobileNumber = 626379779
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "49",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Germany",
                MobileNumber = 15255770261
            };
            listOtpUserData.Add(otpUserData);


            otpUserData = new OtpUserData
            {
                CountryCode = "1",
                Email = "jayant.ingale@yopmail.com",
                FullName = "USA",
                MobileNumber = 2028463060
            };
            listOtpUserData.Add(otpUserData);

            return listOtpUserData;
        }

        private List<OtpUserData> GetAllSMSUsers()
        {
            List<OtpUserData> listOtpUserData = new List<OtpUserData>();

            var otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Pranav",
                MobileNumber = 9821114663
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Manish",
                MobileNumber = 9820955150
            };

            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Photon Support",
                MobileNumber = 7574848669
            };

            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Ketan",
                MobileNumber = 9870053826

            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Rasheema",
                MobileNumber = 9820106940
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Koel Gupta",
                MobileNumber = 9167241295
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Zoha Shaikh",
                MobileNumber = 9867682102
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Nihir Jain",
                MobileNumber = 7045868642
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Swapnil Mishra",
                MobileNumber = 9969757696
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Kunwar Siddharth Daape",
                MobileNumber = 8433888185
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Komal Aggrawal",
                MobileNumber = 9167744850
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Varsha Singh",
                MobileNumber = 7738116266
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Jitendra Kumar",
                MobileNumber = 9466790290
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Rohit Sharma",
                MobileNumber = 9930978754
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "91",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Priyanka Jethwa ",
                MobileNumber = 8369482078
            };
            listOtpUserData.Add(otpUserData);

            //International Numbers
            otpUserData = new OtpUserData
            {
                CountryCode = "44",
                Email = "jayant.ingale@yopmail.com",
                FullName = "United Kingdom",
                MobileNumber = 7397081339
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "40",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Romania",
                MobileNumber = 701245644
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "33",
                Email = "jayant.ingale@yopmail.com",
                FullName = "France",
                MobileNumber = 752961556
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "34",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Spain",
                MobileNumber = 631752947
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "31",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Netherlands",
                MobileNumber = 626379779
            };
            listOtpUserData.Add(otpUserData);

            otpUserData = new OtpUserData
            {
                CountryCode = "49",
                Email = "jayant.ingale@yopmail.com",
                FullName = "Germany",
                MobileNumber = 15255770261
            };
            listOtpUserData.Add(otpUserData);


            otpUserData = new OtpUserData
            {
                CountryCode = "1",
                Email = "jayant.ingale@yopmail.com",
                FullName = "USA",
                MobileNumber = 2028463060
            };
            listOtpUserData.Add(otpUserData);

            return listOtpUserData;
        }


        [HttpGet]
        [Route("testbulkuser/{NoOfTimesToSendSms}/{SetName}/{sendSmsTo}")]
        public async Task<IActionResult> TestBulkSMSUSers(int NoOfTimesToSendSms, int SetName, SendSmsTo sendSmsTo)
        {

            List<OtpUserData> users = default(List<OtpUserData>);

            if (sendSmsTo == SendSmsTo.ToAllLocalUsers)
            {
                users = GetLoalSMSUsers();
            }
            else if (sendSmsTo == SendSmsTo.ToInternationalUsers)
            {
                users = GetSMSInternationUsers();
            }
            else if (sendSmsTo == SendSmsTo.ToAllUsers)
            {
                users = GetAllSMSUsers();
            }
            else
            {
                users = GetSMSSingleUser();
            }

            int loop = NoOfTimesToSendSms;
            for (int i = 1; i <= loop; i++)
            {
                var userId = 161;
                foreach (OtpUserData user in users)
                {
                    try
                    {
                        var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                        int otp = new Random().Next(100000, 999999);
                        var auxiliaryUserToken = new AuxiliaryUserToken
                        {
                            Email = Guid.NewGuid().ToString(),
                            SMS = Convert.ToString(otp),
                            AuxiliaryUserId = userId
                        };

                        if (!string.IsNullOrEmpty(user.Email))
                        {
                            var notificationParam = new NotificationParam
                            {
                                TalentId = userId,
                                Email = user.Email,
                                FullName = user.FullName,
                                MobileNumber = user.CountryCode + user.MobileNumber,
                                Otp = auxiliaryUserToken.SMS,
                                MobileCountryCode = user.CountryCode,
                                TempPrefix = "Set :" + SetName + "    " + i + " of " + loop
                            };

                            var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                            {
                                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAdmin(),
                                NotificationReference = NotificationReferenceEnum.ReferenceAuxiliaryUserId,
                                NotificationReferenceValue = userId,
                                UrlRoute = ViewNotificationEnumDto.EditRecruiter
                            };

                            await notification.SendNotification(NotificationEnum.WelcomeRecruiter, notificationParam, sendSystemNotificationDto);
                        }
                    }

                    catch (Exception ex)
                    {
                        Serilog.Log.Error("Error while initiating Send SMS :" + ex);
                    }

                }
            }
            return Ok();
        }

        [HttpGet]
        [Route("testotp")]
        public async Task<IActionResult> TestOTP()
        {
            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(c => c.EmailId == "jayant.ingale@yopmail.com");


            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            int otp = new Random().Next(100000, 999999);
            var auxiliaryUserToken = new AuxiliaryUserToken
            {
                Email = Guid.NewGuid().ToString(),
                SMS = Convert.ToString(otp),
                AuxiliaryUserId = auxiliaryUser.Id
            };

            if (!string.IsNullOrEmpty(auxiliaryUser.EmailId))
            {
                var notificationParam = new NotificationParam
                {
                    AuxiliaryUserId = auxiliaryUser.Id,
                    Email = auxiliaryUser.EmailId,
                    FullName = auxiliaryUser.FullName,
                    MobileNumber = "+91" + auxiliaryUser.Mobile,
                    Otp = auxiliaryUserToken.SMS,
                    MobileCountryCode = "+91"
                };

                var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                {
                    SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAdmin(),
                    NotificationReference = NotificationReferenceEnum.ReferenceAuxiliaryUserId,
                    NotificationReferenceValue = auxiliaryUser.Id,
                    UrlRoute = ViewNotificationEnumDto.EditRecruiter
                };

                await notification.SendNotification(NotificationEnum.WelcomeRecruiter, notificationParam, sendSystemNotificationDto);
            }
            return null;
        }
        #endregion

        #region Public Actions

        [HttpPost]
        [Route("createTalent")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> CreateTalent([FromBody]TalentDto talentDto, UserInfo userInfo)
        {
            if (talentDto == null)
            {
                return BadRequest();
            }

            talentDto.Email = (talentDto.Email != null) ? talentDto.Email.ToLower() : "";

            //To check the email and mobile number in both talent and auxiliary user table
            bool isNewUser = await IsNewUser(talentDto.Email, talentDto.Mobile);
            if (isNewUser)
            {
                Talent talent = new Talent();
                talent = ConvertToTalentModel(talentDto, talent);

                string randomPassword = RandomString(8);
                randomPassword = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(randomPassword);
                string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(randomPassword, BCrypt.Net.BCrypt.GenerateSalt());

                talent.Password = hashToStoreInDatabase;
                talent.LastTabNo = 0;
                talent.AuthToken = Guid.NewGuid().ToString();

                talent.WhatsupCountryCode = talentDto.WhatsAppCountryCode;
                talent.WhatsupMobile = talentDto.WhatsAppNumber;

                talent = await _talentRepository.AddAsync(talent);

                var talentToken = new TalentToken
                {
                    Email = !string.IsNullOrEmpty(talent.Email) ? constantActivated : string.Empty,
                    SMS = constantActivated,
                    TalentId = talent.Id,
                    LoginType = RegistrationDevice.Website.ToString()
                };
                talentToken = await _talentTokenRepository.AddAsync(talentToken);

                #region add TalentStatusHistory when admin creates a new talent
                await AddCreateTalentStatusHistory(userInfo, talent);
                #endregion

                Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                var notificationParam = new NotificationParam
                {
                    TalentId = talent.Id,
                    Email = talent.Email,
                    FullName = talent.FullName,
                    UserPassword = randomPassword,
                    DeviceOsId = talent.DeviceOsId,
                    DeviceRegistrationId = talent.DeviceRegistrationId,
                    MobileCountryCode = talent.MobileCountryCode,
                    MobileNumber = talent.Mobile
                };

                var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                await notification.SendNotification(NotificationEnum.CreateTalent, notificationParam, sendSystemNotificationDto);

                return Ok(talent);
            }
            else
            {
                return BadRequest(new { talent = "User Already Exist" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> RegisterUser([FromBody]TalentDto talentDto)
        {
            if (talentDto == null)
            {
                return BadRequest();
            }

            ResponseLoginDto responseLoginDto = new ResponseLoginDto();
            talentDto.Email = (talentDto.Email != null) ? talentDto.Email.ToLower() : "";
            bool isNewUser = await IsNewUser(talentDto.Email, talentDto.Mobile);
            if (isNewUser)
            {
                Talent talent = new Talent();
                talent = ConvertToTalentModel(talentDto, talent);

                string pwdToHash = talent.Password;
                string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(pwdToHash, BCrypt.Net.BCrypt.GenerateSalt());
                talent.Password = hashToStoreInDatabase;
                talent.LastTabNo = 0;
                talent.AuthToken = Guid.NewGuid().ToString();

                //as the model name is different from DTO
                talent.WhatsupCountryCode = talentDto.WhatsAppCountryCode;
                talent.WhatsupMobile = talentDto.WhatsAppNumber;

                talent = await _talentRepository.AddAsync(talent);


                TalentToken talentToken = new TalentToken();
                var emailVerificationCode = Guid.NewGuid().ToString();
                talentToken.Email = emailVerificationCode;
                talentToken.Email1 = emailVerificationCode;             // add same GUID in both columns
                talentToken.TalentId = talent.Id;

                if (talentDto.DeviceOsId == (int)DeviceOsEnum.iOS)
                {
                    talentToken.LoginType = RegistrationDevice.iOS.ToString();
                }
                else if (talentDto.DeviceOsId == (int)DeviceOsEnum.Android)
                {
                    talentToken.LoginType = RegistrationDevice.Android.ToString();
                }
                else
                {
                    talentToken.LoginType = RegistrationDevice.Website.ToString();
                }

                talentToken = await _talentTokenRepository.AddAsync(talentToken);
                if (!string.IsNullOrEmpty(talent.Email))
                {
                    Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                    var notificationParam = new NotificationParam
                    {
                        TalentId = talent.Id,
                        Email = talent.Email,
                        FullName = talent.FullName,
                        UniqueId = talentToken.Email,
                        DeviceOsId = talent.DeviceOsId,
                        DeviceRegistrationId = talent.DeviceRegistrationId
                    };

                    var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                    await notification.SendNotification(NotificationEnum.WelcomeTalent, notificationParam, sendSystemNotificationDto);
                }

                responseLoginDto.AuthToken = talent.AuthToken;
                responseLoginDto.LastTabNo = 0;
                responseLoginDto.OnBoarded = false;
                responseLoginDto.TermsConditionAccepted = talent.TermsConditionAccepted;
                responseLoginDto.FullName = talent.FullName;
                responseLoginDto.IsNewUser = true;

                await SendUserSettings(responseLoginDto);

                return Ok(responseLoginDto);

            }
            else
            {
                return BadRequest(new { talent = "User Already Exist" });
            }

        }

        [Route("registerauxiliaryuser")]
        [HttpPost]
        public async Task<IActionResult> RegisterAuxiliaryUser([FromBody]AuxiliaryUserDto auxiliaryUserDto)
        {
            if (auxiliaryUserDto == null)
            {
                return BadRequest();
            }

            ResponseLoginDto responseLoginDto = new ResponseLoginDto();
            auxiliaryUserDto.EmailId = auxiliaryUserDto.EmailId.ToLower();
            //To check the email and mobile number in both talent and auxiliary user table

            bool isNewUser = await IsNewUser(auxiliaryUserDto.EmailId, auxiliaryUserDto.Mobile);

            if (isNewUser)
            {
                AuxiliaryUser auxiliaryUser = new AuxiliaryUser();
                auxiliaryUser = ConvertToAuxiliaryUserModel(auxiliaryUserDto, auxiliaryUser);

                string pwdToHash = auxiliaryUser.Password;
                string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(pwdToHash, BCrypt.Net.BCrypt.GenerateSalt());
                auxiliaryUser.Password = hashToStoreInDatabase;
                auxiliaryUser.AuthToken = Guid.NewGuid().ToString();
                auxiliaryUser = await _auxiliaryUserRepository.AddAsync(auxiliaryUser);

                //store address

                Address address = new Address();
                address.Line1 = auxiliaryUserDto.Line1;
                address.Line2 = auxiliaryUserDto.Line2;
                await _recruiterInfoRepository.GetAuxilaryUserCityCountryId(auxiliaryUserDto, address);

                address = await _addressRepository.AddAsync(address);

                AuxiliaryUserAddress auxiliaryUserAddress = new AuxiliaryUserAddress();
                auxiliaryUserAddress.AuxiliaryUserId = auxiliaryUser.Id;
                auxiliaryUserAddress.AddressId = address.Id;
                auxiliaryUserAddress = await _auxiliaryUserAddressRepository.AddAsync(auxiliaryUserAddress);

                int otp = new Random().Next(100000, 999999);
                AuxiliaryUserToken auxiliaryUserToken = new AuxiliaryUserToken();
                var emailVerificationCode = Guid.NewGuid().ToString();
                auxiliaryUserToken.Email = emailVerificationCode;
                auxiliaryUserToken.Email1 = emailVerificationCode;
                var smsVerificationOtp = Convert.ToString(otp);
                auxiliaryUserToken.SMS = smsVerificationOtp;
                auxiliaryUserToken.Mobile1 = smsVerificationOtp;
                auxiliaryUserToken.AuxiliaryUserId = auxiliaryUser.Id;
                auxiliaryUserToken = await _auxiliaryUserTokenRepository.AddAsync(auxiliaryUserToken);

                var auxiliaryUserRole = new AuxiliaryUserRole();
                auxiliaryUserRole.AuxiliaryUserId = auxiliaryUser.Id;
                auxiliaryUserRole.RoleId = (int)AuxiliaryUserRoleEnum.Recruiter;
                auxiliaryUserRole = await _auxiliaryUserRoleRepository.AddAsync(auxiliaryUserRole);

                Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);


                if (!string.IsNullOrEmpty(auxiliaryUser.EmailId))
                {
                    var notificationParam = new NotificationParam
                    {
                        AuxiliaryUserId = auxiliaryUser.Id,
                        Email = auxiliaryUser.EmailId,
                        FullName = auxiliaryUser.FullName,
                        UniqueId = auxiliaryUserToken.Email,
                        MobileCountryCode = auxiliaryUser.MobileCountryCode,
                        MobileNumber = auxiliaryUser.Mobile,
                        Otp = auxiliaryUserToken.SMS,
                    };

                    var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                    {
                        SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAdmin(),
                        NotificationReference = NotificationReferenceEnum.ReferenceAuxiliaryUserId,
                        NotificationReferenceValue = auxiliaryUser.Id,
                        UrlRoute = ViewNotificationEnumDto.EditRecruiter
                    };
                    // Welcome Notification to Recruiter
                    await notification.SendNotification(NotificationEnum.WelcomeRecruiter, notificationParam, sendSystemNotificationDto);

                    // Send EMAIL AND SMS to  Su,Sys Admin when a new recruiter registers                    
                    var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                    sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                    // list with params to send sms
                    notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                    {
                        AuxiliaryUserId = x.Id,
                        MobileCountryCode = x.MobileCountryCode,
                        MobileNumber = x.Mobile
                    }).ToList();

                    notificationParam.Email = string.Empty;                 // remove recriuter's email 
                    notificationParam.MobileNumber = string.Empty;          // remove recriuter's number 

                    await notification.SendNotification(NotificationEnum.RecruiterRegistration, notificationParam, sendSystemNotificationDto);
                }

                responseLoginDto.lstAuxiliaryUserRoleEnum = new List<string> { AuxiliaryUserRoleEnum.Recruiter.ToString() };

                responseLoginDto.AuthToken = auxiliaryUser.AuthToken;
                responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                responseLoginDto.LastTabNo = 0;
                responseLoginDto.OnBoarded = false;
                responseLoginDto.FullName = auxiliaryUser.FullName;
                responseLoginDto.IsNewUser = true;
                return Ok(responseLoginDto);
            }
            else
            {
                return BadRequest(new { talent = "Recruiter Already Exist" });
            }

        }

        [HttpPut]
        public async Task<IActionResult> UpdateUser([FromBody]TalentDto talentDto)
        {
            if (talentDto == null)
            {
                return BadRequest();
            }

            var talent = await _talentRepository.FindAsync(x => x.Id == talentDto.Id);
            if (talent == null)
            {
                return NotFound();
            }

            talent = _mapper.Map<TalentDto, Talent>(talentDto);

            string pwdToHash = talent.Password;
            string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(pwdToHash, BCrypt.Net.BCrypt.GenerateSalt());
            talent.Password = hashToStoreInDatabase;
            talent = await _talentRepository.UpdateAsync(talent);
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam
            {
                Email = talent.Email,
                FullName = talent.FullName,
                UniqueId = talentToken.Email,
                TalentId = talent.Id,
                DeviceOsId = talent.DeviceOsId,
                DeviceRegistrationId = talent.DeviceRegistrationId
            };

            if (!string.IsNullOrEmpty(talent.Email))
            {

                var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                await notification.SendNotification(NotificationEnum.WelcomeTalent, notificationParam, sendSystemNotificationDto);
            }
            string newOTP = GenerateOTP();


            await SendOtpAsync(talent.MobileCountryCode, talent.Mobile, newOTP, NotificationEnum.WelcomeTalent, notification, notificationParam);

            return Json(talent);

        }

        [HttpPost]
        [Route("activateemailaccount")]
        public async Task<IActionResult> ActivateEmailAccount([FromBody]GUIDDto guidDto)
        {
            if (string.IsNullOrEmpty(guidDto.guid))
            {
                return BadRequest();
            }

            var talentToken = await _talentTokenRepository.FindAsync(x => x.Email == guidDto.guid);
            if (talentToken != null)
            {
                talentToken.Email = constantActivated;
                talentToken = await _talentTokenRepository.UpdateAsync(talentToken);
                return Ok(new { activated = "true" });
            }
            else
            {
                var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.Email == guidDto.guid);

                if (auxiliaryUserToken != null)
                {
                    auxiliaryUserToken.Email = constantActivated;
                    auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);
                    return Ok(new { activated = "true" });
                }
                else
                {
                    return BadRequest(new
                    {
                        activated = "Invalid link"
                    });
                }

            }

        }

        [HttpPost]
        [Route("validateuser")]
        public async Task<IActionResult> TokenUser([FromBody]TalentDto talentDto)
        {
            if ((string.IsNullOrEmpty(talentDto.Email) && string.IsNullOrEmpty(talentDto.Mobile)/* && talentDto.UID > 0*/) || string.IsNullOrEmpty(talentDto.Password))
            {
                return BadRequest();
            }
            else
            {
                LogInformationAsWarning("Login Email Id: " + talentDto.Email);
                LogInformationAsWarning("Login Mobile No: " + talentDto.Mobile);

                ResponseLoginDto responseLoginDto = new ResponseLoginDto();
                talentDto.Email = talentDto.Email.ToLower();
                if (!string.IsNullOrEmpty(talentDto.Email))
                {
                    var talentByEmailId = await _talentRepository.FindAsync(x => x.Email.ToLower() == talentDto.Email);
                    if (talentByEmailId == null)
                    {
                        #region Email - user is a recruiter
                        var auxiliaryUserByEmailId = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == talentDto.Email);
                        var parentAuxiliaryUser = new AuxiliaryUser();
                        if (auxiliaryUserByEmailId == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Emaildoesnotexist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        if (auxiliaryUserByEmailId.ParentAuxiliaryUserId != null)
                        {
                            parentAuxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUserByEmailId.ParentAuxiliaryUserId);
                        }
                        if (parentAuxiliaryUser == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.ParentUserDoesNotExist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        if (auxiliaryUserByEmailId.StatusId == (int)StatusEnum.InActive || parentAuxiliaryUser.StatusId == (int)StatusEnum.InActive)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.UserIsInActive, LoginEnum.Validation.Error);
                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                            return BadRequest(responseLoginDto);
                        }
                        else if (auxiliaryUserByEmailId.StatusId == (int)StatusEnum.Blocked || parentAuxiliaryUser.StatusId == (int)StatusEnum.Blocked)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.UserIsBlocked, LoginEnum.Validation.Error);
                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                            return BadRequest(responseLoginDto);
                        }
                        else
                        {
                            var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUserByEmailId.Id);
                            bool isAuthenticated = _auxiliaryUserRepository.ValidateUser(talentDto.Password, auxiliaryUserByEmailId.Password);
                            if (isAuthenticated)
                            {
                                responseLoginDto.FullName = auxiliaryUserByEmailId.FullName;
                                if (auxiliaryUserToken.Email == constantActivated)
                                {
                                    auxiliaryUserByEmailId.AuthToken = Guid.NewGuid().ToString();
                                    auxiliaryUserByEmailId = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUserByEmailId);

                                    if (auxiliaryUserToken.SMS == constantActivated)
                                    {

                                        // In case Recruiter is logged in from Admin Screen
                                        if ((int)(LoginUserType)auxiliaryUserByEmailId.TypeId == (int)LoginUserType.Recruiter && talentDto.IsAdmin)
                                        {
                                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Emaildoesnotexist, LoginEnum.Validation.Error);
                                            responseLoginDto.isOtpVerified = (auxiliaryUserToken.SMS == constantActivated) ? true : false;
                                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;

                                            return BadRequest(responseLoginDto);
                                        }

                                        LogInformationAsWarning("Logged in AuxiliaryUserId: " + auxiliaryUserByEmailId.Id);

                                        // GET ROLES for the logged in USER & IF any parent is present
                                        var lstAuxiliaryUserRole = await _auxiliaryUserRoleRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryUserByEmailId.Id);
                                        if (lstAuxiliaryUserRole != null)
                                        {
                                            responseLoginDto.lstAuxiliaryUserRoleEnum = lstAuxiliaryUserRole.Select(x => ((AuxiliaryUserRoleEnum)x.RoleId).ToString()).ToList();
                                        }

                                        responseLoginDto.ParentAuxiliaryUser = auxiliaryUserByEmailId.ParentAuxiliaryUserId;
                                        responseLoginDto = ResponseLoginDtoForAuxiliaryUserSuccess(LoginEnum.LoginType.Email, responseLoginDto, auxiliaryUserByEmailId, auxiliaryUserToken, talentDto.IsAdmin);
                                        return Ok(responseLoginDto);
                                    }
                                    // if email is verified and mobile is not ... give error to redirect it to login screen
                                    else
                                    {
                                        responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.SMSisnotverified, LoginEnum.Validation.Error);
                                        responseLoginDto.isOtpVerified = (auxiliaryUserToken.SMS == constantActivated) ? true : false;
                                        responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                                        return BadRequest(responseLoginDto);
                                    }
                                }
                                else
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Emailisnotverified, LoginEnum.Validation.Error);
                                    responseLoginDto.isOtpVerified = (auxiliaryUserToken.SMS == constantActivated) ? true : false;
                                    responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;

                                    return BadRequest(responseLoginDto);
                                }
                            }
                            else
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.InvalidPassword, LoginEnum.Validation.Error);
                                return BadRequest(responseLoginDto);
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        #region Email - user is a Talent

                        if (talentByEmailId.StatusId == (int)StatusEnum.InActive)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.UserIsInActive, LoginEnum.Validation.Error);
                            return BadRequest(responseLoginDto);
                        }
                        else if (talentByEmailId.StatusId == (int)StatusEnum.Blocked)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.UserIsBlocked, LoginEnum.Validation.Error);
                            return BadRequest(responseLoginDto);
                        }
                        else if (string.IsNullOrEmpty(talentByEmailId.Password))
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.PasswordDoesNotExist, LoginEnum.Validation.Error);
                            LogInformationAsWarning("No Password found for TalentId: " + talentByEmailId.Id);
                            return BadRequest(responseLoginDto);
                        }
                        else
                        {
                            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentByEmailId.Id);
                            bool isAuthenticated = _talentRepository.ValidateUser(talentDto.Password, talentByEmailId.Password);
                            if (isAuthenticated && !talentDto.IsAdmin)
                            {
                                responseLoginDto.FullName = talentByEmailId.FullName;
                                if (talentToken.Email == constantActivated)
                                {
                                    talentByEmailId.AuthToken = Guid.NewGuid().ToString();

                                    LogInformationAsWarning("Logged in TalentId: " + talentByEmailId.Id);

                                    // save device id  & Registration Id
                                    talentByEmailId.DeviceOsId = talentDto.DeviceOsId;
                                    talentByEmailId.DeviceRegistrationId = talentDto.DeviceRegistrationId;

                                    talentByEmailId = await _talentRepository.UpdateAsync(talentByEmailId);
                                    responseLoginDto.isOtpVerified = (talentToken.SMS == constantActivated) ? true : false;
                                    responseLoginDto = await ResponseLoginDtoForTalentSuccess(LoginEnum.LoginType.Email, responseLoginDto, talentByEmailId);
                                    return Ok(responseLoginDto);
                                }
                                else
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Emailisnotverified, LoginEnum.Validation.Error);
                                    return BadRequest(responseLoginDto);
                                }
                            }
                            else
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.InvalidPassword, LoginEnum.Validation.Error);
                                return BadRequest(responseLoginDto);
                            }
                        }
                        #endregion
                    }
                }
                else if (!string.IsNullOrEmpty(talentDto.Mobile))
                {
                    var talentByMobile = await _talentRepository.FindAsync(x => x.Mobile == talentDto.Mobile);
                    if (talentByMobile == null)
                    {
                        #region Mobile - user is a recruiter
                        var auxiliaryUserByMobile = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == talentDto.Mobile);
                        var parentAuxiliaryUserMobile = new AuxiliaryUser();
                        if (auxiliaryUserByMobile == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Mobiledoesnotexist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        if (auxiliaryUserByMobile.ParentAuxiliaryUserId != null)
                        {
                            parentAuxiliaryUserMobile = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUserByMobile.ParentAuxiliaryUserId);
                        }
                        if (parentAuxiliaryUserMobile == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.ParentUserDoesNotExist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        if (auxiliaryUserByMobile.StatusId == (int)StatusEnum.InActive || parentAuxiliaryUserMobile.StatusId == (int)StatusEnum.InActive)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.UserIsInActive, LoginEnum.Validation.Error);
                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                            return BadRequest(responseLoginDto);
                        }
                        else if (auxiliaryUserByMobile.StatusId == (int)StatusEnum.Blocked || parentAuxiliaryUserMobile.StatusId == (int)StatusEnum.Blocked)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.UserIsBlocked, LoginEnum.Validation.Error);
                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                            return BadRequest(responseLoginDto);
                        }
                        else
                        {
                            var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUserByMobile.Id);
                            bool isAuthenticated = _auxiliaryUserRepository.ValidateUser(talentDto.Password, auxiliaryUserByMobile.Password);
                            if (isAuthenticated)
                            {
                                responseLoginDto.FullName = auxiliaryUserByMobile.FullName;
                                if (auxiliaryUserToken.SMS == constantActivated)
                                {
                                    auxiliaryUserByMobile.AuthToken = Guid.NewGuid().ToString();
                                    auxiliaryUserByMobile = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUserByMobile);
                                    responseLoginDto = ResponseLoginDtoForAuxiliaryUserSuccess(LoginEnum.LoginType.Mobile, responseLoginDto, auxiliaryUserByMobile, auxiliaryUserToken, talentDto.IsAdmin);

                                    // GET ROLES for the logged in USER & IF any parent is present
                                    var lstAuxiliaryUserRole = await _auxiliaryUserRoleRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryUserByMobile.Id);
                                    if (lstAuxiliaryUserRole != null)
                                    {
                                        responseLoginDto.lstAuxiliaryUserRoleEnum = lstAuxiliaryUserRole.Select(x => ((AuxiliaryUserRoleEnum)x.RoleId).ToString()).ToList();
                                    }

                                    responseLoginDto.ParentAuxiliaryUser = auxiliaryUserByMobile.ParentAuxiliaryUserId;

                                    LogInformationAsWarning("Logged in AuxiliaryUserId: " + auxiliaryUserByMobile.Id);

                                    return Ok(responseLoginDto);
                                }
                                else
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.SMSisnotverified, LoginEnum.Validation.Error);
                                    responseLoginDto.isOtpVerified = false;
                                    responseLoginDto.TermsConditionAccepted = auxiliaryUserByMobile.TermsConditionAccepted;
                                    responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUserByMobile.TypeId;
                                    responseLoginDto.AuthToken = auxiliaryUserByMobile.AuthToken;

                                    LogInformationAsWarning("Logged in AuxiliaryUserId: " + auxiliaryUserByMobile.Id);

                                    return Ok(responseLoginDto);
                                }
                            }
                            else
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.InvalidPassword, LoginEnum.Validation.Error);
                                return BadRequest(responseLoginDto);
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        #region Mobile - User is a Talent

                        if (talentByMobile.StatusId == (int)StatusEnum.InActive)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.UserIsInActive, LoginEnum.Validation.Error);
                            return BadRequest(responseLoginDto);
                        }
                        else if (talentByMobile.StatusId == (int)StatusEnum.Blocked)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.UserIsBlocked, LoginEnum.Validation.Error);
                            return BadRequest(responseLoginDto);
                        }
                        else if (string.IsNullOrEmpty(talentByMobile.Password))
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.PasswordDoesNotExist, LoginEnum.Validation.Error);
                            LogInformationAsWarning("No Password found for TalentId: " + talentByMobile.Id);
                            return BadRequest(responseLoginDto);
                        }
                        else
                        {
                            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentByMobile.Id);
                            bool isAuthenticated = _talentRepository.ValidateUser(talentDto.Password, talentByMobile.Password);

                            if (isAuthenticated && !talentDto.IsAdmin)
                            {
                                responseLoginDto.FullName = talentByMobile.FullName;
                                if (talentToken.SMS == constantActivated)
                                {
                                    talentByMobile.AuthToken = Guid.NewGuid().ToString();

                                    // save device id  & Registration Id
                                    talentByMobile.DeviceOsId = talentDto.DeviceOsId;
                                    talentByMobile.DeviceRegistrationId = talentDto.DeviceRegistrationId;
                                    talentByMobile = await _talentRepository.UpdateAsync(talentByMobile);
                                    responseLoginDto.isOtpVerified = (talentToken.SMS == constantActivated) ? true : false;
                                    responseLoginDto = await ResponseLoginDtoForTalentSuccess(LoginEnum.LoginType.Mobile, responseLoginDto, talentByMobile);

                                    LogInformationAsWarning("Logged in TalentId: " + talentByMobile.Id);

                                    return Ok(responseLoginDto);
                                }
                                else
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.SMSisnotverified, LoginEnum.Validation.Success);
                                    responseLoginDto.AuthToken = talentByMobile.AuthToken;
                                    responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                    responseLoginDto.TermsConditionAccepted = talentByMobile.TermsConditionAccepted;
                                    responseLoginDto.OnBoarded = talentByMobile.Onboarded;
                                    responseLoginDto.LastTabNo = talentByMobile.LastTabNo;
                                    responseLoginDto.isOtpVerified = (talentToken.SMS == constantActivated) ? true : false;
                                    responseLoginDto.UID = talentByMobile.UID;

                                    await SendUserSettings(responseLoginDto);

                                    LogInformationAsWarning("Logged in TalentId: " + talentByMobile.Id);

                                    return Ok(responseLoginDto);
                                }
                            }
                            else
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.InvalidPassword, LoginEnum.Validation.Error);
                                return BadRequest(responseLoginDto);
                            }
                        }
                        #endregion
                    }
                }
                else
                {
                    #region UID - user is talent
                    var talentByUID = await _talentRepository.FindAsync(x => x.UID == talentDto.UID);
                    if (talentByUID == null)
                    {
                        responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.UID, responseLoginDto, LoginEnum.Message.UIDdoesnotexist, LoginEnum.Validation.Error);
                        return NotFound(responseLoginDto);
                    }
                    else
                    {
                        bool isAuthenticated = _talentRepository.ValidateUser(talentDto.Password, talentByUID.Password);
                        if (isAuthenticated)
                        {
                            responseLoginDto.FullName = talentByUID.FullName;
                            talentByUID.AuthToken = Guid.NewGuid().ToString();

                            // save device id  & Registration Id
                            talentByUID.DeviceOsId = talentDto.DeviceOsId;
                            talentByUID.DeviceRegistrationId = talentDto.DeviceRegistrationId;
                            talentByUID = await _talentRepository.UpdateAsync(talentByUID);

                            responseLoginDto = await ResponseLoginDtoForTalentSuccess(LoginEnum.LoginType.UID, responseLoginDto, talentByUID);

                            LogInformationAsWarning("Logged in TalentId: " + talentByUID.Id);

                            return Ok(responseLoginDto);
                        }
                        else
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.UID, responseLoginDto, LoginEnum.Message.InvalidPassword, LoginEnum.Validation.Error);
                            return BadRequest(responseLoginDto);
                        }
                    }
                    #endregion
                }
            }
        }

        /// <summary>
        /// forgeto
        /// </summary>
        /// <param name="forgetPasswordDto">Forget pass</param>
        /// <remarks>Awesome</remarks>        
        /// <returns>1</returns>
        ///  <returns>2</returns>
        [HttpPost]
        [Route("forgetpassword")]
        public async Task<IActionResult> ForgetPassword([FromBody] ForgetPasswordDto forgetPasswordDto)
        {
            ResponseLoginDto responseLoginDto = new ResponseLoginDto();

            #region Security Type - OTP
            if (forgetPasswordDto.SecurityType == LoginEnum.SecurityType.OTP)
            {
                if (string.IsNullOrEmpty(forgetPasswordDto.Email) && string.IsNullOrEmpty(forgetPasswordDto.Mobile))
                {
                    return BadRequest();
                }
                if (!string.IsNullOrEmpty(forgetPasswordDto.Email))
                {
                    forgetPasswordDto.Email = forgetPasswordDto.Email.ToLower();
                    var talent = await _talentRepository.FindAsync(x => x.Email.ToLower() == forgetPasswordDto.Email);

                    if (talent == null)
                    {
                        #region Auxiliary User - Email
                        var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == forgetPasswordDto.Email);
                        if (auxiliaryUser == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Emaildoesnotexist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        else
                        {
                            string newOTP = GenerateOTP();
                            var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);
                            auxiliaryUserToken.Email1 = newOTP;
                            auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);
                            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);


                            var notificationParam = new NotificationParam
                            {
                                Email = forgetPasswordDto.Email,
                                Otp = newOTP,
                                AuxiliaryUserId = auxiliaryUser.Id
                            };

                            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                            await notification.SendNotification(NotificationEnum.ResetPasswordRecruiter, notificationParam, sendSystemNotificationDto);

                            responseLoginDto.ValidateForgotPassword = LoginEnum.Validation.Success;
                            responseLoginDto.Login = LoginEnum.LoginType.Email;
                            //responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                            responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                            responseLoginDto.TermsConditionAccepted = auxiliaryUser.TermsConditionAccepted;
                            return Ok(responseLoginDto);
                        }
                        #endregion Auxiliary User
                    }
                    else
                    {
                        var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);

                        // When talent tries to use socail Login email for forget password, don't allow
                        if (talentToken.LoginType.ToLower() != RegistrationDevice.Website.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.Android.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.iOS.ToString().ToLower())
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.RegisteredWithSocialLogin, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }


                        string newOTP = GenerateOTP();
                        talentToken.Email1 = newOTP;
                        talentToken = await _talentTokenRepository.UpdateAsync(talentToken);

                        #region Send Notification
                        Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                        NotificationParam notificationParam = new NotificationParam();
                        notificationParam.Email = forgetPasswordDto.Email;
                        notificationParam.Otp = newOTP;
                        notificationParam.TalentId = talent.Id;

                        var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                        await notification.SendNotification(NotificationEnum.ResetPasswordTalent, notificationParam, sendSystemNotificationDto);
                        #endregion

                        responseLoginDto.ValidateForgotPassword = LoginEnum.Validation.Success;
                        responseLoginDto.Login = LoginEnum.LoginType.Email;
                        responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                        return Ok(responseLoginDto);
                    }
                }
                else
                {
                    var talent = await _talentRepository.FindAsync(x => x.Mobile == forgetPasswordDto.Mobile);

                    if (talent == null)
                    {
                        #region Auxiliary User - Mobile
                        var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == forgetPasswordDto.Mobile);
                        if (auxiliaryUser == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Mobiledoesnotexist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        else
                        {
                            string newOTP = GenerateOTP();
                            var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);
                            auxiliaryUserToken.Mobile1 = newOTP;
                            auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);


                            //string OTPMessage = "Dear User, " + Environment.NewLine + newOTP + "  is your One time Password(OTP) " + Environment.NewLine + "Regards," + Environment.NewLine + "Team FTC";
                            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                            var notificationParam = new NotificationParam();
                            notificationParam.AuxiliaryUserId = auxiliaryUser.Id;


                            await SendOtpAsync(auxiliaryUser.MobileCountryCode, auxiliaryUser.Mobile, newOTP, NotificationEnum.ResetPasswordRecruiter, notification, notificationParam);


                            //await SendSmsAsync("91" + auxiliaryUser.Mobile, "Your OTP is " + newOTP);
                            responseLoginDto.ValidateForgotPassword = LoginEnum.Validation.Success;
                            responseLoginDto.Login = LoginEnum.LoginType.Mobile;
                            //responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Recruiter;
                            responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                            responseLoginDto.TermsConditionAccepted = auxiliaryUser.TermsConditionAccepted;
                            return Ok(responseLoginDto);
                        }
                        #endregion Auxiliary User
                    }
                    else
                    {

                        var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);

                        // When talent tries to use socail Login mobile for forget password, don't allow
                        if (talentToken.LoginType.ToLower() != RegistrationDevice.Website.ToString().ToLower()
                             && talentToken.LoginType.ToLower() != RegistrationDevice.Android.ToString().ToLower()
                             && talentToken.LoginType.ToLower() != RegistrationDevice.iOS.ToString().ToLower())
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.RegisteredWithSocialLogin, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }

                        string newOTP = GenerateOTP();
                        talentToken.Mobile1 = newOTP;
                        talentToken = await _talentTokenRepository.UpdateAsync(talentToken);


                        Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                        NotificationParam notificationParam = new NotificationParam
                        {
                            TalentId = talent.Id,
                            DeviceOsId = talent.DeviceOsId,
                            DeviceRegistrationId = talent.DeviceRegistrationId
                        };

                        await SendOtpAsync(talent.MobileCountryCode, talent.Mobile, newOTP, NotificationEnum.ResetPasswordTalent, notification, notificationParam);

                        responseLoginDto.ValidateForgotPassword = LoginEnum.Validation.Success;
                        responseLoginDto.Login = LoginEnum.LoginType.Mobile;
                        responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                        return Ok(responseLoginDto);
                    }
                }
            }
            #endregion

            #region Security Type  - SecurityQuestion
            else
            {
                if (string.IsNullOrEmpty(forgetPasswordDto.SecurityAnswer))
                {
                    return BadRequest();
                }
                if (!string.IsNullOrEmpty(forgetPasswordDto.Email))
                {
                    var talent = await _talentRepository.FindAsync(x => x.Email.ToLower() == forgetPasswordDto.Email.ToLower());
                    //TODO: remove the common code (related to security question answer checking)in all cases in a new method
                    if (talent == null)
                    {
                        #region Auxiliary User Security question - Email

                        var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == forgetPasswordDto.Email.ToLower());
                        if (auxiliaryUser != null)
                        {
                            var securityQuestion = await _securityQuestionRepository.FindAsync(x => x.Id == forgetPasswordDto.SecurityQuestion);
                            if (securityQuestion == null)
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Questionnotfound, LoginEnum.Validation.Error);
                                responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                return BadRequest(responseLoginDto);
                            }
                            else
                            {
                                var auxiliarySecurityQuestion = await _auxiliarySecurityQuestionRepository.FindAsync(x => x.SecurityQuestionId == securityQuestion.Id && x.AuxiliaryUserId == auxiliaryUser.Id);
                                if (auxiliarySecurityQuestion == null)
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Usernotansweredthequestion, LoginEnum.Validation.Error);
                                    responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                    return NotFound(responseLoginDto);
                                }
                                else
                                {
                                    if (auxiliarySecurityQuestion.Answer.ToLower() == forgetPasswordDto.SecurityAnswer.ToLower())
                                    {
                                        responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Answeriscorrect, LoginEnum.Validation.Success);
                                        responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                        return Ok(responseLoginDto);
                                    }
                                    else
                                    {
                                        responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Answeriswrong, LoginEnum.Validation.Error);
                                        responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                        return BadRequest(responseLoginDto);
                                    }
                                }
                            }
                        }
                        else
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Emaildoesnotexist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }

                        #endregion
                    }
                    else
                    {
                        #region Check if the user is registered with social login
                        // When talent tries to use socail Login email for forget password, don't allow

                        var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);
                        if (talentToken != null)
                        {
                            if (talentToken.LoginType.ToLower() != RegistrationDevice.Website.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.Android.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.iOS.ToString().ToLower())
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.RegisteredWithSocialLogin, LoginEnum.Validation.Error);
                                return NotFound(responseLoginDto);
                            }
                        }
                        #endregion

                        #region Talent Security Question - email
                        var securityQuestion = await _securityQuestionRepository.FindAsync(x => x.Id == forgetPasswordDto.SecurityQuestion);
                        if (securityQuestion == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Questionnotfound, LoginEnum.Validation.Error);
                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                            return BadRequest(responseLoginDto);
                        }
                        else
                        {
                            var talentSecurityQuestion = await _talentSecurityQuestionRepository.FindAsync(x => x.SecurityQuestionId == securityQuestion.Id && x.TalentId == talent.Id);
                            if (talentSecurityQuestion == null)
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Usernotansweredthequestion, LoginEnum.Validation.Error);
                                responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                return NotFound(responseLoginDto);
                            }
                            else
                            {
                                if (talentSecurityQuestion.Answer.ToLower() == forgetPasswordDto.SecurityAnswer.ToLower())
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Answeriscorrect, LoginEnum.Validation.Success);
                                    responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                    return Ok(responseLoginDto);
                                }
                                else
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.Answeriswrong, LoginEnum.Validation.Error);
                                    responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                    return BadRequest(responseLoginDto);
                                }
                            }
                        }
                        #endregion
                    }
                }
                else
                {
                    var talent = await _talentRepository.FindAsync(x => x.Mobile == forgetPasswordDto.Mobile);

                    if (talent == null)
                    {
                        #region Auxiliary User Security Question - Mobile
                        var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == forgetPasswordDto.Mobile);

                        if (auxiliaryUser != null)
                        {
                            var securityQuestion = await _securityQuestionRepository.FindAsync(x => x.Id == forgetPasswordDto.SecurityQuestion);
                            if (securityQuestion == null)
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Questionnotfound, LoginEnum.Validation.Error);
                                responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                return BadRequest(responseLoginDto);
                            }
                            else
                            {
                                var auxiliarySecurityQuestion = await _auxiliarySecurityQuestionRepository.FindAsync(x => x.SecurityQuestionId == securityQuestion.Id && x.AuxiliaryUserId == auxiliaryUser.Id);
                                if (auxiliarySecurityQuestion == null)
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Usernotansweredthequestion, LoginEnum.Validation.Error);
                                    responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                    return NotFound(responseLoginDto);
                                }
                                else
                                {
                                    if (auxiliarySecurityQuestion.Answer.ToLower() == forgetPasswordDto.SecurityAnswer.ToLower())
                                    {
                                        responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Answeriscorrect, LoginEnum.Validation.Success);
                                        responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                        return Ok(responseLoginDto);
                                    }
                                    else
                                    {
                                        responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Answeriswrong, LoginEnum.Validation.Error);
                                        responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
                                        return BadRequest(responseLoginDto);
                                    }
                                }
                            }
                        }
                        else
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Mobiledoesnotexist, LoginEnum.Validation.Error);
                            return NotFound(responseLoginDto);
                        }
                        #endregion
                    }
                    else
                    {
                        #region Check if the user is registered with social login
                        // When talent tries to use socail Login email for forget password, don't allow

                        var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);
                        if (talentToken != null)
                        {
                            if (talentToken.LoginType.ToLower() != RegistrationDevice.Website.ToString().ToLower()
                                && talentToken.LoginType.ToLower() != RegistrationDevice.Android.ToString().ToLower()
                                && talentToken.LoginType.ToLower() != RegistrationDevice.iOS.ToString().ToLower())
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.RegisteredWithSocialLogin, LoginEnum.Validation.Error);
                                return NotFound(responseLoginDto);
                            }
                        }
                        #endregion

                        #region Talent Security Question - Mobile
                        var securityQuestion = await _securityQuestionRepository.FindAsync(x => x.Id == forgetPasswordDto.SecurityQuestion);
                        if (securityQuestion == null)
                        {
                            responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Questionnotfound, LoginEnum.Validation.Error);
                            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                            return BadRequest(responseLoginDto);
                        }
                        else
                        {
                            var talentSecurityQuestion = await _talentSecurityQuestionRepository.FindAsync(x => x.SecurityQuestionId == securityQuestion.Id && x.TalentId == talent.Id);
                            if (talentSecurityQuestion == null)
                            {
                                responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Usernotansweredthequestion, LoginEnum.Validation.Error);
                                responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                return NotFound(responseLoginDto);
                            }
                            else
                            {
                                if (talentSecurityQuestion.Answer.ToLower() == forgetPasswordDto.SecurityAnswer.ToLower())
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Answeriscorrect, LoginEnum.Validation.Success);
                                    responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                    return Ok(responseLoginDto);
                                }
                                else
                                {
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Mobile, responseLoginDto, LoginEnum.Message.Answeriswrong, LoginEnum.Validation.Error);
                                    responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                                    return BadRequest(responseLoginDto);
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            #endregion
        }

        [HttpPost]
        [Route("verifyotp")]
        public async Task<IActionResult> VerifyOTP([FromBody] VerifyOtpDto verifyOtpDto)
        {
            if ((string.IsNullOrEmpty(verifyOtpDto.Email) && string.IsNullOrEmpty(verifyOtpDto.Mobile)) || string.IsNullOrEmpty(verifyOtpDto.OTP))
            {
                return BadRequest();
            }

            #region Verify Otp via EMAIL

            if (!string.IsNullOrEmpty(verifyOtpDto.Email))
            {
                verifyOtpDto.Email = verifyOtpDto.Email.ToLower();
                if (verifyOtpDto.LoginUserType == LoginEnum.LoginUserType.Talent)
                {
                    var talent = await _talentRepository.FindAsync(x => x.Email.ToLower() == verifyOtpDto.Email);

                    if (talent == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);

                        #region Talent - Verify OTP - Activate Email

                        if (talentToken.Email1 == verifyOtpDto.OTP)
                        {
                            talentToken.Email = constantActivated;
                            talentToken.Email1 = constantActivated;
                            talentToken = await _talentTokenRepository.UpdateAsync(talentToken);
                            return Ok(new { talent = talent.FullName, IsValid = "true" });
                        }
                        else
                        {
                            return BadRequest(new { talent = talent.FullName, IsValid = "false" });
                        }

                        #endregion
                    }
                }
                else if (verifyOtpDto.LoginUserType == LoginEnum.LoginUserType.Recruiter)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == verifyOtpDto.Email);

                    if (auxiliaryUser == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);

                        #region AuxiliaryUser - Verify OTP - Activate Email

                        if (auxiliaryUserToken.Email1 == verifyOtpDto.OTP)
                        {
                            auxiliaryUserToken.Email = constantActivated;
                            auxiliaryUserToken.Email1 = constantActivated;
                            auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);

                            var screen = "";
                            if (verifyOtpDto.Screen == "login")
                            {
                                screen = verifyOtpDto.Screen;
                            }
                            return Ok(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "true", screen = screen, });
                        }
                        else
                        {
                            return BadRequest(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "false" });
                        }

                        #endregion
                    }
                }
                else if (verifyOtpDto.LoginUserType == LoginEnum.LoginUserType.FTCAdmin)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == verifyOtpDto.Email);

                    if (auxiliaryUser == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);

                        #region Admin - Verify OTP - Activate Email

                        if (auxiliaryUserToken.Email1 == verifyOtpDto.OTP)
                        {
                            auxiliaryUserToken.Email = constantActivated;
                            auxiliaryUserToken.Email1 = constantActivated;
                            auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);

                            var screen = "";
                            if (verifyOtpDto.Screen == "login")
                            {
                                screen = verifyOtpDto.Screen;
                            }
                            return Ok(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "true", screen = screen });
                        }
                        else
                        {
                            return BadRequest(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "false" });
                        }

                        #endregion
                    }
                }
                else
                {
                    //for Admin
                    return null;
                }
            }
            #endregion

            #region Verify Otp via SMS
            else
            {
                if (verifyOtpDto.LoginUserType == LoginEnum.LoginUserType.Talent)
                {
                    var talent = await _talentRepository.FindAsync(x => x.Mobile == verifyOtpDto.Mobile);

                    if (talent == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);

                        #region Talent - Verify OTP - Activate SMS

                        if (await VerifyOTP(talent.Id, verifyOtpDto.OTP))
                            return Ok(new { talent = talent.FullName, IsValid = "true" });
                        else
                            return BadRequest(new { talent = talent.FullName, IsValid = "false" });


                        #endregion
                    }
                }
                else if (verifyOtpDto.LoginUserType == LoginEnum.LoginUserType.Recruiter)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == verifyOtpDto.Mobile);

                    if (auxiliaryUser == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);

                        #region Recruiter - Verify OTP - Activate SMS

                        if (auxiliaryUserToken.Mobile1 == verifyOtpDto.OTP)
                        {
                            auxiliaryUserToken.SMS = constantActivated;
                            auxiliaryUserToken.Mobile1 = constantActivated;
                            auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);

                            bool isEmailVerified = (auxiliaryUserToken.Email == constantActivated) ? true : false;

                            return Ok(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "true", isEmailVerified = isEmailVerified });
                        }
                        else
                        {
                            return BadRequest(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "false" });
                        }

                        #endregion
                    }
                }
                else if (verifyOtpDto.LoginUserType == LoginEnum.LoginUserType.FTCAdmin)
                {
                    //for Admin
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == verifyOtpDto.Mobile);

                    if (auxiliaryUser == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);

                        #region Admin - Verify OTP - Activate SMS

                        if (auxiliaryUserToken.Mobile1 == verifyOtpDto.OTP)
                        {
                            auxiliaryUserToken.SMS = constantActivated;
                            auxiliaryUserToken.Mobile1 = constantActivated;
                            auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);
                            return Ok(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "true" });
                        }
                        else
                        {
                            return BadRequest(new { auxiliaryUser = auxiliaryUser.FullName, IsValid = "false" });
                        }

                        #endregion
                    }
                }
                else
                {
                    return null;
                }
            }
            #endregion
        }

        /// <summary>
        /// resetpassword post 
        /// </summary>
        [HttpPost]
        [Route("resetpassword/{isSystemAdmin?}/{talentId?}")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDto resetPasswordDto, bool isSystemAdmin, int talentId)
        {
            if (isSystemAdmin)
            {
                resetPasswordDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                resetPasswordDto.Mobile = _talentRepository.Find(x => x.Id == talentId).Mobile;
            }

            if ((string.IsNullOrEmpty(resetPasswordDto.Email) && string.IsNullOrEmpty(resetPasswordDto.Mobile)) || string.IsNullOrEmpty(resetPasswordDto.NewPassword))
            {
                return BadRequest();
            }
            else
            {
                string pwdToHash = resetPasswordDto.NewPassword;
                string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(pwdToHash, BCrypt.Net.BCrypt.GenerateSalt());

                if (!string.IsNullOrEmpty(resetPasswordDto.Email))
                {
                    #region reset by Email
                    if (resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.Talent)
                    {
                        var talent = await _talentRepository.FindAsync(x => x.Email.ToLower() == resetPasswordDto.Email.ToLower());
                        if (talent != null)
                        {
                            // When talent tries to use socail Login email for Reset password, don't allow
                            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);
                            if (talentToken != null)
                            {
                                if (talentToken.LoginType.ToLower() != RegistrationDevice.Website.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.Android.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.iOS.ToString().ToLower())
                                {
                                    var responseLoginDto = new ResponseLoginDto();
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.RegisteredWithSocialLogin, LoginEnum.Validation.Error);
                                    return NotFound(responseLoginDto);
                                }
                            }

                            talent.Password = hashToStoreInDatabase;
                            talent = await _talentRepository.UpdateAsync(talent);
                            return Ok(new { userName = resetPasswordDto.Email, status = "Success" });
                        }
                        return NotFound();
                    }
                    else if (resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.Recruiter || resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.FTCAdmin)
                    {
                        var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == resetPasswordDto.Email.ToLower());
                        if (auxiliaryUser != null)
                        {
                            auxiliaryUser.Password = hashToStoreInDatabase;
                            auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
                            return Ok(new { userName = resetPasswordDto.Email, status = "Success" });
                        }
                        return NotFound();
                    }
                    else
                    {
                        //ForAdmin
                        return null;
                    }
                    #endregion
                }
                else
                {
                    #region reset by Mobile No.
                    if (resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.Talent)
                    {
                        var talent = await _talentRepository.FindAsync(x => x.Mobile == resetPasswordDto.Mobile);
                        if (talent != null)
                        {
                            // When talent tries to use socail Login email for Reset password, don't allow
                            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);
                            if (talentToken != null)
                            {
                                if (talentToken.LoginType.ToLower() != RegistrationDevice.Website.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.Android.ToString().ToLower()
                            && talentToken.LoginType.ToLower() != RegistrationDevice.iOS.ToString().ToLower())
                                {
                                    var responseLoginDto = new ResponseLoginDto();
                                    responseLoginDto = GetResponseLoginDto(LoginEnum.LoginType.Email, responseLoginDto, LoginEnum.Message.RegisteredWithSocialLogin, LoginEnum.Validation.Error);
                                    return NotFound(responseLoginDto);
                                }
                            }

                            talent.Password = hashToStoreInDatabase;
                            talent = await _talentRepository.UpdateAsync(talent);

                            //Activate Mobile Number [and Email if it exists] if Admin Resets the password
                            if (isSystemAdmin)
                            {
                                //var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);
                                talentToken.SMS = constantActivated;
                                if (!string.IsNullOrEmpty(talent.Email))
                                {
                                    talentToken.Email = constantActivated;
                                }
                                talentToken = await _talentTokenRepository.UpdateAsync(talentToken);

                                #region When Admin resets the password - send SMS,Email & system Notification

                                await notifyTalentWithNewPassword(resetPasswordDto, talent);

                                #endregion
                            }

                            return Ok(new { userName = resetPasswordDto.Mobile, status = "Success" });
                        }
                        return NotFound();
                    }
                    else if (resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.Recruiter)
                    {
                        var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == resetPasswordDto.Mobile);
                        if (auxiliaryUser != null)
                        {
                            auxiliaryUser.Password = hashToStoreInDatabase;
                            auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
                            return Ok(new { userName = resetPasswordDto.Mobile, status = "Success" });
                        }
                        return NotFound();
                    }
                    else
                    {
                        //ForAdmin
                        return null;
                    }
                    #endregion
                }
            }
        }


        /// <summary>
        /// changepassword post 
        /// </summary>
        [HttpPost]
        [Route("changepassword/{isSystemAdmin?}/{talentId?}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<IActionResult> ChangePassword([FromBody] ResetPasswordDto resetPasswordDto, int userId, int userType, bool isSystemAdmin, int talentId)
        {
            if (resetPasswordDto == null || string.IsNullOrEmpty(resetPasswordDto.NewPassword))
            {
                return BadRequest();
            }
            else
            {
                int accountUserId = userId;
                if (isSystemAdmin)
                {
                    accountUserId = talentId;
                    userType = (int)LoginEnum.LoginUserType.Talent;
                    resetPasswordDto.LoginUserType = LoginEnum.LoginUserType.Talent;
                }

                string pwdToHash = resetPasswordDto.NewPassword;
                string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(pwdToHash, BCrypt.Net.BCrypt.GenerateSalt());

                if (resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.Talent)
                {
                    var talent = await _talentRepository.FindAsync(x => x.Id == accountUserId);
                    if (talent != null)
                    {
                        talent.Password = hashToStoreInDatabase;
                        talent = await _talentRepository.UpdateAsync(talent);
                        return Ok(new { userName = resetPasswordDto.Email, status = "Success" });
                    }
                    return NotFound();
                }
                else if (resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.Recruiter || resetPasswordDto.LoginUserType == LoginEnum.LoginUserType.FTCAdmin)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == accountUserId);
                    if (auxiliaryUser != null)
                    {
                        auxiliaryUser.Password = hashToStoreInDatabase;
                        auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
                        return Ok(new { userName = resetPasswordDto.Email, status = "Success" });
                    }
                    return NotFound();
                }
                else
                {
                    //ForAdmin
                    return null;
                }
            }
        }

        /// <summary>
        /// validate old password for - change password 
        /// </summary>
        [HttpGet]
        [Route("validateoldpassword/{password}/{isSystemAdmin}/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<IActionResult> ValidateOldPassword(string password, int userId, int userType, bool isSystemAdmin, int talentId)
        {
            if (string.IsNullOrEmpty(password))
            {
                return BadRequest();
            }
            else
            {
                int accountUserId = 0;
                if (isSystemAdmin)
                {
                    accountUserId = talentId;
                    userType = (int)LoginEnum.LoginUserType.Talent;
                }
                else
                    accountUserId = userId;

                if (userType == (int)LoginEnum.LoginUserType.Talent)
                {
                    var talent = await _talentRepository.FindAsync(x => x.Id == accountUserId);
                    if (talent == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        bool isAuthenticated = _talentRepository.ValidateUser(password, talent.Password);
                        if (isAuthenticated)
                            return Ok(new { result = "validPassword" });

                        else
                            return NotFound();
                    }
                }
                else if (userType == (int)LoginEnum.LoginUserType.Recruiter || userType == (int)LoginEnum.LoginUserType.FTCAdmin)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == accountUserId);
                    if (auxiliaryUser == null)
                    {
                        return NotFound();
                    }
                    else
                    {
                        bool isAuthenticated = _auxiliaryUserRepository.ValidateUser(password, auxiliaryUser.Password);
                        if (isAuthenticated)
                            return Ok(new { result = "validPassword" });
                        else
                            return NotFound();
                    }
                }
                return BadRequest();
            }
        }

        [HttpPost]
        [Route("ReSendOTP")]
        public async Task<IActionResult> ReSendSmsAsync([FromBody]TalentDto talentDto)
        {
            if (string.IsNullOrEmpty(talentDto.Email) && string.IsNullOrEmpty(talentDto.Mobile))
            {
                return BadRequest();
            }
            if (!string.IsNullOrEmpty(talentDto.Email))
            {
                var talent = await _talentRepository.FindAsync(x => x.Email.ToLower() == talentDto.Email.ToLower());
                if (talent == null)
                {
                    #region Resend Otp - email - admin,Recruiter
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == talentDto.Email.ToLower());
                    if (auxiliaryUser != null)
                    {
                        var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);

                        string newOTP = "";

                        newOTP = (string.IsNullOrEmpty(auxiliaryUserToken.Email1) || auxiliaryUserToken.Email1 == constantActivated) ? GenerateOTP() : auxiliaryUserToken.Email1;
                        auxiliaryUserToken.Email1 = newOTP;
                        //auxiliaryUserToken.Email = newOTP;

                        auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);
                        Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);


                        NotificationParam notificationParam = new NotificationParam
                        {
                            Email = talentDto.Email,
                            Otp = newOTP,
                            AuxiliaryUserId = auxiliaryUser.Id

                            //DeviceOsId = talent.DeviceOsId,
                            //DeviceRegistrationId = talent.DeviceRegistrationId
                        };

                        var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                        await notification.SendNotification(NotificationEnum.ResendOtp, notificationParam, sendSystemNotificationDto);

                        return Ok(new { auxiliaryUser = auxiliaryUser.FullName, status = "success" });
                    }
                    else
                    {
                        return NotFound();
                    }
                    #endregion
                }
                else
                {
                    #region Resend OTP - email  - Talent

                    var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);

                    string newOTP = "";

                    newOTP = (string.IsNullOrEmpty(talentToken.Email1) || talentToken.Email1 == constantActivated) ? GenerateOTP() : talentToken.Email1;
                    talentToken.Email1 = newOTP;
                    //talentToken.Email = newOTP;


                    talentToken = await _talentTokenRepository.UpdateAsync(talentToken);
                    Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                    var notificationParam = new NotificationParam
                    {
                        Email = talentDto.Email,
                        Otp = newOTP,
                        DeviceOsId = talent.DeviceOsId,
                        DeviceRegistrationId = talent.DeviceRegistrationId,
                        TalentId = talent.Id

                    };

                    var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                    await notification.SendNotification(NotificationEnum.ResendOtp, notificationParam, sendSystemNotificationDto);
                    #endregion

                    return Ok(new { talent = talent.FullName, status = "success" });
                }
            }
            else
            {
                var talentModel = await _talentRepository.FindAsync(x => x.Mobile == talentDto.Mobile);

                if (talentModel == null)
                {
                    #region Resent OTP - Recruiter,Admin
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == talentDto.Mobile);
                    if (auxiliaryUser != null)
                    {

                        var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);

                        string newOTP = "";

                        newOTP = (string.IsNullOrEmpty(auxiliaryUserToken.Mobile1) || auxiliaryUserToken.Mobile1 == constantActivated) ? GenerateOTP() : auxiliaryUserToken.Mobile1;
                        auxiliaryUserToken.Mobile1 = newOTP;
                        //newOTP = auxiliaryUserToken.SMS;


                        auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);



                        Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                        NotificationParam notificationParam = new NotificationParam
                        {
                            AuxiliaryUserId = auxiliaryUser.Id,
                            MobileNumber = auxiliaryUser.Mobile,
                            MobileCountryCode = auxiliaryUser.MobileCountryCode,
                            Otp = newOTP
                        };

                        var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                        await notification.SendNotification(NotificationEnum.ResendOtp, notificationParam, sendSystemNotificationDto);

                        return Ok(new { auxiliaryUser = auxiliaryUser.FullName, status = "success" });
                    }
                    else
                    {
                        return NotFound();
                    }
                    #endregion
                }
                else
                {
                    #region Resend otp - talent

                    string newOTP = await GetOTPForTalent(talentModel.Id);

                    var talentNotificationModelDto = ConvertToTalentNotificationModelDto(talentModel);

                    // Send Notification on Resend OTP
                    await NotifyTalentWithOTP(talentNotificationModelDto, newOTP, NotificationEnum.ResendOtp);
                    #endregion

                    return Ok(new { talent = talentModel.FullName, status = "success" });
                }
            }
        }

        private TalentNotificationModelDto ConvertToTalentNotificationModelDto(Talent talentModel)
        {
            return new TalentNotificationModelDto()
            {
                TalentId = talentModel.Id,
                MobileCountryCode = talentModel.MobileCountryCode,
                MobileNumber = talentModel.Mobile,
                DeviceOsId = talentModel.DeviceOsId,
                DeviceRegistrationId = talentModel.DeviceRegistrationId
            };
        }

        [HttpGet]
        [Route("isemailexist/{email}")]
        public async Task<IActionResult> IsEmailExist(string email)
        {
            if (email == null)
            {
                return BadRequest();
            }
            else
            {
                email = email.ToLower();
                var talent = await _talentRepository.FindAsync(x => x.Email.ToLower() == email && x.Email != "");
                if (talent == null)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.EmailId.ToLower() == email && x.EmailId != "");

                    if (auxiliaryUser == null)
                    {
                        return NoContent();
                    }
                    // auxiliaryuser is not a talent!
                    return Ok(new { auxiliaryUser = auxiliaryUser.EmailId, status = "Success" });

                }
                else
                {
                    return Ok(new { talent = talent.Email, status = "Success" });
                }
            }
        }

        [HttpGet]
        [Route("ismobileexist/{mobile}")]
        public async Task<IActionResult> IsMobileExist(string mobile)
        {
            if (mobile == null)
            {
                return BadRequest();
            }
            else
            {
                var talent = await _talentRepository.FindAsync(x => x.Mobile == mobile);
                if (talent == null)
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Mobile == mobile);
                    if (auxiliaryUser == null)
                    {
                        return NoContent();
                    }
                    // auxiliaryuser is not a talent!
                    return Ok(new { auxiliaryUser = auxiliaryUser.Mobile, status = "Success" });
                }
                else
                {
                    return Ok(new { talent = talent.Mobile, status = "Success" });
                }
            }
        }

        [HttpPost]
        [Route("sociallogin")]
        public async Task<IActionResult> SocialLogin([FromBody]TalentDto talentDto)
        {
            if (string.IsNullOrEmpty(talentDto.Email) && string.IsNullOrEmpty(talentDto.Mobile))
            {
                return BadRequest();
            }
            else
            {
                talentDto.Email = talentDto.Email.ToLower();
                ResponseLoginDto responseLoginDto = new ResponseLoginDto();

                var talentModel = await _talentRepository.FindAsync
                    (
                        x => (x.Email.ToLower() == talentDto.Email && !string.IsNullOrEmpty(x.Email)) ||
                        (x.Mobile == talentDto.Mobile && !string.IsNullOrEmpty(x.Mobile))
                     );
                var auxillaryUserModel = await _auxiliaryUserRepository.FindAsync(
                    x => (x.EmailId.ToLower() == talentDto.Email && !string.IsNullOrEmpty(x.EmailId)) ||
                    (x.Mobile == talentDto.Mobile && !string.IsNullOrEmpty(x.Mobile))
                    );

                if (talentModel == null && auxillaryUserModel == null)
                {
                    Talent talent = new Talent();
                    talent.Email = talentDto.Email;
                    talent.FullName = talentDto.FullName;
                    talent.Mobile = talentDto.Mobile;
                    talent.Gender = talentDto.Gender;
                    talent.DOB = talentDto.DOB;
                    talent.MobileCountryCode = talentDto.MobileCountryCode;
                    talent.AuthToken = Guid.NewGuid().ToString();
                    talent.TermsConditionAccepted = false;

                    // save device id  & Registration Id
                    talent.DeviceOsId = talentDto.DeviceOsId;
                    talent.DeviceRegistrationId = talentDto.DeviceRegistrationId;

                    talent = await _talentRepository.AddAsync(talent);

                    TalentToken talentToken = new TalentToken();
                    talentToken.TalentId = talent.Id;
                    talentToken.LoginType = talentDto.LoginType.ToString();
                    talentToken = await _talentTokenRepository.AddAsync(talentToken);

                    responseLoginDto.ValidateLogin = LoginEnum.Validation.Success;
                    responseLoginDto.Login = talentDto.LoginType;
                    responseLoginDto.ReturnMessage = LoginEnum.Message.LoginSuccessfull;
                    responseLoginDto.FullName = talent.FullName;
                    responseLoginDto.LastTabNo = talent.LastTabNo;
                    responseLoginDto.OnBoarded = talent.Onboarded;
                    responseLoginDto.AuthToken = talent.AuthToken;
                    responseLoginDto.TermsConditionAccepted = talent.TermsConditionAccepted;
                    responseLoginDto.IsNewUser = true;
                    responseLoginDto.isOtpVerified = (talentToken.SMS == constantActivated) ? true : false;

                    responseLoginDto.UID = talent.UID;

                    await SendUserSettings(responseLoginDto);

                    return Ok(responseLoginDto);
                }
                else if (talentModel == null && auxillaryUserModel != null)
                {
                    GetErrorMessageForSocialLogin(talentDto.LoginType, responseLoginDto);
                    return Ok(responseLoginDto);
                }
                else
                {
                    var talentTokenModel = await _talentTokenRepository.FindAsync(x => x.TalentId == talentModel.Id);

                    if (talentTokenModel.LoginType == constantWebsite
                        || talentTokenModel.LoginType == DeviceOsEnum.iOS.ToString()
                        || talentTokenModel.LoginType == DeviceOsEnum.Android.ToString())
                    {
                        GetErrorMessageForSocialLogin(talentDto.LoginType, responseLoginDto);
                        return Ok(responseLoginDto);
                    }

                    else
                    {
                        string authToken = Guid.NewGuid().ToString();
                        talentModel.AuthToken = authToken;
                        talentModel.DeviceOsId = talentDto.DeviceOsId;
                        talentModel.DeviceRegistrationId = talentDto.DeviceRegistrationId;

                        talentModel = await _talentRepository.UpdateAsync(talentModel);

                        responseLoginDto.ValidateLogin = LoginEnum.Validation.Success;
                        responseLoginDto.Login = talentDto.LoginType;
                        responseLoginDto.ReturnMessage = LoginEnum.Message.LoginSuccessfull;
                        responseLoginDto.FullName = talentModel.FullName;
                        responseLoginDto.LastTabNo = talentModel.LastTabNo;
                        responseLoginDto.OnBoarded = talentModel.Onboarded;
                        responseLoginDto.AuthToken = talentModel.AuthToken;
                        responseLoginDto.TermsConditionAccepted = talentModel.TermsConditionAccepted;
                        responseLoginDto.IsNewUser = false;

                        responseLoginDto.isOtpVerified = (talentTokenModel.SMS == constantActivated) ? true : false;

                        responseLoginDto.UID = talentModel.UID;

                        await SendUserSettings(responseLoginDto);

                        return Ok(responseLoginDto);
                    }
                }
            }
        }

        private void GetErrorMessageForSocialLogin(LoginType loginType, ResponseLoginDto responseLoginDto)
        {
            responseLoginDto.ValidateLogin = LoginEnum.Validation.Error;
            responseLoginDto.Login = loginType;
            responseLoginDto.ReturnMessage = LoginEnum.Message.Useralreadyexist;
        }

        [HttpPost]
        [Route("changeMobileNumber")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> ChangeMobileNumber([FromBody]ChangeMobileNumberDto changeMobileNumberDto, UserInfo userInfo)
        {
            string oldMobileNumber = string.Empty;
            if (string.IsNullOrEmpty(changeMobileNumberDto.NewMobileNumber) && string.IsNullOrEmpty(changeMobileNumberDto.NewMobileCountryCode) && string.IsNullOrEmpty(changeMobileNumberDto.Otp))
                return BadRequest(new { message = "Mobile Number and OTP cannot be blank" });

            // Check if new mobile number is registered to someone else or not
            if (!await IsNewUser(string.Empty, changeMobileNumberDto.NewMobileNumber))
                return StatusCode(409, new { message = "new mobile number already exists" });

            if (await VerifyOTP(userInfo.userId, changeMobileNumberDto.Otp))
            {
                var talent = await _talentRepository.FindAsync(x => x.Id == userInfo.userId);
                oldMobileNumber = talent.Mobile;
                talent.Mobile = changeMobileNumberDto.NewMobileNumber;
                talent.MobileCountryCode = changeMobileNumberDto.NewMobileCountryCode;
                talent.MobileCountryId = changeMobileNumberDto.NewMobileCountryId;
                talent = await _talentRepository.UpdateAsync(talent);

                //insert the data into history table 

                var talentStatusHistory = new TalentStatusHistory
                {
                    TalentId = talent.Id,
                    StatusId = (int)StatusEnum.Edit,
                    FeatureId = (int)AuthorizationFeaturesEnum.TalentOnboarding,
                    text = $"Old MobileNumber -{oldMobileNumber} , New Mobile Number - {changeMobileNumberDto.NewMobileNumber}"
                };
                await _talentStatusHistoryRepository.AddAsync(talentStatusHistory);
                return Ok(talent);
            }
            else
            {
                return BadRequest(new { talent = userInfo.FullName, IsValid = "false", message = "OTP is Invalid" });
            }

        }

        [HttpPost]
        [Route("generateOTP")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GenerateOTP([FromBody]ChangeMobileNumberDto changeMobileNumberDto, UserInfo userInfo)
        {
            string newOTP = await GetOTPForTalent(userInfo.userId, changeMobileNumberDto.GenerateNewOTP);

            var talentModel = await _talentRepository.FindAsync(x => x.Id == userInfo.userId);

            var talentNotificationModelDto = ConvertToTalentNotificationModelDto(talentModel);

            // pass New mobile Number and country code in talent model
            if (!string.IsNullOrEmpty(changeMobileNumberDto.NewMobileNumber) && !string.IsNullOrEmpty(changeMobileNumberDto.NewMobileCountryCode))
            {
                talentNotificationModelDto.MobileCountryCode = changeMobileNumberDto.NewMobileCountryCode;
                talentNotificationModelDto.MobileNumber = changeMobileNumberDto.NewMobileNumber;
            }

            if (changeMobileNumberDto.GenerateNewOTP && string.IsNullOrEmpty(changeMobileNumberDto.NewMobileNumber))
            {
                await NotifyTalentWithOTP(talentNotificationModelDto, newOTP, NotificationEnum.ChangeMobileNumberOld);
            }
            else if (changeMobileNumberDto.GenerateNewOTP && !string.IsNullOrEmpty(changeMobileNumberDto.NewMobileNumber))
            {
                await NotifyTalentWithOTP(talentNotificationModelDto, newOTP, NotificationEnum.ChangeMobileNumberNew);
            }
            else
            {
                await NotifyTalentWithOTP(talentNotificationModelDto, newOTP, NotificationEnum.ResendOtp);
            }

            return Ok(new { talent = talentModel.FullName, status = "success" });

        }

        [HttpGet]
        [Route("verifyGeneratedOTP/{otp}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> VerifyGeneratedOTP(string otp, UserInfo userInfo)
        {
            if (string.IsNullOrEmpty(otp))
                return BadRequest(new { talent = userInfo.FullName, IsValid = "false" });

            if (await VerifyOTP(userInfo.userId, otp))
                return Ok(new { talent = userInfo.FullName, IsValid = "true" });
            else
                return BadRequest(new { talent = userInfo.FullName, IsValid = "false" });


        }

        [HttpGet]
        [Route("issharednameexist/{sharedname}")]
        public async Task<IActionResult> IsSharedNameExist(string sharedName)
        {
            if (string.IsNullOrEmpty(sharedName))
            {
                return BadRequest();
            }
            else
            {
                var talent = await _talentRepository.FindAsync(x => x.SharedProfileName.ToLower() == sharedName.ToLower());
                if (talent == null)
                {
                    return NotFound();
                }
                else
                {
                    return Ok(new { talent = talent, status = "Success" });
                }
            }
        }

        [HttpPost]
        [Route("savetalentsharedetails")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> SaveTalentShareDetails([FromBody]TalentShareDetailDto talentShareDetailDto, int userId)
        {
            if (talentShareDetailDto == null)
            {
                return BadRequest();
            }

            var talent = await _talentRepository.FindAsync(x => x.Id == userId);
            talent.SharedProfileName = talentShareDetailDto.SharedProfileName;
            talent = await _talentRepository.UpdateAsync(talent);
            talentShareDetailDto.TalentId = userId;
            var talentShareDetail = ConvertToTalentShareDetail(talentShareDetailDto);
            talentShareDetail = await _talentShareDetailRepository.AddAsync(talentShareDetail);
            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            List<string> lstEmail = talentShareDetail.EmailIds.Split(',').Select(x => x.Trim()).ToList();
            if (lstEmail.Count > 0)
            {
                var notificationParam = new NotificationParam
                {
                    TalentId = talent.Id,
                    SharedProfileName = talentShareDetailDto.SharedProfileName,
                    Bcc = lstEmail,
                    FullName = talent.FullName,
                    SharedProfileComment = talentShareDetailDto.Notes,
                    DeviceOsId = talent.DeviceOsId,
                    DeviceRegistrationId = talent.DeviceRegistrationId
                };

                var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                await notification.SendNotification(NotificationEnum.TalentShareDetail, notificationParam, sendSystemNotificationDto);
            }
            return Ok(talentShareDetailDto);

        }

        [HttpGet]
        [Route("validateRecruiterName/{recruiterName}")]
        public async Task<IActionResult> ValidateRecruiterName(string recruiterName)
        {
            if (recruiterName == null)
            {
                return BadRequest();
            }
            else
            {
                var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.FullName.ToLower() == recruiterName.ToLower());
                if (auxiliaryUser == null)
                {
                    return NoContent();
                }
                else
                {
                    return Ok(new { UserName = auxiliaryUser.FullName, status = "Already Exist" });
                }
            }
        }

        /// <summary>
        /// This action is use to get talent ratings
        /// </summary>
        /// <param name="talentId">talent id</param>
        /// <param name="userType">todo: describe userType parameter on GetTalentRatings</param>
        /// <returns>returns the list of talent ratings</returns>
        [HttpGet]
        [Route("getratings/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetTalentRatings(int talentId)
        {

            if (talentId == 0)
            {
                return BadRequest();
            }

            var talentRatings = await _talentRepository.GetTalentRatings(talentId);

            if (talentRatings == null || (talentRatings != null && talentRatings.TalentId == 0))
            {
                return NotFound();
            }

            return Ok(talentRatings);
        }

        /// <summary>
        /// This action is use to get talent rmarks
        /// </summary>
        /// <param name="talentId">talent id</param>
        /// <param name="userType">todo: describe userType parameter on GetTalentRMark</param>
        /// <returns>returns list of rmarks</returns>
        [HttpGet]
        [Route("getrmark/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> GetTalentRMark(int talentId)
        {
            if (talentId == 0)
            {
                return BadRequest();
            }
            var talentRmarks = await _talentRepository.GetTalentRmark(talentId);
            return Ok(talentRmarks);
        }

        /// <summary>
        /// This action update list if talent ratings
        /// </summary>
        /// <param name="talentRatings"></param>
        /// <param name="userId">userId</param>
        /// <param name="userName">userName</param>
        /// <returns>returns updated list of talent ratings</returns>
        [HttpPost]
        [Route("updateratings")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> UpdateTalentRatings([FromBody]TalentRatings talentRatings, int userId)
        {
            talentRatings.VerifiedBy = userId;
            var status = await _talentRepository.UpdateRatings(talentRatings, userId);
            if (status)
            {
                return Ok(new { message = "Talent ratings updated successfully" });
            }

            return BadRequest();
        }

        /// <summary>
        /// This action is use to update talent rmarks
        /// </summary>
        /// <param name="rmarks">list of rmarks</param>
        /// <param name="userId">login user id</param>
        /// <returns>returns updated list to rmarks</returns>
        [HttpPost]
        [Route("updatermark")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> UpdateTalentRMark([FromBody]TalentRatingRmarks rmarks, int userId)
        {
            rmarks.VerifiedBy = userId;
            var status = await _talentRepository.UpdateTalentRMark(rmarks, userId);
            if (status)
            {
                return Ok(new { message = "Recommendations updated sucessfully" });
            }
            return BadRequest();
        }

        [HttpDelete]
        [Route("deletetalent")]
        public async Task<IActionResult> DeleteTalent([FromBody] TalentDto talentDto)
        {

            var talentModel = await _talentRepository.FindAsync(
                x => (x.Email.ToLower() == talentDto.Email.ToLower() && !string.IsNullOrEmpty(x.Email))
                || (x.Mobile == talentDto.Mobile && !string.IsNullOrEmpty(x.Mobile))
                );
            if (talentModel != null)
            {
                var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentModel.Id);
                var resulttalentToken = await _talentTokenRepository.DeleteAsync(talentToken);
                var result = await _talentRepository.DeleteAsync(talentModel);
                return Ok("user deleted");
            }
            else
            {
                return BadRequest("user does not exist");
            }
        }

        [HttpPost]
        [Route("termsAccepted")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> UpdateTermsConditionAccepted([FromBody] TalentDto talentDto, int userId)
        {
            var talent = await _talentRepository.FindAsync(x => x.Id == userId);

            if (talent == null)
            {
                #region auxiliary user
                var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == userId);
                if (auxiliaryUser != null)
                {
                    auxiliaryUser.TermsConditionAccepted = talentDto.TermsConditionAccepted;
                    var result = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
                    //return Ok("Accepted");
                    return Ok(new { status = "Success" });
                }
                else
                {
                    //return NotFound("Talent does not exist");
                    return NotFound(new { status = "Failed" });
                }
                #endregion
            }
            else
            {
                talent.TermsConditionAccepted = talentDto.TermsConditionAccepted;
                var result = await _talentRepository.UpdateAsync(talent);
                return Ok(new { status = "Success" });
            }

        }

        /// <summary>
        /// searchTalent
        /// </summary>
        [HttpPost]
        [Route("search/managealltalent")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> searchAllManageTalent([FromBody]SearchParametersDto searchParams, int userId)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var talent = await _talentRepository.Search(search, "all", userId);
            var talentToken = _talentTokenRepository.GetAll();
            var socialLoginTypes = new string[] { "Social", "Google", "Facebook" };
            var talentSpecialHost = await _talentSpecialHostRepository.FindAllAsync(x => x.SpecialHostId == (short)ContestSpecialHostEnum.TataSky && x.StatusId == (int)StatusEnum.Active);

            if (talent != null)
            {
                var results = talent.Results.Select(t => new
                {
                    id = t.Id,
                    uid = t.UID,
                    fullName = t.FullName,
                    talentProfileURL = t.TalentProfileURL,
                    status = t.Status != null ? new { id = t.Status.Id, description = t.Status.Description } : null,
                    dob = t.DOB,
                    city = t.TalentAddress.Count() > 0 ? (t.TalentAddress.FirstOrDefault().Address.CityId != null ? t.TalentAddress.FirstOrDefault().Address.City.CityDescription : "") : "",
                    overallRating = t.OverallRating,
                    talentRatingRmark = t.TalentRatingRmark.Count(x => x.InterestCategoryId != null),
                    tierId = t.TierId,
                    isSocialLogin = talentToken.Where(x => socialLoginTypes.Contains(x.LoginType)).Distinct().Select(x => x.TalentId).Contains(t.Id),
                    isTataSkySubscriber = talentSpecialHost.Where(x => x.TalentId == t.Id).Select(x => x.TalentId).Contains(t.Id)
                });

                return Json(new
                {
                    Results = results,
                    TotalResults = talent.TotalResults,
                    Previous = talent.Previous,
                    Next = talent.Next
                });
            }
            return NotFound();
        }

        /// <summary>
        /// searchTalent
        /// </summary>
        [HttpPost]
        [Route("search/manageselectedtalent")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> searchSelectedManageTalent([FromBody]SearchParametersDto searchParams, int userId)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var talent = await _talentRepository.Search(search, "selected", userId);
            if (talent != null)
            {
                return Json(talent);
            }
            return NotFound();
        }

        /// <summary>
        /// post - talent to push for job Recommendation
        /// </summary>
        [HttpPost]
        [Route("jobTalentRecommendation/{jobId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> PostJobTalentRecommendation([FromBody]int[] Talents, int jobId, int userId)
        {
            if (Talents.Count() < 0)
            {
                return BadRequest();
            }
            foreach (var talent in Talents)
            {
                var jobTalentRecommended = new JobTalentRecommended()
                {
                    JobId = jobId,
                    TalentId = talent,
                    Order = 10,
                    SortOrderTypeId = 1,
                    CreatedBy = userId
                };
                var response = await _jobTalentRecommendedRepository.AddAsync(jobTalentRecommended);
            }
            return new JsonResult("success");
        }

        /// <summary>
        /// Talent/AddTagToTalent : POST
        /// </summary>
        [HttpPost]
        [Route("addTag/{talentId}/{tagId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Talent")]
        public async Task<ActionResult> AddTagToTalent(int talentId, int tagId)
        {
            if (!string.IsNullOrEmpty(talentId.ToString()) && !string.IsNullOrEmpty(tagId.ToString()))
            {
                var talentTag = new TalentTag()
                {
                    TalentId = talentId,
                    TagId = tagId
                };
                var response = await _talentTagRepository.AddAsync(talentTag);
                if (response != null)
                {
                    return Json(new { response = response, status = "Success" });
                }
            }
            return BadRequest();
        }

        /// <summary>
        /// Talent/RemoveTagFromTalent : DELETE
        /// </summary>
        [HttpPost]
        [Route("removeTag/{talentId}/{tagId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Talent")]
        public async Task<ActionResult> RemoveTagFromTalent(int talentId, int tagId)
        {
            if (!string.IsNullOrEmpty(talentId.ToString()) && !string.IsNullOrEmpty(tagId.ToString()))
            {
                var response = await _talentTagRepository.FindAsync(x => x.TalentId == talentId && x.TagId == tagId);
                if (response != null)
                {
                    var result = await _talentTagRepository.DeleteAsync(response);
                    return Json(new { response = result });
                }
                return NotFound();
            }
            return BadRequest();
        }

        /// <summary>
        /// GetTag : GET 
        /// </summary>
        [HttpGet]
        [Route("tag/{talentId}/{talentRelated?}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter,Talent")]
        public async Task<ActionResult> GetTag(int talentId, bool talentRelated)
        {
            if (!string.IsNullOrEmpty(talentId.ToString()))
            {
                var tagCategoryList = new List<TagCategory>();
                if (talentRelated)
                {
                    var responseResult = await _tagCategoryRepository.FindAllAsync(x => x.TagTalentRelated == true);
                    if (responseResult != null)
                    {
                        tagCategoryList = responseResult.ToList();
                    }
                }
                else
                {
                    var responseResult = await _tagCategoryRepository.GetAllAsync();
                    if (responseResult != null)
                    {
                        tagCategoryList = responseResult.ToList();
                    }
                }
                var tagCategoryIds = tagCategoryList.Select(x => x.Id).ToList();
                var talentTagList = await _talentTagRepository.FindAllAsync(x => x.TalentId == talentId);
                var response = await _tagRepository.FindAllAsync(t => tagCategoryIds.Contains(t.TagCategoryId) && talentTagList.ToList().Any(tt => tt.TagId == t.Id));
                response = response.OrderBy(r => r.Name);
                return Json(response);
            }
            return BadRequest();
        }

        /// <summary>
        /// Talent/UpdateTalentTags : POST
        /// </summary>
        [HttpPost]
        [Route("updatetags/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Talent")]
        public async Task<ActionResult> UpdateTalentTags(int talentId, [FromBody]List<int> tagIdList)
        {
            if (!string.IsNullOrEmpty(talentId.ToString()) && tagIdList.Count() > 0)
            {
                var talentTagList = await _talentTagRepository.FindAllAsync(x => x.TalentId == talentId);
                if (talentTagList.Count() > 0)
                {
                    _talentTagRepository.RemoveRange(talentTagList);
                }
                int count = 0;
                foreach (var tagId in tagIdList)
                {
                    var talentTag = new TalentTag()
                    {
                        TalentId = talentId,
                        TagId = tagId
                    };
                    var response = await _talentTagRepository.AddAsync(talentTag);
                    count += 1;
                }
                if (count > 0)
                    return Json(new { status = "Success" });

            }
            return BadRequest();
        }

        /// <summary>
        /// Talent/assignTier : Post
        /// </summary>
        [HttpPost]
        [Route("assigntier/{talentId}/{tierId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<ActionResult> assignTier(int talentId, int tierId)
        {
            if (!string.IsNullOrEmpty(talentId.ToString()) && !string.IsNullOrEmpty(tierId.ToString()))
            {
                var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
                if (talent != null)
                {
                    var tier = await _tierRepository.FindAsync(x => x.TierId == tierId);
                    talent.TierId = (tier != null) ? tier.TierId : (short)0;

                    var talentUpdated = await _talentRepository.UpdateAsync(talent);
                    return Json(new { status = "Success" });
                }
                return NotFound();
            }
            return BadRequest();
        }

        /// <summary>
        /// Talent/changestatus : Post
        /// </summary>
        [HttpPost]
        [Route("changestatus/{talentId}/{activate}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> ChangeTalentStatus(int talentId, bool activate, UserInfo userInfo)
        {
            if (!string.IsNullOrEmpty(talentId.ToString()))
            {
                var response = await _talentRepository.FindAsync(x => x.Id == talentId);
                if (response != null)
                {
                    response.StatusId = (int)(activate ? StatusEnum.Active : StatusEnum.InActive);      //InActive: Status for diactivated Talent
                    if (response.StatusId == (int)StatusEnum.InActive)
                    {
                        response.AuthToken = string.Empty;
                    }

                    var talentUpdated = await _talentRepository.UpdateAsync(response);

                    #region Add TalentStatusHistory when talent is Blocked and Activated
                    var talentStatusHistory = new TalentStatusHistory()
                    {
                        CreatedBy = userInfo.userId,
                        TalentId = talentUpdated.Id,
                        StatusId = talentUpdated.StatusId
                    };

                    await _talentStatusHistoryRepository.AddAsync(talentStatusHistory);

                    #endregion

                    talentUpdated.Status = new Status()
                    {
                        Id = talentUpdated.StatusId ?? 0,
                        Description = Enum.ToObject(typeof(StatusEnum), talentUpdated.StatusId).ToString()
                    };
                    return Json(new { status = talentUpdated.Status });
                }
                return NotFound();
            }
            return BadRequest();
        }

        /// <summary>
        /// Talent/ExportCsvData : Post
        /// </summary>
        [HttpPost]
        [Route("talentdirectory/eportcsv")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> ExportCsvData([FromBody]SearchParametersDto searchParams, int userId)
        {
            var search = _mapper.Map<SearchParameters>(searchParams);
            var talents = await _talentRepository.TalentDataReport(search, userId);
            if (talents != null)
            {
                HttpContext.Response.Headers.Add("content-disposition", "attachment;filename=" + "_FileName" + "_ExportTalentDetails.csv");
                HttpContext.Response.Headers.Remove("Content-Type");
                HttpContext.Response.Headers.Add("Content-Type", "text/csv");

                var headerNames = "Talent Id,Talent UID,Full Name,Email,Gender,DOB,Mobile No.,Whatsup Mobile No.,Talent Profile URL,Onboarded,Profile Completion %,Terms & Condition Accepted,City,Status,Passport Country,Expiry Passport Date,Visa Year,Visa Type," +
                    "About Me,Guardian Name,Guardian Relation,Guardian Mobile No.,Guardian Email,Shared Profile Name,Ftc Rating,Overall Rating,Recruiter Rating,Interest Rating,Rating Notes,Talent Rating Rmark,IsProfilePrivate,Tier," +
                    "Height In Inches,Weight In Kgs,ChestSize In Inches,WaistSize In Inches,Body Type,Skin Color,Eye Color,Hair Color,Hair Length,Hair Type,isVerified,Agency Agent Name,Agency Agent Email,Agency Agent Mobile No,Budget,View Count," +
                    "Address,Ethnicity,Language,Tag,Interest Category,Talent Category,Association,Education,Experience";

                return Json(new
                {
                    result = talents,
                    headers = headerNames.Split(',').ToList()
                });
            }
            return NotFound();
        }

        [HttpPost]
        [Route("specialhost/tatasky")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<ActionResult> TalentSpecialHost([FromBody]TalentSpecialHostDto talentSpecialHostDto, UserInfo userInfo)
        {
            if (userInfo.userType == (int)LoginUserType.Talent)
            {
                talentSpecialHostDto.TalentId = userInfo.userId;
            }

            await _talentSpecialHostRepository.UpdateTalentSpecialHost(talentSpecialHostDto, userInfo.userId, userInfo.userType);


            if (string.IsNullOrEmpty(talentSpecialHostDto.RMN)
                && string.IsNullOrEmpty(talentSpecialHostDto.SubscriberNumber)
                && string.IsNullOrEmpty(talentSpecialHostDto.SubscriberIdText))
                return Json(talentSpecialHostDto);

            var talentSpecialHost = await _talentSpecialHostRepository.SaveTalentSpecialHost(talentSpecialHostDto, userInfo.userId, userInfo.userType);

            return Json(talentSpecialHost);
        }

        [HttpGet]
        [Route("specialhost/tatasky/{specialHostId}/{talentID:int?}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin")]
        public async Task<ActionResult> GetTalentSpecialHost(UserInfo userInfo, int specialHostId, int? talentID = 0)
        {
            int talentId = userInfo.userId;
            if (userInfo.userType == (int)LoginUserType.FTCAdmin)
            {
                talentId = (int)talentID;
            }

            var talentSpecialHost = await _talentSpecialHostRepository.FindAsync(x => x.TalentId == talentId
                                                                                        && x.SpecialHostId == specialHostId
                                                                                        && x.StatusId == (int)StatusEnum.Active);

            if (talentSpecialHost == null)
                return Json(new TalentSpecialHostDto());

            var talentSpecialHostDto = _talentSpecialHostRepository.ConvertToTalentSpecialHostDto(talentSpecialHost);

            talentSpecialHostDto.providerId = _talentSpecialHostRepository.GetProviderId((int)specialHostId);

            return Json(talentSpecialHostDto);
        }
        #endregion

        #region Private Action

        [NonAction]
        private async Task<string> GetOTPForTalent(int talentId, bool? generateNewOTP = false)
        {
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);

            string newOTP = "";

            if ((bool)generateNewOTP)
            {
                newOTP = GenerateOTP();
            }
            else
            {
                newOTP = (string.IsNullOrEmpty(talentToken.Mobile1) || talentToken.Mobile1 == constantActivated) ? GenerateOTP() : talentToken.Mobile1;
            }

            talentToken.Mobile1 = newOTP;

            talentToken = await _talentTokenRepository.UpdateAsync(talentToken);
            return newOTP;
        }

        [NonAction]
        private async Task NotifyTalentWithOTP(TalentNotificationModelDto talentNotificationModelDto, string newOTP, NotificationEnum notificationEnum)
        {
            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            var notificationParam = new NotificationParam
            {
                MobileNumber = talentNotificationModelDto.MobileNumber,
                MobileCountryCode = talentNotificationModelDto.MobileCountryCode,
                Otp = newOTP,
                DeviceOsId = talentNotificationModelDto.DeviceOsId,
                DeviceRegistrationId = talentNotificationModelDto.DeviceRegistrationId,
                TalentId = talentNotificationModelDto.TalentId

            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            await notification.SendNotification(notificationEnum, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private async Task<bool> VerifyOTP(int talentId, string OTP)
        {
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);

            if (talentToken.Mobile1 == OTP)
            {
                talentToken.SMS = constantActivated;
                talentToken.Mobile1 = constantActivated;
                talentToken = await _talentTokenRepository.UpdateAsync(talentToken);

                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// convert ZeroIfEmpty 
        /// </summary>        /// 
        private string ZeroIfEmpty(string s)
        {
            return (string.IsNullOrEmpty(s) || s == null || s == "null") ? "0" : s;
        }

        [NonAction]
        private void LogInformationAsWarning(string message)
        {
            Serilog.Log.Warning("[Information] " + message);
        }

        [NonAction]
        private async Task AddCreateTalentStatusHistory(UserInfo userInfo, Talent talent)
        {
            var talentStatusHistory = new TalentStatusHistory()
            {
                CreatedBy = userInfo.userId,
                CreatedOn = DateTime.Now,
                TalentId = talent.Id,
                StatusId = talent.StatusId,
                FeatureId = (int)AuthorizationFeaturesEnum.CreateTalent
            };

            await _talentStatusHistoryRepository.AddAsync(talentStatusHistory);
        }

        [NonAction]
        private async Task notifyAdminForTalentCSVDownload(int userId)
        {
            //var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            //var notificationParam = new NotificationParam();
            ////{
            ////    FullName = talent.FullName,
            ////    UserPassword = resetPasswordDto.NewPassword,
            ////    Email = talent.Email,
            ////    MobileCountryCode = talent.MobileCountryCode,
            ////    MobileNumber = talent.Mobile,
            ////    DeviceOsId = talent.DeviceOsId,
            ////    DeviceRegistrationId = talent.DeviceRegistrationId
            ////};

            ////RequestSendSystemNotificationDto sendSystemNotificationDto = default(RequestSendSystemNotificationDto);
            ////await notification.SendNotification(NotificationEnum., notificationParam, sendSystemNotificationDto);

            //var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            //await notification.SendNotification(NotificationEnum.CapturePayment, notificationParam, sendSystemNotificationDto);

            /////////////////////
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                AuxiliaryUserId = userId
            };
            //var sendSystemNotificationDto = new RequestSendSystemNotificationDto();

            // Send Email to Auxiliary Users
            //sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userId, (int)NotificationEnum.ProjectApproval, project.Id);
            //var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            //sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            //notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToAuxiliaryUsers
            //{
            //    AuxiliaryUserId = x.Id,
            //    MobileCountryCode = x.MobileCountryCode,
            //    MobileNumber = x.Mobile
            //}).ToList();
            //await notification.SendNotification(NotificationEnum.ProjectApproval, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private async Task notifyTalentWithNewPassword(ResetPasswordDto resetPasswordDto, Talent talent)
        {
            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
            var notificationParam = new NotificationParam()
            {
                FullName = talent.FullName,
                UserPassword = resetPasswordDto.NewPassword,
                Email = talent.Email,
                MobileCountryCode = talent.MobileCountryCode,
                MobileNumber = talent.Mobile,
                DeviceOsId = talent.DeviceOsId,
                DeviceRegistrationId = talent.DeviceRegistrationId,
                TalentId = talent.Id

            };

            RequestSendSystemNotificationDto sendSystemNotificationDto = default(RequestSendSystemNotificationDto);
            await notification.SendNotification(NotificationEnum.ResetPasswordTalentByAdmin, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private TalentShareDetail ConvertToTalentShareDetail(TalentShareDetailDto talentShareDetailDto)
        {
            TalentShareDetail talentShareDetail = new TalentShareDetail();
            talentShareDetail.EmailIds = talentShareDetailDto.EmailIds;
            talentShareDetail.Notes = talentShareDetailDto.Notes;
            talentShareDetail.TalentId = talentShareDetailDto.TalentId;

            return talentShareDetail;
        }

        [NonAction]
        public string GetUserType()
        {
            string userType = HttpContext.Request.Headers["Role"];
            return userType;
        }

        [NonAction]
        private async Task<bool> IsNewUser(string email, string mobileNumber)
        {
            var talentModel = await _talentRepository.FindAsync
                    (
                        x => (x.Email.ToLower() == email && !string.IsNullOrEmpty(x.Email)) ||
                        (x.Mobile == mobileNumber && !string.IsNullOrEmpty(x.Mobile))
                     );
            var auxillaryUserModel = await _auxiliaryUserRepository.FindAsync(
                x => (x.EmailId.ToLower() == email && !string.IsNullOrEmpty(x.EmailId)) ||
                (x.Mobile == mobileNumber && !string.IsNullOrEmpty(x.Mobile))
                );
            if (talentModel == null && auxillaryUserModel == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [NonAction]
        private ResponseLoginDto GetResponseLoginDto(LoginEnum.LoginType loginType, ResponseLoginDto responseLoginDto, LoginEnum.Message returnMessage, LoginEnum.Validation validationType)
        {
            responseLoginDto.ValidateLogin = validationType;
            responseLoginDto.Login = loginType;
            responseLoginDto.ReturnMessage = returnMessage;
            return responseLoginDto;
        }

        [NonAction]
        public void SaveTraceLogin(int userType, int userId, DateTime? loginTime)
        {
            try
            {
                var login = new TraceLogin
                {
                    AuxiliaryUserId = (userType == (int)LoginUserType.Talent) ? (int?)null : userId,
                    TalentId = (userType == (int)LoginUserType.Talent) ? userId : (int?)null,
                    IpAddress = HttpClientHelper.GetRealIP(HttpContext),
                };

                if (loginTime != null)
                {
                    login.LogiinTime = DateTime.UtcNow;
                }

                _traceLoginRepository.Add(login);

            }
            catch (Exception ex)
            {
                Log.Information(ex.ToString());
            }
        }

        [NonAction]
        private ResponseLoginDto ResponseLoginDtoForAuxiliaryUserSuccess(LoginEnum.LoginType loginType, ResponseLoginDto responseLoginDto, AuxiliaryUser auxiliaryUser, AuxiliaryUserToken auxiliaryUserToken, bool isAdmin)
        {
            responseLoginDto.ValidateLogin = LoginEnum.Validation.Success;
            responseLoginDto.Login = loginType;
            responseLoginDto.ReturnMessage = (auxiliaryUserToken.Email == constantActivated) ? LoginEnum.Message.LoginSuccessfull : LoginEnum.Message.Emailisnotverified;

            responseLoginDto.FullName = auxiliaryUser.FullName;
            if ((int)(LoginUserType)auxiliaryUser.TypeId == (int)LoginUserType.Recruiter && !isAdmin)
            {
                responseLoginDto.AuthToken = auxiliaryUser.AuthToken;
            }
            else if ((int)(LoginUserType)auxiliaryUser.TypeId == (int)LoginUserType.FTCAdmin && isAdmin)
            {
                responseLoginDto.AuthToken = auxiliaryUser.AuthToken;
            }
            else
            {
                // if the userType is Recruiter & IsAdmin flag is true
                responseLoginDto.AuthToken = "";
            }

            responseLoginDto.LoginUserType = (LoginEnum.LoginUserType)auxiliaryUser.TypeId;
            responseLoginDto.isOtpVerified = (auxiliaryUserToken.SMS == constantActivated) ? true : false;
            responseLoginDto.TermsConditionAccepted = auxiliaryUser.TermsConditionAccepted;
            responseLoginDto.OnBoarded = auxiliaryUser.Onboarded;

            SaveTraceLogin((int)LoginUserType.Recruiter, auxiliaryUser.Id, DateTime.UtcNow);
            return responseLoginDto;
        }

        [NonAction]
        private async Task<ResponseLoginDto> ResponseLoginDtoForTalentSuccess(LoginEnum.LoginType loginType, ResponseLoginDto responseLoginDto, Talent talent)
        {
            responseLoginDto.ValidateLogin = LoginEnum.Validation.Success;
            responseLoginDto.Login = loginType;
            responseLoginDto.ReturnMessage = LoginEnum.Message.LoginSuccessfull;
            responseLoginDto.AuthToken = talent.AuthToken;
            responseLoginDto.LastTabNo = talent.LastTabNo;
            responseLoginDto.OnBoarded = talent.Onboarded;
            responseLoginDto.FullName = talent.FullName;
            responseLoginDto.TermsConditionAccepted = talent.TermsConditionAccepted;
            responseLoginDto.LoginUserType = LoginEnum.LoginUserType.Talent;
            responseLoginDto.UID = talent.UID;

            await SendUserSettings(responseLoginDto);

            SaveTraceLogin((int)LoginUserType.Talent, talent.Id, DateTime.UtcNow);

            return responseLoginDto;
        }

        private async Task SendUserSettings(ResponseLoginDto responseLoginDto)
        {
            var userSettings = await _paramRepository.GetUserSettings();
            responseLoginDto.IsProfilePicRequired = userSettings.IsProfilePicRequired;
            responseLoginDto.PostLoginRoute = userSettings.PostLoginRoute;
        }

        [NonAction]
        private AuxiliaryUser ConvertToAuxiliaryUserModel(AuxiliaryUserDto auxiliaryUserDto, AuxiliaryUser auxiliaryUser)
        {
            auxiliaryUser.Id = auxiliaryUserDto.Id;
            auxiliaryUser.FullName = auxiliaryUserDto.FullName;
            auxiliaryUser.EmailId = auxiliaryUserDto.EmailId;
            auxiliaryUser.Password = auxiliaryUserDto.Password;
            auxiliaryUser.CreatedBy = auxiliaryUserDto.CreatedBy;
            auxiliaryUser.UpdatedBy = auxiliaryUserDto.UpdatedBy;
            auxiliaryUser.CreatedOn = auxiliaryUserDto.CreatedOn;
            auxiliaryUser.UpdatedOn = auxiliaryUserDto.UpdatedOn;
            auxiliaryUser.Verified = auxiliaryUserDto.Verified;
            auxiliaryUser.VerifiedBy = auxiliaryUserDto.VerifiedBy;
            auxiliaryUser.VerifiedOn = auxiliaryUserDto.VerifiedOn;
            auxiliaryUser.TypeId = (int)LoginEnum.LoginUserType.Recruiter;
            auxiliaryUser.StatusId = auxiliaryUserDto.StatusId;
            auxiliaryUser.Mobile = auxiliaryUserDto.Mobile;
            auxiliaryUser.ParentAuxiliaryUserId = auxiliaryUserDto.ParentAuxiliaryUserId;
            auxiliaryUser.AuthToken = auxiliaryUserDto.AuthToken;
            auxiliaryUser.MobileCountryCode = auxiliaryUserDto.MobileCountryCode;
            auxiliaryUser.Onboarded = auxiliaryUserDto.Onboarded;
            auxiliaryUser.TermsConditionAccepted = auxiliaryUserDto.TermsConditionAccepted;
            auxiliaryUser.ProfileURL = auxiliaryUserDto.ProfileURL;
            auxiliaryUser.MobileCountryId = auxiliaryUserDto.MobileCountryId;
            return auxiliaryUser;
        }

        [NonAction]
        private Talent ConvertToTalentModel(TalentDto talentDto, Talent talent)
        {
            talent.Id = talentDto.Id;
            talent.FullName = talentDto.FullName;
            talent.Email = talentDto.Email;
            talent.Password = talentDto.Password;
            talent.Gender = talentDto.Gender;
            talent.DOB = talentDto.DOB;
            talent.MobileCountryCode = talentDto.MobileCountryCode;
            talent.Mobile = talentDto.Mobile;
            talent.UID = talentDto.UID;
            talent.WhatsupMobile = talentDto.WhatsAppNumber;
            talent.WhatsupCountryCode = talentDto.WhatsAppCountryCode;
            talent.Onboarded = talentDto.OnBoarded;
            talent.LastTabNo = talentDto.LastTabNo;
            talent.CompletionPercentage = talentDto.CompletionPercentage;
            talent.AuthToken = talentDto.AuthToken;
            talent.GuardianName = talentDto.GuardianName;
            talent.GuardianRelation = talentDto.GuardianRelation;
            talent.GuardianMobile = talentDto.GuardianMobile;
            talent.GuardianEmailId = talentDto.GuardianEmailId;
            talent.SharedProfileName = talentDto.SharedProfileName;
            talent.StatusId = talentDto.StatusId;
            talent.TermsConditionAccepted = talentDto.TermsConditionAccepted;
            talent.PassportCountryId = talentDto.PassportCountryId;
            talent.PassportExpirationDate = talentDto.PassportExpirationDate;
            talent.VisaType = talentDto.VisaType;
            talent.VisaYear = talentDto.VisaYear;
            talent.AgencyId = talentDto.AgencyId;
            talent.AgencyAgentName = talentDto.AgencyAgentName;
            talent.AgencyStartDate = talentDto.AgencyStartDate;
            talent.AgencyEndDate = talentDto.AgencyEndDate;
            talent.AgencyAgentMobileNo = talentDto.AgencyAgentMobileNo;
            talent.AgencyAgentEmail = talentDto.AgencyAgentEmail;
            talent.BudgetMin = talentDto.BudgetMin;
            talent.BudgetMax = talentDto.BudgetMax;
            talent.AboutMe = talentDto.AboutMe;
            talent.TalentProfileURL = talentDto.TalentProfileURL;
            talent.MobileCountryId = talentDto.MobileCountryId;
            talent.WhatsupCountryId = talentDto.WhatsupCountryId;
            talent.DeviceOsId = talentDto.DeviceOsId;
            talent.DeviceRegistrationId = talentDto.DeviceRegistrationId;
            return talent;
        }

        [NonAction]
        private async Task SendOtpAsync(string mobilCountryCode, string Mobile, string otp, NotificationEnum notificationDetailType, Notification notification, NotificationParam notificationParam)
        {
            notificationParam.MobileNumber = Mobile;
            notificationParam.Otp = otp;
            notificationParam.MobileCountryCode = mobilCountryCode;

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            await notification.SendNotification(notificationDetailType, notificationParam, sendSystemNotificationDto);
        }

        [NonAction]
        private string GenerateOTP()
        {
            int otp = new Random().Next(100000, 999999);
            return Convert.ToString(otp);

        }

        [NonAction]
        public string RandomString(int length)
        {
            Random random = new Random();
            string pool = Guid.NewGuid().ToString();
            var chars = Enumerable.Range(0, length)
                .Select(x => pool[random.Next(0, pool.Length)]);

            var randomString = new string(chars.ToArray());
            return RemoveSpecialCharactersHelper.RemoveSpecialCharacters(randomString);
        }

        //-------------  GET LIST OF USER to whom notification needs to be send
        //[NonAction]
        //private async Task<List<int>> NotifyListOfAuxiliaryUser(int auxiliaryUserId)
        //{
        //    //  list of au user email, id....user assigned..oles...sys find... add to collection...super admin..whose parent is null.. from au user  a.....super recruiter

        //    //-------------  GET LIST OF USER to whom notification needs to be send
        //    var auxiliaryUserAssigned = await _auxiliaryUserAssignedRepository.FindAllAsync(x => x.AssignedAuxiliaryUserId == auxiliaryUserId);

        //    var lstAuxiliaryUserAssigned = new List<int>();
        //    if (auxiliaryUserAssigned != null)
        //    {
        //        lstAuxiliaryUserAssigned = auxiliaryUserAssigned.Select(x => (int)x.AssignedAuxiliaryUserId).ToList();
        //    }

        //    // get system admin
        //    var lstSystemAdmin = await _auxiliaryUserRoleRepository.FindAllAsync(x => x.RoleId == (int)AuxiliaryUserRoleEnum.SystemAdmin);

        //    // get super admin
        //    var lstSuperAdmin = await _auxiliaryUserRepository.FindAllAsync(x => x.ParentAuxiliaryUserId == null);



        //    var notifyListOfAuxiliaryUser = lstSuperAdmin.Select(x => x.Id).ToList();
        //    notifyListOfAuxiliaryUser.AddRange(lstSystemAdmin.Select(x => (int)x.AuxiliaryUserId).ToList());
        //    notifyListOfAuxiliaryUser.AddRange(lstAuxiliaryUserAssigned);

        //    return notifyListOfAuxiliaryUser;
        //}

        #endregion
    }

    #region PhoneOn Test Code
    public class OtpUserData
    {
        public long MobileNumber { get; set; }
        public string FullName { get; set; }
        public string CountryCode { get; set; }
        public string Email { get; set; }
    }

    public enum SendSmsTo
    {
        ToSingleUser = 1,
        ToAllLocalUsers,
        ToInternationalUsers,
        ToAllUsers
    }
    #endregion

}
