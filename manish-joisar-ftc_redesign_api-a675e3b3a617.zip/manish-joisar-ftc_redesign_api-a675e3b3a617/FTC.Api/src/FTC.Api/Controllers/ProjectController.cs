﻿using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using FTCApi.Dtos.Projects;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class ProjectController : Controller
    {
        private IFileService _fileService;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private AppSettings _appSettings;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private IProjectLocationRepository _projectLocationRepository;
        private ICityRepository _cityRepository;
        private IProductionHouseRepository _productionHouseRepository;
        private IInterestCategoryRepository _interestCategoryRepository;
        private ICountryRepository _countryRepository;
        private IRecruiterPlanRepository _recruiterPlanRepository;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private IEmailService _emailService;
        private IProjectHistoryRepository _projectHistoryRepository;
        private IProjectJobHistoryRepository _projectJobHistoryRepository;

        public ProjectController(IProjectRepository projectRepository,
            IFileService fileService, Microsoft.Extensions.Configuration.IConfiguration configuration,
            IAuxiliaryUserRepository auxiliaryUserRepository,
            IProjectLocationRepository projectLocationRepository,
            ICityRepository cityRepository, IProductionHouseRepository productionHouseRepository,
            IInterestCategoryRepository interestCategoryRepository, ICountryRepository countryRepository,
            IProjectJobRepository projectJobRepository,
            INotificationHeaderRepository notificationHeaderRepository,
            INotificationDetailRepository notificationDetailRepository,
            IUserNotificationRepository userNotificationRepository,
            IEmailService emailService,
            IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository,
            IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
            IRecruiterPlanRepository recruiterPlanRepository, ISmsProviderRepository smsProviderRepository,
            IProjectHistoryRepository projectHistoryRepository,
            IProjectJobHistoryRepository projectJobHistoryRepository)
        {
            _projectRepository = projectRepository;
            _configuration = configuration;
            _projectJobRepository = projectJobRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _appSettings = new AppSettings(_configuration);
            _fileService = fileService;
            _projectLocationRepository = projectLocationRepository;
            _cityRepository = cityRepository;
            _productionHouseRepository = productionHouseRepository;
            _interestCategoryRepository = interestCategoryRepository;
            _countryRepository = countryRepository;
            _recruiterPlanRepository = recruiterPlanRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _notificationDetailRepository = notificationDetailRepository;
            _userNotificationRepository = userNotificationRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _emailService = emailService;
            _smsProviderRepository = smsProviderRepository;
            _projectHistoryRepository = projectHistoryRepository;
            _projectJobHistoryRepository = projectJobHistoryRepository;
        }

        #region Public Actions

        [Route("saveProject")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SaveProject([FromBody]ProjectDto projectDto, UserInfo userInfo)
        {
            Project project = new Project();
            if (projectDto.AuxiliaryUserId == 0)
            {
                projectDto.AuxiliaryUserId = userInfo.userId;
            }

            if (projectDto.Id > 0)
            {
                project = await _projectRepository.FindAsync(x => x.Id == projectDto.Id);
                project = ConvertToProjectModel(userInfo.userId, projectDto, project);
                project.UpdatedBy = userInfo.userId;
                project.UpdatedOn = DateTime.UtcNow;
                project = await _projectRepository.UpdateAsync(project);
                if (projectDto.Locations != null && projectDto.Locations.Count > 0)
                {
                    await SaveLocation(project.Id, projectDto.Locations);
                }
            }
            else
            {
                project = ConvertToProjectModel(userInfo.userId, projectDto, project);
                project.CreatedBy = userInfo.userId;
                project.CreatedOn = DateTime.UtcNow;
                project = await _projectRepository.AddAsync(project);
                projectDto.Id = project.Id;
                if (projectDto.Locations != null && projectDto.Locations.Count > 0)
                {
                    await SaveLocation(project.Id, projectDto.Locations);
                }
                //send notifications only when user creates the project first time
                var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
                var notificationParam = new NotificationParam()
                {
                    ProjectName = project.Name,
                    AuxiliaryUserId = userInfo.userId

                };
                var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                {
                    SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)projectDto.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.ProjectCreation),
                    NotificationReference = NotificationReferenceEnum.Project,
                    NotificationReferenceValue = project.Id,
                    UrlRoute = ViewNotificationEnumDto.EditProject
                };

                // Send Email to Auxiliary Users when a project is Created
                sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.ProjectCreation, project.Id);
                var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                // list with params to send sms
                notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                {
                    AuxiliaryUserId = x.Id,
                    MobileCountryCode = x.MobileCountryCode,
                    MobileNumber = x.Mobile
                }).ToList();

                await notification.SendNotification(NotificationEnum.ProjectCreation, notificationParam, sendSystemNotificationDto);
            }

            return Json(projectDto);
        }
        [HttpPost]
        [Route("verifyproject")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin, Recruiter")]
        public async Task<IActionResult> VerifyProject([FromBody]RequestVerifyProjectDto requestVerifyProjectDto, UserInfo userInfo)
        {
            var project = await _projectRepository.FindAsync(x => x.Id == requestVerifyProjectDto.ProjectId);
            if (project != null)
            {
                var recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
                if (recruiter.Verified == true)
                {
                    project.StatusId = (int)StatusEnum.Verified;
                    project.VerifiedOn = DateTime.UtcNow;
                    project.VerifiedBy = userInfo.userId;
                    if (requestVerifyProjectDto.IsPaidOffline)
                    {
                        project.IsPaid = true;
                        project.IsPaidOffline = true;
                        project.StatusId = (int)StatusEnum.Active;
                    }
                    //need to add custom
                    var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.IsFreePlan && x.StatusId == (int)StatusEnum.Active);

                    if (recruiterPlan != null)
                    {
                        if (project.PlanId == recruiterPlan.Id)
                        {
                            project.IsPaid = true;
                            project.StatusId = (int)StatusEnum.Active;
                        }
                    }
                    project = await _projectRepository.UpdateAsync(project);

                    var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);
                    var notificationParam = new NotificationParam()
                    {
                        ProjectName = project.Name,
                        AuxiliaryUserId = userInfo.userId
                    };
                    var sendSystemNotificationDto = new RequestSendSystemNotificationDto
                    {
                        NotificationReference = NotificationReferenceEnum.Project,
                        NotificationReferenceValue = project.Id,
                        UrlRoute = ViewNotificationEnumDto.EditProject
                    };

                    // Send Email to Auxiliary Users when a project is verified
                    sendSystemNotificationDto.SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAuxiliaryUser((int)project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.ProjectApproval, project.Id);
                    var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
                    sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

                    // list with params to send sms
                    notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
                    {
                        AuxiliaryUserId = x.Id,
                        MobileCountryCode = x.MobileCountryCode,
                        MobileNumber = x.Mobile
                    }).ToList();

                    await notification.SendNotification(NotificationEnum.ProjectApproval, notificationParam, sendSystemNotificationDto);

                    return Ok(new { verified = "true" });

                }
            }
            return Ok(new { verified = "false" });

        }

        [Route("saveProjectBanner")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SaveProjectBanner([FromHeader]int projectId, IFormFile file)
        {
            if (file != null)
            {
                var project = await _projectRepository.FindAsync(x => x.Id == projectId);
                if (!string.IsNullOrEmpty(project.Image))
                {
                    await _fileService.DeleteAsync(project.Image.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                }
                project.Image = await UploadProjectImage(file, project.Id, project.AuxiliaryUserId);
                project = await _projectRepository.UpdateAsync(project);
                return Json(project.Image);
            }
            return BadRequest();

        }

        [Route("removeProjectBanner/{projectId}")]
        [HttpDelete]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> RemoveProjectBanner(int projectId)
        {
            var project = await _projectRepository.FindAsync(x => x.Id == projectId);
            if (project == null)
            {
                return NoContent();
            }
            if (!string.IsNullOrEmpty(project.Image))
            {
                await _fileService.DeleteAsync(project.Image.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
            }
            project.Image = string.Empty;
            project = await _projectRepository.UpdateAsync(project);
            return Json(new { result = "success" });
        }

        [HttpGet]
        [Route("getprojectbyid/{projectId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter, FTCAdmin")]
        public async Task<IActionResult> GetProjectById(int projectId, int userId)
        {
            if (projectId > 0)
            {
                var project = await _projectRepository.FindAsync(x => x.Id == projectId);
                
                var checkAuthorization =_auxiliaryUserRepository.CheckAuthorization(project.AuxiliaryUserId, userId, (int)NotificationEnum.ProjectApproval, project.Id);
                if (!checkAuthorization)
                    return Forbid();

                if (project != null)
                {
                    ProjectDto projectDto = new ProjectDto();
                    projectDto = await ConvertToProjectModelProjectDto(project, projectDto);

                    return Json(projectDto);
                }
                return NotFound();
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetProjectInformationForJobCreation/{projectId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter, FTCAdmin")]
        public async Task<IActionResult> GetProjectInformationForJobCreation(int projectId, int userId)
        {
            if (projectId > 0)
            {
                var project = await _projectRepository.FindAsync(x => x.Id == projectId);
                if (project != null)
                {
                    ProjectDto projectDto = new ProjectDto();
                    try
                    {
                        projectDto = await convertToProjectDto(project, projectDto);
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    return Json(projectDto);
                }
                return NotFound();
            }
            else
            {
                return BadRequest();
            }
        }

        private async Task<ProjectDto> convertToProjectDto(Project project, ProjectDto projectDto)
        {
            projectDto.Id = project.Id;
            projectDto.Name = project.Name;
            projectDto.StartDate = project.StartDate;
            projectDto.EndDate = project.EndDate;
            projectDto.PlanId = project.PlanId;
            projectDto.CastingRequired = project.CastingRequired;
            projectDto.IsPaid = project.IsPaid;
            projectDto.IsPaidOffline = project.IsPaidOffline;
            projectDto.StatusId = project.StatusId;
            var plan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
            if (plan != null)
            {
                projectDto.TotalNumberOfJobs = plan.RoleCount.Value;
            }
            var jobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == project.Id);
            if (jobs != null)
            {
                projectDto.NumberOfJobsCreated = jobs.Sum(x => x.NumberOfRole).Value;
            }
            return projectDto;
        }

        [HttpGet]
        [Route("getprojectsummarybyid/{projectId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter, FTCAdmin")]
        public async Task<IActionResult> GetProjectSummaryById(int projectId, int userId)
        {
            if (projectId > 0)
            {
                var project = await _projectRepository.FindAsync(x => x.Id == projectId);
                if (project != null)
                {
                    var projectSummaryDto = ConvertToProjectModelProjectSummaryDto(project);

                    return Json(projectSummaryDto);
                }
                return NotFound();
            }
            else
            {
                return BadRequest();
            }
        }

        private ProjectSummaryDto ConvertToProjectModelProjectSummaryDto(Project project)
        {
            var projectSummaryDto = new ProjectSummaryDto();
            projectSummaryDto.ProjectId = project.Id;
            projectSummaryDto.ProjectName = project.Name;
            projectSummaryDto.StartDate = project.StartDate;
            projectSummaryDto.EndDate = project.EndDate;
            projectSummaryDto.CreatedOn = project.CreatedOn;

            return projectSummaryDto;
        }

        [Route("manageProjects")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> ManageProject([FromBody]RequestManageProjectDto manageProjectParam, UserInfo userInfo)
        {
            // not used because causing an error : an operation  is already in use in recruiter plan
            //var manageProject = await _projectRepository.ManageProject(manageProjectParam, userInfo.userId);

            var userId = manageProjectParam.RecruiterId > 0 ? manageProjectParam.RecruiterId : userInfo.userId;

            #region Get list of projects

            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);

            IEnumerable<Project> projects = default(IEnumerable<Project>);

            Dictionary<int?, bool> assignedProjects = default(Dictionary<int?, bool>);

            if (isProjectAdmin)
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId);

                // In case of R PA, R JA => get only those Projects or jobs which are assigned to them
                projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == userInfo.userId || assignedProjects.ContainsKey(x.Id));
            }
            else if (isJobAdmin)
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjectsForJobAmin(userInfo.userId);

                // In case of R PA, R JA => get only those Projects or jobs which are assigned to them
                projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == userInfo.userId || assignedProjects.ContainsKey(x.Id));
            }
            else if (isFtcProjectAdmin)
            {
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId, userId);

                // In case of FTC PA
                projects = await _projectRepository.FindAllAsync(x => assignedProjects.ContainsKey(x.Id));
            }
            else
            {
                // in case of FTC Super/Sys, FTC Recruiter Admin
                assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId);

                // this satisfies FTC Super/System Admin, FTC RA, Recruiter, Child recruiter AND NOT FTC PA, R PA, R JA
                projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == userId || assignedProjects.ContainsKey(x.Id));
            }

            #endregion

            var lstProject = projects.ToList();

            if (lstProject == null || lstProject.Count == 0)
            {
                return NotFound();
            }

            #region Search: Project or Job & return  a list of Project
            // on search only show list of projects , no jobs
            if (!string.IsNullOrEmpty(manageProjectParam.Search))
            {
                // if false => search both project and job
                if (manageProjectParam.IncludeJobsInSearch)
                {
                    // to search by job from the list of projects of the recruiter
                    var lstProjectJobId = new List<int>();
                    var lstProjectJob = new List<ProjectJob>();
                    if (lstProject.Count > 0)
                    {
                        foreach (var project in lstProject)
                        {
                            var projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == project.Id);
                            lstProjectJob.AddRange(projectJobs);
                        }

                        lstProjectJob = lstProjectJob.Where(x => x.Title.ToLower().Contains(manageProjectParam.Search.ToLower())).ToList();

                        lstProjectJobId = lstProjectJob.Select(x => x.ProjectId).ToList();


                    }
                    // list of projects which contains the search item {job title}
                    var lstProjectJobSearchResults = lstProject.Where(x => lstProjectJobId.Contains(x.Id)).ToList();
                    lstProject = lstProject.Where(x => x.Name.ToLower().Contains(manageProjectParam.Search.ToLower())).ToList();

                    // final search result containing either project name of job title
                    lstProject = lstProjectJobSearchResults.Union(lstProject).ToList();
                }
                else
                {
                    lstProject = lstProject.Where(x => x.Name.ToLower().Contains(manageProjectParam.Search.ToLower())).ToList();
                }

            }
            #endregion

            #region Status [all, verified and not verified & Paid] FILTER
            if (manageProjectParam.ProjectStatus != ProjectStatusEnum.All)
            {
                // verified projects
                if (manageProjectParam.ProjectStatus == ProjectStatusEnum.Verified)
                {
                    lstProject = lstProject.Where(x => x.StatusId == (int)StatusEnum.Verified).ToList();
                }
                else if (manageProjectParam.ProjectStatus == ProjectStatusEnum.Paid)
                {
                    lstProject = lstProject.Where(x => x.StatusId == (int)StatusEnum.Active).ToList();
                }
                // not verified projects
                else
                {
                    lstProject = lstProject.Where(x => x.StatusId == (int)StatusEnum.Draft).ToList();
                }
            }
            #endregion

            #region pagination of project & Order by CreatedOn
            int projectStartIndex = (manageProjectParam.ProjectCurrentPage > 0) ? ((manageProjectParam.ProjectCurrentPage) * manageProjectParam.ProjectPerPageRecords + 1) : manageProjectParam.ProjectCurrentPage;
            int projectEndIndex = (manageProjectParam.ProjectCurrentPage > 0) ? (projectStartIndex + manageProjectParam.ProjectPerPageRecords) : manageProjectParam.ProjectPerPageRecords;

            var projectCount = lstProject.Count();
            // order by created on
            lstProject = lstProject.OrderByDescending(x => x.CreatedOn)
                                    .Skip(projectStartIndex - 1)
                                    .Take(projectEndIndex - projectStartIndex)
                                    .ToList();
            #endregion

            #region Job results for the specifed projectId & If not present ..get jobs for the first project in the list

            var projectJobCount = 0;
            var listOfProjectJob = new List<ProjectJob>();
            if (string.IsNullOrEmpty(manageProjectParam.Search) && lstProject.Count > 0)
            {
                var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userInfo.userId);

                IEnumerable<ProjectJob> projectJobs = default(IEnumerable<ProjectJob>);
                if (isJobAdmin)
                {
                    projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == lstProject.First().Id);
                    projectJobs = projectJobs.Where(x => assignedProjectJobs.Contains(x.Id));
                }
                else
                {
                    projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == lstProject.First().Id || assignedProjectJobs.Contains(x.Id));
                }

                listOfProjectJob = projectJobs.ToList();


                #region pagination of project Jobs & Order by Name
                int projectJobStartIndex = (manageProjectParam.ProjectJobCurrentPage > 0) ? ((manageProjectParam.ProjectJobCurrentPage) * manageProjectParam.ProjectJobPerPageRecords + 1) : manageProjectParam.ProjectJobCurrentPage;
                int projectJobEndIndex = (manageProjectParam.ProjectJobCurrentPage > 0) ? (projectJobStartIndex + manageProjectParam.ProjectJobPerPageRecords) : manageProjectParam.ProjectJobPerPageRecords;

                projectJobCount = listOfProjectJob.Count();
                // order by created on
                listOfProjectJob = listOfProjectJob.OrderByDescending(x => x.Title)
                                                    .Skip(projectJobStartIndex - 1)
                                                    .Take(projectJobEndIndex - projectJobStartIndex)
                                                    .ToList();
                #endregion
            }




            #endregion

            #region Response Dto
            var manageProject = new ManageProjectDto();
            foreach (var project in lstProject)
            {
                ProjectSummaryDto projectSummaryDto = await _projectRepository.ConvertToProjectSummaryDto(project, manageProjectParam.ProjectId, lstProject.First().Id, listOfProjectJob, projectJobCount, assignedProjects);
                manageProject.Projects.Add(projectSummaryDto);
            }
            manageProject.ProjectCount = projectCount;
            #endregion

            return Json(new { manageProject = manageProject });
        }

        [Route("manageProjects/{projectId}/jobs")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> GetProjectJobsById(int projectId, [FromBody]RequestManageProjectDto projectJobParam, int userId, int userType)
        {
            var project = await _projectRepository.FindAsync(x => x.Id == projectJobParam.ProjectId);
            if (project == null)
            {
                return NotFound();
            }

            // for FTC Su/Sys Admin, FTC RA, FTC PA Get all JOBS
            // for Recruiter, R Child, R PA get all jobs created by them,
            // for R JA - get only jobs assigned

            var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userId);


            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);


            var listOfProjectJob = new List<ProjectJob>();
            // for the selected project fetch the job
            if (projectJobParam.ProjectId > 0)
            {
                IEnumerable<ProjectJob> projectJobs = default(IEnumerable<ProjectJob>);
                if (isJobAdmin)
                {
                    projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectJobParam.ProjectId);
                    projectJobs = projectJobs.Where(x => assignedProjectJobs.Contains(x.Id));
                }
                else
                {
                    projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectJobParam.ProjectId || assignedProjectJobs.Contains(x.Id));
                }

                listOfProjectJob = projectJobs.ToList();
            }

            #region Search: ProjectJob 
            // on search only show list of projects , no jobs
            if (!string.IsNullOrEmpty(projectJobParam.Search) && projectJobParam.IncludeJobsInSearch)
            {
                listOfProjectJob = listOfProjectJob.Where(x => x.Title.ToLower().Contains(projectJobParam.Search.ToLower())).ToList();
            }
            #endregion

            #region pagination of project Jobs & Order by Name
            int projectJobStartIndex = (projectJobParam.ProjectJobCurrentPage > 0) ? ((projectJobParam.ProjectJobCurrentPage) * projectJobParam.ProjectJobPerPageRecords + 1) : projectJobParam.ProjectJobCurrentPage;
            int projectJobEndIndex = (projectJobParam.ProjectJobCurrentPage > 0) ? (projectJobStartIndex + projectJobParam.ProjectJobPerPageRecords) : projectJobParam.ProjectJobPerPageRecords;

            var projectJobCount = listOfProjectJob.Count();
            // order by created on
            listOfProjectJob = listOfProjectJob.OrderByDescending(x => x.Title)
                                                .Skip(projectJobStartIndex - 1)
                                                .Take(projectJobEndIndex - projectJobStartIndex)
                                                .ToList();
            #endregion


            var projectJobPlanDto = new ProjectJobPlanDto();

            #region Response Dto

            var lstProjectJobSummaryDto = new List<ProjectJobSummaryDto>();
            projectJobPlanDto.ProjectPlanConsumed = 0;
            foreach (var projectJob in listOfProjectJob)
            {
                projectJobPlanDto.ProjectPlanConsumed += (int)((projectJob.NumberOfRole != null) ? projectJob.NumberOfRole : 0);
                var projectJobDto = _projectRepository.ConvertToProjectJobSummaryDto(projectJob);
                lstProjectJobSummaryDto.Add(projectJobDto);
            }

            #endregion

            #region Project Plan
            var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
            projectJobPlanDto.ProjectPlan = recruiterPlan != null ? (short)recruiterPlan.RoleCount : (short)0;
            projectJobPlanDto.ProjectPlanId = project.PlanId;
            projectJobPlanDto.ProjectPlanAvailable = projectJobPlanDto.ProjectPlan - projectJobPlanDto.ProjectPlanConsumed;
            #endregion


            return Json(new { ProjectJobs = lstProjectJobSummaryDto, ProjectJobsCount = projectJobCount, ProjectPlan = projectJobPlanDto });
        }


        [HttpGet]
        [Route("checkRecruiterFreePlan/{recruiterId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<CheckRecruiterFreePlanDto> CheckRecruiterFreePlan(int recruiterId, int userId)
        {
            int auxiliaryId;
            if (recruiterId == 0)
            {
                auxiliaryId = userId;
            }
            else
            {
                auxiliaryId = recruiterId;
            }
            CheckRecruiterFreePlanDto checkRecruiterFreePlanDto = new CheckRecruiterFreePlanDto();
            var projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryId);
            if (projects != null && projects.Count() > 0)
            {
                projects = projects.Where(x => x.CreatedOn.Date > DateTime.UtcNow.Subtract(TimeSpan.FromDays(30)).Date);
                if (projects.Count() > 0)
                {
                    var planIds = projects.Select(x => x.PlanId);
                    //need to add custom
                    var recruiterPlans = await _recruiterPlanRepository.FindAsync(x => planIds.Contains(x.Id) && x.IsFreePlan && x.StatusId == (int)StatusEnum.Active);
                    if (recruiterPlans != null)
                    {
                        projects = projects.Where(x => x.PlanId == recruiterPlans.Id);
                        checkRecruiterFreePlanDto.IsFreePlanUsed = true;
                        checkRecruiterFreePlanDto.PlanId = recruiterPlans.Id;
                        checkRecruiterFreePlanDto.Date = String.Format("{0:dd-MM-yyyy}", projects.Max(x => x.CreatedOn));

                    }
                }
            }
            return checkRecruiterFreePlanDto;
        }

        [HttpPut]
        [Route("upgradeProjectPlan/{projectId}/{planId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> UpgradeProjectPlan(int projectId, int planId, UserInfo userInfo)
        {
            if (planId == 0 || projectId == 0)
            {
                return BadRequest();
            }

            var project = await _projectRepository.FindAsync(x => x.Id == projectId);
            var plan = await _recruiterPlanRepository.FindAsync(x => x.Id == planId);

            project.PlanId = planId;

            //get all history details from the history table to get all the previous plans
            var totalPreviousMonths = _projectHistoryRepository.getTotalRenewedMonths(projectId);


            //doesnt handle null value because startdate and projectValidity are not nullable fields
            project.EndDate = project.StartDate.Value.AddMonths(plan.ProjectValidity.Value + totalPreviousMonths) < project.EndDate ? project.EndDate : project.StartDate.Value.AddMonths(plan.ProjectValidity.Value + totalPreviousMonths).AddDays(-1);
            project.UpdatedOn = DateTime.UtcNow;
            project.UpdatedBy = userInfo.userId;
            var updatedJob = await _projectRepository.UpdateAsync(project);
            return new JsonResult(new { status = "success" });
        }

        [HttpGet]
        [Route("upgradePlan/{planId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<RecruiterPlanDto> UpgradePlan(int planId)
        {
            var recruiterPlanDto = new RecruiterPlanDto();
            //fetch the current plan
            var currentPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == planId);

            if (currentPlan != null)
            {
                var planstoUpgrade = await _recruiterPlanRepository.FindAllAsync(x => x.Amount > currentPlan.Amount && x.StatusId == (int)StatusEnum.Active);
                //need to add custom

                if (planstoUpgrade != null && planstoUpgrade.Count() > 0)
                {

                    var plantoUpgrade = planstoUpgrade.OrderBy(x => x.Amount).FirstOrDefault();
                    recruiterPlanDto = createRecruiterPlanDto(plantoUpgrade);
                    //assign the previous plan amount
                    recruiterPlanDto.previousPlanAmount = currentPlan.Amount;
                }
            }
            return recruiterPlanDto;
        }


        [HttpGet]
        [Route("currentPlan/{planId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<RecruiterPlanDto> CurrentPlan(int planId)
        {
            var recruiterPlanDto = new RecruiterPlanDto();
            //fetch the current plan
            var currentPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == planId);

            if (currentPlan != null)
            {
                recruiterPlanDto = createRecruiterPlanDto(currentPlan);
            }
            return recruiterPlanDto;
        }

        private RecruiterPlanDto createRecruiterPlanDto(RecruiterPlan recruiterPlan)
        {
            return new RecruiterPlanDto
            {
                Id = recruiterPlan.Id,
                PlanName = recruiterPlan.Name,
                Amount = recruiterPlan.Amount,
                RoleCount = recruiterPlan.RoleCount,
                Description = recruiterPlan.Description,
                RecommendedCount = recruiterPlan.RecommendedCount,
                selectedForAudition = recruiterPlan.AuditionSelectionCount,
                IsViewPortfolio = recruiterPlan.ViewPortfolio,
                IsOnlineAudition = recruiterPlan.AllowedOnlineAudition,
                IsProvideNotesRating = recruiterPlan.ProvideNotesRating,
                ProjectValidity = recruiterPlan.ProjectValidity,
                IsManagePayments = recruiterPlan.ManagePayments,
                IsSocialIntegration = recruiterPlan.SocialIntegration,
                IsDiscountOnStudioBooking = recruiterPlan.DiscountOnStudioBooking,
                IsDedicatedSupport = recruiterPlan.DedicatedSupport,
                NumberOfUsers = recruiterPlan.NumberOfUsers,
                Customized = recruiterPlan.Customized,
                ManageContract = recruiterPlan.ManageContract,
                ViewAuditionHistory = recruiterPlan.ViewAuditionHistory,
            };
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="manageProjectParam"></param>
        /// <param name="userInfo"></param>
        /// <returns></returns>
        [Route("manageProjectsDuplicate")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> ManageProjectDuplicate([FromBody]RequestManageProjectDto manageProjectParam, UserInfo userInfo)
        {
            int recruiterId = 0;
            if (userInfo.userType == (int)LoginUserType.FTCAdmin)
            {
                recruiterId = manageProjectParam.RecruiterId;
            }
            else
            {
                recruiterId = userInfo.userId;
            }


            var manageProject = await _projectRepository.ManageProject(manageProjectParam, userInfo.userId);



            return Json(new { manageProject = manageProject });


        }


        [HttpPost]
        [Route("renewProjectPlan")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> RenewProjectPlan([FromBody]RenewalDto renewalDto, UserInfo userInfo)
        {
            var projectPlan = default(RecruiterPlan);
            if (renewalDto == null)
            {
                return BadRequest();
            }

            var project = await _projectRepository.FindAsync(x => x.Id == renewalDto.ProjectId);
            if (project != null)
            {
                projectPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
            }
            // var plan = await _recruiterPlanRepository.FindAsync(x => x.Id == planId);

            //insert the entry into project historyTable

            var projectHistory = new ProjectHistory()
            {
                ProjectId = project.Id,
                StartDate = project.StartDate,
                EndDate = project.EndDate,
                UpdatedBy = userInfo.userId,
                PlanId = project.PlanId
            };

            await _projectHistoryRepository.AddAsync(projectHistory);

            //update the project table

            project.EndDate = project.EndDate.Value.AddMonths(projectPlan.ProjectValidity.Value);
            project.UpdatedOn = DateTime.UtcNow;
            project.UpdatedBy = userInfo.userId;
            //update the Project Details
            var updatedJob = await _projectRepository.UpdateAsync(project);


            foreach (var job in renewalDto.Jobs)
            {
                //insert the entry into projectJob historyTale
                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == job.JobId);

                var projectJobHistory = new ProjectJobHistory() { JobId = job.JobId, StartDate = projectJob.StartDate, EndDate = projectJob.EndDate, UpdatedBy = userInfo.userId };
                await _projectJobHistoryRepository.AddAsync(projectJobHistory);

                //Update the job data

                projectJob.EndDate = job.NewJobEndDate;
                await _projectJobRepository.UpdateAsync(projectJob);
            }

            return new JsonResult(new { status = "success" });
        }

        [HttpGet]
        [Route("getJobsByProjectId/{projectId}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter")]
        public async Task<IActionResult> GetJobsByProjectId(int projectId)
        {
            RenewalDto renewalDto = new RenewalDto();
            List<JobRenewalDto> jobRenewalDtoList = new List<JobRenewalDto>();
            if (projectId == 0)
            {
                return BadRequest();
            }
            //Get the plan id based on the project
            var project = await _projectRepository.FindAsync(x => x.Id == projectId);
            if (project != null)
            {
                var projectPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
                renewalDto.RenewalAmount = projectPlan != null ? projectPlan.Amount : 0;
                renewalDto.NewProjectEndDate = project.EndDate.Value.AddMonths(projectPlan.ProjectValidity.Value);
                renewalDto.ProjectName = project.Name;
                renewalDto.ProjectStartDate = project.StartDate;
                renewalDto.ProjectEndDate = project.EndDate;
                renewalDto.PlanName = projectPlan.Name;

            }

            var projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId && x.StatusId != (int)StatusEnum.Close);
            foreach (var projectJob in projectJobs)
            {
                JobRenewalDto jobRenewalDto = new JobRenewalDto();
                jobRenewalDto.JobId = projectJob.Id;
                jobRenewalDto.JobName = projectJob.Title;
                jobRenewalDto.JobEndDate = projectJob.EndDate;
                jobRenewalDto.JobStartDate = projectJob.StartDate;
                jobRenewalDtoList.Add(jobRenewalDto);
            }
            renewalDto.Jobs = jobRenewalDtoList;

            return Json(renewalDto);
        }


        #endregion

        #region Private Methods

        [NonAction]
        private async Task SaveLocation(int projectId, List<LocationDto> locations)
        {
            var cityids = locations.Select(x => x.Id).ToList();

            var projectLocations = await _projectLocationRepository.FindAllAsync(x => x.ProjectId == projectId);
            List<ProjectLocation> lstprojectLocations = projectLocations.ToList();

            if (projectLocations != null && projectLocations.Count() > 0)
            {
                var locationsToBDeleted = projectLocations.Where(x => !cityids.Contains(x.CityId));
                foreach (var locationToBDeleted in locationsToBDeleted)
                {
                    lstprojectLocations.RemoveAll(x => x.Id == locationToBDeleted.Id);
                    await _projectLocationRepository.DeleteAsync(locationToBDeleted);
                }
            }
            if (lstprojectLocations != null && lstprojectLocations.Count > 0)
            {
                foreach (var lstprojectLocation in lstprojectLocations)
                {
                    cityids.RemoveAll(x => x.Value == lstprojectLocation.CityId);
                }
            }
            if (cityids != null && cityids.Count > 0)
            {
                foreach (var cityid in cityids)
                {
                    ProjectLocation prjectLocationModel = new ProjectLocation();
                    var city = await _cityRepository.FindAsync(x => x.CityId == cityid);
                    prjectLocationModel.ProjectId = projectId;
                    prjectLocationModel.CityId = city.CityId;
                    prjectLocationModel.CountryId = city.CityCountryId;
                    prjectLocationModel = await _projectLocationRepository.AddAsync(prjectLocationModel);
                }
            }
        }


        [NonAction]
        private async Task<ProjectDto> ConvertToProjectModelProjectDto(Project project, ProjectDto projectDto)
        {
            projectDto.Id = project.Id;
            projectDto.Name = project.Name;
            projectDto.Description = project.Description;
            projectDto.StartDate = project.StartDate;
            projectDto.EndDate = project.EndDate;
            projectDto.EventDate = project.EventDate;
            projectDto.TheatreGroup = project.TheatreGroup;
            projectDto.Image = project.Image;
            projectDto.ProductionHouse = project.ProductionHouse;
            projectDto.DirectorName = project.DirectorName;
            projectDto.ProducerName = project.ProducerName;
            projectDto.PlanId = project.PlanId;
            projectDto.CompanyBrand = project.CompanyBrand;
            projectDto.AdAgency = project.AdAgency;
            projectDto.CastingRequired = project.CastingRequired;
            projectDto.IsPaid = project.IsPaid;
            projectDto.IsPaidOffline = project.IsPaidOffline;
            projectDto.StatusId = project.StatusId;


            var projectPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
            if (projectPlan != null)
            {
                projectDto.IsFreePlan = projectPlan.IsFreePlan;
            }
            //projectDto.CreativeTeam = project.CreativeTeam;


            if (project.ProductionHouseId != null && project.ProductionHouseId > 0)
            {
                projectDto.ProductionHouseId = project.ProductionHouseId;
                var productionHouse = await _productionHouseRepository.FindAsync(x => x.Id == project.ProductionHouseId);
                projectDto.ProductionHouseDescription = productionHouse.Description;
            }

            if (project.InterestId != null && project.InterestId > 0)
            {
                projectDto.InterestId = project.InterestId;
                var interestCategory = await _interestCategoryRepository.FindAsync(x => x.Id == project.InterestId);
                projectDto.InterestDescription = interestCategory.Description;
            }


            projectDto.AdAgencyId = project.AdAgencyId;
            var adAgency = await _productionHouseRepository.FindAsync(x => x.Id == project.AdAgencyId);
            if (adAgency != null)
            {
                projectDto.AdAgencyDescription = adAgency.Description;
            }


            projectDto.AuxiliaryUserId = project.AuxiliaryUserId;
            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
            if (auxiliaryUser != null)
            {
                projectDto.AuxiliaryUserName = auxiliaryUser.FullName;
                projectDto.AuxiliaryUserEmail = auxiliaryUser.EmailId;
                projectDto.AuxiliaryUserMobile = auxiliaryUser.Mobile;
            }

            projectDto.Locations = await ConvertToLocationDto(project.Id);


            return projectDto;
        }

        [NonAction]
        private async Task<List<LocationDto>> ConvertToLocationDto(int projectId)
        {
            List<LocationDto> lstLocationDto = new List<LocationDto>();
            var projectLocations = await _projectLocationRepository.FindAllAsync(x => x.ProjectId == projectId);
            if (projectLocations != null)
            {
                foreach (var projectLocation in projectLocations)
                {
                    LocationDto locationDto = new LocationDto();
                    locationDto.Id = projectLocation.CityId;
                    var country = await _countryRepository.FindAsync(x => x.Id == projectLocation.CountryId);
                    var city = await _cityRepository.FindAsync(x => x.CityId == projectLocation.CityId);
                    locationDto.Description = city.CityDescription + ',' + country.Name;
                    lstLocationDto.Add(locationDto);
                }
            }
            return lstLocationDto;
        }


        [NonAction]
        private async Task<string> UploadProjectImage(IFormFile file, int projectId, int? recruiterId)
        {
            if (file != null && file.Length > 0)
            {
                string targetPath = _appSettings.MediaBasePath;
                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);
                string savedPath;
                savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetAuxiliaryFolder + recruiterId.ToString() + "/" + _appSettings.GetProjectFolder + projectId.ToString()), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);

                savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);
                return UserAccessiblePath(savedPath, _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
            }
            return null;
        }

        [NonAction]
        private string CreateUniqueFileName(string fileName)
        {
            int idx = fileName.LastIndexOf('.');
            //get filename
            string name = fileName.Substring(0, idx);
            //name = name.Trim().Replace(" ", string.Empty);
            name = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(name);
            //get extention
            string extenstion = fileName.Substring(idx + 1);

            return name + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "." + extenstion;
        }

        [NonAction]
        private string ApplicationAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is FileService)
            {
                return filePath.ToApplicationAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToApplicationAccessibleS3Path(baseURL, bucketName);
            }
            return filePath;
        }

        [NonAction]
        private string UserAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is Infrastructure.FileService)
            {
                return filePath.ToUserAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToUserAccessibleS3Path(bucketName, baseURL);
            }

            return filePath;
        }
        [NonAction]
        private Project ConvertToProjectModel(int userId, ProjectDto projectDto, Project project)
        {
            project.AuxiliaryUserId = projectDto.AuxiliaryUserId;
            project.Name = projectDto.Name;
            project.Description = projectDto.Description;
            project.InterestId = projectDto.InterestId;
            project.StartDate = projectDto.StartDate;
            project.EndDate = projectDto.EndDate;
            project.EventDate = projectDto.EventDate;
            project.TheatreGroup = projectDto.TheatreGroup;
            project.ProductionHouse = projectDto.ProductionHouse;
            project.DirectorName = projectDto.DirectorName;
            project.ProducerName = projectDto.ProducerName;
            //project.StatusId = projectDto.StatusId;
            project.ProductionHouseId = projectDto.ProductionHouseId;
            project.PlanId = projectDto.PlanId;
            project.CompanyBrand = projectDto.CompanyBrand;
            project.AdAgencyId = projectDto.AdAgencyId;
            project.AdAgency = projectDto.AdAgency;
            project.CastingRequired = projectDto.CastingRequired;
            return project;
        }

        #endregion
    }
}
