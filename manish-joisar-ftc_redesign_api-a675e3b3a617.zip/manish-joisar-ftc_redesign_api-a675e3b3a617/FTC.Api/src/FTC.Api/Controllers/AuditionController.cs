﻿using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.JobAuditionsDtos;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class AuditionController : Controller
    {
        private AppSettings _appSettings;
        private readonly IConfiguration _configuration;
        private IFileService _fileService;
        private IProjectJobRepository _projectJob;
        private IProjectRepository _project;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IJobAuditionRepository _jobAuditionRepository;
        private IJobAuditionTalentRepository _jobAuditionTalentRepository;
        private IJobMediaRepository _jobMediaRepository;
        private IMediaFileRepository _mediaFileRepository;
        private IProjectJobRepository _projectJobRepository;
        private IFileTypeRepository _fileTypeRepository;
        private IInterestCategoryRepository _interestCategoryRepository;
        public AuditionController(IConfiguration configuration, IProjectJobRepository projectJob, IProjectRepository project,
            IAuxiliaryUserRepository auxiliaryUserRepository, IJobAuditionRepository jobAuditionRepository, IJobAuditionTalentRepository jobAuditionTalentRepository,
            IJobMediaRepository jobMediaRepository, IMediaFileRepository mediaFileRepository,
        IFileService fileService, IProjectJobRepository projectJobRepository, IFileTypeRepository fileTypeRepository, IInterestCategoryRepository interestCategoryRepository)
        {
            _projectJob = projectJob;
            _project = project;
            _configuration = configuration;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _jobAuditionRepository = jobAuditionRepository;
            _jobAuditionTalentRepository = jobAuditionTalentRepository;
            _jobMediaRepository = jobMediaRepository;
            _mediaFileRepository = mediaFileRepository;
            _fileService = fileService;
            _projectJobRepository = projectJobRepository;
            _fileTypeRepository = fileTypeRepository;
            _interestCategoryRepository = interestCategoryRepository;
            _appSettings = new AppSettings(_configuration);
        }
        // GET: api/values
        [HttpGet]
        [Route("getJobDetailById/{jobId}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetJobById(int jobId, int userId)
        {
            var projectJob = await _projectJob.FindAsync(x => x.Id == jobId);
            if (projectJob == null)
            {
                return NotFound();
            }
            else
            {
                AuditionJobDetailDto auditionJobDetailDto = new AuditionJobDetailDto();
                var project = await _project.FindAsync(x => x.Id == projectJob.ProjectId);
                var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == project.AuxiliaryUserId);
                var intersertCategory = await _interestCategoryRepository.FindAsync(x => x.Id == project.InterestId);

                auditionJobDetailDto.RecruiterName = auxiliaryUser.FullName;
                auditionJobDetailDto.CreatedOn = projectJob.CreatedOn;
                auditionJobDetailDto.StartDate = projectJob.StartDate;
                auditionJobDetailDto.EndDate = projectJob.EndDate;
                auditionJobDetailDto.Title = projectJob.Title;
                auditionJobDetailDto.ReferenceMedia = projectJob.ReferenceMedia;
                auditionJobDetailDto.MediaFiletypeId = projectJob.MediaFiletypeId;
                auditionJobDetailDto.InterestCategory = intersertCategory.Description;
                auditionJobDetailDto.ProfileUrl = auxiliaryUser.ProfileURL;
                return Json(auditionJobDetailDto);
            }
        }

        [HttpGet]
        [Route("getAllRoundonJobIdId/{jobId}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetAllRoundonJobIdId(int jobId, int userId)
        {
            var jobAuditions = await _jobAuditionRepository.FindAllAsync(x => x.JobId == jobId);
            var offlineAudition = jobAuditions.Where(x => x.AuditionTypeId == 2).ToList();
            var onlinejobAuditions = jobAuditions.Where(x => x.AuditionTypeId == 1).ToList();
            if (jobAuditions == null)
            {
                return NotFound();
            }
            else
            {
                TalentAuditionDto talentAuditionDto = new TalentAuditionDto();
                var currentJobAudition = new JobAudition();
                if (onlinejobAuditions != null && onlinejobAuditions.Count > 0)
                {
                    var jobAuditionIds = onlinejobAuditions.Select(x => (int?)x.Id).ToList();
                    var jobAuditionTalent = await _jobAuditionTalentRepository.FindAllAsync(x => jobAuditionIds.Contains(x.JobAuditionId) && x.TalentId == userId);
                    if (jobAuditionTalent.Count() > 0)
                    {
                        var talentJobAuditionIds = jobAuditionTalent.Select(x => (int)x.JobAuditionId);
                        onlinejobAuditions = onlinejobAuditions.Where(x => talentJobAuditionIds.Contains(x.Id)).ToList();
                        talentAuditionDto.NumberOfRounds = onlinejobAuditions.Count();

                        foreach (var jobAudition in onlinejobAuditions)
                        {
                            Rounds rounds = new Rounds();
                            rounds.JobAuditionId = jobAudition.Id;
                            rounds.RoundNumbers = jobAudition.RoundNumber;
                            talentAuditionDto.Rounds.Add(rounds);
                            talentAuditionDto.Rounds = talentAuditionDto.Rounds.OrderByDescending(x => x.JobAuditionId).ToList();
                        }
                        var maxRound = talentAuditionDto.Rounds.OrderByDescending(x => x.RoundNumbers).FirstOrDefault();
                        var jobMedia = await _jobMediaRepository.FindAsync(x => x.JobAuditionId == maxRound.JobAuditionId && x.TalentId == userId);
                        if (jobMedia != null)
                        {
                            talentAuditionDto.IsJobAuditionDisabled = true;
                            var media = await _mediaFileRepository.FindAsync(x => x.Id == jobMedia.MediaFileId);
                            talentAuditionDto.JobMediaFile = media.FilePath;
                            talentAuditionDto.Notes = jobMedia.Notes;
                        }
                        talentAuditionDto.CurrentJobAuditionId = maxRound.JobAuditionId;
                        currentJobAudition = onlinejobAuditions.Where(x => x.Id == talentAuditionDto.CurrentJobAuditionId).FirstOrDefault();

                        JobAuditionDto jobAuditionDto = new JobAuditionDto();
                        jobAuditionDto.Id = currentJobAudition.Id;
                        jobAuditionDto.JobId = currentJobAudition.JobId;
                        jobAuditionDto.Brief = currentJobAudition.Brief;
                        jobAuditionDto.Instruction = currentJobAudition.Instruction;
                        jobAuditionDto.ReferenceMedia = currentJobAudition.ReferenceMedia;
                        jobAuditionDto.Address = currentJobAudition.Address;
                        jobAuditionDto.RoundNumber = currentJobAudition.RoundNumber;
                        jobAuditionDto.StartDate = currentJobAudition.StartDate;
                        jobAuditionDto.EndDate = currentJobAudition.EndDate;
                        jobAuditionDto.StartTime = currentJobAudition.StartTime;
                        jobAuditionDto.EndTime = currentJobAudition.EndTime;

                        talentAuditionDto.CurrentJobAudition = jobAuditionDto;
                    }
                }
                if (offlineAudition != null && offlineAudition.Count > 0)
                {
                    var jobAuditionTalent = await _jobAuditionTalentRepository.FindAsync(x => x.JobAuditionId == offlineAudition.FirstOrDefault().Id && x.TalentId == userId);
                    if (jobAuditionTalent != null)
                    {
                        talentAuditionDto.OfflineRoundExist = true;
                        talentAuditionDto.OfflineAuditionId = jobAuditionTalent.JobAuditionId;
                        talentAuditionDto.CurrentJobAuditionId = (int)jobAuditionTalent.JobAuditionId;
                        currentJobAudition = offlineAudition.Where(x => x.Id == talentAuditionDto.CurrentJobAuditionId).FirstOrDefault();
                    }
                }

                return Json(talentAuditionDto);
            }
        }

        [HttpGet]
        [Route("getFileTypes/{fileType}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> GetFileTypes(int fileType)
        {
            var fileTypes = await _fileTypeRepository.FindAsync(x => x.Id == fileType);
            return Json(fileTypes.AllowedExtensions);
        }

        [HttpGet]
        [Route("getRoundDetailsId/{jobAuditionId}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> GetRoundDetailsId(int jobAuditionId, int userId)
        {
            var jobMedia = await _jobMediaRepository.FindAsync(x => x.JobAuditionId == jobAuditionId && x.TalentId == userId);
            TalentAuditionDto talentAuditionDto = new TalentAuditionDto();
            if (jobMedia != null)
            {
                talentAuditionDto.IsJobAuditionDisabled = true;
                var media = await _mediaFileRepository.FindAsync(x => x.Id == jobMedia.MediaFileId);
                talentAuditionDto.JobMediaFile = media.FilePath;
                talentAuditionDto.Notes = jobMedia.Notes;

            }
            var jobAudition = await _jobAuditionRepository.FindAsync(x => x.Id == jobAuditionId);
            JobAuditionDto jobAuditionDto = new JobAuditionDto();
            jobAuditionDto.Id = jobAudition.Id;
            jobAuditionDto.JobId = jobAudition.JobId;
            jobAuditionDto.Brief = jobAudition.Brief;
            jobAuditionDto.Instruction = jobAudition.Instruction;
            jobAuditionDto.ReferenceMedia = jobAudition.ReferenceMedia;
            jobAuditionDto.Address = jobAudition.Address;
            jobAuditionDto.RoundNumber = jobAudition.RoundNumber;
            jobAuditionDto.StartDate = jobAudition.StartDate;
            jobAuditionDto.EndDate = jobAudition.EndDate;
            jobAuditionDto.StartTime = jobAudition.StartTime;
            jobAuditionDto.EndTime = jobAudition.EndTime;
            talentAuditionDto.CurrentJobAudition = jobAuditionDto;
            return Json(talentAuditionDto);
        }

        [HttpGet]
        [Route("getMediasByJobIdAndTalentId/{talentId}/{jobId}")]
        public async Task<IActionResult> GetMediasByJobIdAndTalentId(int talentId, int jobId, int userId)
        {
            var job = await _projectJobRepository.FindAsync(x => x.Id == jobId);
            var jobMedia = await _jobMediaRepository.FindAllAsync(x => x.JobId == jobId && x.TalentId == talentId);
            if (jobMedia != null)
            {
                var jobAuditionIdList = jobMedia.Select(x => x.JobAuditionId);

                var jobAuditionList = await _jobAuditionRepository.FindAllAsync(x => jobAuditionIdList.Contains(x.Id));

                var onlineAuditionList = jobAuditionList.Where(x => x.AuditionTypeId == 1).Select(y => y.Id).ToList();
                var offlineAuditionList = jobAuditionList.Where(x => x.AuditionTypeId == 2).Select(y => y.Id).ToList();

                var onlineJobMedias = jobMedia.Where(x => onlineAuditionList.Contains((int)x.JobAuditionId));
                var offlineJobMedias = jobMedia.Where(x => offlineAuditionList.Contains((int)x.JobAuditionId));
                List<MediaWithRounDNameDto> lstOnlineMediaWithRounDNameDto = new List<MediaWithRounDNameDto>();
                foreach (var onlineJobMedia in onlineJobMedias)
                {
                    MediaWithRounDNameDto onlineMediaWithRounDNameDto = new MediaWithRounDNameDto();
                    var mediaFile = await _mediaFileRepository.FindAsync(x => x.Id == onlineJobMedia.MediaFileId);
                    onlineMediaWithRounDNameDto.MediaPath = mediaFile.FilePath;
                    onlineMediaWithRounDNameDto.RoundName = jobAuditionList.Where(x => x.Id == onlineJobMedia.JobAuditionId).FirstOrDefault().Brief;
                    lstOnlineMediaWithRounDNameDto.Add(onlineMediaWithRounDNameDto);
                }
                List<MediaWithRounDNameDto> lstOfflineMediaWithRounDNameDto = new List<MediaWithRounDNameDto>();
                foreach (var offlineJobMedia in offlineJobMedias)
                {
                    MediaWithRounDNameDto offlineMediaWithRounDNameDto = new MediaWithRounDNameDto();
                    var mediaFile = await _mediaFileRepository.FindAsync(x => x.Id == offlineJobMedia.MediaFileId);
                    offlineMediaWithRounDNameDto.MediaPath = mediaFile.FilePath;
                    offlineMediaWithRounDNameDto.RoundName = jobAuditionList.Where(x => x.Id == offlineJobMedia.JobAuditionId).FirstOrDefault().Brief;
                    lstOfflineMediaWithRounDNameDto.Add(offlineMediaWithRounDNameDto);
                }

                var talentMediaFileList = new List<MediaWithRounDNameDto>(lstOnlineMediaWithRounDNameDto);
                talentMediaFileList.AddRange(lstOfflineMediaWithRounDNameDto);
                return Ok(new { onlineMediaPathList = lstOnlineMediaWithRounDNameDto, offlineMediaPathList = lstOfflineMediaWithRounDNameDto, jobMediaType = job.MediaFiletypeId, talentMediaFileList = talentMediaFileList });
            }
            return null;
        }



        [HttpPost]
        [Route("saveMedia")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> SaveMedia([FromHeader] IFormFile file, string notes, int jobId, int auditionId, int fileType, int userId)
        {
            if (file != null)
            {
                TalentAuditionDto talentAuditionDto = new TalentAuditionDto();

                talentAuditionDto.JobMediaFile = await UploadAuditionMedia(file, jobId, auditionId, userId);

                MediaFile mediaFile = new MediaFile();
                mediaFile.FileTypeId = fileType;
                mediaFile.FileName = talentAuditionDto.JobMediaFile.Substring(talentAuditionDto.JobMediaFile.LastIndexOf('=') + 1);
                mediaFile.FilePath = talentAuditionDto.JobMediaFile;
                mediaFile.IsExternalUrl = false;
                mediaFile.CreatedOn = DateTime.UtcNow;
                mediaFile.UpdatedOn = DateTime.UtcNow;
                string mime = MimeKit.MimeTypes.GetMimeType(mediaFile.FileName);
                mediaFile.FileMimeType = mime;
                mediaFile = await _mediaFileRepository.AddAsync(mediaFile);

                JobMedia jobMedia = new JobMedia();
                jobMedia.JobId = jobId;
                jobMedia.TalentId = userId;
                jobMedia.JobAuditionId = auditionId;
                jobMedia.MediaFileId = mediaFile.Id;
                jobMedia.CreatedOn = DateTime.UtcNow;
                jobMedia.Notes = notes;
                jobMedia = await _jobMediaRepository.AddAsync(jobMedia);


                talentAuditionDto.IsJobAuditionDisabled = true;
                talentAuditionDto.Notes = notes;
                return Json(talentAuditionDto);
            }
            return BadRequest();
        }

        [HttpPost]
        [Route("saveOfflineMedia")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> SaveOfflineMedia([FromHeader] IFormFile file, int jobId, int auditionId, int fileType, int talentId, int userId)
        {
            if (file != null)
            {
                TalentAuditionDto talentAuditionDto = new TalentAuditionDto();
                var jobMediaModel = await _jobMediaRepository.FindAsync(x => x.JobId == jobId && x.JobAuditionId == auditionId && x.TalentId == talentId);
                if (jobMediaModel != null)
                {
                    var mediaFileModel = await _mediaFileRepository.FindAsync(x => x.Id == jobMediaModel.MediaFileId);
                    await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));
                    await _mediaFileRepository.DeleteAsync(mediaFileModel);

                    talentAuditionDto.JobMediaFile = await UploadAuditionMedia(file, jobId, auditionId, talentId);

                    MediaFile mediaFile = new MediaFile();
                    mediaFile.FileTypeId = fileType;
                    mediaFile.FileName = talentAuditionDto.JobMediaFile.Substring(talentAuditionDto.JobMediaFile.LastIndexOf('=') + 1);
                    mediaFile.FilePath = talentAuditionDto.JobMediaFile;
                    mediaFile.IsExternalUrl = false;
                    mediaFile.CreatedOn = DateTime.UtcNow;
                    mediaFile.UpdatedOn = DateTime.UtcNow;
                    string mime = MimeKit.MimeTypes.GetMimeType(mediaFile.FileName);
                    mediaFile.FileMimeType = mime;
                    mediaFile = await _mediaFileRepository.AddAsync(mediaFile);

                    jobMediaModel.MediaFileId = mediaFile.Id;
                    jobMediaModel = await _jobMediaRepository.UpdateAsync(jobMediaModel);

                }
                else
                {
                    talentAuditionDto.JobMediaFile = await UploadAuditionMedia(file, jobId, auditionId, talentId);
                    MediaFile mediaFile = new MediaFile();
                    mediaFile.FileTypeId = fileType;
                    mediaFile.FileName = talentAuditionDto.JobMediaFile.Substring(talentAuditionDto.JobMediaFile.LastIndexOf('=') + 1);
                    mediaFile.FilePath = talentAuditionDto.JobMediaFile;
                    mediaFile.IsExternalUrl = false;
                    mediaFile.CreatedOn = DateTime.UtcNow;
                    mediaFile.UpdatedOn = DateTime.UtcNow;
                    string mime = MimeKit.MimeTypes.GetMimeType(mediaFile.FileName);
                    mediaFile.FileMimeType = mime;
                    mediaFile = await _mediaFileRepository.AddAsync(mediaFile);

                    JobMedia jobMedia = new JobMedia();
                    jobMedia.JobId = jobId;
                    jobMedia.TalentId = talentId;
                    jobMedia.JobAuditionId = auditionId;
                    jobMedia.MediaFileId = mediaFile.Id;
                    jobMedia.CreatedOn = DateTime.UtcNow;
                    jobMedia.Notes = "";
                    jobMedia = await _jobMediaRepository.AddAsync(jobMedia);
                }

                talentAuditionDto.IsJobAuditionDisabled = true;
                talentAuditionDto.Notes = "";
                return Json(talentAuditionDto);
            }
            return BadRequest();
        }


        [HttpDelete]
        [Route("removeOfflineMedia/{jobId}/{auditionId}/{talentId}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<IActionResult> RemoveOfflineMedia(int jobId, int auditionId, int talentId)
        {
            var jobMediaModel = await _jobMediaRepository.FindAsync(x => x.JobId == jobId && x.JobAuditionId == auditionId && x.TalentId == talentId);
            if (jobMediaModel == null)
            {
                return NoContent();
            }
            var mediaFileModel = await _mediaFileRepository.FindAsync(x => x.Id == jobMediaModel.MediaFileId);
            await _fileService.DeleteAsync(mediaFileModel.FilePath.Replace(_appSettings.S3BaseUrlForUser, _appSettings.S3BucketNameUser));      //delete media from s3
            await _mediaFileRepository.DeleteAsync(mediaFileModel);                             // //delete media from Media file Table
            await _jobMediaRepository.DeleteAsync(jobMediaModel);                               // delete media from jobMedia

            return Json(new { result = "success"});
        }


        [NonAction]
        private async Task<string> UploadAuditionMedia(IFormFile file, int jobId, int auditionId, int userId)
        {
            if (file != null && file.Length > 0)
            {
                string targetPath = _appSettings.MediaBasePath;
                var inputStream = file.OpenReadStream();
                var fileName = CreateUniqueFileName(file.FileName);
                string savedPath = ApplicationAccessiblePath(Path.Combine(targetPath, _appSettings.GetJobFolder + jobId.ToString() + "/" + _appSettings.GetAuditionFolder + auditionId.ToString() + "/" + _appSettings.GetTalentFolder + userId.ToString()), _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);

                var stopWatch = Stopwatch.StartNew();
                LogInformationAsWarning($"Uploading file: {fileName}, fileSize: {file.Length}  for  {userId} ...");

                savedPath = await _fileService.UploadAsync(inputStream, savedPath, fileName);

                stopWatch.Stop();
                LogInformationAsWarning($"Upload of file: {fileName}, fileSize: {file.Length} completed Successfully for  {userId} in {stopWatch.Elapsed.TotalMilliseconds}");

                return UserAccessiblePath(savedPath, _appSettings.S3BucketNameUser, _appSettings.S3BaseUrlForUser);
            }
            return null;
        }

        [NonAction]
        private void LogInformationAsWarning(string message)
        {
            Serilog.Log.Warning("[Information] " + message);
        }

        [NonAction]
        private string CreateUniqueFileName(string fileName)
        {
            int idx = fileName.LastIndexOf('.');
            //get filename
            string name = fileName.Substring(0, idx);
            //name = name.Trim().Replace(" ", string.Empty);
            name = RemoveSpecialCharactersHelper.RemoveSpecialCharacters(name);
            //get extention
            string extenstion = fileName.Substring(idx + 1);

            return name + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "." + extenstion;
        }

        [NonAction]
        private string ApplicationAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is FileService)
            {
                return filePath.ToApplicationAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToApplicationAccessibleS3Path(baseURL, bucketName);
            }
            return filePath;
        }

        [NonAction]
        private string UserAccessiblePath(string filePath, string bucketName, string baseURL)
        {
            if (_fileService is Infrastructure.FileService)
            {
                return filePath.ToUserAccessiblePath();
            }
            else if (_fileService is Infrastructure.S3FileService)
            {
                return filePath.ToUserAccessibleS3Path(bucketName, baseURL);
            }

            return filePath;
        }
    }
}