﻿using Amazon.CloudFront;
using FTC.Api.CommonServices;
using FTC.Api.Extensions;
using FTC.Api.Filters;
using FTC.Api.Helpers;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.CommonControllerDtos;
using FTCApi.Dtos.Enum;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    public class CommonController : Controller
    {
        private ICountryRepository _countryRepository;
        private IEthnicityRepository _ethnicityRepository;
        private ISecurityQuestionRepository _securityQuestionRepository;
        private IBodyTypeRepository _bodyTypeRepository;
        private IChestSizeRepository _chestSizeRepository;
        private ICityRepository _cityRepository;
        private ITalentCategoryRepository _talentCategoryRepository;
        private IEyeColorRepository _eyeColorRepository;
        private IFileTypeRepository _fileTypeRepository;
        private IHairColorRepository _hairColorRepository;
        private IHairLengthRepository _hairLengthRepository;
        private IHairTypeRepository _hairTypeRepository;
        private IInterestCategoryRepository _interestCategoryRepository;
        private ILanguageRepository _languageRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IProjectLocationRepository _projectLocationRepository;
        private ISkinColorRepository _skinColorRepository;
        private IStatusRepository _statusRepository;
        private IWaistSizeRepository _waistSizeRepository;
        private ITagRepository _tagRepository;
        private ITagCategoryRepository _tagCategoryRepository;
        private ITierRepository _tierRepository;
        private IConfiguration _configuration;
        private IHeightRepository _heightRepository;
        private IWeightRepository _weightRepository;
        private IAssociationRepository _associationRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private ISocialLinkRepository _socialLinkRepository;
        private IRecruiterTypeRepository _recruiterTypeRepository;
        private IContestTypeRepository _contestTypeRepository;
        private IProductionHouseRepository _productionHouseRepository;
        private ISchoolRepository _schoolRepository;
        private IContestSpecialHostRepository _contestSpecialHostRepository;
        private IRecruiterPlanRepository _recruiterPlanRepository;
        private IAuxiliaryRecruiterRepository _auxiliaryRecruiterRepository;
        private ITalentRepository _talentRepository;
        private IProductionHouseCategoryRepository _productionHouseCategoryRepository;
        private IContestRepository _contestRepository;
        private IParamRepository _paramRepository;
        private IFeatureRolePermissionRepository _featureRolePermissionRepository;
        private IRecruiterPlanUserRepository _recruiterPlanUserRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;


        private ITraceActivityRepository _traceActivityRepository;
        private ITraceLoginRepository _traceLoginRepository;

        private AppSettings _appSettings;

        private const string constantOthers = "others";

        public CommonController(ICountryRepository countryRepository,
                                IEthnicityRepository ethnicityRepository,
                                ISecurityQuestionRepository securityQuestionRepository,
                                IBodyTypeRepository bodyTypeRepository,
                                IChestSizeRepository chestSizeRepository,
                                ICityRepository cityRepository,
                                ITalentCategoryRepository talentCategoryRepository,
                                IEyeColorRepository eyeColorRepository,
                                IFileTypeRepository fileTypeRepository,
                                IHairColorRepository hairColorRepository,
                                IHairLengthRepository hairLengthRepository,
                                IHairTypeRepository hairTypeRepository,
                                IInterestCategoryRepository interestCategoryRepository,
                                ILanguageRepository languageRepository,
                                IProjectRepository projectRepository,
                                IProjectJobRepository projectJobRepository,
                                IProjectLocationRepository projectLocationRepository,
                                ISkinColorRepository skinColorRepository,
                                IStatusRepository statusRepository,
                                IWaistSizeRepository waistSizeRepository,
                                ITagRepository tagRepository,
                                ITagCategoryRepository tagCategoryRepository,
                                ITierRepository tierRepository,
                                IHeightRepository heightRepository,
                                IWeightRepository weightRepository,
                                IConfiguration configuration,
                                IAssociationRepository associationRepository,
                                ISocialLinkRepository socialLinkRepository,
                                IRecruiterTypeRepository recruiterTypeRepository,
                                IContestTypeRepository contestTypeRepository,
                                IAuxiliaryUserRepository auxiliaryUserRepository,
                                IParamRepository paramRepository,
                                IProductionHouseRepository productionHouseRepository,
                                ISchoolRepository schoolRepository,
                                IContestSpecialHostRepository contestSpecialHostRepository,
                                IRecruiterPlanRepository recruiterPlanRepository,
                                IAuxiliaryRecruiterRepository auxiliaryRecruiterRepository,
                                IFeatureRolePermissionRepository featureRolePermissionRepository,
                                IProductionHouseCategoryRepository productionHouseCategoryRepository,
                                IContestRepository contestRepository,
                                IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
                                ITalentRepository talentRepository, ITraceActivityRepository traceActivityRepository, ITraceLoginRepository traceLoginRepository,
                                IRecruiterPlanUserRepository recruiterPlanUserRepository, IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository)
        {
            _countryRepository = countryRepository;
            _ethnicityRepository = ethnicityRepository;
            _securityQuestionRepository = securityQuestionRepository;
            _bodyTypeRepository = bodyTypeRepository;
            _chestSizeRepository = chestSizeRepository;
            _cityRepository = cityRepository;
            _talentCategoryRepository = talentCategoryRepository;
            _eyeColorRepository = eyeColorRepository;
            _fileTypeRepository = fileTypeRepository;
            _hairColorRepository = hairColorRepository;
            _hairTypeRepository = hairTypeRepository;
            _interestCategoryRepository = interestCategoryRepository;
            _languageRepository = languageRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _projectLocationRepository = projectLocationRepository;
            _skinColorRepository = skinColorRepository;
            _statusRepository = statusRepository;
            _waistSizeRepository = waistSizeRepository;
            _tagRepository = tagRepository;
            _tagCategoryRepository = tagCategoryRepository;
            _tierRepository = tierRepository;
            _heightRepository = heightRepository;
            _weightRepository = weightRepository;
            _configuration = configuration;
            _hairLengthRepository = hairLengthRepository;
            _associationRepository = associationRepository;
            _socialLinkRepository = socialLinkRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _recruiterTypeRepository = recruiterTypeRepository;
            _contestTypeRepository = contestTypeRepository;
            _productionHouseRepository = productionHouseRepository;
            _schoolRepository = schoolRepository;
            _contestSpecialHostRepository = contestSpecialHostRepository;
            _recruiterPlanRepository = recruiterPlanRepository;
            _paramRepository = paramRepository;
            _auxiliaryRecruiterRepository = auxiliaryRecruiterRepository;
            _talentRepository = talentRepository;
            _featureRolePermissionRepository = featureRolePermissionRepository;
            _productionHouseCategoryRepository = productionHouseCategoryRepository;
            _traceActivityRepository = traceActivityRepository;
            _traceLoginRepository = traceLoginRepository;
            _recruiterPlanUserRepository = recruiterPlanUserRepository;
            _contestRepository = contestRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _appSettings = new AppSettings(_configuration);
        }


        /// <summary>
        /// Get List of All production House
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("getProductionHouse")]
        public async Task<ActionResult> GetProductionHouse()
        {
            var response = await _productionHouseRepository.GetAllAsync();
            return Json(response);
        }



        [HttpGet]
        [Route("signedcookies")]

        public async Task<ActionResult> SetCookieCustomPolicy()
        {

            // The key pair Id for the CloudFront key pair
            var cloudFrontKeyPairId = _appSettings.SignedCookieKeyPairId;

            // The RSA key pair file (.pem file) that contains the private key    
            var privateKeyFile = new FileInfo(_appSettings.SignedCookieKeyPairFile);

            var cookies = AmazonCloudFrontCookieSigner.GetCookiesForCustomPolicy(
                AmazonCloudFrontCookieSigner.Protocols.Http |
                AmazonCloudFrontCookieSigner.Protocols.Https, // Allow either http or https

                _appSettings.SignedCookieFTCDomainName,      // CloudFront distribution domain
                privateKeyFile,
                 _appSettings.SignedCookieAllowWildCard,          // Allows use of wildcards
                cloudFrontKeyPairId,
                  DateTime.Now.AddMinutes(_appSettings.ExpireCookieInMinute), // Date till which the signed cookies are valid
                DateTime.MinValue,         // Date from which the signed cookies are valid,
                                           // a value of DateTime.MinValue is ignored			
                null);           // Source IP or range of IP addresses,
                                 // a value of string.Empty or null is ignored

            return Ok(cookies);
        }


        /// <summary>
        /// Get top 20 productionHouse only and if search parameter is passed {which is optional} ... get the production house matchin the search results
        /// </summary>
        /// <param name="productionHouseName"></param>
        /// <returns></returns>
        [Route("productionHouse/{productionHouseName?}")]
        [HttpGet]
        public async Task<ActionResult> GetProductionHouseSearch(string productionHouseName = "")
        {
            IEnumerable<ProductionHouse> response = null;
            if (!string.IsNullOrEmpty(productionHouseName))
            {
                var searchProductionHouseName = productionHouseName.ToLower();
                response = await _productionHouseRepository.FindAllAsync(x => x.Description.ToLower().Contains(searchProductionHouseName) && x.CategoryId != null);
            }
            else
            {
                response = await _productionHouseRepository.FindAllAsync(x => x.CategoryId != null);
            }

            var otherProductionHouse = await _productionHouseRepository.FindAllAsync(x => x.CategoryId == null);

            response = response.OrderBy(r => r.Description).Take(20);
            response = otherProductionHouse.Union(response);
            return Json(response);
        }

        /// <summary>
        /// Add production house to the master - {ADMIN ONLY} AND Edit by passing the productionHouseId
        /// </summary>
        /// <param name="productionHouseDto"></param>
        /// <param name="productionHouseId"></param>
        /// <returns></returns>
        [Route("saveProductionHouse/{productionHouseId?}")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> AddProductionHouse([FromBody]ProductionHouseDto productionHouseDto, int? productionHouseId = 0)
        {
            if (productionHouseDto == null)
            {
                return BadRequest();
            }
            var productionHouse = new ProductionHouse();
            if (productionHouseId > 0)
            {
                productionHouse = await _productionHouseRepository.FindAsync(x => x.Id == productionHouseId);
                if (productionHouse == null)
                {
                    return NotFound();
                }
                productionHouse.Description = productionHouseDto.Description;
                productionHouse.CategoryId = productionHouseDto.CategoryId;
                productionHouse = await _productionHouseRepository.UpdateAsync(productionHouse);
                return Json(productionHouse);
            }

            productionHouse.Description = productionHouseDto.Description;
            productionHouse.CategoryId = productionHouseDto.CategoryId;
            productionHouse = await _productionHouseRepository.AddAsync(productionHouse);
            return Json(productionHouse);
        }

        /// <summary>
        /// GET production house category list
        /// </summary>
        /// <returns></returns>
        [Route("productionHouseCategory")]
        [HttpGet]
        public async Task<ActionResult> ProductionHouseCategory()
        {
            var response = await _productionHouseCategoryRepository.GetAllAsync();
            return Json(response);
        }

        /// <summary>
        /// GET production house by productionHouseCategoryID
        /// </summary>
        /// <returns></returns>
        [Route("productionHouseByCategoryId/{productionHouseCategoryId}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> ProductionHouseByCategoryId(int productionHouseCategoryId)
        {
            var response = await _productionHouseRepository.FindAllAsync(x => x.CategoryId == productionHouseCategoryId);
            return Json(response);
        }

        /// <summary>
        /// Add production house category - {ADMIN ONLY}
        /// </summary>
        /// <param name="productionHouseDescription"></param>
        /// <returns></returns>
        [Route("productionHouseCategory/{productionHouseDescription}")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> AddProductionHouseCategory(string productionHouseDescription)
        {
            if (string.IsNullOrEmpty(productionHouseDescription))
            {
                return BadRequest();
            }
            var productionHouseCategory = new ProductionHouseCategory();
            productionHouseCategory.Desc = productionHouseDescription;

            productionHouseCategory = await _productionHouseCategoryRepository.AddAsync(productionHouseCategory);
            return Json(productionHouseCategory);
        }

        /// <summary>
        /// update production house category - {ADMIN ONLY}
        /// </summary>
        /// <param name="tagCategoryId"></param>
        /// <param name="tagCategoryDescription"></param>
        /// <returns></returns>
        [Route("productionHouseCategory/{productionHouseId}/{productionHouseDescription}")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> UpdateProductionHouseCategory(int productionHouseId, string productionHouseDescription)
        {
            if (string.IsNullOrEmpty(productionHouseDescription))
            {
                return BadRequest();
            }

            var productionHouseCategory = await _productionHouseCategoryRepository.FindAsync(x => x.Id == productionHouseId);
            if (productionHouseCategory == null)
            {
                return NotFound();
            }
            productionHouseCategory.Desc = productionHouseDescription;
            productionHouseCategory = await _productionHouseCategoryRepository.UpdateAsync(productionHouseCategory);
            return Json(productionHouseCategory);
        }


        [Route("productionAgencies/{productionAgencies?}")]
        [HttpGet]
        public async Task<ActionResult> GetProductionAgencies(string productionAgencies = "")
        {
            IEnumerable<ProductionHouse> response = null;
            if (!string.IsNullOrEmpty(productionAgencies))
            {
                response = await _productionHouseRepository.FindAllAsync(x => x.CategoryId == (int)ProductionHouseCategoryEnum.AdFilmProductionHouses
                                                                                && x.Description.ToLower().Contains(productionAgencies.ToLower()));
            }
            else
            {
                response = await _productionHouseRepository.FindAllAsync(x => x.CategoryId == (int)ProductionHouseCategoryEnum.AdFilmProductionHouses);
            }

            var otherAgency = await _productionHouseRepository.FindAllAsync(x => x.CategoryId == null);

            response = response.OrderBy(r => r.Description).Take(20);
            response = otherAgency.Union(response);
            return Json(response);
        }

        [Route("profileInformation/{roleId?}/{profileId?}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: false, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetProfileInformation(int userId, int userType, int? roleId = 0, int? profileId = 0)
        {
            var response = new ProfileInformationDto();
            // TODO: optimise
            #region other profile Id & Role
            if (profileId > 0)
            {
                userId = (int)profileId;
                if (roleId == (int)LoginUserType.Talent)
                {
                    var talent = await _talentRepository.FindAsync(x => x.Id == userId);
                    if (talent == null)
                    {
                        return NotFound();
                    }
                    response = new ProfileInformationDto
                    {
                        Id = talent.Id,
                        FullName = talent.FullName,
                        ProfileUrl = talent.TalentProfileURL
                    };
                }
                else
                {
                    var auxiliaryuser = await _auxiliaryUserRepository.FindAsync(x => x.Id == userId);
                    if (auxiliaryuser == null)
                    {
                        return NotFound();
                    }
                    response = new ProfileInformationDto
                    {
                        Id = auxiliaryuser.Id,
                        FullName = auxiliaryuser.FullName,
                        ProfileUrl = auxiliaryuser.ProfileURL
                    };
                }
            }

            #endregion

            #region Logged in user
            else
            {
                if (userType == (int)LoginUserType.Talent)
                {
                    var talent = await _talentRepository.FindAsync(x => x.Id == userId);
                    if (talent == null)
                    {
                        return NotFound();
                    }
                    response = new ProfileInformationDto
                    {
                        Id = talent.Id,
                        FullName = talent.FullName,
                        ProfileUrl = talent.TalentProfileURL
                    };
                }
                else
                {
                    var auxiliaryuser = await _auxiliaryUserRepository.FindAsync(x => x.Id == userId);
                    if (auxiliaryuser == null)
                    {
                        return NotFound();
                    }
                    response = new ProfileInformationDto
                    {
                        Id = auxiliaryuser.Id,
                        FullName = auxiliaryuser.FullName,
                        ProfileUrl = auxiliaryuser.ProfileURL
                    };
                }
            }
            #endregion
            return Json(response);
        }

        [HttpGet]
        [Route("projectByProjectJob/{jobId}")]
        [AuthorizeTokenFilter(validate: false, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetProjectProjectJobById(int jobId, UserInfo userInfo)
        {
            var projectJob = await _projectJobRepository.FindAsync(x => x.Id == jobId);
            if (projectJob == null)
            {
                return NotFound();
            }

            var project = await _projectRepository.FindAsync(x => x.Id == projectJob.ProjectId);

            var checkAuthorization = _auxiliaryUserRepository.CheckAuthorization(project.AuxiliaryUserId, userInfo.userId, (int)NotificationEnum.JobCreation, projectJob.ProjectId, projectJob.Id);
            if (!checkAuthorization)
                return Forbid();

            var response = new
            {
                JobId = projectJob.Id,
                JobTitle = projectJob.Title,
                ProjectId = project.Id,
                ProjectName = project.Name,
                StatusId = projectJob.StatusId,
                CastingRequired = projectJob.CastRequired
            };
            return Json(response);
        }

        [HttpGet]
        [Route("NoContent")]
        public async Task<ActionResult> TestNoContent()
        {
            return NoContent();
        }


        /// <summary>
        /// This action is use to get autocomplte city data from geobytes api
        /// </summary>
        /// <param name="term"></param>
        /// <param name="filter">todo: describe filter parameter on AutoCompleteCity</param>
        /// <returns></returns>
        [Route("geobytes/autocompletecity")]
        [HttpGet]
        public async Task<ActionResult> AutoCompleteCity(string term, string filter)
        {
            if (string.IsNullOrEmpty(term))
            {
                return null;
            }

            var autoCompleteCityUrl = string.Format(_appSettings.GetAutoCompleteCityUrl, filter, term);

            //This will get autocomplete information based provided term.
            var result = await HttpClientHelper.GetAsync(autoCompleteCityUrl);

            return Ok(new { data = result });

        }

        /// <summary>
        /// This action is use to get details of city from geobytes api
        /// </summary>
        /// <param name="city"></param>
        /// <returns></returns>
        [Route("geobytes/citydetails/{city}")]
        [HttpGet]
        public async Task<ActionResult> GetCityDetails(string city)
        {
            if (string.IsNullOrEmpty(city))
            {
                return null;
            }

            var cityDetailsUrl = string.Format(_appSettings.CityDetailsUrl, city);
            var result = await HttpClientHelper.GetAsync(cityDetailsUrl);
            //TODO: Serialize the response in JSON 
            return Ok(new { data = result });
        }

        /// <summary>
        /// This action is use to save trace activity 
        /// </summary>
        /// <param name="traceActivity"></param>
        /// <param name="userType"></param>
        /// <param name="userId"></param> 
        /// <returns></returns>
        [Route("trace/activity")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> SaveTraceActivity([FromBody]TraceActivityDto traceActivity, int userType, int userId)
        {

            try
            {
                var activity = new TraceActivity
                {
                    AuxiliaryUserId = (userType == (int)LoginUserType.Talent) ? (int?)null : userId,
                    TalentId = (userType == (int)LoginUserType.Talent) ? userId : (int?)null,
                    Browser = HttpContext.Request.Headers["User-Agent"].ToString(),
                    CreatedOn = DateTime.UtcNow,
                    IpAddress = HttpClientHelper.GetRealIP(HttpContext),
                    Route = traceActivity.Route,
                    Functionality = traceActivity.Functionality,
                };

                var traceData = await _traceActivityRepository.AddAsync(activity);
                return Ok(new { message = "sucess" });

            }
            catch (Exception ex)
            {

                Log.Information(ex.ToString());
            }


            return Ok(new { message = "fail" });
        }

 
        /// <summary>
        /// This action is use to save trace login information
        /// </summary>
        /// <param name="traceLogin"></param>
        /// <param name="userType"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [Route("trace/login")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> TraceLogin(int userType, int userId)
        {
            try
            {
                var traceData = await SaveTraceLogout(userType, userId);
                return Ok(new { message = "sucess" });
            }
            catch (Exception ex)
            {
                Log.Information(ex.ToString());
            }

            return Ok(new { message = "fail" });
        }

        [NonAction]
        private async Task<TraceLogin> SaveTraceLogout(int userType, int userId)
        {
            var login = new TraceLogin
            {
                AuxiliaryUserId = (userType == (int)LoginUserType.Talent) ? (int?)null : userId,
                TalentId = (userType == (int)LoginUserType.Talent) ? userId : (int?)null,
                IpAddress = HttpClientHelper.GetRealIP(HttpContext),
                LogoutTime = DateTime.UtcNow
            };

            var traceData = await _traceLoginRepository.AddAsync(login);
            return traceData;
        }


        [HttpGet]
        [Route("recruiterPlans/{recruiterId?}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin, Recruiter")]
        public async Task<ActionResult> GetRecruiterPlans(UserInfo userInfo, int? recruiterId = 0)
        {
            IEnumerable<RecruiterPlanUser> recruiterUserPlan = new List<RecruiterPlanUser>();


            var recruiterPlans = await _recruiterPlanRepository.GetAllPlans();

            if ((recruiterId > 0 && userInfo.userType == (int)LoginUserType.FTCAdmin) || userInfo.userType == (int)LoginUserType.Recruiter)
            {
                recruiterUserPlan = await _recruiterPlanUserRepository.FindAllAsync(x => x.AuxiliaryUserId == (userInfo.userType == (int)LoginUserType.Recruiter ? userInfo.userId : recruiterId));

                if (recruiterUserPlan.Count() > 0)
                {
                    var planIds = recruiterUserPlan.Select(x => x.RecruiterPlanId);
                    recruiterPlans = recruiterPlans.Where(x => planIds.Contains(x.Id) || x.StatusId == (int)StatusEnum.Active || x.StatusId == (int)StatusEnum.Custom).ToList();
                }
                else
                {
                    recruiterPlans = recruiterPlans.Where(x => x.StatusId == (int)StatusEnum.Active).ToList();
                }
            }
            else if (userInfo.userType == (int)LoginUserType.FTCAdmin)
            {
                recruiterPlans = recruiterPlans.Where(x => x.StatusId == (int)StatusEnum.Active || x.StatusId == (int)StatusEnum.Custom).ToList();
            }

            var recruiterPlanDtos = new List<RecruiterPlanDto>();
            //crate the custom respose to fill the recruiters dropdown
            foreach (var recruiterPlan in recruiterPlans)
            {
                recruiterPlanDtos.Add(new RecruiterPlanDto
                {
                    Id = recruiterPlan.Id,
                    PlanName = recruiterPlan.Name,
                    Amount = recruiterPlan.Amount,
                    Description = recruiterPlan.Description,
                    RoleCount = recruiterPlan.RoleCount,
                    RecommendedCount = recruiterPlan.RecommendedCount,
                    selectedForAudition = recruiterPlan.AuditionSelectionCount,
                    IsViewPortfolio = recruiterPlan.ViewPortfolio,
                    IsOnlineAudition = recruiterPlan.AllowedOnlineAudition,
                    IsProvideNotesRating = recruiterPlan.ProvideNotesRating,
                    ProjectValidity = recruiterPlan.ProjectValidity,
                    IsManagePayments = recruiterPlan.ManagePayments,
                    IsSocialIntegration = recruiterPlan.SocialIntegration,
                    IsDiscountOnStudioBooking = recruiterPlan.DiscountOnStudioBooking,
                    IsDedicatedSupport = recruiterPlan.DedicatedSupport,
                    NumberOfUsers = recruiterPlan.NumberOfUsers,
                    Customized = recruiterPlan.Customized,
                    ManageContract = recruiterPlan.ManageContract,
                    ViewAuditionHistory = recruiterPlan.ViewAuditionHistory,
                    Recruiters = getSpecificRecruiters(recruiterPlan.RecruiterPlanUser)
                });
            }
            return Json(recruiterPlanDtos);
        }

        private List<MultiSelectDto> getSpecificRecruiters(ICollection<RecruiterPlanUser> recruiterPlanUsers)
        {
            var recruiters = new List<MultiSelectDto>();
            if (recruiterPlanUsers != null && recruiterPlanUsers.Count > 0)
            {
                foreach (var user in recruiterPlanUsers)
                {
                    recruiters.Add(new MultiSelectDto
                    {
                        Id = user.AuxiliaryUserId.Value,
                        Description = user.AuxiliaryUser.FullName
                    });
                }
            }
            return recruiters;
        }

        [HttpGet]
        [Route("recruiterPlanById/{planId}")]
        public async Task<ActionResult> GetRecruiterPlanById(int planId)
        {
            var response = await _recruiterPlanRepository.FindAsync(x => x.Id == planId);
            return Json(response);
        }

        [Route("authorize/permissions")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetPermissions(int userId)
        {
            var response = await _featureRolePermissionRepository.GetPermissions(userId);
            return Json(response);
        }

        [Route("server/check")]
        [HttpGet]
        public async Task<ActionResult> HealthCheck()
        {
            return Ok(new { message = "Success" });
        }

        [HttpGet]
        [Route("getschool")]
        public async Task<ActionResult> GetSchoolDetails()
        {
            var response = await _schoolRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("school/{schoolName?}")]
        [HttpGet]
        public async Task<ActionResult> GetSchool(string schoolName)
        {
            IEnumerable<School> response = null;
            if (!string.IsNullOrEmpty(schoolName))
            {
                var schoolNameKeyword = schoolName.ToLower();
                response = await _schoolRepository.FindAllAsync(x => x.Description.ToLower().Contains(schoolNameKeyword));
            }
            else
            {
                response = await _schoolRepository.FindAllAsync(x => x.Description.ToLower() != constantOthers);
            }

            var OtherSchool = await _schoolRepository.FindAllAsync(x => x.Description.ToLower() == constantOthers);

            response = response.OrderBy(r => r.Description).Take(20);
            response = OtherSchool.Union(response);
            return Json(response);
        }

        [HttpPost]
        [Route("school/{schoolName}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> AddSchool(string schoolName)
        {
            // check if the scholl name already exist
            var response = await _schoolRepository.FindAsync(x => x.Description.ToLower() == schoolName.ToLower());
            if (response != null)
            {
                return Json(new { response = response, status = "Already Exist" });
            }
            var school = new School();
            school.Description = schoolName;
            //TODO: CHECK IF Status needs to be passed or default as active
            var schoolResponse = await _schoolRepository.AddAsync(school);

            return Json(new { response = schoolResponse });
        }

        [HttpPost]
        [Route("school/{schoolId}/{schoolName}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> UpdateSchool(int schoolId, string schoolName)
        {
            // check if the scholl name already exist
            var response = await _schoolRepository.FindAsync(x => x.Id == schoolId);
            if (response == null)
            {
                return NotFound();
            }

            response.Description = schoolName;
            response = await _schoolRepository.UpdateAsync(response);

            return Json(new { response = response });
        }

        [Route("contestSpecialHost/{id}")]
        [HttpGet]
        public async Task<ActionResult> GetContestSpecialHostById(int id)
        {
            var contestSpecialHost = await _contestSpecialHostRepository.FindAsync(x => x.Id == id);
            var auxiliaryRecruiter = await _auxiliaryRecruiterRepository.FindAsync(x => x.AuxiliaryId == contestSpecialHost.AuxiliaryUserId);
            if (contestSpecialHost != null)
            {
                return Ok(new { contestSpecialHost = contestSpecialHost, recruiterBanner = auxiliaryRecruiter.ContestBannerImage });
            }
            return NotFound();
        }

        // used in Contest Landing page for talents & In Create Contest for Admin
        [Route("recruiter")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: false, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetRecruiter(UserInfo userInfo)
        {
            IEnumerable<AuxiliaryUser> auxiliaryUser = null;

            // if logged in user is an FTC Recruiter Admin - show only list of assigned recruiters in Contest Create page
            if (userInfo.userId > 0 && userInfo.userType == (int)LoginUserType.FTCAdmin)
            {
                bool isFtcRecruiterAdmin;
                var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
                _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);
                if (isFtcRecruiterAdmin)
                {
                    var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userInfo.userId);

                    auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                    && x.StatusId != (int)StatusEnum.Blocked
                                                                                    && x.ParentAuxiliaryUserId == null
                                                                                    && assignedRecruiters.Contains(x.Id));
                }
                else
                {

                    auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                        && x.StatusId != (int)StatusEnum.Blocked
                                                                                        && x.ParentAuxiliaryUserId == null);
                }

            }
            else
            {

                auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                    && x.StatusId != (int)StatusEnum.Blocked
                                                                                    && x.ParentAuxiliaryUserId == null);
            }
            if (auxiliaryUser == null)
            {
                return NoContent();
            }
            var response = auxiliaryUser.Select(x => new { x.Id, x.FullName }).OrderBy(x => x.FullName).ToList();

            return Json(response);
        }

        [HttpGet]
        [Route("recruiter/{id}")]
        [AuthorizeTokenFilter(validate: false, role: "FTCAdmin")]
        public async Task<ActionResult> GetRecruiter(int id)
        {
            //TODO
            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == id);
            var response = new
            {
                id = auxiliaryUser.Id,
                FullName = auxiliaryUser.FullName
            };
            return Json(response);
        }

        /// <summary>
        /// GetRecruiterSearch for auto search
        /// </summary>
        [HttpGet]
        [Route("recruiter/search/{recruiterName?}")]
        // TODO: Check authentication is must! and if so change validate to true
        [AuthorizeTokenFilter(validate: false, role: "Talent,Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetRecruiterSearch(string recruiterName, UserInfo userInfo)
        {
            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin, isFtcRecruiterAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);

            if (!string.IsNullOrEmpty(recruiterName))
            {
                if (isFtcProjectAdmin || isFtcRecruiterAdmin)
                {
                    var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userInfo.userId);
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                && x.FullName.ToLower().Contains(recruiterName.ToLower())
                                                                                && x.StatusId != (int)StatusEnum.Blocked
                                                                                && x.ParentAuxiliaryUserId == null
                                                                                && assignedRecruiters.Contains(x.Id));
                    var response = auxiliaryUser.Select(x => new { x.Id, Description = x.FullName }).OrderBy(x => x.Description).Take(20);
                    return Json(response);
                }
                else
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                && x.FullName.ToLower().Contains(recruiterName.ToLower())
                                                                                && x.ParentAuxiliaryUserId == null
                                                                                && x.StatusId != (int)StatusEnum.Blocked);
                    var response = auxiliaryUser.Select(x => new { x.Id, Description = x.FullName }).OrderBy(x => x.Description).Take(20);
                    return Json(response);
                }

            }
            else
            {

                if (isFtcProjectAdmin || isFtcRecruiterAdmin)
                {
                    var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userInfo.userId);

                    var auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                    && x.StatusId != (int)StatusEnum.Blocked
                                                                                    && x.ParentAuxiliaryUserId == null
                                                                                    && assignedRecruiters.Contains(x.Id));

                    var response = auxiliaryUser.Select(x => new { x.Id, Description = x.FullName }).OrderBy(x => x.Description).Take(20);
                    return Json(response);
                }
                else
                {
                    var auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                    && x.ParentAuxiliaryUserId == null
                                                                                    && x.StatusId != (int)StatusEnum.Blocked);

                    var response = auxiliaryUser.Select(x => new { x.Id, Description = x.FullName }).OrderBy(x => x.Description).Take(20);
                    return Json(response);
                }

            }
        }

        [Route("assignedRecruiter/search/{recruiterName?}")]
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetAssignedRecruiter(string recruiterName, UserInfo userInfo)
        {
            IEnumerable<AuxiliaryUser> auxiliaryUser = default(IEnumerable<AuxiliaryUser>);
            if (!string.IsNullOrEmpty(recruiterName))
            {
                auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                   && x.FullName.ToLower().Contains(recruiterName.ToLower())
                                                                                   && x.StatusId != (int)StatusEnum.Blocked
                                                                                   && x.ParentAuxiliaryUserId == null);

            }
            else
            {
                auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                    && x.StatusId != (int)StatusEnum.Blocked
                                                                                    && x.ParentAuxiliaryUserId == null);

            }

            var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userInfo.userId);
            auxiliaryUser = auxiliaryUser.Where(x => assignedRecruiters.Contains(x.Id));

            var response = auxiliaryUser.Select(x => new { x.Id, Description = x.FullName }).OrderBy(x => x.Description).Take(20);

            return Json(response);
        }

        [Route("recruitersForPlan")]
        [HttpGet]
        public async Task<ActionResult> GetRecruiterForPlans()
        {
            var auxiliaryUser = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.Recruiter
                                                                                && x.ParentAuxiliaryUserId == null);
            var response = auxiliaryUser.Select(x => new { x.Id, Description = x.FullName }).OrderBy(x => x.Description).ToList();

            return Json(response);
        }

        [Route("contestType")]
        [HttpGet]
        public async Task<ActionResult> GetContestType()
        {
            var contestTypes = await _contestTypeRepository.GetAllAsync();
            contestTypes = contestTypes.OrderBy(r => r.Description);

            var lstContestTypeDto = new List<ContestTypeDto>();
            foreach (var contestType in contestTypes)
            {
                var contestTypeDto = await ConvertToContestTypeDto(contestType);
                lstContestTypeDto.Add(contestTypeDto);
            }

            return Json(lstContestTypeDto);
        }

        [NonAction]
        private async Task<ContestTypeDto> ConvertToContestTypeDto(ContestType contestType)
        {
            var contestTypeDto = new ContestTypeDto();
            contestTypeDto.Id = contestType.Id;
            contestTypeDto.Description = contestType.Description;
            contestTypeDto.LongDescription = contestType.LongDescription;
            contestTypeDto.Image = contestType.Image;
            var contest = await _contestRepository.FindAllAsync(x => x.ContestTypeId == contestType.Id);
            contestTypeDto.ContestCount = contest.Where(x => (x.StatusId == (int)StatusEnum.Active
                                                            || x.StatusId == (int)StatusEnum.Published)
                                                            && x.EndDate >= DateTime.Now.Date).Count();

            return contestTypeDto;
        }

        [Route("recruiterType")]
        [HttpGet]
        public async Task<ActionResult> GetRecruiterType()
        {
            var response = await _recruiterTypeRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("talentSocialLink")]
        [HttpGet]
        public async Task<ActionResult> GetTalentSocialLink()
        {
            var response = await _socialLinkRepository.FindAllAsync(x => x.IsTalentRelated == true);

            return Json(response);
        }

        [Route("recruiterSocialLink")]
        [HttpGet]
        public async Task<ActionResult> GetRecruiterSocialLink()
        {
            var response = await _socialLinkRepository.FindAllAsync(x => x.IsAuxiliaryUserRelated == true);

            return Json(response);
        }

        [Route("association")]
        [HttpGet]
        public async Task<ActionResult> GetAssociations()
        {
            var response = await _associationRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [HttpPost]
        [Route("association/{description}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> AddAssociation(string description)
        {
            // check if the scholl name already exist
            var response = await _associationRepository.FindAsync(x => x.Description.ToLower() == description.ToLower());
            if (response != null)
            {
                return Json(new { response = response, status = "Already Exist" });
            }
            var association = new Association();
            association.Description = description;
            //TODO: CHECK IF Status needs to be passed or default as active
            var associationResponse = await _associationRepository.AddAsync(association);

            return Json(new { response = associationResponse });
        }

        [HttpPost]
        [Route("association/{associationId}/{description}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> UpdateAssociations(int associationId, string description)
        {
            // check if the scholl name already exist
            var response = await _associationRepository.FindAsync(x => x.Id == associationId);
            if (response == null)
            {
                return NotFound();
            }

            response.Description = description;
            //TODO: CHECK IF Status needs to be passed or default as active

            response = await _associationRepository.UpdateAsync(response);

            return Json(new { response = response });
        }

        [Route("agencyname")]
        [HttpGet]
        public async Task<ActionResult> GetAgencies()
        {
            var response = await _auxiliaryUserRepository.FindAllAsync(x => x.TypeId == (int)LoginUserType.TalentManager);
            response = response.OrderBy(r => r.FullName);
            return Json(response);
        }

        [Route("country")]
        [HttpGet]
        public async Task<ActionResult> GetCountry()
        {
            var response = await _countryRepository.GetAllAsync();
            foreach (var items in response)
            {
                items.MobileCode = items.MobileCode.Trim();
            }
            response = response.OrderBy(r => r.Name);
            return Json(response);
        }

        /// <summary>
        /// Get country mobile code for auto search
        /// </summary>
        [HttpGet]
        [Route("mobileCountryCode/search/{countryCode?}")]
        [AuthorizeTokenFilter(validate: false, role: "Recruiter,FTCAdmin,Talent")]
        public async Task<ActionResult> GetMobileCountryCodeSearch(string countryCode, int userId, int userType)
        {
            if (!string.IsNullOrEmpty(countryCode))
            {
                //remove everything after(
                countryCode = countryCode.Split(' ')[0];

                var country = await _countryRepository.FindAllAsync(x => x.Code.ToLower().Contains(countryCode.ToLower()) || x.MobileCode.Contains(countryCode));
                foreach (var items in country)
                {
                    items.MobileCode = items.MobileCode.Trim();
                }
                var response = country.Select(x => new { Id = x.Id, MobileCode = x.MobileCode, Description = x.Code + " (" + x.MobileCode + ")" }).OrderBy(x => x.Description);
                return Json(response);
            }
            else
            {
                var country = await _countryRepository.GetAllAsync();
                foreach (var items in country)
                {
                    items.MobileCode = items.MobileCode.Trim();
                }
                var response = country.Select(x => new { Id = x.Id, MobileCode = x.MobileCode, Description = x.Code + " (" + x.MobileCode + ")" }).OrderBy(x => x.Description);
                return Json(response);
            }
        }

        [HttpGet]
        [Route("ethnicity")]
        public async Task<ActionResult> GetEthnicity()
        {
            var response = await _ethnicityRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("securityQuestion")]
        [HttpGet]
        public async Task<ActionResult> GetSecurityQuestion()
        {
            var response = await _securityQuestionRepository.GetAllAsync();
            return Json(response);
        }

        [Route("bodyType")]
        [HttpGet]
        public async Task<ActionResult> GetBodyType()
        {
            var response = await _bodyTypeRepository.GetAllAsync();
            return Json(response);
        }

        [Route("chestSize")]
        [HttpGet]
        public async Task<ActionResult> GetChestSize()
        {
            var response = await _chestSizeRepository.GetAllAsync();
            response = response.OrderBy(x => x.Cms);
            return Json(response);
        }

        [Route("city")]
        [HttpGet]
        public async Task<ActionResult> GetCity()
        {
            var response = await _cityRepository.GetAllAsync();
            response = response.OrderBy(r => r.CityDescription);
            return Json(response);
        }

        [Route("city/{cityByCountryId}")]
        [HttpGet]
        public async Task<ActionResult> GetCityByCountryId(int cityByCountryId)
        {
            var response = await _cityRepository.FindAllAsync(x => x.CityCountryId == cityByCountryId);
            return Json(response);
        }

        /// <summary>
        /// Get CitiesByMultipleCountryId
        /// </summary>
        [HttpGet]
        [Route("cities/{countryIds}")]
        public async Task<ActionResult> GetCitiesByMultipleCountryId(string countryIds)
        {
            var ListOfCountryIds = countryIds.Split(',').Select(int.Parse).ToList();
            var response = await _cityRepository.FindAllAsync(x => ListOfCountryIds.Contains((int)x.CityCountryId));
            response = response.OrderBy(r => r.CityId);
            return Json(response);
        }

        [HttpGet]
        [Route("citieswithcountry")]
        public async Task<ActionResult> GetCitiesWithCountry()
        {
            var response =  await _cityRepository.GetCitiesWithCountry();
            return Json(response);
        }
        
        [HttpGet]
        [Route("talentCategory")]
        public async Task<ActionResult> GetTalentCategory()
        {
            var response = await _talentCategoryRepository.FindAllAsync(x => x.ParentId == null);
            //var iconUrl = _configuration.GetValue<string>("ImageIcons:Icons");
            var iconUrl = _appSettings.IconsUrl;

            foreach (var items in response)
            {
                items.SelectedIcon = iconUrl + items.SelectedIcon;
                items.NotSelectedIcon = iconUrl + items.NotSelectedIcon;
            }
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("talentCategoryById/{id}")]
        [HttpGet]
        public async Task<ActionResult> GetTalentCategoryById(string id)
        {
            List<string> ListOfId = id.Split(',').ToList<string>();
            var response = await _talentCategoryRepository.FindAllAsync(x => ListOfId.Contains(x.ParentId.ToString()));
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("eyeColor")]
        [HttpGet]
        public async Task<ActionResult> GetEyeColor()
        {
            var response = await _eyeColorRepository.GetAllAsync();
            var sortedEyeColor = response.OrderBy(x => x.Description);
            return Json(sortedEyeColor);
        }

        [Route("fileType")]
        [HttpGet]
        public async Task<ActionResult> GetFileType()
        {
            var response = await _fileTypeRepository.GetAllAsync();
            var sortedFileTypes = response.OrderBy(x => x.Name);
            return Json(sortedFileTypes);
        }

        [Route("hairColor")]
        [HttpGet]
        public async Task<ActionResult> GetHairColor()
        {
            var response = await _hairColorRepository.GetAllAsync();
            var sortedHairColor = response.OrderBy(x => x.Description);
            return Json(sortedHairColor);
        }

        [HttpGet]
        [Route("param")]
        public async Task<IActionResult> GetParam()
        {
            var lstParam = await _paramRepository.GetAllAsync();
            var param = lstParam.First();

            return Ok(new
            {
                ImageCount = param.ImageCount,
                VideoCount = param.VideoCount,
                AudioCount = param.AudioCount,
                ScriptCount = param.ScriptCount,
                TalentRatingWeightage = param.TalentRatingWeightage,
                ParameterRatingWeightage = param.ParameterRatingWeightage,
                FtcRatingWeightage = param.FtcRatingWeightage,
                RecruiterRatingWeightage = param.RecruiterRatingWeightage
            });
        }

        [Route("hairLength")]
        [HttpGet]
        public async Task<ActionResult> GetHairLength()
        {
            var response = await _hairLengthRepository.GetAllAsync();
            return Json(response);
        }

        [Route("hairType")]
        [HttpGet]
        public async Task<ActionResult> GetHairType()
        {
            var response = await _hairTypeRepository.GetAllAsync();
            return Json(response);
        }
        [Route("interestCategory")]
        [HttpGet]
        public async Task<ActionResult> GetInterestCategory()
        {
            var response = await _interestCategoryRepository.GetAllAsync();
            //var iconUrl = _configuration.GetValue<string>("ImageIcons:Icons");
            var iconUrl = _appSettings.IconsUrl;
            foreach (var items in response)
            {
                items.SelectedIcon = iconUrl + items.SelectedIcon;
                items.NotselectedIcon = iconUrl + items.NotselectedIcon;
            }
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("language")]
        [HttpGet]
        public async Task<ActionResult> GetLanguage()
        {
            var response = await _languageRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("project")]
        [HttpGet]
        public async Task<ActionResult> GetProject()
        {
            var response = await _projectRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [Route("projectWithRecruiterName")]
        [HttpGet]
        public async Task<ActionResult> GetProjectWithRecruiterName()
        {
            var response = await _projectRepository.GetAllProjects();
            var projectDetails = response.Select(x => new { Id = x.Id, Description = (x.AuxiliaryUser != null ? x.AuxiliaryUser.FullName : string.Empty) + " - " + x.Name, RecruiterId = x.AuxiliaryUser != null ? x.AuxiliaryUser.Id : 0 });
            return Json(projectDetails);
        }

        [HttpGet]
        [Route("projectsByUserId")]
        [AuthorizeTokenFilter(validate: false, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetProjectsByUserId(UserInfo userInfo)
        {
            var projects = await _projectRepository.FindAllAsync(x => x.AuxiliaryUserId == userInfo.userId);
            var response = projects.Select(x => new { Id = x.Id, Description = x.Name }).OrderBy(r => r.Description);
            return Json(response);
        }

        [HttpGet]
        [Route("jobsByUserId")]
        [AuthorizeTokenFilter(validate: false, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetJobsByUserId(int userId)
        {
            var jobs = await _projectJobRepository.GetAllJobs(userId);
            var response = jobs.Select(x => new { Id = x.Id, Description = x.Project.Name + '-' + x.Title, projectId = x.ProjectId }).OrderBy(r => r.Description);
            return Json(response);
        }

        [HttpGet]
        [Route("project/getName/{id}")]
        [AuthorizeTokenFilter(validate: false, role: "FTCAdmin,Recruiter")]
        public async Task<ActionResult> GetProject(int id)
        {
            var project = await _projectRepository.FindAsync(x => x.Id == id);
            if (project == null)
            {
                return NotFound();
            }
            var response = new
            {
                Id = project.Id,
                Name = project.Name
            };
            return Json(response);
        }

        /// <summary>
        /// GetProjectSearch for auto search
        /// </summary>
        [HttpGet]
        [Route("project/search/{recruiterId?}/{projectName?}")]
        [AuthorizeTokenFilter(validate: false, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetProjectSearch(int recruiterId, string projectName, int userId, int userType)
        {
            if (userType == (int)(LoginUserType.Recruiter))
            {
                recruiterId = userId;
            }
            
            if (recruiterId.ToString() != null && recruiterId > 0)
            {
                var response = await _projectRepository.GetProjectByRecruiterId(recruiterId, projectName, userId, userType);
                return Json(response);
            }

            return NotFound();
        }

        [HttpGet]
        [Route("projects/search/{projectName?}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> SearchProject(string projectName, UserInfo userInfo)
        {
            #region Code before refacorting
            //bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin, isFtcRecruiterAdmin;
            //var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userInfo.userId);
            //_auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);
            //_auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);


            //IEnumerable<Project> project = null;
            //if (isFtcProjectAdmin || isFtcRecruiterAdmin || isProjectAdmin || isJobAdmin)
            //{
            //    var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId);
            //    //projects = await _projectRepository.FindAllAsync(c => assignedProjects.ContainsKey(c.Id));


            //    if (!string.IsNullOrEmpty(projectName))
            //    {
            //        project = await _projectRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active || (x.StatusId ?? 0) == (int)StatusEnum.Verified)
            //                                                                    && (x.AuxiliaryUserId == userInfo.userId || assignedProjects.ContainsKey(x.Id))
            //                                                                    && x.Name.ToLower().Contains(projectName.ToLower()));
            //    }
            //    else
            //    {
            //        project = await _projectRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active || (x.StatusId ?? 0) == (int)StatusEnum.Verified)
            //                                                                && (x.AuxiliaryUserId == userInfo.userId || assignedProjects.ContainsKey(x.Id)));
            //    }
            //}
            //// if he is a recruiter
            //else if (userInfo.userType == (int)LoginUserType.Recruiter)
            //{
            //    var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userInfo.userId);

            //    if (!string.IsNullOrEmpty(projectName))
            //    {
            //        project = await _projectRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active || (x.StatusId ?? 0) == (int)StatusEnum.Verified)
            //                                                                    && x.Name.ToLower().Contains(projectName.ToLower())
            //                                                                    && x.AuxiliaryUserId == userInfo.userId);
            //    }
            //    else
            //    {
            //        project = await _projectRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active || (x.StatusId ?? 0) == (int)StatusEnum.Verified)
            //                                                                && x.AuxiliaryUserId == userInfo.userId);
            //    }
            //}
            //// he is an admin
            //else
            //{
            //    if (!string.IsNullOrEmpty(projectName))
            //    {
            //        project = await _projectRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active || (x.StatusId ?? 0) == (int)StatusEnum.Verified)
            //                                                                    && x.Name.ToLower().Contains(projectName.ToLower()));
            //    }
            //    else
            //    {
            //        project = await _projectRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active || (x.StatusId ?? 0) == (int)StatusEnum.Verified));
            //    }
            //}
            #endregion

            var response = await _projectRepository.SearchProjects(projectName, userInfo.userId, userInfo.userType);
            return Json(response);
        }

        /// <summary>
        /// get projects by recruiterId
        /// </summary>
        [HttpGet]
        [Route("projectsByRecruiterId/{recruiterId}")]
        public async Task<ActionResult> GetProjectsByrecruiterId(int recruiterId)
        {
            var project = await _projectRepository.FindAllAsync(x => (x.StatusId == (int)StatusEnum.Active || x.StatusId == (int)StatusEnum.Verified) && x.AuxiliaryUserId == recruiterId); //TODO: x.Verified == true && x.StatusId == 1
            if (project != null)
                return new JsonResult(project.ToList());
            return NotFound();
        }

        [Route("projectJob")]
        [HttpGet]
        public async Task<ActionResult> GetProjectJob()
        {
            var response = await _projectJobRepository.GetAllAsync();
            response = response.OrderBy(r => r.Description);
            return Json(response);
        }

        [HttpGet]
        [Route("projectJob/getName/{id}")]
        [AuthorizeTokenFilter(validate: false, role: "FTCAdmin,Recruiter")]
        public async Task<ActionResult> GetProjectJob(int id)
        {
            var projectJob = await _projectJobRepository.FindAsync(x => x.Id == id);
            if (projectJob == null)
            {
                return NotFound();
            }
            var response = new
            {
                Id = projectJob.Id,
                Title = projectJob.Title
            };
            return Json(response);
        }

        /// <summary>
        /// GetProjectJobSearch for auto search
        /// </summary>
        [HttpGet]
        [Route("job/search/{projectId?}/{projectJobName?}")]
        [AuthorizeTokenFilter(validate: false, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetProjectJobSearch(int projectId, string projectJobName, int userId)
        {
            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);


            IEnumerable<ProjectJob> jobs = null;

            if (isJobAdmin)
            {
                var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userId);
                jobs = await _projectJobRepository.FindAllAsync(x => assignedProjectJobs.Contains(x.Id));
            }
            else
            {
                jobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == projectId);
            }

            if (projectId > 0 && jobs != null)
            {
                if (!string.IsNullOrEmpty(projectJobName))
                {
                    var projectJobNameKeyword = projectJobName.ToLower();
                    jobs = jobs.Where(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active) && x.Title.ToLower().Contains(projectJobNameKeyword));
                    var response = jobs.Select(x => new { x.Id, Description = x.Title, IsCastingRequired = x.CastRequired }).OrderBy(x => x.Description).Take(20);
                    return Json(response);
                }
                else
                {
                    jobs = jobs.Where(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active));
                    var response = jobs.Select(x => new { x.Id, Description = x.Title, IsCastingRequired = x.CastRequired }).OrderBy(x => x.Description).Take(20);
                    return Json(response);
                }
            }
            return NotFound();
        }

        /// <summary>
        /// GetRecruiterSearch for auto search
        /// </summary>
        [HttpGet]
        [Route("talent/search/{talentName?}")]
        public async Task<ActionResult> GetTalentByName(string talentName)
        {
            //TODO: Check where it is used on screen
            // returning talentCategory only and Not their subcategory
            if (!string.IsNullOrEmpty(talentName))
            {
                var talents = await _talentCategoryRepository.FindAllAsync(x => x.ParentId == null && x.Description.ToLower().Contains(talentName.ToLower()));
                var response = talents.Select(x => new { x.Id, Description = x.Description }).OrderBy(r => r.Description).Take(20);
                return Json(response);
            }
            else
            {
                var talents = await _talentCategoryRepository.FindAllAsync(x => x.ParentId == null);
                var response = talents.Select(x => new { x.Id, Description = x.Description }).OrderBy(r => r.Description).Take(20);
                return Json(response);
            }
        }

        [HttpGet]
        [Route("nationality/search/{nationality?}")]
        public async Task<ActionResult> GetNationalityByName(string nationality)
        {
            if (!string.IsNullOrEmpty(nationality))
            {
                var nationalities = await _countryRepository.FindAllAsync(x => x.Nationality.ToLower().Contains(nationality.ToLower()));

                var response = nationalities.Select(x => new { x.Id, Description = x.Nationality }).OrderBy(r => r.Description).Take(20);
                return Json(response);
            }
            else
            {
                var nationalities = await _countryRepository.FindAllAsync(x => x.Nationality != null);
                var response = nationalities.Select(x => new { x.Id, Description = x.Nationality }).OrderBy(r => r.Description).Take(20);
                return Json(response);
            }
        }

        /// <summary>
        /// get projectJobs by projectId
        /// </summary>
        [HttpGet]
        [Route("jobsByProjectId/{projectId}")]
        public async Task<ActionResult> GetJobsByprojectId(int projectId)
        {
            var projectJob = await _projectJobRepository.FindAllAsync(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active) && x.ProjectId == projectId);
            if (projectJob != null)
                return new JsonResult(projectJob.ToList());
            return NotFound();
        }

        [Route("projectLocation")]
        [HttpGet]
        public async Task<ActionResult> GetProjectLocation()
        {
            var response = await _projectLocationRepository.GetAllAsync();
            return Json(response);
        }

        [Route("skinColor")]
        [HttpGet]
        public async Task<ActionResult> GetSkinColor()
        {
            var response = await _skinColorRepository.GetAllAsync();
            return Json(response);
        }

        [Route("status")]
        [HttpGet]
        public async Task<ActionResult> GetStatus()
        {
            var response = await _statusRepository.GetAllAsync();
            return Json(response);
        }

        [Route("waistSize")]
        [HttpGet]
        public async Task<ActionResult> GetWaistSize()
        {
            var response = await _waistSizeRepository.GetAllAsync();
            response = response.OrderBy(x => x.Cms);
            return Json(response);
        }

        [HttpPost]
        [Route("saveTagCategory/{tagDescription}/{tagTalentRelated}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> AddTagCategory(string tagDescription, bool tagTalentRelated)
        {
            if (string.IsNullOrEmpty(tagDescription))
            {
                return BadRequest();
            }
            var tagCategory = new TagCategory();
            tagCategory.Description = tagDescription;
            tagCategory.TagTalentRelated = tagTalentRelated;

            tagCategory = await _tagCategoryRepository.AddAsync(tagCategory);
            return Json(tagCategory);
        }

        //[Route("tag/{tagCategoryId}")]
        //[HttpGet]
        //[AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        //public async Task<ActionResult> TagsByTagCategoryId(int tagCategoryId)
        //{
        //    var response = await _tagRepository.FindAllAsync(x => x.TagCategoryId == tagCategoryId);
        //    return Json(response);
        //}

        [Route("tagCategory/{tagCategoryId}/{tagCategoryDescription}")]
        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> UpdateTagCategory(int tagCategoryId, string tagCategoryDescription)
        {
            if (string.IsNullOrEmpty(tagCategoryDescription))
            {
                return BadRequest();
            }

            var tagCategory = await _tagCategoryRepository.FindAsync(x => x.Id == tagCategoryId);
            if (tagCategory == null)
            {
                return NotFound();
            }
            tagCategory.Description = tagCategoryDescription;
            tagCategory = await _tagCategoryRepository.UpdateAsync(tagCategory);
            return Json(tagCategory);
        }

        /// <summary>
        /// GetTagCategory : GET 
        /// </summary>
        [HttpGet]
        [Route("tagCategory/{talentRelated?}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> GetTagCategory(bool talentRelated)
        {
            if (talentRelated)
            {
                var tagCategories = await _tagCategoryRepository.FindAllAsync(x => x.TagTalentRelated == true);
                if (tagCategories != null)
                    return Json(tagCategories);
                else
                    return NotFound();
            }
            else
            {
                var tagCategories = await _tagCategoryRepository.GetAllAsync();
                if (tagCategories != null)
                    return Json(tagCategories);
                else
                    return NotFound();
            }
        }

        /// <summary>
        /// GetTagCategorySearch for auto search
        /// </summary>
        [HttpGet]
        [Route("tagCategory/search/{tagCategoryName?}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> GetTagCategorySearch(string tagCategoryName)
        {
            if (!string.IsNullOrEmpty(tagCategoryName))
            {
                var tagCategory = await _tagCategoryRepository.FindAllAsync(x => x.Description.ToLower().Contains(tagCategoryName.Trim().ToLower()));
                var response = tagCategory.Select(x => new { x.Id, Description = x.Description }).OrderBy(x => x.Description).Take(20);
                return Json(response);
            }
            else
            {
                var tagCategory = await _tagCategoryRepository.GetAllAsync();
                var response = tagCategory.Select(x => new { x.Id, Description = x.Description }).OrderBy(x => x.Description).Take(20);
                return Json(response);
            }
        }

        /// <summary>
        /// GetTag : GET 
        /// </summary>
        [HttpGet]
        [Route("tag/{talentRelated?}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter,Talent")]
        public async Task<ActionResult> GetTag(bool talentRelated)
        {
            var tagCategoryList = new List<TagCategory>();
            if (talentRelated)
            {
                var responseResult = await _tagCategoryRepository.FindAllAsync(x => x.TagTalentRelated == true);
                if (responseResult != null)
                {
                    tagCategoryList = responseResult.ToList();
                }
            }
            else
            {
                var responseResult = await _tagCategoryRepository.GetAllAsync();
                if (responseResult != null)
                {
                    tagCategoryList = responseResult.ToList();
                }
            }
            var tagCategoryIds = tagCategoryList.Select(x => x.Id).ToList();
            var response = await _tagRepository.FindAllAsync(t => tagCategoryIds.Contains(t.TagCategoryId));
            response = response.OrderBy(r => r.Name);
            return Json(response);
        }

        /// <summary>
        /// GetTagByTagCategoryId : GET 
        /// </summary>
        [HttpGet]
        [Route("tag/{tagCategoryId}/{talentRelated?}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter,Talent")]
        public async Task<ActionResult> GetTagByTagCategoryId(int tagCategoryId, bool talentRelated)
        {
            var tagCategoryList = new List<TagCategory>();
            if (talentRelated)
            {
                var responseResult = await _tagCategoryRepository.FindAllAsync(x => x.TagTalentRelated == true && x.Id == tagCategoryId);
                if (responseResult != null)
                {
                    tagCategoryList = responseResult.ToList();
                }
            }
            else
            {
                var responseResult = await _tagCategoryRepository.FindAllAsync(x => x.Id == tagCategoryId);
                if (responseResult != null)
                {
                    tagCategoryList = responseResult.ToList();
                }
            }
            var tagCategoryIds = tagCategoryList.Select(x => x.Id).ToList();
            var response = await _tagRepository.FindAllAsync(t => tagCategoryIds.Contains(t.TagCategoryId));
            response = response.OrderBy(r => r.Name);
            return Json(response);
        }

        /// <summary>
        /// AddTag : POST 
        /// </summary>
        [HttpPost]
        [Route("tag/{tagCategoryId}/{tagName}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> AddTag(int tagCategoryId, string tagName)
        {
            if (tagCategoryId > 0 && !string.IsNullOrEmpty(tagName))
            {
                var tagCategory = await _tagCategoryRepository.FindAsync(x => x.Id == tagCategoryId);
                if (tagCategory != null)
                {
                    var response = await _tagRepository.FindAsync(x => x.Name.ToLower() == tagName.ToLower());
                    if (response != null)
                    {
                        return Json(new { response = response, status = "Already Exist" });
                    }
                    var tag = new Tag();
                    tag.Name = tagName;
                    tag.TagCategoryId = tagCategory.Id;
                    var tagResponse = await _tagRepository.AddAsync(tag);
                    return Json(new { response = tagResponse, status = "Success" });
                }
                return NotFound(tagCategoryId);
            }
            return BadRequest();
        }

        /// <summary>
        /// UpdateTag : PUT
        /// </summary>
        [HttpPut]
        [Route("tag/{tagId}/{tagCategoryId}/{tagName}")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<ActionResult> UpdateTag(int tagId, int tagCategoryId, string tagName)
        {
            if (string.IsNullOrEmpty(tagId.ToString()))
            {
                return BadRequest();
            }
            else
            {
                if (tagId > 0 && tagCategoryId > 0 && !string.IsNullOrEmpty(tagName))
                {
                    var tagCategory = await _tagCategoryRepository.FindAsync(x => x.Id == tagCategoryId);
                    if (tagCategory != null)
                    {
                        var tag = await _tagRepository.FindAsync(x => x.Id == tagId);
                        if (tag != null)
                        {
                            tag.Name = tagName;
                            tag.TagCategoryId = tagCategory.Id;
                            var tagResponse = await _tagRepository.UpdateAsync(tag);
                            return Json(new { response = tagResponse, status = "Success" });
                        }
                        return NotFound(tagId);
                    }
                    return NotFound(tagCategoryId);
                }
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("weight")]
        public async Task<ActionResult> GetWeight()
        {
            var response = await _weightRepository.GetAllAsync();
            response = response.OrderBy(x => x.Kgs);
            return Json(response);

        }

        [HttpGet]
        [Route("height")]
        public async Task<ActionResult> GetHeight()
        {
            var response = await _heightRepository.GetAllAsync();
            response = response.OrderBy(x => x.Cms);
            return Json(response);
        }

        /// <summary>
        /// Get : Tier
        /// </summary>
        [HttpGet]
        [Route("tier")]
        public async Task<ActionResult> GetTier()
        {
            var response = await _tierRepository.GetAllAsync();
            response = response.OrderBy(x => x.TierDesc);
            return Json(response);
        }

        [HttpPost]
        [Route("downloadfile")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin,Recruiter,Talent")]
        public async Task<ActionResult> DownloadFile([FromBody] string filePath, string referer)
        {
            byte[] fileBytes = await GetAsync(filePath, referer);
            string fileName = UploadExtensions.ExtractFileNameFromPath(filePath);            
            Response.Headers.Add("Content-Disposition", "attachment; filename="+ fileName);

            string contentType;
            new FileExtensionContentTypeProvider().TryGetContentType(fileName, out contentType);
            contentType = contentType ?? "application/octet-stream";
            //return File(fileBytes, "application/force-download", fileName);
            return File(fileBytes, contentType, fileName);
        }

        public async static Task<byte[]> GetAsync(string uri, string referer)
        {
            byte[] responseString = null;
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Referer", referer);

                var response = await client.GetAsync(uri);
                response.EnsureSuccessStatusCode();
                responseString = await response.Content.ReadAsByteArrayAsync();
            }
            return responseString;
        }
    }
}
