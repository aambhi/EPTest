﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    /// <summary>
    /// Controller to perform recruiter plan crud
    /// </summary>
    public class RecruiterPlanController : Controller
    {
        private IRecruiterPlanRepository _recruiterPlanRepository;

        private const string All = "all";
        private const string Specific = "specific";
        /// <summary>
        /// 
        /// </summary>
        /// <param name="recruiterPlanRepository"></param>
        public RecruiterPlanController(IRecruiterPlanRepository recruiterPlanRepository)
        {
            _recruiterPlanRepository = recruiterPlanRepository;
        }


        /// <summary>
        /// post recruiter plan
        /// </summary>
        [HttpPost]
        [Route("recruiterPlan/create")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> Post([FromBody] RecruiterPlanDto recruiterPlanDto, UserInfo userInfo)
        {
            bool isFreePlan = false;
            if (recruiterPlanDto == null)
            {
                return BadRequest();
            }
            try
            {
                //if plan is open in edit mode then only deactivate the previous plan
                if (recruiterPlanDto.Id > 0)
                {
                    var previousPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == recruiterPlanDto.Id);
                    if (previousPlan != null)
                    {
                        previousPlan.StatusId = (int)StatusEnum.InActive;
                        //need to check whether the created plan is free plan is available
                        if (previousPlan.IsFreePlan)
                        {
                            isFreePlan = true;
                            previousPlan.IsFreePlan = false;
                        }
                        await _recruiterPlanRepository.UpdateAsync(previousPlan);
                    }
                }
                //add the new plan
                var recruiterPlan = ConvertToRecruiterPlanModel(recruiterPlanDto, userInfo);

                if (isFreePlan)
                    recruiterPlan.IsFreePlan = true;
                var newRecruiterPlan = await _recruiterPlanRepository.AddAsync(recruiterPlan);
                recruiterPlanDto.Id = newRecruiterPlan.Id;
            }
            catch (Exception ex)
            {
                throw;
            }
            return new JsonResult(recruiterPlanDto);
        }

        [HttpGet]
        [Route("recruiterPlan/IsPlanNameExist/{planName}")]
        public async Task<IActionResult> IsPlanNameExist(string planName)
        {
            if (planName == null)
            {
                return BadRequest();
            }
            else
            {
                var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Name.ToLower() == planName.ToLower() && x.Name != string.Empty && x.StatusId == (int)StatusEnum.Active);
                if (recruiterPlan == null)
                {
                    return NotFound();
                }
                else
                {
                    return Ok(new { planName = recruiterPlan.Name, status = "Success" });
                }
            }
        }

        private RecruiterPlan ConvertToRecruiterPlanModel(RecruiterPlanDto recruiterPlanDto, UserInfo userInfo)
        {
            return new RecruiterPlan
            {
                Name = recruiterPlanDto.PlanName,
                Description = recruiterPlanDto.Description,
                Amount = recruiterPlanDto.Amount,
                ManageContract = recruiterPlanDto.ManageContract,
                RoleCount = recruiterPlanDto.RoleCount,
                RecommendedCount = recruiterPlanDto.RecommendedCount,
                AuditionSelectionCount = recruiterPlanDto.selectedForAudition,
                ViewPortfolio = recruiterPlanDto.IsViewPortfolio,
                AllowedOnlineAudition = recruiterPlanDto.IsOnlineAudition,
                ProvideNotesRating = recruiterPlanDto.IsProvideNotesRating,
                ProjectValidity = recruiterPlanDto.ProjectValidity,
                ViewAuditionHistory = recruiterPlanDto.ViewAuditionHistory,
                SocialIntegration = recruiterPlanDto.IsSocialIntegration,
                NumberOfUsers = recruiterPlanDto.NumberOfUsers,
                StatusId = recruiterPlanDto.RecruiterType == All ? (int)StatusEnum.Active : (int)StatusEnum.Custom,
                RecruiterPlanUser = recruiterPlanDto.RecruiterType == Specific ? getRecruiterPlanUsers(recruiterPlanDto.Recruiters) : null,
                CreatedBy = userInfo.userId,
                CreatedOn = DateTime.UtcNow
        };
    }

    private ICollection<RecruiterPlanUser> getRecruiterPlanUsers(List<MultiSelectDto> recruiters)
    {
        var recruiterPlanUsers = new List<RecruiterPlanUser>();
        if (recruiters != null && recruiters.Count > 0)
        {
            foreach (var recruiter in recruiters)
            {
                recruiterPlanUsers.Add(new RecruiterPlanUser
                {
                    AuxiliaryUserId = recruiter.Id
                });
            }
        }
        return recruiterPlanUsers;
    }
}
}
