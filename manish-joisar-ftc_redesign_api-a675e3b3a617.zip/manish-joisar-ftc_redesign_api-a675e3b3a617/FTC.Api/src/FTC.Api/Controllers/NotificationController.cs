﻿using FTC.Api.Filters;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Notification;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    public class NotificationController : Controller
    {
        private IUserNotificationRepository _userNotificationRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IContestRepository _contestRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private const string constantUser= "User";

        public NotificationController(IUserNotificationRepository userNotificationRepository,
                                        IProjectRepository projectRepository,
                                        IProjectJobRepository projectJobRepository,
                                        IContestRepository contestRepository,
                                        IAuxiliaryUserRepository auxiliaryUserRepository)
        {
            _userNotificationRepository = userNotificationRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _contestRepository = contestRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
        }

        #region Public Actions

        [HttpPost]
        [Route("notification")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin,Recruiter")]
        public async Task<ActionResult> GetUserNotification([FromBody]RequestUserNotificationParam requestUserNotificationParam, int userId, int userType)
        {
            if (requestUserNotificationParam == null)
            {
                return BadRequest();
            }

            var lstUserNotification = new List<UserNotification>();
            if (userType == (int)LoginEnum.LoginUserType.Talent)
            {
                var userNotifications = await _userNotificationRepository.FindAllAsync(x => x.TalentId == userId);
                lstUserNotification = userNotifications.ToList();
            }
            else
            {
                var userNotifications = await _userNotificationRepository.FindAllAsync(x => x.AuxiliaryUserId == userId);
                // show only unread notification
                lstUserNotification = userNotifications.ToList();
            }

            #region Filter Notification based on Reference Name - { Project, Job, Contest}

            if (requestUserNotificationParam.NotificationReferenceFilter != NotificationReferenceEnum.All)
            {
                if (requestUserNotificationParam.NotificationReferenceFilter == NotificationReferenceEnum.Project)
                {
                    lstUserNotification = lstUserNotification.Where(x => x.ProjectId > 0).ToList();
                }
                else if (requestUserNotificationParam.NotificationReferenceFilter == NotificationReferenceEnum.Job)
                {
                    lstUserNotification = lstUserNotification.Where(x => x.JobId > 0).ToList();
                }
                else if (requestUserNotificationParam.NotificationReferenceFilter == NotificationReferenceEnum.ReferenceAuxiliaryUserId)
                {
                    lstUserNotification = lstUserNotification.Where(x => x.ReferenceAuxiliaryUserId > 0).ToList();
                }
                else
                {
                    lstUserNotification = lstUserNotification.Where(x => x.ContestId > 0).ToList();
                }
            }

            #endregion

            #region filter based on Read Status
            if (requestUserNotificationParam.NotificationReadStatus != NotificationReadStatus.All)
            {
                if (requestUserNotificationParam.NotificationReadStatus == NotificationReadStatus.Read)
                {
                    lstUserNotification = lstUserNotification.Where(x => x.Read == true).ToList();
                }
                else
                {
                    lstUserNotification = lstUserNotification.Where(x => x.Read == false).ToList();
                }
            }
            #endregion

            #region Search: Search based on Reference Name or Notification Description
            if (!string.IsNullOrEmpty(requestUserNotificationParam.SearchKeyword))
            {
                //// search by reference name
                //var lstUserNotificationByReference = lstUserNotification.Where(x => x.ReferenceName.Contains(requestUserNotificationParam.SearchKeyword));

                // search by Notification text
                lstUserNotification = lstUserNotification.Where(x => x.Text.ToLower().Contains(requestUserNotificationParam.SearchKeyword.ToLower())).ToList();

                //lstUserNotification = lstUserNotification.Union(lstUserNotificationByReference).ToList();

            }
            #endregion

            #region pagination of User Notification by CreatedOn - latest notification first
            int startIndex = (requestUserNotificationParam.CurrentPage > 0) ? ((requestUserNotificationParam.CurrentPage) * requestUserNotificationParam.PerPageRecord + 1) : requestUserNotificationParam.CurrentPage;
            int endIndex = (requestUserNotificationParam.CurrentPage > 0) ? (startIndex + requestUserNotificationParam.PerPageRecord) : requestUserNotificationParam.PerPageRecord;

            var userNotificationCount = lstUserNotification.Count();
            // order by created on
            lstUserNotification = lstUserNotification.OrderByDescending(x => x.CreatedOn)
                                    .Skip(startIndex - 1)
                                    .Take(endIndex - startIndex)
                                    .ToList();
            #endregion

            var lstUserNotificationDto = new List<UserNotificationDto>();
            foreach (var notification in lstUserNotification)
            {
                var userNotificationDto = await ConvertToUserNotificationDto(notification);
                lstUserNotificationDto.Add(userNotificationDto);
            }


            return Json(new { userNotifications = lstUserNotificationDto, userNotificationCount = userNotificationCount });
        }

        [HttpGet]
        [Route("notification/{notificationId}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin,Recruiter")]
        public async Task<ActionResult> UpdateNotificationStatus(int notificationId, int userId, int userType)
        {
            if (notificationId == null || notificationId == 0)
            {
                return BadRequest();
            }

            var userNotification = new UserNotification();
            if (userType == (int)LoginEnum.LoginUserType.Talent)
            {
                userNotification = await _userNotificationRepository.FindAsync(x => x.TalentId == userId && x.Id == notificationId);
            }
            else
            {
                userNotification = await _userNotificationRepository.FindAsync(x => x.AuxiliaryUserId == userId && x.Id == notificationId);
            }
            if (userNotification == null)
            {
                return NotFound();
            }
            if (!userNotification.Read)
            {
                userNotification.Read = true;
                userNotification = await _userNotificationRepository.UpdateAsync(userNotification);
            }
            var userNotificationDto = await ConvertToUserNotificationDto(userNotification);

            return Json(new { userNotification = userNotificationDto });
        }

        [HttpDelete]
        [Route("notification")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin,Recruiter")]
        public async Task<ActionResult> RemoveNotifications([FromBody]List<int> lstNotificationId, int userId, int userType)
        {
            if(lstNotificationId == null)
            {
                return BadRequest();
            }
            int result = 0;
            foreach (var notificationId in lstNotificationId)
            {
                var userNotification = new UserNotification();
                if (userType == (int)LoginEnum.LoginUserType.Talent)
                {   
                    userNotification = await _userNotificationRepository.FindAsync(x => x.TalentId == userId && x.Id == notificationId);
                }
                else
                {
                    userNotification = await _userNotificationRepository.FindAsync(x => x.AuxiliaryUserId == userId && x.Id == notificationId);
                }
                if (userNotification != null)
                {
                    result = await _userNotificationRepository.DeleteAsync(userNotification);
                }
            }
            return Json(result);
        }

        #endregion

        #region Private Method

        private async Task<UserNotificationDto> ConvertToUserNotificationDto(UserNotification userNotification)
        {
            var userNotificationDto = new UserNotificationDto();
            userNotificationDto.Id = userNotification.Id;

            userNotificationDto.Text = userNotification.Text;

            userNotificationDto.CreatedOn = userNotification.CreatedOn;

            userNotificationDto.ProjectId = userNotification.ProjectId;

            userNotificationDto.JobId = userNotification.JobId;

            userNotificationDto.ReferenceAuxiliaryUserId = userNotification.ReferenceAuxiliaryUserId;

            userNotificationDto.ContestId = userNotification.ContestId;

            userNotificationDto.Read = userNotification.Read;

            if (userNotification.ProjectId > 0)
            {
                userNotificationDto.Reference = NotificationReferenceEnum.Project.ToString();
                var project = await _projectRepository.FindAsync(x => x.Id == userNotification.ProjectId);
                userNotificationDto.ProjectName = project.Name;
                userNotificationDto.ReferenceName = project.Name;
            }
            else if (userNotification.JobId > 0)
            {
                userNotificationDto.Reference = NotificationReferenceEnum.Job.ToString();
                var projectJob = await _projectJobRepository.FindAsync(x => x.Id == userNotification.JobId);
                userNotificationDto.JobName = projectJob.Title;
                userNotificationDto.ReferenceName = projectJob.Title;
            }
            else if (userNotification.ReferenceAuxiliaryUserId > 0)
            {
                //userNotificationDto.Reference = NotificationReferenceEnum.ReferenceAuxiliaryUserId.ToString();                
                userNotificationDto.Reference = constantUser;
                var referenceAuxiliaryUserId = await _auxiliaryUserRepository.FindAsync(x => x.Id == userNotification.ReferenceAuxiliaryUserId);
                userNotificationDto.ReferenceAuxiliaryUserName = referenceAuxiliaryUserId.FullName;
                userNotificationDto.ReferenceName = referenceAuxiliaryUserId.FullName;
            }
            else
            {
                userNotificationDto.Reference = NotificationReferenceEnum.Contest.ToString();
                var contest = await _contestRepository.FindAsync(x => x.Id == userNotification.ContestId);
                userNotificationDto.ContestName = contest.Title;
                userNotificationDto.ReferenceName = contest.Title;
            }

            // Null handling - if UrlRoute is null for existing data 
            userNotificationDto.UrlRoute = userNotification.UrlRoute !=null ? (ViewNotificationEnumDto)userNotification.UrlRoute : 0;

            return userNotificationDto;
        }

        #endregion

    }
}
