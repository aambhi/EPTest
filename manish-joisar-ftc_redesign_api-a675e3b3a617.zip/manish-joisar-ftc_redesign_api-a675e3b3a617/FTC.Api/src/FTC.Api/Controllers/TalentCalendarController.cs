﻿using FTC.Api.Filters;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class TalentCalendarController : Controller
    {
        private ITalentCalendarRepository _talentCalendarRepository;
        private ITalentRepository _talentRepository;

        public TalentCalendarController(ITalentCalendarRepository talentCalendarRepository,
                                        ITalentRepository talentRepository)
        {
            _talentCalendarRepository = talentCalendarRepository;
            _talentRepository = talentRepository;
        }

        #region Public Actions
        [HttpGet]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> GetTalentCalendar(int userId)
        {
            int talentId = userId;
            var calendarResponse = await _talentCalendarRepository.FindAllAsync(x => x.TalentId == talentId);

            List<TalentCalendarDto> talentCalendarList = new List<TalentCalendarDto>();

            foreach (var talentCalendar in calendarResponse)
            {
                TalentCalendarDto talentCalendarDto = await ConvertToTalentCalendarDto(talentCalendar);
                talentCalendarList.Add(talentCalendarDto);
            }
            return Json(talentCalendarList);
        }

        [HttpPost]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> CreateTalentCalendar([FromBody]TalentCalendarDto talentCalendarDto, int userId)
        {
            if (talentCalendarDto == null)
            {
                return BadRequest();
            }

            int talentId = userId;

            TalentCalendar talentCalendar = ConvertToTalentCalendar(talentCalendarDto);
            talentCalendar.TalentId = talentId;

            var calendarResponse = await _talentCalendarRepository.AddAsync(talentCalendar);
            return Json(ConvertToTalentCalendarDto(calendarResponse));
        }

        [HttpPut("{id}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> UpdateTalentCalendar(int id, [FromBody]TalentCalendarDto talentCalendarDto, int userId)
        {
            if (talentCalendarDto == null)
            {
                return BadRequest();
            }

            int talentId = userId;

            var talentCalendar = await _talentCalendarRepository.FindAsync(x => x.Id == id);

            if (talentCalendar == null)
            {
                return NotFound();
            }

            talentCalendar.Title = talentCalendarDto.Title;
            talentCalendar.Description = talentCalendarDto.Description;
            talentCalendar.FromDateTime = talentCalendarDto.FromDateTime;
            talentCalendar.ToDateTime = talentCalendarDto.ToDateTime;

            var calendarResponse = await _talentCalendarRepository.UpdateAsync(talentCalendar);


            return Json(ConvertToTalentCalendarDto(calendarResponse));
        }


        [HttpDelete]
        [Route("{id}")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<ActionResult> DeleteTalentCalendar(int id, int userId)
        {
            int talentId = userId;
            var calendarResponse = await _talentCalendarRepository.FindAsync(x => x.TalentId == talentId && x.Id == id);
            var result = await _talentCalendarRepository.DeleteAsync(calendarResponse);
            return Json(result);
        }
        #endregion

        #region Private Methods
        [NonAction]
        private async Task<TalentCalendarDto> ConvertToTalentCalendarDto(TalentCalendar calendarResponse)
        {
            TalentCalendarDto talentCalendar = new TalentCalendarDto();
            talentCalendar.Id = calendarResponse.Id;
            talentCalendar.Title = calendarResponse.Title;
            talentCalendar.Description = calendarResponse.Description;
            talentCalendar.FromDateTime = calendarResponse.FromDateTime;
            talentCalendar.ToDateTime = calendarResponse.ToDateTime;
            talentCalendar.TalentId = calendarResponse.TalentId;

            return talentCalendar;
        }

        [NonAction]
        private TalentCalendar ConvertToTalentCalendar(TalentCalendarDto talentCalendarDto)
        {
            TalentCalendar talentCalendar = new TalentCalendar();
            talentCalendar.Id = talentCalendarDto.Id;
            talentCalendar.Title = talentCalendarDto.Title;
            talentCalendar.Description = talentCalendarDto.Description;
            talentCalendar.FromDateTime = talentCalendarDto.FromDateTime;
            talentCalendar.ToDateTime = talentCalendarDto.ToDateTime;

            return talentCalendar;
        }
        #endregion
    }
}
