﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using FTCApi.Dtos.PaymentDtos;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class PaymentController : Controller
    {

        #region Private Variables

        private IPaymentRepository _paymentRepository;
        private IConfiguration _configuration;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IEmailService _emailService;
        private ITalentRepository _talentRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private ITalentPlanRepository _talentPlanRepository;
        private ITalentPlanFeatureRepository _talentPlanFeatureRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private ITalentTokenRepository _talentTokenRepository;
        private const string constantActivated = "Activated";
        private AppSettings _appSettings;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="paymentRepository"></param>
        /// <param name="configuration"></param>
        public PaymentController(IPaymentRepository paymentRepository, IConfiguration configuration, INotificationHeaderRepository notificationHeaderRepository,
            IUserNotificationRepository userNotificationRepository,
            ITalentPlanRepository talentPlanRepository,
            ITalentPlanFeatureRepository talentPlanFeatureRepository,
            INotificationDetailRepository notificationDetailRepository, 
            IEmailService emailService, 
            ITalentRepository talentRepository, 
            IAuxiliaryUserRepository auxiliaryUserRepository, 
            ISmsProviderRepository smsProviderRepository,
            ITalentTokenRepository talentTokenRepository)
        {
            _paymentRepository = paymentRepository;
            _configuration = configuration;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _talentRepository = talentRepository;
            _emailService = emailService;
            _userNotificationRepository = userNotificationRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _talentPlanRepository = talentPlanRepository;
            _talentPlanFeatureRepository = talentPlanFeatureRepository;
            _smsProviderRepository = smsProviderRepository;
            _talentTokenRepository = talentTokenRepository;
            _appSettings = new AppSettings(_configuration);
        }

        #endregion

        #region Public Actions

        /// <summary>
        /// This action is use to get talent plans
        /// </summary>
        /// <param name="userId">model binding: talent id</param>
        /// <returns>returns list of talent plans</returns>
        [HttpGet]
        [Route("talent/plans")]
        [AuthorizeTokenFilter(validate: true, role: "Talent,FTCAdmin,Recruiter")]
        public async Task<IActionResult> GetTalentPlans(int userId)
        {
            var talentPlans = await _paymentRepository.GetTalentPlans(userId);
            if (talentPlans != null && talentPlans.Count > 0)
            {
                return Ok(talentPlans);
            }
            return NotFound();
        }

        /// <summary>
        /// This action is use to create order 
        /// </summary>
        /// <param name="data">{"amount":"1000"}</param>
        /// <param name="userId">model binding: talent id</param>
        /// <returns></returns>
        [HttpPost]
        [Route("talent/createorder")]
        [AuthorizeTokenFilter(validate: true, role: "Talent, Recruiter")]
        public async Task<IActionResult> CreateOrder([FromBody]Dictionary<string, object> data, int userId, int userType)
        {
            if (data == null)
            {
                return BadRequest();
            }

            var credentials = InitPaymentCredentials();
            if (data != null)
            {
                data.Add("currency", "INR");
                data.Add("receipt", Guid.NewGuid());
            }
            var order = await _paymentRepository.CreateOrder(credentials, userId, data, userType);
            if (order != null)
            {
                return Ok(order);
            }

            return NotFound();
        }

        /// <summary>
        /// This action is use to capture payment 
        /// </summary>
        /// <param name="userId">model binding: talent id</param>
        /// <param name="paymentRequest">payment request object</param>
        /// <returns></returns>
        [HttpPost]
        [Route("talent/capturepayment")]
        [AuthorizeTokenFilter(validate: true, role: "Talent")]
        public async Task<IActionResult> CapturePayment(int userId, [FromBody]PaymentRequest paymentRequest)
        {
            if (paymentRequest == null || paymentRequest.Plans == null)
            {
                return BadRequest();
            }

            paymentRequest.TalentId = userId;
            var credentials = InitPaymentCredentials();

            var payment = await _paymentRepository.CapturePayment(credentials, paymentRequest);
            if (payment != null)
            {
                await SendPaymentCaptureNotificationToTalent(userId, payment);

                return Ok(payment);
            }

            return NotFound();
        }

        /// <summary>
        /// This action is use to capture payment 
        /// </summary>
        /// <param name="userId">model binding: talent id</param>
        /// <param name="paymentRequest">payment request object</param>
        /// <returns></returns>
        [HttpPost]
        [Route("recruiter/capturepayment")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter")]
        public async Task<IActionResult> CaptureRecruiterPayment(int userId, [FromBody]PaymentRequest paymentRequest)
        {
            if (paymentRequest == null || paymentRequest.Plans == null)
            {
                return BadRequest();
            }

            paymentRequest.AuxiliaryUserId = userId;
            var credentials = InitPaymentCredentials();

            try
            {
                var payment = await _paymentRepository.CaptureRecruiterPayment(credentials, paymentRequest);
                if (payment != null)
                {
                    await SendRecruiterPaymentCaptureNotification(userId, payment);

                    return Ok(payment);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error while capturing payment" + ex);
                throw ex;
            }

            return NotFound();
        }

        [HttpPost]
        [Route("talent/planfeature/create")]
        [AuthorizeTokenFilter(validate: true, role: "FTCAdmin")]
        public async Task<IActionResult> SaveTalentPlanFeature([FromBody]PlanFeatureDto planFeatureDto, UserInfo userInfo)
        {
            if (planFeatureDto == null)
            {
                return BadRequest();
            }

            var talentPlanResponse = await _talentPlanRepository.FindAsync(x => x.Id == planFeatureDto.PlanId);
            if (talentPlanResponse != null)
            {
                talentPlanResponse.StatusId = (int)StatusEnum.InActive;
                talentPlanResponse = await _talentPlanRepository.UpdateAsync(talentPlanResponse);
            }

            var talentPlan = await _paymentRepository.SaveTalentPlan(planFeatureDto, userInfo.userId);

            var talentPlanFeatures = await _paymentRepository.SaveTalentPlanFeatures(talentPlan.Id, planFeatureDto);

            return Json(new { talentPlan = talentPlan});
        }
        
        #endregion

        #region Private Methods

        private Credentials InitPaymentCredentials() => new Credentials { Key = _appSettings.RazorpayKey, Secret = _appSettings.RazorpaySecret };

        private async Task SendPaymentCaptureNotificationToTalent(int talentId, Razorpay.Payment payment)
        {
            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);

            decimal paymentAmount = GetPaymentAmount(payment);

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            var notificationParam = new NotificationParam
            {
                TalentId = talentId,                
                Email = talent.Email,
                FullName = talent.FullName,
                DeviceOsId = talent.DeviceOsId,
                DeviceRegistrationId = talent.DeviceRegistrationId,
                IsEmailVerifed = talentToken.Email == constantActivated ? true : false,           // send email only if Email is verified
                MobileCountryCode = talent.MobileCountryCode,
                MobileNumber = talent.Mobile,
                PaymentAmount = paymentAmount.ToString()
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            await notification.SendNotification(NotificationEnum.CapturePayment, notificationParam, sendSystemNotificationDto);
        }


        private async Task SendRecruiterPaymentCaptureNotification(int auxiliaryUserId, Razorpay.Payment payment)
        {
            decimal paymentAmount = GetPaymentAmount(payment);

            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUserId);

            var notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            var notificationParam = new NotificationParam
            {
                AuxiliaryUserId = auxiliaryUserId,
                Email = auxiliaryUser.EmailId,
                FullName = auxiliaryUser.FullName,
                MobileCountryCode = auxiliaryUser.MobileCountryCode,
                MobileNumber = auxiliaryUser.Mobile,
                PaymentAmount = paymentAmount.ToString()
            };

            var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
            await notification.SendNotification(NotificationEnum.CapturePayment, notificationParam, sendSystemNotificationDto);
        }

        private decimal GetPaymentAmount(Razorpay.Payment payment)
        {
            var transactionAmount = ((JValue)(((JToken)payment.Attributes).Root["amount"])).Value;
            var paymentAmount = Convert.ToDecimal(transactionAmount) / 100;

            return paymentAmount;
        }
        #endregion
    }
}
