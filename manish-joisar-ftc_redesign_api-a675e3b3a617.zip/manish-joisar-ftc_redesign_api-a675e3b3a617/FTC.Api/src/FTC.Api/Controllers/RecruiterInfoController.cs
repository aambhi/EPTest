﻿using FTC.Api.CommonServices;
using FTC.Api.Filters;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Notification;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Controllers
{
    [Route("[controller]")]
    public class RecruiterInfoController : Controller
    {
        private IRecruiterInfoRepository _recruiterInfoRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IAuxiliaryUserTokenRepository _auxiliaryUserTokenRepository;
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private INotificationHeaderRepository _notificationHeaderRepository;
        private INotificationDetailRepository _notificationDetailRepository;
        private IEmailService _emailService;
        private ITalentRepository _talentRepository;
        private IUserNotificationRepository _userNotificationRepository;
        private ISmsProviderRepository _smsProviderRepository;
        private IAuxiliaryUserStatusHistoryRepository _auxiliaryUserStatusHistoryRepository;

        public RecruiterInfoController(IRecruiterInfoRepository recruiterInfoRepository, IAuxiliaryUserRepository auxiliaryUserRepository,
                                IAuxiliaryUserTokenRepository auxiliaryUserTokenRepository,
                                INotificationDetailRepository notificationDetailRepository,
                                INotificationHeaderRepository notificationHeaderRepository, Microsoft.Extensions.Configuration.IConfiguration configuration,
                                IEmailService emailService,
                                IUserNotificationRepository userNotificationRepository,
                                ITalentRepository talentRepository, ISmsProviderRepository smsProviderRepository,
                                IAuxiliaryUserStatusHistoryRepository auxiliaryUserStatusHistoryRepository)
        {
            _recruiterInfoRepository = recruiterInfoRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _auxiliaryUserTokenRepository = auxiliaryUserTokenRepository;
            _configuration = configuration;
            _notificationDetailRepository = notificationDetailRepository;
            _notificationHeaderRepository = notificationHeaderRepository;
            _emailService = emailService;
            _userNotificationRepository = userNotificationRepository;
            _talentRepository = talentRepository;
            _smsProviderRepository = smsProviderRepository;
            _auxiliaryUserStatusHistoryRepository = auxiliaryUserStatusHistoryRepository;
        }

        #region Public Actions

        [HttpGet]
        //[Route("recruiterprofile/{id?}")]
        [Route("recruiterprofile/{id:int?}")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> GetRecruiterProfile(int userId, int userType, int id = 0)
        {
            int recruiterId = userId;
            if (id > 0 && (userType == (int)LoginUserType.FTCAdmin))
            {
                recruiterId = id;
            }

            RecruiterInfoDto recruiterInfoDto = new RecruiterInfoDto();

            recruiterInfoDto.AuxiliaryUser = await _recruiterInfoRepository.GetAuxiliaryUser(recruiterId);
            recruiterInfoDto.AuxiliaryRecruiter = await _recruiterInfoRepository.GetAuxiliaryRecruiter(recruiterId);
            recruiterInfoDto.AuxiliaryUserExperiences = await _recruiterInfoRepository.GetAuxiliaryUserExperiences(recruiterId);
            recruiterInfoDto.AuxiliaryUserAwards = await _recruiterInfoRepository.GetAuxiliaryUserAwards(recruiterId);
            recruiterInfoDto.AuxiliaryUserSocialLinks = await _recruiterInfoRepository.GetAuxiliaryUserSocialLinks(recruiterId);
            recruiterInfoDto.AuxiliaryUserAssociations = await _recruiterInfoRepository.GetAuxiliaryUserAssociations(recruiterId);
            recruiterInfoDto.AuxiliarySecurityQuestions = await _recruiterInfoRepository.GetAuxiliarySecurityQuestions(recruiterId);
            return Json(recruiterInfoDto);

        }

        [HttpPost]
        [Route("saverecruiterprofile")]
        [AuthorizeTokenFilter(validate: true, role: "Recruiter,FTCAdmin")]
        public async Task<ActionResult> SaveRecruiterProfile([FromBody]RecruiterInfoDto recruiterInfoDto, int userId, int userType)
        {
            bool IsnewRecruiter = false;
            int recruiterId;
            if (userType == (int)LoginUserType.FTCAdmin)
            {
                if (recruiterInfoDto.AuxiliaryUser.Id == 0)
                {

                    bool isNewUser = await IsNewUser(recruiterInfoDto.AuxiliaryUser.EmailId, recruiterInfoDto.AuxiliaryUser.Mobile);

                    if (isNewUser)
                    {
                        string randomPassword = _recruiterInfoRepository.RandomString(8);

                        string hashToStoreInDatabase = BCrypt.Net.BCrypt.HashPassword(randomPassword, BCrypt.Net.BCrypt.GenerateSalt());
                        recruiterInfoDto.AuxiliaryUser.Password = hashToStoreInDatabase;

                        recruiterInfoDto.AuxiliaryUser = await _recruiterInfoRepository.CreateRecruiter(userId, recruiterInfoDto.AuxiliaryUser);

                        await NotifyRecruiterCreation(recruiterInfoDto, userId, randomPassword);

                        IsnewRecruiter = true;
                    }
                    else
                    {
                        return BadRequest(new { talent = "User Already Exist" });
                    }
                }
                recruiterId = recruiterInfoDto.AuxiliaryUser.Id;

                #region Add AuxiliaryUserStatusHistory when recruiter is created  or when admin updates recruiter profile

                await AddCreateRecruiterStatusHistory(recruiterInfoDto, userId);

                #endregion
            }
            else
            {
                recruiterId = userId;
            }
                        
            var recruiter = await _auxiliaryUserRepository.FindAsync(x => x.Id == recruiterId);

            if (recruiterInfoDto.AuxiliaryUser != null && !IsnewRecruiter)
            {
                var auxiliaryUser = await _recruiterInfoRepository.SaveAuxiliaryUser(recruiterId, recruiterInfoDto.AuxiliaryUser);
                recruiterInfoDto.AuxiliaryUser = auxiliaryUser;
            }
            if (recruiterInfoDto.AuxiliaryRecruiter != null)
            {
                var auxiliaryRecruiter = await _recruiterInfoRepository.SaveAuxiliaryRecruiter(recruiterId, recruiterInfoDto.AuxiliaryRecruiter);
                recruiterInfoDto.AuxiliaryRecruiter = auxiliaryRecruiter;
            }
            var auxiliaryUserExperiences = await _recruiterInfoRepository.SaveAuxiliaryUserExperiences(recruiterId, recruiterInfoDto.AuxiliaryUserExperiences);
            recruiterInfoDto.AuxiliaryUserExperiences = auxiliaryUserExperiences;
            var auxiliaryUserAwards = await _recruiterInfoRepository.SaveAuxiliaryUserAwards(recruiterId, recruiterInfoDto.AuxiliaryUserAwards);
            recruiterInfoDto.AuxiliaryUserAwards = auxiliaryUserAwards;
            var auxiliaryUserSocialLinks = await _recruiterInfoRepository.SaveAuxiliarySocialLinks(recruiterId, recruiterInfoDto.AuxiliaryUserSocialLinks);
            recruiterInfoDto.AuxiliaryUserSocialLinks = auxiliaryUserSocialLinks;
            var auxiliaryUserAssociations = await _recruiterInfoRepository.SaveAuxiliaryUserAssociations(recruiterId, recruiterInfoDto.AuxiliaryUserAssociations);
            recruiterInfoDto.AuxiliaryUserAssociations = auxiliaryUserAssociations;
            var auxiliarySecurityQuestions = await _recruiterInfoRepository.SaveAuxiliarySecurityQuestions(recruiterId, recruiterInfoDto.AuxiliarySecurityQuestions);
            recruiterInfoDto.AuxiliarySecurityQuestions = auxiliarySecurityQuestions;

            return Json(recruiterInfoDto);

        }

        private async Task AddCreateRecruiterStatusHistory(RecruiterInfoDto recruiterInfoDto, int userId)
        {
            var auxiliaryUserStatusHistory = new AuxiliaryUserStatusHistory()
            {
                CreatedBy = userId,
                AuxiliaryUserId = recruiterInfoDto.AuxiliaryUser.Id,
                StatusId = recruiterInfoDto.AuxiliaryUser.StatusId                
            };

            await _auxiliaryUserStatusHistoryRepository.AddAsync(auxiliaryUserStatusHistory);
        }

        private async Task NotifyRecruiterCreation(RecruiterInfoDto recruiterInfoDto, int userId, string randomPassword)
        {
            Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

            var notificationParam = new NotificationParam
            {
                AuxiliaryUserId = userId,
                Email = recruiterInfoDto.AuxiliaryUser.EmailId,
                FullName = recruiterInfoDto.AuxiliaryUser.FullName,
                UserPassword = randomPassword,
                MobileNumber = recruiterInfoDto.AuxiliaryUser.Mobile,
                MobileCountryCode = recruiterInfoDto.AuxiliaryUser.MobileCountryCode
            };

            RequestSendSystemNotificationDto sendSystemNotificationDto = null;

            await notification.SendNotification(NotificationEnum.CreateRecruiter, notificationParam, sendSystemNotificationDto);

            sendSystemNotificationDto = new RequestSendSystemNotificationDto
            {
                SendNotificationToAuxiliaryUsers = await _auxiliaryUserRepository.NotifyListOfAdmin(),
                NotificationReference = NotificationReferenceEnum.ReferenceAuxiliaryUserId,
                NotificationReferenceValue = recruiterInfoDto.AuxiliaryUser.Id,
                UrlRoute = ViewNotificationEnumDto.EditRecruiter
            };

            // Send EMAIL AND SMS to  Su,Sys Admin when a new recruiter registers                    
            var auxiliaryUsers = await _auxiliaryUserRepository.FindAllAsync(x => sendSystemNotificationDto.SendNotificationToAuxiliaryUsers.Contains(x.Id));
            // Remove the sender from the list
            auxiliaryUsers = auxiliaryUsers.Where(x => x.Id != userId);
            sendSystemNotificationDto.SendEmailToAuxiliaryUsers = auxiliaryUsers.Select(x => x.EmailId).ToList();

            // list with params to send sms
            notificationParam.SendSmsToAuxiliaryUsers = auxiliaryUsers.Select(x => new SendSmsToUsers
            {
                AuxiliaryUserId = x.Id,
                MobileCountryCode = x.MobileCountryCode,
                MobileNumber = x.Mobile
            }).ToList();
            notificationParam.Email = string.Empty;                 // remove recriuter's email 
            notificationParam.MobileNumber = string.Empty;          // remove recriuter's number 


            await notification.SendNotification(NotificationEnum.NewRecruiterCreated, notificationParam, sendSystemNotificationDto);
        }

        #endregion


        #region

        [NonAction]
        private async Task ChangeInEmailId(string newEmail, AuxiliaryUser auxiliaryUser)
        {
            if (newEmail != auxiliaryUser.EmailId)
            {
                var auxiliaryUserToken = await _auxiliaryUserTokenRepository.FindAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);
                auxiliaryUserToken.Email = Guid.NewGuid().ToString();

                auxiliaryUserToken = await _auxiliaryUserTokenRepository.UpdateAsync(auxiliaryUserToken);

                Notification notification = new Notification(_configuration, _notificationDetailRepository, _notificationHeaderRepository, _userNotificationRepository, _emailService, _smsProviderRepository);

                var notificationParam = new NotificationParam
                {
                    Email = newEmail,
                    FullName = auxiliaryUser.FullName,
                    UniqueId = auxiliaryUserToken.Email,
                    AuxiliaryUserId = auxiliaryUser.Id
                    
                };

                var sendSystemNotificationDto = new RequestSendSystemNotificationDto();
                await notification.SendNotification(NotificationEnum.ChangeinEmailRecruiter, notificationParam, sendSystemNotificationDto);
            }
        }

        [NonAction]
        private async Task<bool> IsNewUser(string email, string mobileNumber)
        {
            var talentModel = await _talentRepository.FindAsync
                    (
                        x => (x.Email.ToLower() == email && !string.IsNullOrEmpty(x.Email)) ||
                        (x.Mobile == mobileNumber && !string.IsNullOrEmpty(x.Mobile))
                     );
            var auxillaryUserModel = await _auxiliaryUserRepository.FindAsync(
                x => (x.EmailId.ToLower() == email && !string.IsNullOrEmpty(x.EmailId)) ||
                (x.Mobile == mobileNumber && !string.IsNullOrEmpty(x.Mobile))
                );
            if (talentModel == null && auxillaryUserModel == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

    }
}
