﻿using FTC.Api.Middleware;
using FTC.Api.Swagger;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Data;
using FTCApi.Data.Repositories;
using Infrastructure;
using Infrastructure.Core.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog;
using Swashbuckle.Swagger.Model;

namespace FTC.Api
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();


            Configuration = builder.Build();

            Log.Logger = new LoggerConfiguration()
              .ReadFrom.Configuration(Configuration)
              .CreateLogger();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<FormOptions>(x =>
            {
                x.ValueLengthLimit = int.MaxValue;
                x.MultipartBodyLengthLimit = int.MaxValue;
                x.MultipartHeadersLengthLimit = int.MaxValue;
            });
            // Register the Swagger generator, defining one or more Swagger documents
            services.AddSwaggerGen(c =>
                {
                    //Set the comments path for the swagger json and ui.
                    var basePath = Microsoft.Extensions.PlatformAbstractions.PlatformServices.Default.Application.ApplicationBasePath;
                    var xmlPath = System.IO.Path.Combine(basePath, "FTC.Api.xml");
                    c.IncludeXmlComments(xmlPath);
                    //c.AddSecurityDefinition("Bearer", new ApiKeyScheme()
                    //    { In = "header", Description = "Please insert JWT with Bearer into field", Name = "Authorization", Type = "apiKey" });

                    c.SingleApiVersion(new Info
                    {
                        Version = "v1",
                        Title = "FTC Api",
                        Description = "talent hunt begins!",
                        TermsOfService = "You’re responsible for your account and any activity on it. Also, you need to be at least 13 years old to use  it",
                        Contact = new Contact { Name = "Tony Stark", Email = "abc@cba.com", Url = "https://dev.fthecouch.com" },
                        License = new License { Name = "Use under dev ", Url = "https://dev.fthecouch.com" }

                    });
                    c.DescribeAllEnumsAsStrings();

                    c.OperationFilter<AddRequiredHeaderParameter>();
                    c.OperationFilter<FileUploadOperation>(); //Register File Upload Operation Filter

                });


            services.AddDbContext<FTCDbContext>(
             options =>
                 options.UseNpgsql(Configuration["DataAccessPostgreSqlProvider:ConnectionString"],
                     b => b.MigrationsAssembly("FTC.Api")));


            services.AddCors(options => options.AddPolicy("AllowAll", p => p.AllowAnyOrigin()
                                                                      .AllowAnyMethod()
                                                                       .AllowAnyHeader()));
            // in-memory cache
            services.AddMemoryCache();

            //JsonOptions added to handle circular reference. 
            services.AddMvc().AddJsonOptions(options =>
            {
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                //options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            });


            services.AddCors(options => options.AddPolicy("AllowAll", p => p.AllowAnyOrigin()
                                                                      .AllowAnyMethod()
                                                                       .AllowAnyHeader()));

            services.AddSingleton<IConfiguration>(Configuration);
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IBodyTypeRepository, BodyTypeRepository>();
            services.AddScoped<ITalentTokenRepository, TalentTokenRepository>();
            services.AddScoped<ITalentRepository, TalentRepository>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<ICountryRepository, CountryRepository>();
            services.AddScoped<IAddressRepository, AddressRepository>();
            services.AddScoped<IAuxiliaryUserRepository, AuxiliaryUserRepository>();
            services.AddScoped<IAuxiliaryUserAssignedRepository, AuxiliaryUserAssignedRepository>();
            services.AddScoped<IAuxiliaryRecruiterRepository, AuxiliaryRecruiterRepository>();
            services.AddScoped<IMediaFileRepository, MediaFileRepository>();
            services.AddScoped<IChestSizeRepository, ChestSizeRepository>();
            services.AddScoped<ICityRepository, CityRepository>();
            services.AddScoped<ITagRepository, TagRepository>();
            services.AddScoped<ITierRepository, TierRepository>();
            services.AddScoped<ITalentCategoryRepository, TalentCategoryRepository>();
            services.AddScoped<ISecurityQuestionRepository, SecurityQuestionRepository>();
            services.AddScoped<ITalentSecurityQuestionRepository, TalentSecurityQuestionRepository>();
            services.AddScoped<IEthnicityRepository, EthnicityRepository>();
            services.AddScoped<IEyeColorRepository, EyeColorRepository>();
            services.AddScoped<IFileTypeRepository, FileTypeRepository>();
            services.AddScoped<IHairColorRepository, HairColorRepository>();
            services.AddScoped<IHairLengthRepository, HairLengthRepository>();
            services.AddScoped<IHairTypeRepository, HairTypeRepository>();
            services.AddScoped<IInterestCategoryRepository, InterestCategoryRepository>();
            services.AddScoped<ILanguageRepository, LanguageRepository>();
            services.AddScoped<IProjectRepository, ProjectRepository>();
            services.AddScoped<IProjectJobRepository, ProjectJobRepository>();
            services.AddScoped<IProjectJobLocationRepository, ProjectJobLocationRepository>();
            services.AddScoped<IProjectJobLanguageRepository, ProjectJobLanguageRepository>();
            services.AddScoped<IProjectJobSkinColorRepository, ProjectJobSkinColorRepository>();
            services.AddScoped<IProjectJobEyeColorRepository, ProjectJobEyeColorRepository>();
            services.AddScoped<IProjectJobHairColorRepository, ProjectJobHairColorRepository>();
            services.AddScoped<IProjectJobTagRepository, ProjectJobTagRepository>();
            services.AddScoped<ITalentJobRepository, TalentJobRepository>();
            services.AddScoped<IProjectLocationRepository, ProjectLocationRepository>();
            services.AddScoped<IProjectJobStatusRepository, ProjectJobStatusRepository>();
            services.AddScoped<IProjectJobSubTalentRepository, ProjectJobSubTalentRepository>();
            services.AddScoped<IProjectJobBodyTypeRepository, ProjectJobBodyTypeRepository>();
            services.AddScoped<IProjectJobEthnicityRepository, ProjectJobEthnicityRepository>();
            services.AddScoped<ISkinColorRepository, SkinColorRepository>();

            services.AddScoped<IStatusRepository, StatusRepository>();
            services.AddScoped<IWaistSizeRepository, WaistSizeRepository>();
            services.AddScoped<ITalentAddressRepository, TalentAddressRepository>();
            services.AddScoped<ITalentInterestCategoryRepository, TalentInterestCategoryRepository>();
            services.AddScoped<ITalentTalentCategoryRepository, TalentTalentCategoryRepository>();
            services.AddScoped<ITalentMediaRepository, TalentMediaRepository>();
            services.AddScoped<ITalentInfoRepository, TalentInfoRepository>();
            services.AddScoped<ITalentPhysicalAttributeRepository, TalentPhysicalAttributeRepository>();
            services.AddScoped<IHeightRepository, HeightRepository>();
            services.AddScoped<IWeightRepository, WeightRepository>();
            services.AddScoped<ITalentCalendarRepository, TalentCalendarRepository>();
            services.AddScoped<ITalentShareDetailRepository, TalentShareDetailRepository>();
            services.AddScoped<IAuxiliaryUserTypeRepository, AuxiliaryUserTypeRepository>();
            services.AddScoped<IAuxiliaryUserTokenRepository, AuxiliaryUserTokenRepository>();
            services.AddScoped<ITalentTagRepository, TalentTagRepository>();
            services.AddScoped<ITagCategoryRepository, TagCategoryRepository>();
            services.AddScoped<ITalentLanguageRepository, TalentLanguageRepository>();
            services.AddScoped<ITalentEthnicityRepository, TalentEthnicityRepository>();
            services.AddScoped<ITalentEducationRepository, TalentEducationRepository>();
            services.AddScoped<ITalentExperienceRepository, TalentExperienceRepository>();
            services.AddScoped<ITalentAssociationRepository, TalentAssociationRepository>();
            services.AddScoped<IAssociationRepository, AssociationRepository>();
            services.AddScoped<IAuxiliaryUserAddressRepository, AuxiliaryUserAddressRepository>();
            services.AddScoped<ITalentPlanFeatureRepository, TalentPlanFeatureRepository>();
            services.AddScoped<ITalentTransactionDetailRepository, TalentTransactionDetailRepository>();
            services.AddScoped<ITalentTransactionRepository, TalentTransactionRepository>();
            services.AddScoped<ITalentFeatureRepository, TalentFeatureRepository>();
            services.AddScoped<ITalentPlanRepository, TalentPlanRepository>();
            services.AddScoped<IRecruiterInfoRepository, RecruiterInfoRepository>();
            services.AddScoped<IAuxiliaryUserExperienceRepository, AuxiliaryUserExperienceRepository>();
            services.AddScoped<IAuxiliaryUserAwardRepository, AuxiliaryUserAwardRepository>();
            services.AddScoped<IAuxiliaryUserSocialLinkRepository, AuxiliaryUserSocialLinkRepository>();
            services.AddScoped<IAuxiliaryUserAssociationRepository, AuxiliaryUserAssociationRepository>();
            services.AddScoped<ITalentSocialLinkRepository, TalentSocialLinkRepository>();
            services.AddScoped<IAuxiliarySecurityQuestionRepository, AuxiliarySecurityQuestionRepository>();
            services.AddScoped<IContestRepository, ContestRepository>();
            services.AddScoped<IContestSubmissionRepository, ContestSubmissionRepository>();
            services.AddScoped<IContestSubmissionMediaRepository, ContestSubmissionMediaRepository>();
            services.AddScoped<IContestResultRepository, ContestResultRepository>();
            services.AddScoped<ISocialLinkRepository, SocialLinkRepository>();
            services.AddScoped<IRecruiterTypeRepository, RecruiterTypeRepository>();
            //services.AddScoped<IFileService, FileService>();
            services.AddScoped<IFileService, S3FileService>();
            services.AddScoped<IContestRepository, ContestRepository>();
            services.AddScoped<IContestTypeRepository, ContestTypeRepository>();
            services.AddScoped<IContestSubmissionRepository, ContestSubmissionRepository>();
            services.AddScoped<IContestResultRepository, ContestResultRepository>();
            services.AddScoped<IProviderRepository, ProviderRepository>();
            services.AddScoped<IContestSpecialHostRepository, ContestSpecialHostRepository>();
            services.AddScoped<IParamRepository, ParamRepository>();
            services.AddScoped<ITalentRatingInterestCategoryRepository, TalentRatingInterestCategoryRepository>();
            services.AddScoped<ITalentRatingParameterRepository, TalentRatingParameterRepository>();
            services.AddScoped<ITalentRatingTalentCategoryRepository, TalentRatingTalentCategoryRepository>();
            services.AddScoped<ITalentRatingRmarksRepository, TalentRatingRmarksRepository>();
            services.AddScoped<INotificationHeaderRepository, NotificationHeaderRepository>();
            services.AddScoped<INotificationDetailRepository, NotificationDetailRepository>();
            services.AddScoped<IContestProviderRepository, ContestProviderRepository>();

            services.AddScoped<IMessageRepository, MessageRepository>();
            services.AddScoped<IProductionHouseRepository, ProductionHouseRepository>();
            services.AddScoped<ISchoolRepository, SchoolRepository>();
            services.AddScoped<IPaymentRepository, PaymentRepository>();
            services.AddScoped<IRazorPayStagingRepository, RazorPayStagingRepository>();
            services.AddScoped<IRecruiterPlanRepository, RecruiterPlanRepository>();
            services.AddScoped<IJobTalentRecommendedRepository, JobTalentRecommendedRepository>();
            services.AddScoped<ITalentJobHistoryRepository, TalentJobHistoryRepository>();
            services.AddScoped<IUserNotificationRepository, UserNotificationRepository>();
            services.AddScoped<IJobAuditionRepository, JobAuditionRepository>();

            services.AddScoped<IAuxiliaryRecruiterTransactionRepository, AuxiliaryRecruiterTransactionRepository>();
            services.AddScoped<IJobAuditionTalentRepository, JobAuditionTalentRepository>();
            services.AddScoped<IJobNotesRepository, JobNotesRepository>();

            services.AddScoped<IJobShareDetailRepository, JobShareDetailRepository>();
            services.AddScoped<IJobShareViewDetailRepository, JobShareViewDetailRepository>();
            services.AddScoped<IJobMediaRepository, JobMediaRepository>();


            services.AddScoped<IAuxiliaryUserRoleRepository, AuxiliaryUserRoleRepository>();
            services.AddScoped<IProductionHouseCategoryRepository, ProductionHouseCategoryRepository>();

            services.AddScoped<IFeatureRolePermissionRepository, FeatureRolePermissionRepository>();

            services.AddScoped<ITraceActivityRepository, TraceActivityRepository>();
            services.AddScoped<ITraceLoginRepository, TraceLoginRepository>();
            services.AddScoped<IRecruiterPlanUserRepository, RecruiterPlanUserRepository>();
            services.AddScoped<ISmsProviderRepository, SmsProviderRepository>();
            services.AddScoped<ITraceSmsGatewayRepository, TraceSmsGatewayRepository>();
            services.AddScoped<IAdminDashboardRepository, AdminDashboardRepository>();

            services.AddScoped<IContestStatusHistoryRepository, ContestStatusHistoryRepository>();
            services.AddScoped<IAuxiliaryUserStatusHistoryRepository, AuxiliaryUserStatusHistoryRepository>();
            services.AddScoped<IProjectJobStatusHistoryRepository, ProjectJobStatusHistoryRepository>();
            services.AddScoped<ITalentStatusHistoryRepository, TalentStatusHistoryRepository>();
            services.AddScoped<IWhitelistIpRepository, WhitelistIpRepository>();
            services.AddScoped<IWhitelistExcludeRepository, WhitelistExcludeRepository>();
            services.AddScoped<IProjectHistoryRepository, ProjectHistoryRepository>();
            services.AddScoped<IProjectJobHistoryRepository, ProjectJobHistoryRepository>();
            services.AddScoped<ITalentJobSpecialHostRepository, TalentJobSpecialHostRepository>();
            services.AddScoped<ITalentSpecialHostRepository, TalentSpecialHostRepository>();

            services.AddScoped<IAdminReportsRepository, AdminReportsRepository>();
            services.AddScoped<IAppVersionRepository, AppVersionRepository>();

            services.AddScoped<ITraceEmailGatewayRepository, TraceEmailGatewayRepository>();            

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();
            //loggerFactory.AddSerilog();

            app.UseMiddleware<SerilogMiddleware>();

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();
            // Enable middleware to serve swagger-ui (HTML, JS, CSS etc.), specifying the Swagger JSON endpoint.
            //app.UseSwagger("FTCApi/swagger/v1/swagger.json");            
            app.UseSwaggerUi();

            app.UseMiddleware<MobileVersionSupportMiddleware>();

            //RequireHeaderSymmetry: Set to true if the mapping should be aborted and a warning logged when the headers are asymmetric
            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.All,
                RequireHeaderSymmetry = false
            });

            app.UseCors("AllowAll");


            app.UseMvc();
        }
    }
}
