﻿using FTC.Api.CommonServices;
using FTC.Api.Helpers;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Serilog;
using System;
using System.Linq;
using static FTCApi.Dtos.LoginEnum;

namespace FTC.Api.Filters
{
    /// <summary>
    /// This action filter check authorized user. 
    /// </summary>
    public class AuthorizeTokenFilter : ActionFilterAttribute
    {
        #region Private Variable & constants

        private const string AUTHORIZATION = "Authorization";
        private const string ROLE = "Role";
        private const string USERID = "userId";
        private const string USERTYPE = "userType";
        private const string USERINFO = "UserInfo";
        private const string REFERER = "referer";

        //UserInfo USERINFO = new UserInfo();

        private readonly IAuxiliaryUserRepository _auxiliaryUserRepository;
        private readonly ITalentRepository _talentRepository;

        /// <summary>
        /// Constructor for AuthorizeToken Filter.
        /// </summary>
        /// <param name="validate"></param>
        public AuthorizeTokenFilter(bool validate, string role)
        {
            _validate = validate;
            _role = role;
        }

        private bool _validate { get; set; }

        private string _role { get; set; }
        #endregion

        #region OnActionExecuting
        /// <summary>
        /// Action filter
        /// </summary>
        /// <param name="context"></param>
        public override async void OnActionExecuting(ActionExecutingContext context)
        {
            string authHeader = context.HttpContext.Request.Headers[AUTHORIZATION];
            string referer = context.HttpContext.Request.Headers["x-Referer"];

            AuthTokenVerify authTokenVerify = null;
            var userType = Convert.ToInt32(context.HttpContext.Request.Headers[ROLE]);

            if (Convert.ToInt32(userType) == Convert.ToInt32(LoginUserType.Talent))
            {
                // Resolve instance
                var _talentRepository = (ITalentRepository)context.HttpContext.RequestServices.GetService(typeof(ITalentRepository));
                authTokenVerify = new AuthTokenVerify(_talentRepository);
            }
            else
            {
                // Resolve instance
                var _auxiliaryUserRepository = (IAuxiliaryUserRepository)context.HttpContext.RequestServices.GetService(typeof(IAuxiliaryUserRepository));
                authTokenVerify = new AuthTokenVerify(_auxiliaryUserRepository);
            }

            var user = authTokenVerify.VerifyAuthToken(authHeader, userType);

            //This section allow only white listed IPs of FTC admin.
            if ((userType == (int)LoginUserType.FTCAdmin))
            {
                var _whitelistIpRepository = (IWhitelistIpRepository)context.HttpContext.RequestServices.GetService(typeof(IWhitelistIpRepository));
                var _whitelistExcludeRepository = (IWhitelistExcludeRepository)context.HttpContext.RequestServices.GetService(typeof(IWhitelistExcludeRepository));

                var whitelistIp = _whitelistIpRepository.GetAll();
                var whitelistExludeUsers = _whitelistExcludeRepository.GetAll();

                var remoteIp = HttpClientHelper.GetRealIP(context.HttpContext);

                if (!whitelistExludeUsers.Any(x => x.AuxiliaryUserId == user.Id && x.StatusId == (int)StatusEnum.Active)) // this code is added to exclude the users present in WhitelistExclude user tables
                {
                    if (!whitelistIp.Any(option => String.Equals(option.IpAddress, remoteIp, StringComparison.OrdinalIgnoreCase)))
                    {
                        Log.Error($"Forbidden request from remote IP address: {remoteIp} - AuthHeader: {authHeader}");
                        context.Result = new UnauthorizedResult();
                    }
                }
            }

            var inRole = CheckInRole(userType);

            if (user == null || !inRole)
            {
                if (_validate)
                {
                    Log.Error($"User is not in role type - AuthHeader: {authHeader}");
                    context.Result = new UnauthorizedResult();
                }
            }
            else
            {

                var userInfo = new UserInfo
                {
                    userType = Convert.ToInt32(userType)
                };

                if (userType == (int)LoginUserType.Recruiter || userType == (int)LoginUserType.FTCAdmin)
                {
                    userInfo.userId = user.Id;
                    userInfo.parentId = user.ParentAuxiliaryUserId;
                    userInfo.FullName = user.FullName;
                    userInfo.ProfileUrl = user.ProfileURL;
                }
                else
                {
                    userInfo.userId = user.Id;
                    userInfo.ProfileUrl = user.TalentProfileURL;
                    userInfo.FullName = user.FullName;
                }
                context.ActionArguments[USERINFO] = userInfo;
                context.ActionArguments[USERTYPE] = Convert.ToInt32(userType);
                context.ActionArguments[USERID] = user.Id;
                context.ActionArguments[REFERER] = referer;

            }
            base.OnActionExecuting(context);
        }

        private bool CheckInRole(int userType)
        {
            var roles = GetRoles(_role);
            foreach (string role in roles)
            {
                var loginUserType = (LoginUserType)Enum.Parse(typeof(LoginUserType), role, true);
                if ((int)loginUserType == userType)
                {
                    return true;
                }
            }
            return false;
        }

        private static T ParseEnum<T>(string value)
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }

        private static string[] GetRoles(string strRoles)
        {
            string[] roles = null;
            if (!string.IsNullOrEmpty(strRoles))
            {
                roles = strRoles.Split(',');
            }
            return roles;
        }

        
        #endregion
    }
}
