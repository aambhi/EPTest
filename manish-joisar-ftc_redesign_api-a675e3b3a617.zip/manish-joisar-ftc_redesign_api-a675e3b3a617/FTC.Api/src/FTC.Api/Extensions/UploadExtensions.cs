﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace FTC.Api.Extensions
{
    public static class UploadExtensions
    {
        internal static string ToUserAccessiblePath(this string savedPath)
        {
            if (savedPath == null)
            {
                throw new ArgumentNullException(nameof(savedPath));
            }

            return Regex.Replace(savedPath, @"^wwwroot\s*", string.Empty)
                        .NormalizeUrlSlashes();
        }

        internal static string ToUserAccessibleS3Path(this string savedPath, string bucketName, string s3bucketBaseUrl)
        {
            if (savedPath == null)
            {
                throw new ArgumentNullException(nameof(savedPath));
            }

            savedPath = NormalizeUrlSlashes(savedPath);
            //Remove the bucket name if present
            savedPath = Regex.Replace(savedPath, string.Format(@"^{0}\s*", bucketName), string.Empty);

            var pathBuilder = new StringBuilder(s3bucketBaseUrl);
            if (!savedPath.StartsWith("/"))
            {
                pathBuilder.Append("/");
            }
            pathBuilder.Append(savedPath);
            return NormalizeUrlSlashes(pathBuilder.ToString());
        }

        internal static string ToApplicationAccessiblePath(this string filePath)
        {
            if (filePath == null)
            {
                throw new ArgumentNullException(nameof(filePath));
            }
            var pathBuilder = new StringBuilder("wwwroot");
            if (!filePath.StartsWith("/"))
            {
                pathBuilder.Append("/");
            }
            pathBuilder.Append(filePath);
            return pathBuilder.ToString().NormalizeUrlSlashes();
        }

        internal static string ToApplicationAccessibleS3Path(this string filePath, string s3BaseUrl, string bucketName)
        {
            if (filePath == null)
            {
                throw new ArgumentNullException(nameof(filePath));
            }
            if (s3BaseUrl == null)
            {
                throw new ArgumentNullException(nameof(s3BaseUrl));
            }
            if (bucketName == null)
            {
                throw new ArgumentNullException(nameof(bucketName));
            }

            filePath = filePath.Replace(s3BaseUrl, string.Empty);

            var pathBuilder = new StringBuilder(bucketName);
            if (!filePath.StartsWith("/"))
            {
                pathBuilder.Append("/");
            }
            pathBuilder.Append(filePath);
            return pathBuilder.ToString().NormalizeUrlSlashes();
        }

        internal static string ExtractFileNameFromPath(this string filePath)
        {
            if (filePath == null)
            {
                throw new ArgumentNullException(nameof(filePath));
            }

            var normalizedPath = filePath.NormalizeUrlSlashes();
            var fileNameStart = normalizedPath.LastIndexOf("/");
            fileNameStart = fileNameStart >= 0 ? fileNameStart + 1 : fileNameStart;
            return fileNameStart >= 0 ? normalizedPath.Substring(fileNameStart)
                                      : string.Empty;
        }

        public static string SafePath(this string path)
        {
            Uri result;
            var absoluteUrl = Uri.TryCreate(path, UriKind.Absolute, out result);
            return absoluteUrl ? NormalizeUrlSlashes(path) : NormalizeUrlSlashes($"~{path}");
        }

        public static string NormalizeUrlSlashes(this string path)
        {
            return path.Replace("\\", "/");
        }
    }
}
