﻿using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace FTC.Provider.Helper
{
    public class HttpClientHelper
    {
        /// <summary>
        /// This method is use to post data
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="data"></param>
        /// <returns>returns response string</returns>
        public async static Task<string> PostAsync(string uri, object data)
        {
            var responseString = string.Empty;
            using (var client = new HttpClient())
            {
                var jsonInString = JsonConvert.SerializeObject(data);
            
                using (var stringContent = new StringContent(jsonInString, Encoding.UTF8, "application/json"))
                {
                    var response = await client.PostAsync(uri, stringContent);
                    response.EnsureSuccessStatusCode();
                    responseString = await response.Content.ReadAsStringAsync();
                }
            }
            return responseString;
        }
    }
}