﻿using FTC.Provider.Host;
using FTCApi.Core.Enums;

namespace FTC.Provider
{
    public class ProviderFactory
    {
        /// <summary>
        ///
        /// </summary>
        public abstract class ProviderContainer
        {
            public abstract IProvider GetProvider(Providers provider);
        }

        /// <summary>
        /// This method returns provider concreate object
        /// </summary>
        public class ConcreteProviderFactory : ProviderContainer
        {
            public override IProvider GetProvider(Providers provider)
            {
                switch (provider)
                {
                    case Providers.TATASKY:
                        return new TataSkyProvider();

                    case Providers.ZEETV:
                        return new ZeeTVProvider();

                    case Providers.DEFAULT:
                        return new DefaultProvider();

                    default:
                        return new DefaultProvider();
                }
            }
        }
    }
}