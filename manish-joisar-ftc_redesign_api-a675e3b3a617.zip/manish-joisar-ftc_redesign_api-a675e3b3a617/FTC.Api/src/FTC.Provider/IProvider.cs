﻿using FTCApi.Core.Models.Provider;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTC.Provider
{
    public interface IProvider
    {
        Task<ProviderResponse> Authenticate(ProviderDetails providerDetails);

        Task<List<AccountDetail>> GetSubscriptions(ProviderDetails providerDetails);
    }
}