﻿using FTCApi.Core.Models.Provider;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FTC.Provider.Host
{
    /// <summary>
    /// ZeeTVProvider 'Concrete' class
    /// </summary>
    public class ZeeTVProvider: IProvider
    {
        #region Public Methods

        public Task<ProviderResponse> Authenticate(ProviderDetails providerDetails)
        {
            throw new NotImplementedException();
        }

        public Task<List<AccountDetail>> GetSubscriptions(ProviderDetails providerDetails)
        {
            throw new NotImplementedException();
        } 

        #endregion
    }
}
