﻿using FTC.Provider.Helper;
using FTCApi.Core.Enums;
using FTCApi.Core.Models.Provider;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Provider.Host
{
    /// <summary>
    /// This class contains 'TataSky' provider implementation.
    /// </summary>
    public class TataSkyProvider : IProvider
    {
        #region Private static string

        private static string Source = "TSADDA";

        #endregion

        #region Public Methods

        /// <summary>
        /// This method authenticate based in subscriberId
        /// </summary>
        /// <param name="providerDetails"></param>
        /// <returns>returns provider response </returns>
        public async Task<ProviderResponse> Authenticate(ProviderDetails providerDetails)
        {
            dynamic requestObj = new ExpandoObject();
            requestObj.subscriberId = providerDetails.SubscriberId;
            requestObj.source = Source;

            // Make call to subscription endpoint to get package details.
            var postEndpointUri = GetEndpoint(providerDetails.ContestProvider.Endpoint, EndpointType.RMN);
            ProviderResponse responseObj = null;

            if (!string.IsNullOrEmpty(postEndpointUri))
            {
                try
                {
                    //Response from Tata Sky api
                    string response = await HttpClientHelper.PostAsync(postEndpointUri, requestObj);

                    //Parse response into object 
                    var subscriptionDetails = JsonConvert.DeserializeObject<PackageDetail>(response);

                    if (subscriptionDetails != null)
                    {
                        responseObj = ValidatePackage(subscriptionDetails);
                    }
                    else
                    {
                        responseObj = new ProviderResponse
                        {
                            IsValid = false,
                            Status = StatusCode.NoPkgDetails,
                            Message = "No package found"
                        };
                    }
                }
                catch (Exception ex)
                {
                    responseObj = new ProviderResponse
                    {
                        IsValid = false,
                        Status = StatusCode.Error,
                        Message = ex.Message
                    };
                }
            }
            else
            {
                responseObj = new ProviderResponse
                {
                    IsValid = false,
                    Status = StatusCode.Error,
                    Message = "Endpoint is not configured"
                };
            }

            return await Task.Run(() => responseObj);
        }

        /// <summary>
        /// Get list of subscriptions based on rmn number.
        /// </summary>
        /// <param name="providerDetails">This provider details contains rmn number</param>
        /// <returns>returns list of active list of subscriptions</returns>
        public async Task<List<AccountDetail>> GetSubscriptions(ProviderDetails providerDetails)
        {
            var accountDetails = new AccountDetails
            {
                rmn = providerDetails.rmn,
                source = Source
            };

            var contentWrapper = new RootObject { accountDetails = accountDetails };

            // Make call to subscription endpoint to get active subsciption list.
            var postEndpointUri = GetEndpoint(providerDetails.ContestProvider.Endpoint, EndpointType.SUBSCRIPTION);

            var response = await HttpClientHelper.PostAsync(postEndpointUri, contentWrapper);

            //Parse response into object 
            var rootObject = JsonConvert.DeserializeObject<RootObject>(response);

            var subscriptions = rootObject.accountDetails == null ? null : rootObject.accountDetails.accountDetails;

            //Returns active accounts
            subscriptions = subscriptions == null ? null : subscriptions.Where(x => x.accountStatus == "Active").ToList();

            return await Task.Run(() => subscriptions);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// This method validate package.
        /// </summary>
        /// <param name="details"></param>
        /// <returns></returns>
        private static ProviderResponse ValidatePackage(PackageDetail details)
        {
            var responseObj = new ProviderResponse();
            if (details == null || (details.subscriptionDetails != null && details.subscriptionDetails.Count == 0))
            {
                responseObj.IsValid = false;
                responseObj.Status = StatusCode.NoPkgDetails;
                responseObj.Message = "No package found";
                return responseObj;
            }
            else if (details.transStatus == "FAILURE")
            {
                responseObj.IsValid = false;
                responseObj.Status = StatusCode.NotValidSubId;
                responseObj.Message = "Not Valid Subscriber Id";
                return responseObj;
            }
            else
            {
                switch (details.accountStatus.ToLower())
                {
                    case "writtenoff":
                        responseObj.IsValid = false;
                        responseObj.Status = StatusCode.Writtenoff;
                        responseObj.Message = "Your Tata Sky Account is written off. Please call the helpline to activate your account.";
                        return responseObj;

                    case "deactivated":
                        responseObj.IsValid = false;
                        responseObj.Status = StatusCode.Deactivated;
                        responseObj.Message = "Your Tata Sky account is de-active. Please recharge to continue.";
                        return responseObj;
                    case "cancelled":
                        responseObj.IsValid = false;
                        responseObj.Status = StatusCode.Cancelled;
                        responseObj.Message = "Your Tata Sky account is inactive. Please call the Helpline for assistance.";
                        return responseObj;
                    case "temp suspension":
                        responseObj.IsValid = false;
                        responseObj.Status = StatusCode.TempSuspension;
                        responseObj.Message = "Your  Tata Sky Account is Temporarily suspended. Please call the Helpline to activate your account.";
                        return responseObj;
                    case "blacklisted":
                        responseObj.IsValid = false;
                        responseObj.Status = StatusCode.Blacklisted;
                        responseObj.Message = "Your  Tata Sky Account is black listed. Please call the Helpline to activate your account.";
                        return responseObj;
                    default:
                        responseObj.IsValid = true;
                        responseObj.Status = StatusCode.Success;
                        responseObj.Message = "Package found";
                        return responseObj;
                }
            }
        }

        /// <summary>
        /// This get endpoint based on endpoint type.
        /// </summary>
        /// <param name="endpoints"></param>
        /// <param name="type">(e.g.RMN, SUBSCRIPTION)</param>
        /// <returns></returns>
        private static string GetEndpoint(string endpoints, EndpointType type)
        {
            //parsing logic 
            var endpoint = string.Empty;

            if (!string.IsNullOrEmpty(endpoints))
            {

                var endpointsObj = JsonConvert.DeserializeObject<List<KeyValue>>(endpoints);

                switch (type)
                {
                    case EndpointType.RMN:
                        endpoint = endpointsObj.Where(x => x.Key.ToLower() == EndpointType.RMN.ToString().ToLower()).Select(x => x.Value).FirstOrDefault();
                        break;
                    case EndpointType.SUBSCRIPTION:
                        endpoint = endpointsObj.Where(x => x.Key.ToLower() == EndpointType.SUBSCRIPTION.ToString().ToLower()).Select(x => x.Value).FirstOrDefault();
                        break;
                }
            }
            return endpoint;
        }

        #endregion
    }
}
