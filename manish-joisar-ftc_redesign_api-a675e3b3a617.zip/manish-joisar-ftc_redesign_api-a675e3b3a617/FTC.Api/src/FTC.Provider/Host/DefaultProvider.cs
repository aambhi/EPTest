﻿using FTC.Provider.Helper;
using FTCApi.Core.Enums;
using FTCApi.Core.Models.Provider;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace FTC.Provider.Host
{
    public class DefaultProvider : IProvider
    {

        #region Public Methods

        public async Task<ProviderResponse> Authenticate(ProviderDetails providerDetails)
        {
            dynamic requestObj = new ExpandoObject();
            requestObj.SubscriberId = providerDetails.SubscriberId;
            ProviderResponse responseObj = null;

            // Make call to subscription endpoint to get package details.
            var postEndpointUri = GetEndpoint(providerDetails.ContestProvider.Endpoint, EndpointType.ENDPOINT);

            if (!string.IsNullOrEmpty(postEndpointUri))
            {
                try
                {
                    //Response from api
                    string response = await HttpClientHelper.PostAsync(postEndpointUri, requestObj);

                    //Parse response into object 
                    var subscriptionDetails = JsonConvert.DeserializeObject<ProviderResponse>(response);

                    if (subscriptionDetails != null)
                    {
                      return subscriptionDetails;
                    }
                    else
                    {
                        responseObj = new ProviderResponse
                        {
                            IsValid = false,
                            Status = StatusCode.NoPkgDetails,
                            Message = "No package found"
                        };
                    }
                }
                catch (Exception ex)
                {
                    responseObj = new ProviderResponse
                    {
                        IsValid = false,
                        Status = StatusCode.Error,
                        Message = ex.Message

                    };
                }
            }
            else
            {
                responseObj = new ProviderResponse
                {
                    IsValid = false,
                    Status = StatusCode.Error,
                    Message = "Endpoint is not configured"
                };
            }

            return await Task.Run(() => responseObj);
        }

        public Task<List<AccountDetail>> GetSubscriptions(ProviderDetails providerDetails)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// This get endpoint based on endpoint type.
        /// </summary>
        /// <param name="endpoints"></param>
        /// <param name="type">(e.g.RMN, SUBSCRIPTION)</param>
        /// <returns></returns>
        private static string GetEndpoint(string endpoints, EndpointType type)
        {
            //parsing logic 
            var endpoint = string.Empty;

            if (!string.IsNullOrEmpty(endpoints))
            {

                var endpointsObj = JsonConvert.DeserializeObject<List<KeyValue>>(endpoints);

                switch (type)
                {
                    case EndpointType.ENDPOINT:
                        endpoint = endpointsObj.Where(x => x.Key.ToLower() == EndpointType.ENDPOINT.ToString().ToLower()).Select(x => x.Value).FirstOrDefault();
                        break;
                }
            }
            return endpoint;
        }


        #endregion
    }
}
