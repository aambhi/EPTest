﻿using FTCApi.Core.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace FTCApi.Data.Extensions
{
    public static class EntityExtensions
    {
        public static TEntity Find<TEntity>(this DbSet<TEntity> set, params object[] keyValues) where TEntity : class
        {
            var context = ((IInfrastructure<IServiceProvider>)set).GetService<DbContext>();

            var entityType = context.Model.FindEntityType(typeof(TEntity));
            var key = entityType.FindPrimaryKey();

            var entries = context.ChangeTracker.Entries<TEntity>();

            var i = 0;
            foreach (var property in key.Properties)
            {
                var id = i;
                entries = entries.Where(e => e.Property(property.Name).CurrentValue == keyValues[id]);
                i++;
            }

            var entry = entries.FirstOrDefault();
            if (entry != null)
            {
                // Return the local object if it exists.
                return entry.Entity;
            }

            // TODO: Build the real LINQ Expression
            // set.Where(x => x.Id == keyValues[0]);
            var parameter = Expression.Parameter(typeof(TEntity), "x");
            var query = set.Where((Expression<Func<TEntity, bool>>)
                Expression.Lambda(
                    Expression.Equal(
                        Expression.Property(parameter, "Id"),
                        Expression.Constant(keyValues[0])),
                    parameter));

            // Look in the database
            return query.FirstOrDefault();
        }

        public static IQueryable<T> ApplySorting<T>(this IQueryable<T> query,
                                                                string sortOn,
                                                                SortOrder sortOrder)
        {
            if (!string.IsNullOrWhiteSpace(sortOn))
            {
                return sortOrder == SortOrder.Ascending ?
                    query.OrderBy(x => GetPropertyValue(x, sortOn)) :
                                          query.OrderByDescending(x => GetPropertyValue(x, sortOn));
            }

            return query;
        }

        public static IQueryable<T> ApplyPaging<T>(this IQueryable<T> query,
                                                              int pageNumber,
                                                              int pageSize)
        {
            return query.Skip(pageNumber * pageSize)
                        .Take(pageSize);
        }

        public static object GetPropertyValue(object obj, string propertyName)
        {
            //complex type nested
            if (propertyName.Contains("."))
            {
                var temp = propertyName.Split(new char[] { '.' }, 2);

                return GetPropertyValue(GetPropertyValue(obj, temp[0]), temp[1]);
            }
            else
            {
                var prop = obj != null ? obj.GetType().GetProperty(propertyName) : null;
                return prop != null ? prop.GetValue(obj) : null;
            }
        }

        
    }
}
