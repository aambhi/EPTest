﻿using FTCApi.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace FTCApi.Data
{
    public class FTCDbContext : DbContext
    {
        public FTCDbContext(DbContextOptions options) : base(options)
        {
            this.Database.SetCommandTimeout(180);
        }
        public DbSet<User> Users { get; set; }
        public DbSet<BodyType> BodyType { get; set; }

        public DbSet<Ethnicity> Ethnicity { get; set; }
        public DbSet<InterestCategory> InterestCategory { get; set; }
        public DbSet<Language> Language { get; set; }
        public DbSet<SecurityQuestion> SecurityQuestion { get; set; }
        public DbSet<TalentCategory> TalentCategory { get; set; }

        public DbSet<ChestSize> ChestSize { get; set; }
        public DbSet<WaistSize> WaistSize { get; set; }
        public DbSet<Country> Country { get; set; }
        public DbSet<EyeColor> EyeColor { get; set; }
        public DbSet<HairColor> HairColor { get; set; }
        public DbSet<HairLength> HairLength { get; set; }
        public DbSet<HairType> HairType { get; set; }
        
        public DbSet<SkinColor> SkinColor { get; set; }
        public DbSet<Talent> Talent { get; set; }
        public DbSet<TalentToken> TalentToken { get; set; }

        public DbSet<Address> Address { get; set; }
        public virtual DbSet<TalentEthnicity> TalentEthnicity { get; set; }

        public virtual DbSet<AuxiliaryUserAssigned> AuxiliaryUserAssigned { get; set; }
        public virtual DbSet<AuxiliaryUserRole> AuxiliaryUserRole { get; set; }

        public virtual DbSet<Feature> Feature { get; set; }
        public virtual DbSet<FeatureOperation> FeatureOperation { get; set; }
        public virtual DbSet<FeaturePermission> FeaturePermission { get; set; }
        public virtual DbSet<FeatureRolePermission> FeatureRolePermission { get; set; }
        public virtual DbSet<TraceActivity> TraceActivity { get; set; }
        public virtual DbSet<TraceLogin> TraceLogin { get; set; }

        public DbSet<AuxiliaryUser> AuxiliaryUser { get; set; }
        public DbSet<MediaFile> MediaFile { get; set; }
        public DbSet<FileType> FileType { get; set; }
        public DbSet<ProjectLocation> ProjectLocation { get; set; }
        public DbSet<Project> Project { get; set; }
        public DbSet<ProjectJob> ProjectJob { get; set; }
        public DbSet<Tag> Tag { get; set; }
        public DbSet<TalentAddress> TalentAddress { get; set; }
        public DbSet<TalentJob> TalentJob { get; set; }
        public DbSet<TalentLanguage> TalentLanguage { get; set; }

        public DbSet<TalentMedia> TalentMedia { get; set; }
        public DbSet<TalentTag> TalentTag { get; set; }

        public DbSet<City> City { get; set; }
        public DbSet<TalentSecurityQuestion> TalentSecurityQuestion { get; set; }

        public DbSet<Status> Status { get; set; }

        public DbSet<TalentPhysicalAttribute> TalentPhysicalAttribute { get; set; }
        public DbSet<Weight> Weight { get; set; }
        public DbSet<Height> Height { get; set; }

        public DbSet<TalentCalendar> TalentCalendar { get; set; }
        public DbSet<AuxiliaryRecruiter> AuxiliaryRecruiter { get; set; }

        public DbSet<AuxiliaryUserType> AuxiliaryUserType { get; set; }
        public virtual DbSet<JobNotes> JobNotes { get; set; }


        public DbSet<ProjectJobLocation> ProjectJobLocation { get; set; }
        public DbSet<ProjectJobLanguage> ProjectJobLanguage { get; set; }
        public DbSet<ProjectJobTag> ProjectJobTag { get; set; }
        public DbSet<TalentShareDetail> TalentShareDetail { get; set; }

        public DbSet<ProjectJobStatus> ProjectJobStatus { get; set; }

        public DbSet<Association> Association { get; set; }
        public DbSet<TalentAssociation> TalentAssociation { get; set; }

        public DbSet<TalentPlan> TalentPlan { get; set; }
        public DbSet<Param> Param { get; set; }

        public virtual DbSet<SocialLink> SocialLink { get; set; }
        public virtual DbSet<TalentSocialLink> TalentSocialLink { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public DbSet<TalentEducation> TalentEducation { get; set; }

        public virtual DbSet<TalentExperience> TalentExperience { get; set; }


        public virtual DbSet<ProjectJobBodytype> ProjectJobBodytype { get; set; }

        public virtual DbSet<ProjectJobEthnicity> ProjectJobEthnicity { get; set; }
        public virtual DbSet<ProjectJobEyeColor> ProjectJobEyeColor { get; set; }
        public virtual DbSet<ProjectJobHairColor> ProjectJobHairColor { get; set; }
        public virtual DbSet<ProjectJobKeywordTag> ProjectJobKeywordTag { get; set; }

        public virtual DbSet<ProjectJobSkinColor> ProjectJobSkinColor { get; set; }
        public virtual DbSet<ProjectJobSubTalent> ProjectJobSubTalent { get; set; }

        public virtual DbSet<AuxiliaryUserAddress> AuxiliaryUserAddress { get; set; }
        public virtual DbSet<AuxiliaryUserToken> AuxiliaryUserToken { get; set; }

        public virtual DbSet<AuxiliaryUserAward> AuxiliaryUserAward { get; set; }

        public virtual DbSet<AuxiliaryUserExperience> AuxiliaryUserExperience { get; set; }

        public virtual DbSet<AuxiliaryUserSocialLink> AuxiliaryUserSocialLink { get; set; }
        public virtual DbSet<AuxiliaryUserAssociation> AuxiliaryUserAssociation { get; set; }

        public virtual DbSet<ProjectMedia> ProjectMedia { get; set; }

        public virtual DbSet<TalentTransactionDetail> TalentTransactionDetail { get; set; }

        public virtual DbSet<TalentTransaction> TalentTransaction { get; set; }

        public virtual DbSet<TalentFeature> TalentFeature { get; set; }
        public virtual DbSet<TalentPlanFeature> TalentPlanFeature { get; set; }
        public virtual DbSet<AuxiliarySecurityQuestion> AuxiliarySecurityQuestion { get; set; }

        public virtual DbSet<Contest> Contest { get; set; }

        public virtual DbSet<ContestSubmission> ContestSubmission { get; set; }

        public virtual DbSet<ContestSubmissionMedia> ContestSubmissionMedia { get; set; }

        public virtual DbSet<ContestResult> ContestResult { get; set; }

        public virtual DbSet<ContestType> ContestType { get; set; }

        public virtual DbSet<ContestProvider> ContestProvider { get; set; }

        public virtual DbSet<ContestSpecialHost> ContestSpecialHost { get; set; }

        public virtual DbSet<MstTalentRatingParameter> MstTalentRatingParameter { get; set; }

        public virtual DbSet<TalentRatingParameter> TalentRatingParameter { get; set; }

        public virtual DbSet<TalentRatingInterestCategory> TalentRatingInterestCategory { get; set; }

        public virtual DbSet<TalentRatingRmark> TalentRatingRmark { get; set; }
        public virtual DbSet<TalentRatingTalentCategory> TalentRatingTalentCategory { get; set; }

        public virtual DbSet<NotificationDetail> NotificationDetail { get; set; }

        public virtual DbSet<NotificationHeader> NotificationHeader { get; set; }


        public virtual DbSet<MstSmsGateway> MstSmsGateway { get; set; }
        public virtual DbSet<TraceSmsGateway> TraceSmsGateway { get; set; }
        public virtual DbSet<ProductionHouse> ProductionHouse { get; set; }

        public virtual DbSet<School> School { get; set; }

        public virtual DbSet<RazorPayStaging> RazorPayStaging { get; set; }
        public virtual DbSet<RecruiterPlan> RecruiterPlan { get; set; }
        public virtual DbSet<ProductionHouseCategory> ProductionHouseCategory { get; set; }

        public virtual DbSet<JobTalentRecommended> JobTalentRecommended { get; set; }
        //public virtual DbSet<Param> Param { get; set; }

        public virtual DbSet<TalentJobHistory> TalentJobHistory { get; set; }
        public virtual DbSet<AuxiliaryRecruiterTransaction> AuxiliaryRecruiterTransaction { get; set; }

        public virtual DbSet<MstSortOrderType> MstSortOrderType { get; set; }

        public virtual DbSet<UserNotification> UserNotification { get; set; }
        public virtual DbSet<Message> Message { get; set; }
        public virtual DbSet<JobAudition> JobAudition { get; set; }
        public virtual DbSet<JobAuditionTalent> JobAuditionTalent { get; set; }
        public virtual DbSet<JobMedia> JobMedia { get; set; }

        public virtual DbSet<AuditionType> AuditionType { get; set; }

        public virtual DbSet<MstDeviceOs> MstDeviceOs { get; set; }
        public virtual DbSet<ContestStatusHistory> ContestStatusHistory { get; set; }
        public virtual DbSet<ProjectJobStatusHistory> ProjectJobStatusHistory { get; set; }
        public virtual DbSet<TalentStatusHistory> TalentStatusHistory { get; set; }
        public virtual DbSet<AuxiliaryUserStatusHistory> AuxiliaryUserStatusHistory { get; set; }
        public virtual DbSet<ProjectHistory> ProjectHistory { get; set; }
        public virtual DbSet<ProjectJobHistory> ProjectJobHistory { get; set; }
        public virtual DbSet<TransactionType> TransactionType { get; set; }
        public virtual DbSet<TalentSpecialHost> TalentSpecialHost { get; set; }
        public virtual DbSet<TalentJobSpecialHost> TalentJobSpecialHost { get; set; }

        public virtual DbSet<TraceEmailGateway> TraceEmailGateway { get; set; }

        public virtual DbSet<WhitelistIp> WhitelistIp { get; set; }

        public virtual DbSet<WhitelistExclude> WhitelistExclude { get; set; }
        public virtual DbSet<AppVersion> AppVersion { get; set; }
        


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {           

            modelBuilder.Entity<AppVersion>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_app_version");

                entity.ToTable("ftc_app_version");

                entity.Property(e => e.Id).HasColumnName("av_id");

                entity.Property(e => e.Date).HasColumnName("av_date");

                entity.Property(e => e.DeviceOsId).HasColumnName("av_device_os_id");

                entity.Property(e => e.Feature)
                    .HasColumnName("av_feature")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Permissible)
                    .HasColumnName("av_permissible")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Version)
                    .HasColumnName("av_version")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.HasOne(d => d.DeviceOs)
                    .WithMany(p => p.AppVersion)
                    .HasForeignKey(d => d.DeviceOsId)
                    .HasConstraintName("ftc_app_version_av_device_os_id_fkey");
            });

            modelBuilder.Entity<WhitelistExclude>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_whitelist_exclude");

                entity.ToTable("ftc_whitelist_exclude");

                entity.Property(e => e.Id).HasColumnName("we_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("we_auxiliary_user_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("we_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.StatusId).HasColumnName("we_status_id");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("we_updated_on")
                    .HasDefaultValueSql("now()");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.WhitelistExclude)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_whitelist_exclude_we_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.WhitelistExclude)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_whitelist_exclude_we_status_id_fkey");
            });

            modelBuilder.Entity<TalentSpecialHost>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_special_host");

                entity.ToTable("ftc_talent_special_host");

                entity.Property(e => e.Id).HasColumnName("tsh_id");

                entity.Property(e => e.CreatedBy).HasColumnName("tsh_created_by");

                entity.Property(e => e.UpdatedBy).HasColumnName("tsh_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("tsh_updated_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tsh_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.SpecialHostId).HasColumnName("tsh_special_host_id");

                entity.Property(e => e.StatusId)
                    .HasColumnName("tsh_status_id")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.TalentId).HasColumnName("tsh_talent_id");

                entity.Property(e => e.Value1)
                    .HasColumnName("tsh_value1")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Value2)
                    .HasColumnName("tsh_value2")
                    .HasColumnType("varchar");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TalentSpecialHost)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_talent_special_host_tsh_created_by_fkey");

                entity.HasOne(d => d.SpecialHost)
                    .WithMany(p => p.TalentSpecialHost)
                    .HasForeignKey(d => d.SpecialHostId)
                    .HasConstraintName("ftc_talent_special_host_tsh_special_host_id_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.TalentSpecialHost)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_talent_special_host_tsh_status_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentSpecialHost)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_special_host_tsh_talent_id_fkey");
            });

            modelBuilder.Entity<TalentJobSpecialHost>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_job_special_host");

                entity.ToTable("ftc_talent_job_special_host");

                entity.Property(e => e.Id).HasColumnName("jsh_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("jsh_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.SpecialHostId).HasColumnName("jsh_special_host_id");

                entity.Property(e => e.TalentJobId).HasColumnName("jsh_talent_job_id");

                entity.HasOne(d => d.SpecialHost)
                    .WithMany(p => p.TalentJobSpecialHost)
                    .HasForeignKey(d => d.SpecialHostId)
                    .HasConstraintName("ftc_talent_job_special_host_jsh_special_host_id_fkey");

                entity.HasOne(d => d.TalentJob)
                    .WithMany(p => p.TalentJobSpecialHost)
                    .HasForeignKey(d => d.TalentJobId)
                    .HasConstraintName("ftc_talent_job_special_host_jsh_talent_job_id_fkey");
            });

            modelBuilder.Entity<TransactionType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_transaction_type");

                entity.ToTable("ftc_mst_transaction_type");

                entity.Property(e => e.Id)
                    .HasColumnName("tt_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasColumnName("tt_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<ProjectJobHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_history");

                entity.ToTable("ftc_mst_project_job_history");

                entity.Property(e => e.Id).HasColumnName("pjh_id");

                entity.Property(e => e.EndDate).HasColumnName("pjh_end_date");

                entity.Property(e => e.JobId).HasColumnName("pjh_job_id");

                entity.Property(e => e.StartDate).HasColumnName("pjh_start_date");

                entity.Property(e => e.UpdatedBy).HasColumnName("pjh_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("pjh_updated_on")
                    .HasDefaultValueSql("now()");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.ProjectJobHistory)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_history_pjh_job_id_fkey");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.ProjectJobHistory)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("ftc_mst_project_job_history_pjh_updated_by_fkey");
            });

            modelBuilder.Entity<ProjectHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_history");

                entity.ToTable("ftc_mst_project_history");

                entity.Property(e => e.Id).HasColumnName("ph_id");

                entity.Property(e => e.EndDate).HasColumnName("ph_end_date");

                entity.Property(e => e.ProjectId).HasColumnName("ph_project_id");

                entity.Property(e => e.StartDate).HasColumnName("ph_start_date");

                entity.Property(e => e.UpdatedBy).HasColumnName("ph_updated_by");
                entity.Property(e => e.PlanId).HasColumnName("ph_plan_id");

                entity.HasOne(d => d.Plan)
                    .WithMany(p => p.ProjectHistory)
                    .HasForeignKey(d => d.PlanId)
                    .HasConstraintName("ftc_mst_project_history_ph_plan_id_fkey");


                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("ph_updated_on")
                    .HasDefaultValueSql("now()");
                
                entity.HasOne(d => d.Project)
                    .WithMany(p => p.ProjectHistory)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_mst_project_history_ph_project_id_fkey");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.ProjectHistory)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("ftc_mst_project_history_ph_updated_by_fkey");
            });

            modelBuilder.Entity<ContestStatusHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_contest_status_history");

                entity.ToTable("ftc_mst_contest_status_history");

                entity.Property(e => e.Id).HasColumnName("cs_id");

                entity.Property(e => e.ContestId).HasColumnName("cs_contest_id");

                entity.Property(e => e.CreatedBy).HasColumnName("cs_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("cs_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.StatusId).HasColumnName("cs_status_id");

                entity.HasOne(d => d.Contest)
                    .WithMany(p => p.ContestStatusHistory)
                    .HasForeignKey(d => d.ContestId)
                    .HasConstraintName("ftc_mst_contest_status_history_cs_contest_id_fkey");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.ContestStatusHistory)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_mst_contest_status_history_cs_contest_created_by_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ContestStatusHistory)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_contest_status_history_cs_status_id_fkey");
            });

            modelBuilder.Entity<TraceEmailGateway>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_trace_email_gateway");

                entity.ToTable("ftc_trace_email_gateway");

                entity.Property(e => e.Id).HasColumnName("teg_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("teg_auxiliary_user_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("teg_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Email)
                    .HasColumnName("teg_email")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.EmailRequest).HasColumnName("teg_email_request");

                entity.Property(e => e.EmailResponse).HasColumnName("teg_email_response");

                entity.Property(e => e.Message)
                    .HasColumnName("teg_message")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Sent)
                    .HasColumnName("teg_sent")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.TalentId).HasColumnName("teg_talent_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.TraceEmailGateway)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_trace_email_gateway_teg_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TraceEmailGateway)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_trace_email_gateway_teg_talent_id_fkey");
            });

            modelBuilder.Entity<ProjectJobStatusHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_status_history");

                entity.ToTable("ftc_mst_project_job_status_history");

                entity.Property(e => e.Id).HasColumnName("jsh_id");

                entity.Property(e => e.CreatedBy).HasColumnName("jsh_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("jsh_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("jsh_job_id");

                entity.Property(e => e.StatusId).HasColumnName("jsh_status_id");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.ProjectJobStatusHistory)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_mst_project_job_status_history_jsh_created_by_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.ProjectJobStatusHistory)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_status_history_jsh_job_id_fkey");

                entity.HasOne(d => d.JshStatus)
                    .WithMany(p => p.ProjectJobStatusHistory)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_project_job_status_history_jsh_status_id_fkey");
            });


            modelBuilder.Entity<TalentStatusHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_status_history");

                entity.ToTable("ftc_talent_status_history");

                entity.Property(e => e.Id).HasColumnName("tsh_id");

                entity.Property(e => e.CreatedBy).HasColumnName("tsh_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tsh_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.StatusId).HasColumnName("tsh_staus_id");

                entity.Property(e => e.TalentId).HasColumnName("tsh_talent_id");
                                
                entity.Property(e => e.FeatureId).HasColumnName("tsh_feature_id");

                entity.Property(e => e.text).HasColumnName("tsh_text");

                entity.HasOne(d => d.Feature)
                                .WithMany(p => p.TalentStatusHistory)
                                .HasForeignKey(d => d.FeatureId)
                                .HasConstraintName("ftc_talent_status_history_tsh_feature_id_fkey");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TalentStatusHistory)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_talent_status_history_tsh_created_by_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.TalentStatusHistory)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_talent_status_history_tsh_staus_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentStatusHistory)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_status_history_tsh_talent_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserStatusHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_status_history");

                entity.ToTable("ftc_auxiliary_user_status_history");

                entity.Property(e => e.Id).HasColumnName("ush_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("ush_auxiliary_user_id");

                entity.Property(e => e.CreatedBy).HasColumnName("ush_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("ush_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.StatusId).HasColumnName("ush_status_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserStatusHistory)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_status_history_ush_auxiliary_user_id_fkey");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.AuxiliaryUserStatusHistoryCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_auxiliary_user_status_history_ush_created_by_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.AuxiliaryUserStatusHistory)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_auxiliary_user_status_history_ush_status_id_fkey");
            });

            modelBuilder.Entity<RecruiterPlanUser>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_recruiter_plan_user");

                entity.ToTable("ftc_mst_recruiter_plan_user");

                entity.Property(e => e.Id).HasColumnName("rps_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("rps_auxiliary_user_id");

                entity.Property(e => e.RecruiterPlanId).HasColumnName("rps_recruiter_plan_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.RecruiterPlanUser)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_mst_recruiter_plan_user_rps_auxiliary_user_id_fkey");

                entity.HasOne(d => d.RecruiterPlan)
                    .WithMany(p => p.RecruiterPlanUser)
                    .HasForeignKey(d => d.RecruiterPlanId)
                    .HasConstraintName("ftc_mst_recruiter_plan_user_rps_recruiter_plan_id_fkey");
            });

            modelBuilder.Entity<JobNotes>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_notes");

                entity.ToTable("ftc_job_notes");

                entity.Property(e => e.Id).HasColumnName("jn_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("jn_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("jn_job_id");

                entity.Property(e => e.Notes)
                    .HasColumnName("jn_notes")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.Property(e => e.TalentId).HasColumnName("jn_talent_id");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.JobNotes)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_job_notes_jn_job_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.JobNotes)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_job_notes_jn_talent_id_fkey");
            });

            modelBuilder.Entity<AuditionType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_audition_type");

                entity.ToTable("ftc_mst_audition_type");

                entity.Property(e => e.Id)
                    .HasColumnName("at_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasColumnName("at_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<MstDeviceOs>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_device_os");

                entity.ToTable("ftc_mst_device_os");

                entity.Property(e => e.Id)
                    .HasColumnName("do_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Name)
                    .HasColumnName("do_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<JobMedia>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_media");

                entity.ToTable("ftc_job_media");

                entity.Property(e => e.CreatedOn)
                  .HasColumnName("jm_created_on")
                  .HasDefaultValueSql("now()");

                entity.Property(e => e.Id).HasColumnName("jm_id");

                entity.Property(e => e.JobAuditionId).HasColumnName("jm_job_audition_id");

                entity.Property(e => e.JobId).HasColumnName("jm_job_id");

                entity.Property(e => e.MediaFileId).HasColumnName("jm_media_file_id");

                entity.Property(e => e.TalentId).HasColumnName("jm_talent_id");

                entity.Property(e => e.Notes).HasColumnName("jm_notes");

                entity.HasOne(d => d.JobAudition)
                    .WithMany(p => p.JobMedia)
                    .HasForeignKey(d => d.JobAuditionId)
                    .HasConstraintName("ftc_job_media_jm_job_audition_id_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.JobMedia)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_job_media_jm_job_id_fkey");

                entity.HasOne(d => d.MediaFile)
                    .WithMany(p => p.JobMedia)
                    .HasForeignKey(d => d.MediaFileId)
                    .HasConstraintName("ftc_job_media_jm_media_file_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.JobMedia)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_job_media_jm_talent_id_fkey");
            });

            modelBuilder.Entity<JobAuditionTalent>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_audition_talent");

                entity.ToTable("ftc_job_audition_talent");

                entity.Property(e => e.Id).HasColumnName("jat_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("jat_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobAuditionId).HasColumnName("jat_job_audition_id");

                entity.Property(e => e.MoveToAuditionId).HasColumnName("jat_move_to_audition_id");

                entity.Property(e => e.MovedToNextStage)
                    .HasColumnName("jat_moved_to_next_stage")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.NotSelected)
                    .HasColumnName("jat_not_selected")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.Notes).HasColumnName("jat_notes");

                entity.Property(e => e.TalentId).HasColumnName("jat_talent_id");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("jat_updated_on")
                    .HasDefaultValueSql("now()");

                entity.HasOne(d => d.JobAudition)
                    .WithMany(p => p.JobAuditionTalent)
                    .HasForeignKey(d => d.JobAuditionId)
                    .HasConstraintName("ftc_job_audition_talent_jat_job_audition_id_fkey");

                entity.HasOne(d => d.MoveToAudition)
                    .WithMany(p => p.MoveToAudition)
                    .HasForeignKey(d => d.MoveToAuditionId)
                    .HasConstraintName("ftc_job_audition_talent_jat_move_to_audition_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.JobAuditionTalent)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_job_audition_talent_jat_talent_id_fkey");
            });

            modelBuilder.Entity<JobAudition>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_audition");

                entity.ToTable("ftc_job_audition");

                entity.Property(e => e.Id).HasColumnName("ja_id");

                entity.Property(e => e.Address)
                    .HasColumnName("ja_address")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.AuditionTypeId).HasColumnName("ja_audition_type_id");

                entity.Property(e => e.Brief).HasColumnName("ja_brief");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("ja_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.EndDate).HasColumnName("ja_end_date");

                entity.Property(e => e.EndTime)
                    .HasColumnName("ja_end_time")
                    .HasColumnType("time");

                entity.Property(e => e.Instruction)
                    .HasColumnName("ja_instruction")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.Property(e => e.JobId).HasColumnName("ja_job_id");

                entity.Property(e => e.ReferenceMedia)
                    .HasColumnName("ja_reference_media")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.RoundNumber).HasColumnName("ja_round_number");

                entity.Property(e => e.StartDate).HasColumnName("ja_start_date");

                entity.Property(e => e.StartTime)
                    .HasColumnName("ja_start_time")
                    .HasColumnType("time");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("ja_updated_on")
                    .HasDefaultValueSql("now()");

                entity.HasOne(d => d.AuditionType)
                    .WithMany(p => p.JobAudition)
                    .HasForeignKey(d => d.AuditionTypeId)
                    .HasConstraintName("ftc_job_audition_ja_audition_type_id_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.JobAudition)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_job_audition_ja_job_id_fkey");
            });

            modelBuilder.Entity<Message>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_message");

                entity.ToTable("ftc_message");

                entity.Property(e => e.Id).HasColumnName("mes_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("mes_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.FromAuxiliaryId).HasColumnName("mes_from_auxiliary_id");

                entity.Property(e => e.FromTalentId).HasColumnName("mes_from_talent_id");

                entity.Property(e => e.JobId).HasColumnName("mes_job_id");

                entity.Property(e => e.MessageText)
                    .HasColumnName("mes_message")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.Read)
                    .HasColumnName("mes_read")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.ToAuxiliaryId).HasColumnName("mes_to_auxiliary_id");

                entity.Property(e => e.ToTalentId).HasColumnName("mes_to_talent_id");

                entity.HasOne(d => d.FromAuxiliary)
                    .WithMany(p => p.MessageMesFromAuxiliary)
                    .HasForeignKey(d => d.FromAuxiliaryId)
                    .HasConstraintName("ftc_message_mes_from_auxiliary_id_fkey");

                entity.HasOne(d => d.FromTalent)
                    .WithMany(p => p.MessageMesFromTalent)
                    .HasForeignKey(d => d.FromTalentId)
                    .HasConstraintName("ftc_message_mes_from_talent_id_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.Message)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_message_mes_job_id_fkey");

                entity.HasOne(d => d.ToAuxiliary)
                    .WithMany(p => p.MessageMesToAuxiliary)
                    .HasForeignKey(d => d.ToAuxiliaryId)
                    .HasConstraintName("ftc_message_mes_to_auxiliary_id_fkey");

                entity.HasOne(d => d.ToTalent)
                    .WithMany(p => p.MessageMesToTalent)
                    .HasForeignKey(d => d.ToTalentId)
                    .HasConstraintName("ftc_message_mes_to_talent_id_fkey");
            });

            modelBuilder.Entity<UserNotification>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_user_notification");

                entity.ToTable("ftc_user_notification");

                entity.Property(e => e.Id).HasColumnName("un_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("un_auxiliary_user_id");

                entity.Property(e => e.ContestId).HasColumnName("un_contest_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("un_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("un_job_id");

                entity.Property(e => e.UrlRoute).HasColumnName("un_url_route");

                entity.Property(e => e.ProjectId).HasColumnName("un_project_id");

                entity.Property(e => e.TalentId).HasColumnName("un_talent_id");
                entity.Property(e => e.ReferenceAuxiliaryUserId).HasColumnName("un_ref_auxiliary_user_id");


                entity.Property(e => e.Text).HasColumnName("un_text");


                entity.Property(e => e.Read)
                    .HasColumnName("un_read")
                    .HasDefaultValueSql("false");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_user_notification_un_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Contest)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.ContestId)
                    .HasConstraintName("ftc_user_notification_un_contest_id_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_user_notification_un_job_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_user_notification_un_project_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_user_notification_un_talent_id_fkey");
            });

            modelBuilder.Entity<School>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_school");

                entity.ToTable("ftc_mst_school");

                entity.Property(e => e.Id).HasColumnName("sch_id");

                entity.Property(e => e.Description)
                    .HasColumnName("sch_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.StatusId)
                    .HasColumnName("sch_status_id")
                    .HasDefaultValueSql("1");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.School)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_school_sch_status_id_fkey");
            });

            modelBuilder.Entity<MstTier>(entity =>
            {
                entity.HasKey(e => e.TierId)
                    .HasName("PK_ftc_mst_tier");

                entity.ToTable("ftc_mst_tier");

                entity.Property(e => e.TierId)
                    .HasColumnName("tier_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.TierDesc)
                    .HasColumnName("tier_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<MstSortOrderType>(entity =>
            {
                entity.HasKey(e => e.SotId)
                    .HasName("PK_ftc_mst_sort_order_type");

                entity.ToTable("ftc_mst_sort_order_type");

                entity.Property(e => e.SotId)
                    .HasColumnName("sot_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.SotDesc)
                    .HasColumnName("sot_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.SotOrder).HasColumnName("sot_order");
            });

            modelBuilder.Entity<AuxiliaryRecruiterTransaction>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_recruiter_transaction");

                entity.ToTable("ftc_auxiliary_recruiter_transaction");

                entity.Property(e => e.Id).HasColumnName("art_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("art_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.OrderId)
                    .HasColumnName("art_order_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.PaymentGatewayResponse).HasColumnName("art_payment_gateway_response");

                entity.Property(e => e.PlanId).HasColumnName("art_recruiter_plan_id");

                entity.Property(e => e.PaymentId)
                    .HasColumnName("art_payment_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
                entity.Property(e => e.Amount)
                    .HasColumnName("art_amount");

                entity.Property(e => e.ProjectId).HasColumnName("art_project_id");

                entity.Property(e => e.StatusId).HasColumnName("art_status_id");

                entity.Property(e => e.TransactionTypeId)
                    .HasColumnName("art_transaction_type_id")
                    .HasDefaultValueSql("1");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.AuxiliaryRecruiterTransaction)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_auxiliary_recruiter_transaction_art_project_id_fkey");


                entity.HasOne(d => d.RecruiterPlan)
                    .WithMany(p => p.AuxiliaryRecruiterTransaction)
                    .HasForeignKey(d => d.PlanId)
                    .HasConstraintName("ftc_auxiliary_recruiter_transaction_art_recruiter_plan_id_key");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.AuxiliaryRecruiterTransaction)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_auxiliary_recruiter_transaction_art_status_id_fkey");

                entity.HasOne(d => d.TransactionType)
                    .WithMany(p => p.AuxiliaryRecruiterTransaction)
                    .HasForeignKey(d => d.TransactionTypeId)
                    .HasConstraintName("ftc_auxiliary_recruiter_transaction_art_transaction_type_id_fke");
            });

            modelBuilder.Entity<AuxiliaryUserAssigned>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_assigned");

                entity.ToTable("ftc_auxiliary_user_assigned");

                entity.Property(e => e.Id).HasColumnName("ua_id");

                entity.Property(e => e.AssignedAuxiliaryUserId).HasColumnName("ua_assigned_auxiliary_user_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("ua_auxiliary_user_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("ua_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("ua_job_id");

                entity.Property(e => e.ProjectId).HasColumnName("ua_project_id");

                entity.HasOne(d => d.AssignedAuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserAssignedUaAssignedAuxiliaryUser)
                    .HasForeignKey(d => d.AssignedAuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_assigned_ua_assigned_auxiliary_user_fkey");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserAssignedUaAuxiliaryUser)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_assigned_ua_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.AuxiliaryUserAssigned)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_auxiliary_user_assigned_ua_job_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.AuxiliaryUserAssigned)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_auxiliary_user_assigned_ua_project_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserRole>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_role");

                entity.ToTable("ftc_auxiliary_user_role");

                entity.Property(e => e.Id).HasColumnName("ur_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("ur_auxiliary_user_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("ur_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.RoleId).HasColumnName("ur_role_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserRole)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_role_ur_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.AuxiliaryUserRole)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("ftc_auxiliary_user_role_ur_role_id_fkey");
            });


            modelBuilder.Entity<ProductionHouse>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_production_house");

                entity.ToTable("ftc_mst_production_house");

                entity.Property(e => e.Id).HasColumnName("ph_id");

                entity.Property(e => e.CategoryId).HasColumnName("ph_category_id");

                entity.Property(e => e.Description)
                    .HasColumnName("ph_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.StatusId)
                    .HasColumnName("ph_status_id")
                    .HasDefaultValueSql("1");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.ProductionHouse)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("ftc_mst_production_house_ph_category_id_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ProductionHouse)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_production_house_ph_status_id_fkey");
            });

            modelBuilder.Entity<ProductionHouseCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_production_house_category");

                entity.ToTable("ftc_mst_production_house_category");

                entity.Property(e => e.Id).HasColumnName("phc_id");

                entity.Property(e => e.Desc)
                    .HasColumnName("phc_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Feature>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_feature");

                entity.ToTable("ftc_feature");

                entity.Property(e => e.Id).HasColumnName("fe_id");

                entity.Property(e => e.Desc)
                    .HasColumnName("fe_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<FeatureOperation>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_feature_operation");

                entity.ToTable("ftc_feature_operation");

                entity.Property(e => e.Id).HasColumnName("fo_id");

                entity.Property(e => e.Desc)
                    .HasColumnName("fo_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<FeaturePermission>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_feature_permission");

                entity.ToTable("ftc_feature_permission");

                entity.Property(e => e.Id).HasColumnName("fp_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("fp_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.FeatureId).HasColumnName("fp_feature_id");

                entity.Property(e => e.FeatureOperationId).HasColumnName("fp_feature_operation_id");

                entity.HasOne(d => d.Feature)
                    .WithMany(p => p.FeaturePermission)
                    .HasForeignKey(d => d.FeatureId)
                    .HasConstraintName("ftc_feature_permission_fp_feature_id_fkey");

                entity.HasOne(d => d.FeatureOperation)
                    .WithMany(p => p.FeaturePermission)
                    .HasForeignKey(d => d.FeatureOperationId)
                    .HasConstraintName("ftc_feature_permission_fp_feature_operation_id_fkey");
            });

            modelBuilder.Entity<FeatureRolePermission>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_feature_role_permission");

                entity.ToTable("ftc_feature_role_permission");

                entity.Property(e => e.Id).HasColumnName("frp_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("frp_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.FeaturePermissionId).HasColumnName("frp_feature_permission_id");

                entity.Property(e => e.RoleId).HasColumnName("frp_role_id");

                entity.HasOne(d => d.FeaturePermission)
                    .WithMany(p => p.FeatureRolePermission)
                    .HasForeignKey(d => d.FeaturePermissionId)
                    .HasConstraintName("ftc_feature_role_permission_frp_feature_permission_id_fkey");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.FeatureRolePermission)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("ftc_feature_role_permission_frp_role_id_fkey");
            });

            modelBuilder.Entity<JobShareDetail>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_share_detail");

                entity.ToTable("ftc_job_share_detail");

                entity.Property(e => e.Id).HasColumnName("jsd_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("jsd_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.EmailIds)
                    .HasColumnName("jsd_email_ids")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.JobId).HasColumnName("jsd_job_id");

                entity.Property(e => e.Notes)
                    .HasColumnName("jsd_notes")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.JobShareDetail)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_job_share_detail_jsd_job_id_fkey");
            });

            modelBuilder.Entity<JobShareViewDetail>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_share_view_detail");

                entity.ToTable("ftc_job_share_view_detail");

                entity.Property(e => e.Id).HasColumnName("svd_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("svd_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.EmailId)
                    .HasColumnName("svd_email_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.JobId).HasColumnName("svd_job_id");

                entity.Property(e => e.Name)
                    .HasColumnName("svd_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.JobShareViewDetail)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_job_share_view_detail_svd_job_id_fkey");
            });

            modelBuilder.Entity<AuditionType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_audition_type");

                entity.ToTable("ftc_mst_audition_type");

                entity.Property(e => e.Id)
                    .HasColumnName("at_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasColumnName("at_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<RecruiterPlan>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_recruiter_plan");

                entity.ToTable("ftc_mst_recruiter_plan");

                entity.Property(e => e.Id).HasColumnName("rp_id");

                entity.Property(e => e.AllowedOnlineAudition)
                    .HasColumnName("rp_allowed_online_audition")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Amount).HasColumnName("rp_amount");

                entity.Property(e => e.AuditionSelectionCount).HasColumnName("rp_audition_selection_count");

                entity.Property(e => e.CreatedBy).HasColumnName("rp_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("rp_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Customized)
                    .HasColumnName("rp_customized")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.DedicatedSupport)
                    .HasColumnName("rp_dedicated_support")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.DiscountOnStudioBooking)
                    .HasColumnName("rp_discount_on_studio_booking")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.ManageContract).HasColumnName("rp_manage_contract");

                entity.Property(e => e.ManagePayments)
                    .HasColumnName("rp_manage_payments")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.Name)
                    .HasColumnName("rp_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.NumberOfUsers).HasColumnName("rp_number_of_users");

                entity.Property(e => e.ProjectValidity).HasColumnName("rp_project_validity");

                entity.Property(e => e.ProvideNotesRating)
                    .HasColumnName("rp_provide_notes_rating")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.RecommendedCount).HasColumnName("rp_recommended_count");

                entity.Property(e => e.RoleCount).HasColumnName("rp_role_count");

                entity.Property(e => e.SocialIntegration)
                    .HasColumnName("rp_social_integration")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.ViewAuditionHistory).HasColumnName("rp_view_audition_history");

                entity.Property(e => e.ViewPortfolio)
                    .HasColumnName("rp_view_portfolio")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.StatusId)
                    .HasColumnName("rp_status_id");

                entity.Property(e => e.Description)
                      .HasColumnName("rp_desc")
                      .HasColumnType("varchar")
                      .HasMaxLength(50);

                entity.Property(e => e.IsFreePlan).HasColumnName("rp_is_free");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.RecruiterPlan)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_mst_recruiter_plan_rp_created_by_fkey");

            });
            modelBuilder.Entity<ProductionHouse>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_production_house");

                entity.ToTable("ftc_mst_production_house");

                entity.Property(e => e.Id).HasColumnName("ph_id");

                entity.Property(e => e.Description)
                    .HasColumnName("ph_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.StatusId)
                    .HasColumnName("ph_status_id")
                    .HasDefaultValueSql("1");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ProductionHouse)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_production_house_ph_status_id_fkey");
            });

            modelBuilder.Entity<NotificationDetail>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_notification_detail");

                entity.ToTable("ftc_notification_detail");

                entity.Property(e => e.Id).HasColumnName("nd_id");

                entity.Property(e => e.Body)
                    .HasColumnName("nd_body")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.NotificationHeaderId).HasColumnName("nd_notification_header_id");

                entity.Property(e => e.Send)
                    .HasColumnName("nd_send")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.SendToAllRole)
                    .HasColumnName("nd_send_to_all_role")
                    .HasDefaultValueSql("false");


                entity.Property(e => e.Subject)
                    .HasColumnName("nd_subject")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.Type)
                    .HasColumnName("nd_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.HasOne(d => d.NotificationHeader)
                    .WithMany(p => p.NotificationDetail)
                    .HasForeignKey(d => d.NotificationHeaderId)
                    .HasConstraintName("ftc_notification_detail_nd_notification_header_id_fkey");
            });



            modelBuilder.Entity<NotificationHeader>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_notification_header");

                entity.ToTable("ftc_notification_header");

                entity.Property(e => e.Id)
                    .HasColumnName("nh_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.FromEmail)
                    .HasColumnName("nh_from_email")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.MailFooter)
                    .HasColumnName("nh_mail_footer")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Type)
                    .HasColumnName("nh_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);
            });
            modelBuilder.Entity<Param>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_param");

                entity.ToTable("ftc_param");

                entity.Property(e => e.Id)
                    .HasColumnName("param_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AudioCount).HasColumnName("param_audio_count");

                entity.Property(e => e.ImageCount).HasColumnName("param_image_count");

                entity.Property(e => e.ScriptCount).HasColumnName("param_script_count");

                entity.Property(e => e.VideoCount).HasColumnName("param_video_count");
            });

            modelBuilder.Entity<TalentRatingTalentCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_rating_talent_category");

                entity.ToTable("ftc_talent_rating_talent_category");

                entity.Property(e => e.Id).HasColumnName("trt_id");

                entity.Property(e => e.Rating).HasColumnName("trt_rating");

                entity.Property(e => e.TalentCategoryId).HasColumnName("trt_talent_category_id");

                entity.Property(e => e.TalentId).HasColumnName("trt_talent_id");

                entity.HasOne(d => d.TalentCategory)
                    .WithMany(p => p.TalentRatingTalentCategory)
                    .HasForeignKey(d => d.TalentCategoryId)
                    .HasConstraintName("ftc_talent_rating_talent_category_trt_talent_category_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentRatingTalentCategory)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_rating_talent_category_trt_talent_id_fkey");
            });

            modelBuilder.Entity<TalentRatingRmark>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_rating_rmark");

                entity.ToTable("ftc_talent_rating_rmark");

                entity.Property(e => e.Id).HasColumnName("trr_id");

                entity.Property(e => e.InterestCategoryId).HasColumnName("trr_interest_category_id");

                entity.Property(e => e.TalentCategoryId).HasColumnName("trr_talent_category_id");

                entity.Property(e => e.TalentId).HasColumnName("trr_talent_id");

                entity.HasOne(d => d.InterestCategory)
                    .WithMany(p => p.TalentRatingRmark)
                    .HasForeignKey(d => d.InterestCategoryId)
                    .HasConstraintName("ftc_talent_rating_rmark_trr_interest_category_id_fkey");

                entity.HasOne(d => d.TalentCategory)
                    .WithMany(p => p.TalentRatingRmark)
                    .HasForeignKey(d => d.TalentCategoryId)
                    .HasConstraintName("ftc_talent_rating_rmark_trr_talent_category_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentRatingRmark)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_rating_rmark_trr_talent_id_fkey");
            });

            modelBuilder.Entity<TalentRatingInterestCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_rating_interest_category");

                entity.ToTable("ftc_talent_rating_interest_category");

                entity.Property(e => e.Id).HasColumnName("tri_id");

                entity.Property(e => e.InterestCategoryId).HasColumnName("tri_interest_category_id");

                entity.Property(e => e.Rating).HasColumnName("tri_rating");

                entity.Property(e => e.TalentId).HasColumnName("tri_talent_id");

                entity.HasOne(d => d.InterestCategory)
                    .WithMany(p => p.TalentRatingInterestCategory)
                    .HasForeignKey(d => d.InterestCategoryId)
                    .HasConstraintName("ftc_talent_rating_interest_catego_tri_interest_category_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentRatingInterestCategory)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_rating_interest_category_tri_talent_id_fkey");
            });

            modelBuilder.Entity<TalentRatingParameter>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_rating_parameter");

                entity.ToTable("ftc_talent_rating_parameter");

                entity.Property(e => e.Id).HasColumnName("trp_id");

                entity.Property(e => e.Rating).HasColumnName("trp_rating");

                entity.Property(e => e.RatingParameterId).HasColumnName("trp_rating_parameter_id");

                entity.Property(e => e.TalentId).HasColumnName("trp_talent_id");

                entity.HasOne(d => d.RatingParameter)
                    .WithMany(p => p.TalentRatingParameter)
                    .HasForeignKey(d => d.RatingParameterId)
                    .HasConstraintName("ftc_talent_rating_parameter_trp_rating_parameter_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentRatingParameter)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_rating_parameter_trp_talent_id_fkey");
            });

            modelBuilder.Entity<MstTalentRatingParameter>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_talent_rating_parameter");

                entity.ToTable("ftc_mst_talent_rating_parameter");

                entity.Property(e => e.Id)
                    .HasColumnName("trp_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasColumnName("trp_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<ContestSpecialHost>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_contest_special_host");

                entity.ToTable("ftc_mst_contest_special_host");

                entity.Property(e => e.Id)
                    .HasColumnName("csh_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("csh_auxiliary_user_id");

                entity.Property(e => e.Name)
                    .HasColumnName("csh_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Parameters)
                    .HasColumnName("csh_parameters")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.ContestSpecialHost)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_mst_contest_special_host_csh_auxiliary_user_id_fkey");

            });

            modelBuilder.Entity<ContestProvider>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_contest_provider");

                entity.ToTable("ftc_mst_contest_provider");

                entity.Property(e => e.Id).HasColumnName("cp_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("cp_auxiliary_user_id");

                entity.Property(e => e.ContestId).HasColumnName("cp_contest_id");

                entity.Property(e => e.Endpoint)
                    .HasColumnName("cp_endpoint")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.ContestProvider)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_mst_contest_provider_cp_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Contest)
                    .WithMany(p => p.ContestProvider)
                    .HasForeignKey(d => d.ContestId)
                    .HasConstraintName("ftc_mst_contest_provider_cp_contest_id_fkey");
            });

            modelBuilder.Entity<ContestType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_contest_type");

                entity.ToTable("ftc_mst_contest_type");

                entity.Property(e => e.Id).HasColumnName("ct_id");

                entity.Property(e => e.Description)
                    .HasColumnName("ct_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.LongDescription)
                    .HasColumnName("ct_description")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.Property(e => e.Image)
                    .HasColumnName("ct_image")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<ContestResult>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_contest_result");

                entity.ToTable("ftc_contest_result");

                entity.Property(e => e.Id).HasColumnName("csr_id");

                entity.Property(e => e.ContestRank).HasColumnName("csr_contest_rank");

                entity.Property(e => e.ContestSubmissionId).HasColumnName("csr_contest_submission_id");

                entity.HasOne(d => d.ContestSubmission)
                    .WithMany(p => p.ContestResult)
                    .HasForeignKey(d => d.ContestSubmissionId)
                    .HasConstraintName("ftc_contest_result_csr_contest_submission_id_fkey");
            });

            modelBuilder.Entity<ContestSubmissionMedia>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_contest_submission_media");

                entity.ToTable("ftc_contest_submission_media");

                entity.Property(e => e.Id).HasColumnName("csm_id");

                entity.Property(e => e.ContestSubmissionId).HasColumnName("csm_contest_submission_id");

                entity.Property(e => e.MediaFileId).HasColumnName("csm_media_file_id");

                entity.HasOne(d => d.ContestSubmission)
                    .WithMany(p => p.ContestSubmissionMedia)
                    .HasForeignKey(d => d.ContestSubmissionId)
                    .HasConstraintName("ftc_contest_submission_media_csm_contest_submission_id_fkey");

                entity.HasOne(d => d.MediaFile)
                    .WithMany(p => p.ContestSubmissionMedia)
                    .HasForeignKey(d => d.MediaFileId)
                    .HasConstraintName("ftc_contest_submission_media_csm_media_file_id_fkey");
            });

            modelBuilder.Entity<ContestSubmission>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_contest_submission");

                entity.ToTable("ftc_contest_submission");

                entity.Property(e => e.Id).HasColumnName("cs_id");

                entity.Property(e => e.ApiResponse).HasColumnName("cs_api_response");

                entity.Property(e => e.ContestId).HasColumnName("cs_contest_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("cs_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.IpAddress)
                    .HasColumnName("cs_ip_address")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.Property(e => e.ParticipatedDate).HasColumnName("cs_participated_date");

                entity.Property(e => e.Selected)
                    .HasColumnName("cs_selected")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.TalentId).HasColumnName("cs_talent_id");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("cs_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Value1)
                    .HasColumnName("cs_value1")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.Value2)
                    .HasColumnName("cs_value2")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.HasOne(d => d.Contest)
                    .WithMany(p => p.Submission)
                    .HasForeignKey(d => d.ContestId)
                    .HasConstraintName("ftc_contest_submission_cs_contest_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.ContestSubmission)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_contest_submission_cs_talent_id_fkey");
            });

            modelBuilder.Entity<Contest>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_contest");

                entity.ToTable("ftc_mst_contest");

                entity.Property(e => e.Id).HasColumnName("contest_id");

                entity.Property(e => e.Gratification)
                    .HasColumnName("conest_gratification")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Assets)
                    .HasColumnName("contest_assets")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("contest_auxiliary_user_id");

                entity.Property(e => e.CreatedBy).HasColumnName("contest_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("contest_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.CreativeDirection)
                    .HasColumnName("contest_creative_direction")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Description)
                    .HasColumnName("contest_description")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.EndDate).HasColumnName("contest_end_date");


                entity.Property(e => e.EngagementLink)
                    .HasColumnName("contest_engagement_link")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.TextColor)
                    .HasColumnName("contest_text_color")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.VerifiedOn).HasColumnName("contest_verified_on");

                entity.Property(e => e.IdentificationLabel)
                    .HasColumnName("contest_identification_label")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.MediaFileTypeId).HasColumnName("contest_media_file_type_id");

                entity.Property(e => e.Name)
                    .HasColumnName("contest_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.NumberPosition).HasColumnName("contest_number_position");

                entity.Property(e => e.Order).HasColumnName("contest_order");

                entity.Property(e => e.Packages)
                    .HasColumnName("contest_packages")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.PrivateKey)
                    .HasColumnName("contest_private_key")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.ShortDetail)
                    .HasColumnName("contest_short_detail")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.StartDate).HasColumnName("contest_start_date");

                entity.Property(e => e.StatusId).HasColumnName("contest_status_id")
                                                .HasDefaultValue(6);

                entity.Property(e => e.TermsAndConditions)
                    .HasColumnName("contest_terms_and_conditions")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Thumbnail)
                    .HasColumnName("contest_thumbnail")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Title)
                    .HasColumnName("contest_title")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.TempBannerImage)
                    .HasColumnName("contest_temp_banner_image")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ContestTypeId).HasColumnName("contest_type_id");

                entity.Property(e => e.UpdatedBy).HasColumnName("contest_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("contest_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.ValidationRequired).HasColumnName("contest_validation_required");

                entity.Property(e => e.VerifiedBy).HasColumnName("contest_verified_by");

                entity.Property(e => e.WinnerPublished)
                    .HasColumnName("contest_winner_published")
                    .HasDefaultValueSql("false");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.ContestContestAuxiliaryUser)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_mst_contest_contest_auxiliary_user_id_fkey");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.ContestContestCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_mst_contest_contest_created_by_fkey");

                entity.HasOne(d => d.MediaFileType)
                    .WithMany(p => p.Contest)
                    .HasForeignKey(d => d.MediaFileTypeId)
                    .HasConstraintName("ftc_mst_contest_contest_media_file_type_id_fkey");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.Contest)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_contest_contest_status_id_fkey");

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.Contest)
                    .HasForeignKey(d => d.ContestTypeId)
                    .HasConstraintName("ftc_mst_contest_contest_type_id_fkey");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.ContestContestUpdatedByNavigation)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("ftc_mst_contest_contest_updated_by_fkey");
            });

            modelBuilder.Entity<AuxiliarySecurityQuestion>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_security_question");

                entity.ToTable("ftc_auxiliary_security_question");

                entity.Property(e => e.Id).HasColumnName("asq_id");

                entity.Property(e => e.Answer)
                    .HasColumnName("asq_answer")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("asq_auxiliary_user_id");

                entity.Property(e => e.SecurityQuestionId).HasColumnName("asq_security_question_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliarySecurityQuestion)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_security_question_asq_auxiliary_user_id_fkey");

                entity.HasOne(d => d.SecurityQuestion)
                    .WithMany(p => p.AuxiliarySecurityQuestion)
                    .HasForeignKey(d => d.SecurityQuestionId)
                    .HasConstraintName("ftc_auxiliary_security_question_asq_security_question_id_fkey");
            });

            modelBuilder.Entity<TalentPlanFeature>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_talent_plan_feature");

                entity.ToTable("ftc_mst_talent_plan_feature");

                entity.Property(e => e.Id)
                    .HasColumnName("tpf_id");


                entity.Property(e => e.ImageCount).HasColumnName("tpf_image_count");

                entity.Property(e => e.VideoCount).HasColumnName("tpf_video_count");

                entity.Property(e => e.AudioCount).HasColumnName("tpf_audio_count");

                entity.Property(e => e.ScriptCount).HasColumnName("tpf_script_count");


                entity.Property(e => e.TalentFeatureId).HasColumnName("tpf_talent_feature_id");

                entity.Property(e => e.TalentPlanId).HasColumnName("tpf_talent_plan_id");

                entity.HasOne(d => d.TalentFeature)
                    .WithMany(p => p.TalentPlanFeature)
                    .HasForeignKey(d => d.TalentFeatureId)
                    .HasConstraintName("ftc_mst_talent_plan_feature_tpf_talent_feature_id_fkey");

                entity.HasOne(d => d.TalentPlan)
                    .WithMany(p => p.TalentPlanFeature)
                    .HasForeignKey(d => d.TalentPlanId)
                    .HasConstraintName("ftc_mst_talent_plan_feature_tpf_talent_plan_id_fkey");
            });

            modelBuilder.Entity<TalentFeature>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_talent_feature");

                entity.ToTable("ftc_mst_talent_feature");

                entity.Property(e => e.Id)
                    .HasColumnName("tf_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AudioCount).HasColumnName("tf_audio_count");

                entity.Property(e => e.Desc)
                    .HasColumnName("tf_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.ImageCount).HasColumnName("tf_image_count");

                entity.Property(e => e.ScriptCount).HasColumnName("tf_script_count");

                entity.Property(e => e.VideoCount).HasColumnName("tf_video_count");
            });

            modelBuilder.Entity<TalentTransaction>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_transaction");

                entity.ToTable("ftc_talent_transaction");

                entity.Property(e => e.Id).HasColumnName("tt_id");

                entity.Property(e => e.Amount)
                    .HasColumnName("tt_amount")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.OrderId)
                    .HasColumnName("tt_order_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.PaymentGatewayResponse).HasColumnName("tt_payment_gateway_response");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tt_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.PaymentId)
                    .HasColumnName("tt_payment_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.StatusId).HasColumnName("tt_status_id");

                entity.Property(e => e.TalentId).HasColumnName("tt_talent_id");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentTransaction)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_transaction_tt_talent_id_fkey");
            });

            modelBuilder.Entity<TalentJob>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_job");

                entity.ToTable("ftc_talent_job");

                entity.Property(e => e.Id)
                    .HasColumnName("tj_id")
                    .HasDefaultValueSql("nextval('ftc_talent_job_tj_id_seq'::regclass)");

                entity.Property(e => e.JobId).HasColumnName("tj_job_id");

                entity.Property(e => e.NotSelected)
                      .HasColumnName("tj_not_selected")
                      .HasDefaultValueSql("false");

                entity.Property(e => e.CollaboratorFeedback)
               .HasColumnName("tj_collaborator_feedback")
               .HasDefaultValueSql("0");

                entity.Property(e => e.EmailSent)
                  .HasColumnName("tj_email_sent")
                  .HasDefaultValueSql("false");


                entity.Property(e => e.Rating).HasColumnName("tj_rating");

                entity.Property(e => e.SelectedForAudition)
                   .HasColumnName("tj_selected_for_audition")
                   .HasDefaultValueSql("false");

                entity.Property(e => e.CreatedOn)
                 .HasColumnName("tj_created_on")
                 .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.UpdatedOn)
                 .HasColumnName("tj_updated_on")
                 .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.TalentId).HasColumnName("tj_talent_id");

                entity.Property(e => e.StatusId)
                    .HasColumnName("tj_status_id")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.Rating)
                     .HasColumnName("tj_rating");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.TalentJob)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_talent_job_tj_job_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentJob)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_job_tj_talent_id_fkey");
            });

            modelBuilder.Entity<RecruiterType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_recruiter_type");

                entity.ToTable("ftc_mst_recruiter_type");

                entity.Property(e => e.Id).HasColumnName("rt_id");

                entity.Property(e => e.Description)
                    .HasColumnName("rt_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });


            modelBuilder.Entity<TalentJobHistory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_job_history");

                entity.ToTable("ftc_talent_job_history");

                entity.Property(e => e.Id).HasColumnName("tjh_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tjh_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("tjh_job_id");

                entity.Property(e => e.JobStatusId).HasColumnName("tjh_job_status_id");

                entity.Property(e => e.TalentId).HasColumnName("tjh_talent_id");
                entity.Property(e => e.AuditionId).HasColumnName("tjh_audition_id");

                entity.HasOne(d => d.Audition)
                 .WithMany(p => p.TalentJobHistory)
                 .HasForeignKey(d => d.AuditionId)
                 .HasConstraintName("ftc_talent_job_history_tjh_audition_id");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.TalentJobHistory)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_talent_job_history_tjh_job_id_fkey");

                entity.HasOne(d => d.JobStatus)
                    .WithMany(p => p.TalentJobHistory)
                    .HasForeignKey(d => d.JobStatusId)
                    .HasConstraintName("ftc_talent_job_history_tjh_job_status_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentJobHistory)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_job_history_tjh_talent_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserAssociation>(entity =>
            {
                entity.HasKey(e => new { e.AuxiliaryUserId, e.AssociationId })
                    .HasName("PK_ftc_auxiliary_user_association");

                entity.ToTable("ftc_auxiliary_user_association");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("aua_auxiliary_user_id");

                entity.Property(e => e.AssociationId).HasColumnName("aua_association_id");

                entity.Property(e => e.MembershipId)
                    .HasColumnName("aua_membership_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.HasOne(d => d.Association)
                    .WithMany(p => p.AuxiliaryUserAssociation)
                    .HasForeignKey(d => d.AssociationId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("ftc_auxiliary_user_association_aua_association_id_fkey");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserAssociation)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("ftc_auxiliary_user_association_aua_auxiliary_user_id_fkey");
            });

            modelBuilder.Entity<ProjectMedia>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_media");

                entity.ToTable("ftc_mst_project_media");

                entity.Property(e => e.Id).HasColumnName("pm_id");

                entity.Property(e => e.MediaFileId).HasColumnName("pm_media_file_id");

                entity.Property(e => e.ProjectId).HasColumnName("pm_project_id");

                entity.HasOne(d => d.MediaFile)
                    .WithMany(p => p.ProjectMedia)
                    .HasForeignKey(d => d.MediaFileId)
                    .HasConstraintName("ftc_mst_project_media_pm_media_file_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.ProjectMedia)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_mst_project_media_pm_project_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserSocialLink>(entity =>
            {
                entity.HasKey(e => new { e.AuxiliaryUserId, e.SocialLinkId })
                    .HasName("PK_ftc_auxiliary_user_social_link");

                entity.ToTable("ftc_auxiliary_user_social_link");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("aus_auxiliary_user_id");

                entity.Property(e => e.SocialLinkId).HasColumnName("aus_social_link_id");

                entity.Property(e => e.Link)
                    .HasColumnName("aus_link")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserSocialLink)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("ftc_auxiliary_user_social_link_aus_auxiliary_user_id_fkey");

                entity.HasOne(d => d.SocialLink)
                    .WithMany(p => p.AuxiliaryUserSocialLink)
                    .HasForeignKey(d => d.SocialLinkId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("ftc_auxiliary_user_social_link_aus_social_link_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserExperience>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_experience");

                entity.ToTable("ftc_auxiliary_user_experience");

                entity.Property(e => e.Id).HasColumnName("aue_id");

                entity.Property(e => e.AddtionalDetails)
                    .HasColumnName("aue_addtional_details")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("aue_auxiliary_user_id");

                entity.Property(e => e.CompanyName)
                    .HasColumnName("aue_company_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.InterestCategoryId).HasColumnName("aue_interest_category_id");

                entity.Property(e => e.Link)
                    .HasColumnName("aue_link")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ProjectTitle)
                    .HasColumnName("aue_project_title")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Year).HasColumnName("year");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserExperience)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_experience_aue_auxiliary_user_id_fkey");

                entity.HasOne(d => d.InterestCategory)
                    .WithMany(p => p.AuxiliaryUserExperience)
                    .HasForeignKey(d => d.InterestCategoryId)
                    .HasConstraintName("ftc_auxiliary_user_experience_aue_interest_category_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserAward>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_award");

                entity.ToTable("ftc_auxiliary_user_award");

                entity.Property(e => e.Id).HasColumnName("aa_id");

                entity.Property(e => e.AddtionalDetails)
                    .HasColumnName("aa_addtional_details")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("aa_auxiliary_user_id");

                entity.Property(e => e.Criteria)
                    .HasColumnName("aa_criteria")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Name)
                    .HasColumnName("aa_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Year).HasColumnName("aa_year");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserAward)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_award_aa_auxiliary_user_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserToken>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_token");

                entity.ToTable("ftc_auxiliary_user_token");

                entity.Property(e => e.Id).HasColumnName("aut_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("aut_auxiliary_user_id");

                entity.Property(e => e.DateCreated)
                    .HasColumnName("aut_date_created")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.DateUpdated)
                    .HasColumnName("aut_date_updated")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Email)
                    .HasColumnName("aut_email")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Email1)
                    .HasColumnName("aut_email1")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Mobile1)
                    .HasColumnName("aut_mobile1")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.SMS)
                    .HasColumnName("aut_sms")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.Type)
                    .HasColumnName("aut_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(10);

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserToken)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_token_aut_auxiliary_user_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserAddress>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user_address");

                entity.ToTable("ftc_auxiliary_user_address");

                entity.Property(e => e.Id)
                    .HasColumnName("aua_id")
                    .HasDefaultValueSql("nextval('ftc_mst_auxiliary_user_address_aua_id_seq'::regclass)");

                entity.Property(e => e.AddressId).HasColumnName("aua_address_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("aua_auxiliary_user_id");

                entity.HasOne(d => d.Address)
                    .WithMany(p => p.AuxiliaryUserAddress)
                    .HasForeignKey(d => d.AddressId)
                    .HasConstraintName("ftc_mst_auxiliary_user_address_aua_address_id_fkey");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliaryUserAddress)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_mst_auxiliary_user_address_aua_auxiliary_user_id_fkey");
            });

            modelBuilder.Entity<ProjectJobTag>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_tag");

                entity.ToTable("ftc_mst_project_job_tag");

                entity.Property(e => e.Id).HasColumnName("pjt_id");

                entity.Property(e => e.JobId).HasColumnName("pjt_job_id");

                entity.Property(e => e.TagId).HasColumnName("pjt_tag_id");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobTag)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_tag_pjt_job_id_fkey");

                entity.HasOne(d => d.Tag)
                    .WithMany(p => p.ProjectJobTag)
                    .HasForeignKey(d => d.TagId)
                    .HasConstraintName("ftc_mst_project_job_tag_pjt_tag_id_fkey");
            });

            modelBuilder.Entity<ProjectJobSubTalent>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_sub_talent");

                entity.ToTable("ftc_mst_project_job_sub_talent");

                entity.Property(e => e.Id).HasColumnName("jst_id");

                entity.Property(e => e.JobId).HasColumnName("jst_job_id");

                entity.Property(e => e.JobSubTalentId).HasColumnName("jst_sub_talent_id");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobSubTalent)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_sub_talent_jst_job_id_fkey");

                entity.HasOne(d => d.TalentCategory)
                    .WithMany(p => p.ProjectJobSubTalent)
                    .HasForeignKey(d => d.JobSubTalentId)
                    .HasConstraintName("ftc_mst_project_job_sub_talent_jst_job_sub_talent_id_fkey");
            });

            modelBuilder.Entity<ProjectJobSkinColor>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_skincolor");

                entity.ToTable("ftc_mst_project_job_skincolor");

                entity.Property(e => e.Id)
                    .HasColumnName("jsc_id");
                //.ValueGeneratedNever();

                entity.Property(e => e.JobId).HasColumnName("jsc_job_id");

                entity.Property(e => e.SkinColorId).HasColumnName("jsc_skincolor_id");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobSkinColor)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_skincolor_jsc_job_id_fkey");

                entity.HasOne(d => d.SkinColor)
                    .WithMany(p => p.ProjectJobSkincolor)
                    .HasForeignKey(d => d.SkinColorId)
                    .HasConstraintName("ftc_mst_project_job_skincolor_jsc_skincolor_id_fkey");
            });

            modelBuilder.Entity<ProjectJobLocation>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_location");

                entity.ToTable("ftc_mst_project_job_location");

                entity.Property(e => e.Id).HasColumnName("pjl_id");

                entity.Property(e => e.CityId).HasColumnName("pjl_city_id");

                entity.Property(e => e.JobId).HasColumnName("pjl_job_id");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.ProjectJobLocation)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("ftc_mst_project_job_location_pjl_city_id_fkey");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobLocation)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_location_pjl_job_id_fkey");
            });

            modelBuilder.Entity<ProjectJobLanguage>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_language");

                entity.ToTable("ftc_mst_project_job_language");

                entity.Property(e => e.Id).HasColumnName("pjla_id");

                entity.Property(e => e.JobId).HasColumnName("pjla_job_id");

                entity.Property(e => e.LanguageId).HasColumnName("pjla_language_id");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.ProjectJobLanguage)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_language_pjla_job_id_fkey");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.ProjectJobLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .HasConstraintName("ftc_mst_project_job_language_pjla_language_id_fkey");
            });

            modelBuilder.Entity<ProjectJobKeywordTag>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_keyword_tag");

                entity.ToTable("ftc_mst_project_job_keyword_tag");

                entity.Property(e => e.Id).HasColumnName("jkt_id");

                entity.Property(e => e.JobId).HasColumnName("jkt_job_id");

                entity.Property(e => e.TagId).HasColumnName("jkt_tag_id");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobKeywordTag)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_keyword_tag_jkt_job_id_fkey");

                entity.HasOne(d => d.Tag)
                    .WithMany(p => p.ProjectJobKeywordTag)
                    .HasForeignKey(d => d.TagId)
                    .HasConstraintName("ftc_mst_project_job_keyword_tag_jkt_tag_id_fkey");
            });

            //modelBuilder.Entity<ProjectJobHairColor>(entity =>
            //{
            //    entity.HasKey(e => e.Id)
            //        .HasName("PK_ftc_mst_project_job_haircolor");

            //    entity.ToTable("ftc_mst_project_job_haircolor");

            //    entity.Property(e => e.Id)
            //        .HasColumnName("jhc_id");
            //       // .HasDefaultValueSql("nextval('ftc_mst_project_job_haircolor_jhl_id_seq'::regclass)");

            //    entity.Property(e => e.JobId).HasColumnName("jhc_job_id");

            //    entity.Property(e => e.HaircolorId).HasColumnName("jhc_haircolor_id");

            //    entity.HasOne(d => d.HairColor)
            //        .WithOne(p => p.ProjectJobHaircolor)
            //        .HasForeignKey<ProjectJobHairColor>(d => d.Id)
            //        .OnDelete(DeleteBehavior.Restrict)
            //        .HasConstraintName("ftc_mst_project_job_haircolor_jhl_id_fkey");

            //    entity.HasOne(d => d.ProjectJob)
            //        .WithMany(p => p.ProjectJobHairColor)
            //        .HasForeignKey(d => d.JobId)
            //        .HasConstraintName("ftc_mst_project_job_haircolor_jhl_job_id_fkey");
            //});


            modelBuilder.Entity<ProjectJobHairColor>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_haircolor");

                entity.ToTable("ftc_mst_project_job_haircolor");

                entity.Property(e => e.Id)
                    .HasColumnName("jhc_id")
                    .HasDefaultValueSql("nextval('ftc_mst_project_job_haircolor_jhl_id_seq'::regclass)");

                entity.Property(e => e.HaircolorId).HasColumnName("jhc_haircolor_id");

                entity.Property(e => e.JobId).HasColumnName("jhc_job_id");

                entity.HasOne(d => d.HairColor)
                    .WithMany(p => p.ProjectJobHaircolor)
                    .HasForeignKey(d => d.HaircolorId)
                    .HasConstraintName("ftc_mst_project_job_haircolor_jhc_haircolor_id_fkey");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobHairColor)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_haircolor_jhl_job_id_fkey");
            });

            modelBuilder.Entity<ProjectJobEyeColor>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_eyecolor");

                entity.ToTable("ftc_mst_project_job_eyecolor");

                entity.Property(e => e.Id).HasColumnName("jec_id");

                entity.Property(e => e.EyecolorId).HasColumnName("jec_eyecolor_id");

                entity.Property(e => e.JobId).HasColumnName("jec_job_id");

                entity.HasOne(d => d.EyeColor)
                    .WithMany(p => p.ProjectJobEyecolor)
                    .HasForeignKey(d => d.EyecolorId)
                    .HasConstraintName("ftc_mst_project_job_eyecolor_jec_eyecolor_id_fkey");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobEyecolor)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_eyecolor_jec_job_id_fkey");
            });

            modelBuilder.Entity<ProjectJobEthnicity>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_ethnicity");

                entity.ToTable("ftc_mst_project_job_ethnicity");

                entity.Property(e => e.Id).HasColumnName("jec_id");

                entity.Property(e => e.EthnicityId).HasColumnName("jec_ethnicity_id");

                entity.Property(e => e.JobId).HasColumnName("jec_job_id");

                entity.HasOne(d => d.Ethnicity)
                    .WithMany(p => p.ProjectJobEthnicity)
                    .HasForeignKey(d => d.EthnicityId)
                    .HasConstraintName("ftc_mst_project_job_ethnicity_jec_ethnicity_id_fkey");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobEthnicity)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_ethnicity_jec_job_id_fkey");
            });

            modelBuilder.Entity<ProjectJobBodytype>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_bodytype");

                entity.ToTable("ftc_mst_project_job_bodytype");

                entity.Property(e => e.Id)
                    .HasColumnName("jbt_id");
                //.ValueGeneratedNever();

                entity.Property(e => e.BodytypeId).HasColumnName("jbt_bodytype_id");

                entity.Property(e => e.JobId).HasColumnName("jbt_job_id");

                entity.HasOne(d => d.BodyType)
                    .WithMany(p => p.ProjectJobBodytype)
                    .HasForeignKey(d => d.BodytypeId)
                    .HasConstraintName("ftc_mst_project_job_bodytype_jbt_bodytype_id_fkey");

                entity.HasOne(d => d.ProjectJob)
                    .WithMany(p => p.ProjectJobBodytype)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_mst_project_job_bodytype_jbt_job_id_fkey");
            });

            modelBuilder.Entity<Address>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_address");

                entity.ToTable("ftc_address");

                entity.Property(e => e.Id).HasColumnName("add_id");

                entity.Property(e => e.CityId).HasColumnName("add_city_id");

                entity.Property(e => e.CountryId).HasColumnName("add_country_id");

                entity.Property(e => e.CreatedDate)
                    .HasColumnName("add_created_date")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Line1)
                    .HasColumnName("add_line1")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Line2)
                    .HasColumnName("add_line2")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);


                entity.Property(e => e.Type)
                    .HasColumnName("add_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(20)
                    .HasDefaultValueSql("'Permanent'::character varying");

                entity.Property(e => e.UpdatedDate)
                    .HasColumnName("add_updated_date")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.ZipCode)
                    .HasColumnName("add_zipcode")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Address)
                    .HasForeignKey(d => d.CityId)
                    .HasConstraintName("ftc_address_add_city_id_fkey");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.Address)
                    .HasForeignKey(d => d.CountryId)
                    .HasConstraintName("ftc_address_add_country_id_fkey");


            });

            modelBuilder.Entity<AuxiliaryRecruiter>(entity =>
            {
                entity.HasKey(e => e.AuxiliaryId)
                    .HasName("PK_ftc_auxiliary_recruiter");

                entity.ToTable("ftc_auxiliary_recruiter");

                entity.Property(e => e.AuxiliaryId)
                    .HasColumnName("aur_auxiliary_id")
                    .ValueGeneratedNever();


                entity.Property(e => e.RecruiterTypeId).HasColumnName("aur_recruiter_type_id");

                entity.Property(e => e.ContestBannerImage)
                    .HasColumnName("aur_contest_banner_image")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.BusinessPhoneNumber)
                    .HasColumnName("aur_business_phone_number")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.BusinessPermanentAddress)
                    .HasColumnName("aur_business_permanent_address")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.Name)
                    .HasColumnName("aur_personal_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Email)
                    .HasColumnName("aur_personal_email")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Mobile)
                    .HasColumnName("aur_personal_mobile")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.HasOne(d => d.AuxiliaryUser)
                            .WithOne(p => p.AuxiliaryRecruiter)
                            .HasForeignKey<AuxiliaryRecruiter>(d => d.AuxiliaryId)
                            .OnDelete(DeleteBehavior.Restrict)
                            .HasConstraintName("ftc_auxiliary_recruiter_aur_id_fkey");

                entity.HasOne(d => d.RecruiterType)
                    .WithMany(p => p.AuxiliaryRecruiter)
                    .HasForeignKey(d => d.RecruiterTypeId)
                    .HasConstraintName("ftc_auxiliary_recruiter_aur_recruiter_type_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUser>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_user");

                entity.ToTable("ftc_auxiliary_user");

                entity.Property(e => e.Id).HasColumnName("au_id");

                entity.Property(e => e.CreatedBy).HasColumnName("au_created_by");

                entity.Property(e => e.MobileCountryId).HasColumnName("au_mobile_country_id");

                entity.HasOne(d => d.MobileCountry)
                    .WithMany(p => p.AuxiliaryUser)
                    .HasForeignKey(d => d.MobileCountryId)
                    .HasConstraintName("ftc_auxiliary_user_au_mobile_country_id_fkey");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("au_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.EmailId)
                    .HasColumnName("au_email_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.AuthToken)
                    .HasColumnName("au_auth_token")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ProfileURL)
                    .HasColumnName("au_profile_url")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);


                entity.Property(e => e.FullName)
                    .HasColumnName("au_fullname")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Password)
                    .HasColumnName("au_password")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.StatusId)
                    .HasColumnName("au_status_id")
                    .HasDefaultValueSql("8");

                entity.Property(e => e.MobileCountryCode)
                    .HasColumnName("au_mobile_country_code")
                    .HasColumnType("varchar")
                    .HasMaxLength(5);

                entity.Property(e => e.Onboarded)
                    .HasColumnName("au_onboarded")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.TermsConditionAccepted)
                    .HasColumnName("au_terms_condition_accepted")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.Mobile)
                    .HasColumnName("au_mobile")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.ParentAuxiliaryUserId).HasColumnName("au_parent_auxiliary_user_id");

                entity.Property(e => e.TypeId).HasColumnName("au_type_id");

                entity.Property(e => e.UpdatedBy).HasColumnName("au_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("au_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Verified)
                    .HasColumnName("au_verified")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.VerifiedBy).HasColumnName("au_verified_by");

                entity.Property(e => e.VerifiedOn).HasColumnName("au_verified_on");

                entity.HasOne(d => d.ParentAuxiliaryUser)
                    .WithMany(p => p.InverseAuParentAuxiliaryUser)
                    .HasForeignKey(d => d.ParentAuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_user_au_parent_auxiliary_user_id_fkey");

                entity.HasOne(d => d.AuType)
                    .WithMany(p => p.AuxiliaryUser)
                    .HasForeignKey(d => d.TypeId)
                    .HasConstraintName("ftc_auxiliary_user_au_type_id_fkey");
            });

            modelBuilder.Entity<MediaFile>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_media_file");

                entity.ToTable("ftc_media_file");

                entity.Property(e => e.Id).HasColumnName("mf_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("mf_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.FileMimeType)
                    .HasColumnName("mf_file_mime_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.FileName)
                    .HasColumnName("mf_file_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.FilePath)
                    .HasColumnName("mf_file_path")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);



                entity.Property(e => e.FileTypeId).HasColumnName("mf_file_type_id");

                entity.Property(e => e.IsExternalUrl)
                                    .HasColumnName("mf_is_external_url")
                                    .HasDefaultValueSql("false");

                entity.Property(e => e.StatusId)
                    .HasColumnName("mf_status_id")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("mf_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.HasOne(d => d.FileType)
                    .WithMany(p => p.MediaFile)
                    .HasForeignKey(d => d.FileTypeId)
                    .HasConstraintName("ftc_media_file_mf_file_type_id_fkey");

                entity.HasOne(d => d.Status)
                   .WithMany(p => p.MediaFile)
                   .HasForeignKey(d => d.StatusId)
                   .HasConstraintName("ftc_media_file_mf_status_id_fkey");
            });

            modelBuilder.Entity<AuxiliaryUserType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_auxiliary_user_type");

                entity.ToTable("ftc_mst_auxiliary_user_type");

                entity.Property(e => e.Id).HasColumnName("aut_id");

                entity.Property(e => e.Description)
                    .HasColumnName("aut_desc")
                    .HasColumnType("varchar");
            });

            modelBuilder.Entity<BodyType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_bodytype");

                entity.ToTable("ftc_mst_bodytype");

                entity.HasIndex(e => e.Description)
                    .HasName("unique_ftc_mst_bodytype")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("bt_id");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("bt_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Status)
                    .HasColumnName("bt_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });

            modelBuilder.Entity<ChestSize>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_chestsize");

                entity.ToTable("ftc_mst_chestsize");

                entity.Property(e => e.Id).HasColumnName("cs_id");

                entity.Property(e => e.Description)
                    .HasColumnName("cs_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Status)
                    .HasColumnName("cs_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");

                entity.Property(e => e.Inches).HasColumnName("cs_inches");

                entity.Property(e => e.Cms).HasColumnName("cs_cms");

                entity.Property(e => e.ShortDescription)
                    .HasColumnName("cs_short_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<City>(entity =>
            {
                entity.HasKey(e => e.CityId)
                    .HasName("PK_ftc_mst_city");

                entity.ToTable("ftc_mst_city");

                entity.Property(e => e.CityId).HasColumnName("city_id");

                entity.Property(e => e.CityDescription)
                    .HasColumnName("city_desc")
                    .HasColumnType("varchar");

                entity.Property(e => e.CityState)
                        .HasColumnName("city_state")
                        .HasColumnType("varchar")
                        .HasMaxLength(100);

                entity.Property(e => e.CityStateCode)
                        .HasColumnName("city_state_code")
                        .HasColumnType("varchar")
                        .HasMaxLength(10);

                entity.Property(e => e.CityCountryId)
                    .HasColumnName("city_country_id");

                entity.HasOne(d => d.CityCountry)
                    .WithMany(p => p.City)
                    .HasForeignKey(d => d.CityCountryId)
                    .HasConstraintName("ftc_mst_city_city_country_id_fkey");



            });

            modelBuilder.Entity<Country>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_country");

                entity.ToTable("ftc_mst_country");

                entity.Property(e => e.Id).HasColumnName("cn_id");

                entity.Property(e => e.Code)
                    .HasColumnName("cn_code")
                    .HasColumnType("varchar")
                    .HasMaxLength(10);

                entity.Property(e => e.MobileCode)
                    .HasColumnName("cn_mobile_code")
                    .HasColumnType("bpchar")
                    .HasMaxLength(5);

                entity.Property(e => e.Name)
                    .HasColumnName("cn_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Nationality)
                    .HasColumnName("cn_nationality")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Ethnicity>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_ethnicity");

                entity.ToTable("ftc_mst_ethnicity");

                entity.HasIndex(e => e.Description)
                    .HasName("unique_ftc_mst_ethnicity")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("eth_id");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("eth_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Status)
                    .HasColumnName("eth_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });

            modelBuilder.Entity<EyeColor>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_eyecolor");

                entity.ToTable("ftc_mst_eyecolor");

                entity.Property(e => e.Id).HasColumnName("ec_id");

                entity.Property(e => e.Description)
                    .HasColumnName("ec_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.RGB)
                    .HasColumnName("ec_rgb")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Status)
                    .HasColumnName("ec_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });

            modelBuilder.Entity<FileType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_file_type");

                entity.ToTable("ftc_mst_file_type");

                entity.Property(e => e.Id).HasColumnName("ft_id");

                entity.Property(e => e.AllowedExtensions)
                    .HasColumnName("ft_allowed_extensions")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Icon)
                    .HasColumnName("ft_icon")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Name)
                    .HasColumnName("ft_name")
                    .HasColumnType("varchar");
            });

            modelBuilder.Entity<HairColor>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_haircolor");

                entity.ToTable("ftc_mst_haircolor");

                entity.Property(e => e.Id).HasColumnName("hc_id");

                entity.Property(e => e.Description)
                    .HasColumnName("hc_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.RGB)
                    .HasColumnName("hc_rgb")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.Property(e => e.Status)
                    .HasColumnName("hc_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<HairLength>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_hairlength");

                entity.ToTable("ftc_mst_hairlength");

                entity.Property(e => e.Id).HasColumnName("hl_id");

                entity.Property(e => e.Description)
                    .HasColumnName("hl_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Status)
                    .HasColumnName("hl_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });

            modelBuilder.Entity<HairType>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_hairtype");

                entity.ToTable("ftc_mst_hairtype");

                entity.Property(e => e.Id).HasColumnName("ht_id");

                entity.Property(e => e.Description)
                    .HasColumnName("ht_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Status)
                    .HasColumnName("ht_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });

            modelBuilder.Entity<InterestCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_interest_category");

                entity.ToTable("ftc_mst_interest_category");

                entity.HasIndex(e => e.Description)
                    .HasName("unique_ftc_mst_interest")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("int_id")
                    .HasDefaultValueSql("nextval('ftc_mst_interest_int_id_seq'::regclass)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("int_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.NotselectedIcon)
                    .HasColumnName("int_notselected_icon")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.SelectedIcon)
                    .HasColumnName("int_selected_icon")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.StatusId)
                     .HasColumnName("int_status_id")
                     .HasDefaultValueSql("1");
            });

            modelBuilder.Entity<Language>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_language");

                entity.ToTable("ftc_mst_language");

                entity.HasIndex(e => e.Description)
                    .HasName("unique_ftc_mst_languages")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("lang_id");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("lang_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Status)
                    .HasColumnName("lang_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });

            modelBuilder.Entity<Project>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project");

                entity.ToTable("ftc_mst_project");

                entity.Property(e => e.Id).HasColumnName("prj_id");

                entity.Property(e => e.AdAgency)
                    .HasColumnName("prj_ad_agency")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.AdAgencyId).HasColumnName("prj_ad_agency_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("prj_auxiliary_user_id");

                entity.Property(e => e.CastingRequired).HasColumnName("prj_casting_required");

                entity.Property(e => e.IsPaid).HasColumnName("prj_paid");

                entity.Property(e => e.IsPaidOffline).HasColumnName("prj_paid_offline");

                entity.Property(e => e.CompanyBrand)
                    .HasColumnName("prj_company_brand")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.CreatedBy).HasColumnName("prj_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("prj_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.EventDate)
                    .HasColumnName("prj_event_date")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Description)
                    .HasColumnName("prj_description")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.DirectorName)
                    .HasColumnName("prj_director_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.EndDate).HasColumnName("prj_end_date");

                entity.Property(e => e.Image)
                    .HasColumnName("prj_image")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.InterestId).HasColumnName("prj_interest_id");

                entity.Property(e => e.Name)
                    .HasColumnName("prj_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.TheatreGroup)
                    .HasColumnName("prj_theatre_group")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.PlanId).HasColumnName("prj_plan_id");

                entity.Property(e => e.ProducerName)
                    .HasColumnName("prj_producer_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ProductionHouse)
                    .HasColumnName("prj_production_house")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ProductionHouseId).HasColumnName("prj_production_house_id");

                entity.Property(e => e.StartDate).HasColumnName("prj_start_date");

                entity.Property(e => e.StatusId)
                    .HasColumnName("prj_status_id")
                    .HasDefaultValueSql("8");

                entity.Property(e => e.UpdatedBy).HasColumnName("prj_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("prj_updated_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Verified)
                    .HasColumnName("prj_verified")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.VerifiedBy).HasColumnName("prj_verified_by");

                entity.Property(e => e.VerifiedOn).HasColumnName("prj_verified_on");

                entity.Property(e => e.Video)
                    .HasColumnName("prj_video")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.HasOne(d => d.AdAgencyNavigation)
                    .WithMany(p => p.ProjectPrjAdAgencyNavigation)
                    .HasForeignKey(d => d.AdAgencyId)
                    .HasConstraintName("ftc_mst_project_prj_ad_agency_id_fkey");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.Project)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_mst_project_prj_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Interest)
                    .WithMany(p => p.Project)
                    .HasForeignKey(d => d.InterestId)
                    .HasConstraintName("ftc_mst_project_prj_interest_id_fkey");

                entity.HasOne(d => d.Plan)
                    .WithMany(p => p.Project)
                    .HasForeignKey(d => d.PlanId)
                    .HasConstraintName("ftc_mst_project_prj_plan_id_fkey");

                entity.HasOne(d => d.ProductionHouseNavigation)
                    .WithMany(p => p.ProjectPrjProductionHouseNavigation)
                    .HasForeignKey(d => d.ProductionHouseId)
                    .HasConstraintName("ftc_mst_project_prj_production_house_id_fkey");
            });

            modelBuilder.Entity<ProjectLocation>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_location");

                entity.ToTable("ftc_mst_project_location");

                entity.Property(e => e.Id)
                    .HasColumnName("pl_id")
                    .HasDefaultValueSql("nextval('ftc_mst_proejct_location_pl_id_seq'::regclass)");

                entity.Property(e => e.CityId).HasColumnName("pl_city_id");

                entity.Property(e => e.CountryId).HasColumnName("pl_country_id");

                entity.Property(e => e.ProjectId).HasColumnName("pl_project_id");

                entity.Property(e => e.StateId).HasColumnName("pl_state_id");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.ProjectLocation)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_mst_proejct_location_pl_project_id_fkey");
            });

            modelBuilder.Entity<SecurityQuestion>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_security_question");

                entity.ToTable("ftc_mst_security_question");

                entity.Property(e => e.Id).HasColumnName("sq_id");

                entity.Property(e => e.Description)
                    .HasColumnName("sq_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<SkinColor>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_skincolor");

                entity.ToTable("ftc_mst_skincolor");

                entity.Property(e => e.Id).HasColumnName("sc_id");

                entity.Property(e => e.Description)
                    .HasColumnName("sc_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.RGB)
                    .HasColumnName("sc_rgb")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Status)
                    .HasColumnName("sc_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");
            });



            modelBuilder.Entity<Status>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_status");

                entity.ToTable("ftc_mst_status");

                entity.Property(e => e.Id).HasColumnName("status_id");

                entity.Property(e => e.Description)
                    .HasColumnName("status_desc")
                    .HasColumnType("varchar");
            });


            modelBuilder.Entity<TalentCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_talent_category");

                entity.ToTable("ftc_mst_talent_category");

                entity.Property(e => e.Id)
                    .HasColumnName("tal_id")
                    .HasDefaultValueSql("nextval('ftc_mst_talent_tal_id_seq'::regclass)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("tal_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.NotSelectedIcon)
                    .HasColumnName("tal_notselected_icon")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ParentId).HasColumnName("tal_parent_id");

                entity.Property(e => e.SelectedIcon)
                    .HasColumnName("tal_selected_icon")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.StatusId).HasColumnName("tal_status_id");

                entity.HasOne(d => d.TalParent)
                    .WithMany(p => p.InverseTalParent)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("fk_ftc_mst_talent_category_parent_id");

                entity.HasOne(d => d.TalStatus)
                    .WithMany(p => p.TalentCategory)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_mst_talent_category_tal_status_id_fkey");
            });

            modelBuilder.Entity<WaistSize>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_waistsize");

                entity.ToTable("ftc_mst_waistsize");

                entity.Property(e => e.Id).HasColumnName("ws_id");

                entity.Property(e => e.Description)
                    .HasColumnName("ws_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Status)
                    .HasColumnName("ws_status")
                    .HasColumnType("varchar")
                    .HasMaxLength(30)
                    .HasDefaultValueSql("'Active'::character varying");

                entity.Property(e => e.Inches).HasColumnName("ws_inches");

                entity.Property(e => e.Cms).HasColumnName("ws_cms");

                entity.Property(e => e.ShortDescription)
                    .HasColumnName("ws_short_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<Tag>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_tag");

                entity.ToTable("ftc_mst_tag");

                entity.Property(e => e.Id)
                    .HasColumnName("tag_id")
                    .HasDefaultValueSql("nextval('ftc_tags_tag_id_seq'::regclass)");

                entity.Property(e => e.TagCategoryId).HasColumnName("tag_category_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tag_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Name)
                    .HasColumnName("tag_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("tag_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.HasOne(d => d.TagCategory)
                  .WithMany(p => p.Tag)
                  .HasForeignKey(d => d.TagCategoryId)
                  .HasConstraintName("ftc_mst_tag_tag_category_id_fkey");
            });

            modelBuilder.Entity<RazorPayStaging>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_razor_pay_staging");

                entity.ToTable("ftc_razor_pay_staging");

                entity.Property(e => e.Id)
                    .HasColumnName("rs_id")
                    .HasDefaultValueSql("nextval('ftc_razor_staging_rs_id_seq'::regclass)");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("rs_auxiliary_user_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("rs_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.OrderId)
                    .HasColumnName("rs_order_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.PaymentId)
                    .HasColumnName("rs_payment_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Response)
                    .HasColumnName("rs_response")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.Property(e => e.StatusId).HasColumnName("rs_status_id");

                entity.Property(e => e.TalentId).HasColumnName("rs_talent_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.RazorPayStaging)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_razor_staging_rs_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.RazorPayStaging)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_razor_staging_rs_talent_id_fkey");
            });

            modelBuilder.Entity<Talent>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent");

                entity.ToTable("ftc_talent");

                entity.Property(e => e.Id).HasColumnName("talent_id");

                entity.Property(e => e.AboutMe)
                    .HasColumnName("talent_about_me")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.AgencyAgentEmail)
                    .HasColumnName("talent_agency_agent_email")
                    .HasColumnType("bpchar")
                    .HasMaxLength(50);

                entity.Property(e => e.AgencyAgentMobileNo)
                    .HasColumnName("talent_agency_agent_mobile_no")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.AgencyAgentName)
                    .HasColumnName("talent_agency_agent_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.AgencyEndDate).HasColumnName("talent_agency_end_date");

                entity.Property(e => e.AgencyId).HasColumnName("talent_agency_id");

                entity.Property(e => e.AgencyStartDate).HasColumnName("talent_agency_start_date");

                entity.Property(e => e.AuthToken).HasColumnName("talent_authtoken");

                entity.Property(e => e.BudgetMax).HasColumnName("talent_budget_max");

                entity.Property(e => e.BudgetMin).HasColumnName("talent_budget_min");
                entity.Property(e => e.TalentProfileURL).HasColumnName("talent_profile_url");

                entity.Property(e => e.CompletionPercentage)
                    .HasColumnName("talent_completion_percentage")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("talent_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.DeviceOsId).HasColumnName("talent_device_os_id");

                entity.Property(e => e.DeviceRegistrationId)
                    .HasColumnName("talent_device_registration_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.DOB).HasColumnName("talent_dob");

                entity.Property(e => e.Email)
                    .HasColumnName("talent_email")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.FullName)
                    .HasColumnName("talent_fullname")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Gender)
                    .HasColumnName("talent_gender")
                    .HasColumnType("varchar")
                    .HasMaxLength(15);

                entity.Property(e => e.GuardianEmailId)
                    .HasColumnName("talent_guardian_email_id")
                    .HasColumnType("bpchar")
                    .HasMaxLength(100);

                entity.Property(e => e.GuardianMobile)
                    .HasColumnName("talent_guardian_mobile")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.GuardianName)
                    .HasColumnName("talent_guardian_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.GuardianRelation)
                    .HasColumnName("talent_guardian_relation")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.LastTabNo)
                    .HasColumnName("talent_last_tab_no")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.Mobile)
                    .HasColumnName("talent_mobile")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.MobileCountryCode)
                    .HasColumnName("talent_mobile_country_code")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.Property(e => e.Onboarded)
                    .HasColumnName("talent_onboarded")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.IsProfilePrivate)
                    .HasColumnName("is_profile_private")
                    .HasDefaultValueSql("false");

                entity.HasOne(d => d.TalentDeviceOs)
                  .WithMany(p => p.Talent)
                  .HasForeignKey(d => d.DeviceOsId)
                  .HasConstraintName("ftc_talent_talent_device_os_id_fkey");

                entity.Property(e => e.PassportCountryId).HasColumnName("talent_passport_country_id");

                entity.Property(e => e.PassportExpirationDate).HasColumnName("talent_passport_expiration_date");

                entity.Property(e => e.FtcRating).HasColumnName("talent_ftc_rating");

                entity.Property(e => e.OverallRating).HasColumnName("talent_overall_rating");

                entity.Property(e => e.RecruiterRating).HasColumnName("talent_recruiter_rating");

                entity.Property(e => e.InterestRating).HasColumnName("talent_interest_rating");

                entity.Property(e => e.MobileCountryId).HasColumnName("talent_mobile_country_id");

                entity.Property(e => e.WhatsupCountryId).HasColumnName("talent_whatsup_country_id");

                entity.Property(e => e.RecruiterRatingCount).HasColumnName("talent_recruiter_rating_count");

                entity.HasOne(d => d.TalentMobileCountry)

                    .WithMany(p => p.TalentMobileCountry)
                    .HasForeignKey(d => d.MobileCountryId)
                    .HasConstraintName("ftc_talent_talent_mobile_country_id_fkey");

                entity.HasOne(d => d.TalentWhatsupCountry)
                    .WithMany(p => p.TalentWhatsupCountry)
                    .HasForeignKey(d => d.WhatsupCountryId)
                    .HasConstraintName("ftc_talent_talent_whatsup_country_id_fkey");

                entity.Property(e => e.RatingNotes)
                    .HasColumnName("talent_rating_notes")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.Password)
                    .HasColumnName("talent_password")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.SharedProfileName).HasColumnName("talent_shared_profile_name");

                entity.Property(e => e.StatusId)
                    .HasColumnName("talent_status_id")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.TermsConditionAccepted)
                    .HasColumnName("talent_terms_condition_accepted")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.TierId)
                .HasColumnName("talent_tier_id")
                .HasDefaultValueSql("3");

                entity.Property(e => e.UID)
                    .HasColumnName("talent_uid");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("talent_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.ViewCount).HasColumnName("talent_view_count");

                entity.Property(e => e.VisaType)
                    .HasColumnName("talent_visa_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.VisaYear)
                    .HasColumnName("talent_visa_year")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.WhatsupCountryCode)
                    .HasColumnName("talent_whatsup_country_code")
                    .HasColumnType("varchar")
                    .HasMaxLength(5);

                entity.Property(e => e.WhatsupMobile)
                    .HasColumnName("talent_whatsup_mobile")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.Talent)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("ftc_talent_talent_status_id_fkey");
                entity.HasOne(d => d.Tier)
                    .WithMany(p => p.Talent)
                    .HasForeignKey(d => d.TierId)
                    .HasConstraintName("ftc_talent_talent_tier_id");
            });

            modelBuilder.Entity<TalentAddress>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_address");

                entity.ToTable("ftc_talent_address");

                entity.Property(e => e.Id).HasColumnName("taladd_id");

                entity.Property(e => e.AddressId).HasColumnName("taladd_address_id");

                entity.Property(e => e.TalentId).HasColumnName("taladd_talent_id");

                entity.HasOne(d => d.Address)
                    .WithMany(p => p.TalentAddress)
                    .HasForeignKey(d => d.AddressId)
                    .HasConstraintName("ftc_talent_address_taladd_address_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentAddress)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_address_taladd_talent_id_fkey");
            });

            modelBuilder.Entity<TalentEthnicity>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("ftc_talent_ethnicity_pkey");

                entity.ToTable("ftc_talent_ethnicity");

                entity.Property(e => e.Id).HasColumnName("taleth_id");

                entity.Property(e => e.Ethnicity).HasColumnName("taleth_ethnicity");

                entity.Property(e => e.TalentId).HasColumnName("taleth_talent_id");

                entity.HasOne(d => d.EthnicityNavigation)
                    .WithMany(p => p.TalentEthnicity)
                    .HasForeignKey(d => d.Ethnicity)
                    .HasConstraintName("ftc_talent_ethnicity_taleth_ethnicity_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentEthnicity)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_ethnicity_taleth_talent_id_fkey");
            });

            modelBuilder.Entity<TalentInterestCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_interest_category");

                entity.ToTable("ftc_talent_interest_category");

                entity.Property(e => e.Id).HasColumnName("tti_id");

                entity.Property(e => e.InterestCategoryId).HasColumnName("tti_interest_category_id");

                entity.Property(e => e.TalentId).HasColumnName("tti_talent_id");

                entity.HasOne(d => d.InterestCategory)
                    .WithMany(p => p.TalentInterestCategory)
                    .HasForeignKey(d => d.InterestCategoryId)
                    .HasConstraintName("ftc_talent_interest_category_tti_interest_category_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentInterestCategory)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_interest_category_tti_talent_id_fkey");
            });



            modelBuilder.Entity<TalentLanguage>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_language");

                entity.ToTable("ftc_talent_language");

                entity.Property(e => e.Id).HasColumnName("tlan_id");

                entity.Property(e => e.LanguageId).HasColumnName("tlan_language_id");

                entity.Property(e => e.TalentId).HasColumnName("tlan_talent_id");

                entity.HasOne(d => d.Language)
                    .WithMany(p => p.TalentLanguage)
                    .HasForeignKey(d => d.LanguageId)
                    .HasConstraintName("fk_ftc_talent_language_ftc_mst_language");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentLanguage)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("fk_ftc_talent_language_ftc_talent");
            });

            modelBuilder.Entity<TalentMedia>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_media");

                entity.ToTable("ftc_talent_media");

                entity.Property(e => e.Id).HasColumnName("tm_id");

                entity.Property(e => e.Flag)
                    .HasColumnName("tm_flag")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.MediaFileId).HasColumnName("tm_media_file_id");

                entity.Property(e => e.TalentId).HasColumnName("tm_talent_id");

                entity.HasOne(d => d.MediaFile)
                    .WithMany(p => p.TalentMedia)
                    .HasForeignKey(d => d.MediaFileId)
                    .HasConstraintName("ftc_talent_media_tm_media_file_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentMedia)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_media_tm_talent_id_fkey");
            });

            modelBuilder.Entity<TalentSecurityQuestion>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_security_question");

                entity.ToTable("ftc_talent_security_question");

                entity.Property(e => e.Id).HasColumnName("tsq_id");

                entity.Property(e => e.Answer)
                    .HasColumnName("tsq_answer")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.Property(e => e.SecurityQuestionId).HasColumnName("tsq_security_question_id");

                entity.Property(e => e.TalentId).HasColumnName("tsq_talent_id");
            });

            modelBuilder.Entity<TalentTag>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_tag");

                entity.ToTable("ftc_talent_tag");

                entity.Property(e => e.Id).HasColumnName("taltag_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tagtag_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.CreatedBy).HasColumnName("taltag_created_by");

                entity.Property(e => e.TagId).HasColumnName("taltag_tag_id");

                entity.Property(e => e.TalentId).HasColumnName("taltag_talent_id");

                entity.Property(e => e.UpdatedBy).HasColumnName("taltag_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("taltag_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.TalentTagTaltagCreatedByNavigation)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_talent_tag_taltag_created_by_fkey");

                entity.HasOne(d => d.Tag)
                    .WithMany(p => p.TalentTag)
                    .HasForeignKey(d => d.TagId)
                    .HasConstraintName("ftc_talent_tag_taltag_tag_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentTag)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_tag_taltag_talent_id_fkey");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.TalentTagTaltagUpdatedByNavigation)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("ftc_talent_tag_taltag_updated_by_fkey");
            });

            modelBuilder.Entity<TalentTalentCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_talent_category");

                entity.ToTable("ftc_talent_talent_category");

                entity.Property(e => e.Id).HasColumnName("ttc_id");

                entity.Property(e => e.TalentCategoryId).HasColumnName("ttc_talent_category_id");

                entity.Property(e => e.TalentId).HasColumnName("ttc_talent_id");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentTalentCategory)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("fk_ftc_talent_talent_category");
            });

            modelBuilder.Entity<TalentToken>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_token");

                entity.ToTable("ftc_talent_token");

                entity.Property(e => e.Id).HasColumnName("tok_id");

                entity.Property(e => e.DateCreated)
                    .HasColumnName("tok_date_created")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.DateUpdated)
                    .HasColumnName("tok_date_updated")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Email)
                    .HasColumnName("tok_email")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Email1)
                    .HasColumnName("tok_email1")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.LoginType)
                    .HasColumnName("tok_login_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(10)
                    .HasDefaultValueSql("'Website'::character varying");

                entity.Property(e => e.Mobile1)
                    .HasColumnName("tok_mobile1")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.SMS)
                    .HasColumnName("tok_sms")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.TalentId).HasColumnName("tok_talent_id");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentToken)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("fk_ftc_talent_talent_id_tok_talent_id");
            });

            modelBuilder.Entity<TalentPhysicalAttribute>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_profile");

                entity.ToTable("ftc_talent_profile");

                entity.Property(e => e.Id).HasColumnName("tp_id");

                entity.Property(e => e.BodyTypeId).HasColumnName("tp_body_type_id");

                entity.Property(e => e.ChestSizeId).HasColumnName("tp_chest_size_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tp_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.EyeColorId).HasColumnName("tp_eye_color_id");

                entity.Property(e => e.HairColorId).HasColumnName("tp_hair_color_id");

                entity.Property(e => e.HairLengthId).HasColumnName("tp_hair_length_id");

                entity.Property(e => e.HairTypeId).HasColumnName("tp_hair_type_id");

                entity.Property(e => e.HeightId).HasColumnName("tp_height_id");

                entity.Property(e => e.SkinColorId).HasColumnName("tp_skin_color_id");

                entity.Property(e => e.TalentId).HasColumnName("tp_talent_id");

                entity.Property(e => e.VerifiedOn).HasColumnName("tp_verified_on");

                entity.Property(e => e.VerifiedBy).HasColumnName("tp_verified_by");

                entity.Property(e => e.Verified)
                    .HasColumnName("tp_verified")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("tp_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.WaistId).HasColumnName("tp_waist_id");

                entity.Property(e => e.WeightSizeId).HasColumnName("tp_weight_size_id");
            });

            modelBuilder.Entity<Weight>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_weight");

                entity.ToTable("ftc_mst_weight");

                entity.Property(e => e.Id).HasColumnName("we_id");

                entity.Property(e => e.Description)
                    .HasColumnName("we_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.ShortDescription)
                    .HasColumnName("we_short_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(10);

                entity.Property(e => e.Kgs).HasColumnName("we_kgs");

                entity.Property(e => e.Lbs).HasColumnName("we_lbs");
            });

            modelBuilder.Entity<Height>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_height");

                entity.ToTable("ftc_mst_height");

                entity.Property(e => e.Id)
                    .HasColumnName("he_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cms).HasColumnName("he_cms");

                entity.Property(e => e.Description)
                    .HasColumnName("he_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Inches).HasColumnName("he_inches");

                entity.Property(e => e.ShortDescription)
                    .HasColumnName("he_short_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<TalentCalendar>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_calendar");

                entity.ToTable("ftc_talent_calendar");

                entity.Property(e => e.Id)
                    .HasColumnName("tc_id")
                    .HasDefaultValueSql("nextval('ftc_talent_calendar_fc_id_seq'::regclass)");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tc_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Description)
                    .HasColumnName("tc_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.FromDateTime).HasColumnName("tc_from_date_time");

                entity.Property(e => e.TalentId).HasColumnName("tc_talent_id");

                entity.Property(e => e.Title)
                    .HasColumnName("tc_title")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.ToDateTime).HasColumnName("tc_to_date_time");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("tc_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentCalendar)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_calendar_fc_talent_id_fkey");
            });

            modelBuilder.Entity<TagCategory>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_tag_category");

                entity.ToTable("ftc_mst_tag_category");

                entity.Property(e => e.Id).HasColumnName("tagc_id");

                entity.Property(e => e.Description)
                    .HasColumnName("tagc_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.TagTalentRelated)
                    .HasColumnName("tagc_talent_related")
                    .HasDefaultValueSql("false");
            });

            modelBuilder.Entity<TalentShareDetail>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_share_detail");

                entity.ToTable("ftc_talent_share_detail");

                entity.Property(e => e.Id).HasColumnName("tsd_id");

                entity.Property(e => e.EmailIds)
                    .HasColumnName("tsd_email_ids")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Notes)
                    .HasColumnName("tsd_notes")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.TalentId).HasColumnName("tsd_talent_id");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentShareDetail)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_share_detail_tsd_talent_id_fkey");
            });

            modelBuilder.Entity<ProjectJobStatus>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job_status");

                entity.ToTable("ftc_mst_project_job_status");

                entity.Property(e => e.Id).HasColumnName("pjs_id");

                entity.Property(e => e.Description)
                    .HasColumnName("pjs_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.RGB)
                    .HasColumnName("pjs_rgb")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<Association>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_association");

                entity.ToTable("ftc_mst_association");

                entity.Property(e => e.Id).HasColumnName("as_id");

                entity.Property(e => e.Description)
                    .HasColumnName("as_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TalentAssociation>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_association");

                entity.ToTable("ftc_talent_association");

                entity.Property(e => e.Id).HasColumnName("ta_id");

                entity.Property(e => e.AssociationId).HasColumnName("ta_association_id");

                entity.Property(e => e.MembershipId)
                    .HasColumnName("ta_membership_id")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.TalentId).HasColumnName("ta_talent_id");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentAssociation)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_association_ta_talent_id_fkey");
            });

            modelBuilder.Entity<TalentPlan>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_talent_plan");

                entity.ToTable("ftc_mst_talent_plan");

                entity.Property(e => e.Id)
                    .HasColumnName("tp_id");

                entity.Property(e => e.Amount)
                    .HasColumnName("tp_amount")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.StatusId)
                    .HasColumnName("tp_status_id")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.Name)
                    .HasColumnName("tp_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Brief)
                   .HasColumnName("tp_brief")
                   .HasColumnType("varchar")
                   .HasMaxLength(500);

                entity.Property(e => e.CreatedBy).HasColumnName("tp_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tp_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Description)
                   .HasColumnName("tp_description")
                   .HasColumnType("varchar")
                   .HasMaxLength(100);


                entity.Property(e => e.Period).HasColumnName("tp_period");
            });


            modelBuilder.Entity<Param>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_param");

                entity.ToTable("ftc_param");

                entity.Property(e => e.Id)
                    .HasColumnName("param_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.ImageCount)
                    .HasColumnName("param_image_count")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.VideoCount)
                    .HasColumnName("param_video_count")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.ScriptCount)
                    .HasColumnName("param_script_count")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.AudioCount)
                    .HasColumnName("param_audio_count")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.TalentRatingWeightage)
                 .HasColumnName("param_talent_rating_weightage")
                 .HasDefaultValueSql("0");

                entity.Property(e => e.ParameterRatingWeightage)
                 .HasColumnName("param_parameter_rating_weightage")
                 .HasDefaultValueSql("0");

                entity.Property(e => e.FtcRatingWeightage)
                 .HasColumnName("param_ftc_rating_weightage")
                 .HasDefaultValueSql("0");

                entity.Property(e => e.RecruiterRatingWeightage)
                 .HasColumnName("param_recruiter_rating_weightage")
                 .HasDefaultValueSql("0");

                entity.Property(e => e.IsProfilePicRequired)
                    .HasColumnName("param_is_profile_pic_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.PostLoginRoute)
                    .HasColumnName("param_post_login_route")
                    .HasDefaultValueSql("1");

            });

            modelBuilder.Entity<TalentTransactionDetail>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_transaction_detail");

                entity.ToTable("ftc_talent_transaction_detail");

                entity.Property(e => e.Id).HasColumnName("ttd_id");

                entity.Property(e => e.EndDate).HasColumnName("ttd_end_date");

                entity.Property(e => e.TalentPlanId).HasColumnName("ttd_talent_plan_id");

                entity.Property(e => e.TalentTransactionId).HasColumnName("ttd_talent_transaction_id");

                entity.HasOne(d => d.TalentPlan)
                    .WithMany(p => p.TalentTransactionDetail)
                    .HasForeignKey(d => d.TalentPlanId)
                    .HasConstraintName("ftc_talent_transaction_detail_ttd_talent_plan_id_fkey");

                entity.HasOne(d => d.TalentTransaction)
                    .WithMany(p => p.TalentTransactionDetail)
                    .HasForeignKey(d => d.TalentTransactionId)
                    .HasConstraintName("ftc_talent_transaction_detail_ttd_talent_transaction_id_fkey");
            });

            modelBuilder.Entity<TalentEducation>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_education");

                entity.ToTable("ftc_talent_education");

                entity.Property(e => e.Id).HasColumnName("ted_id");

                entity.Property(e => e.City)
                    .HasColumnName("ted_city")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Country)
                    .HasColumnName("ted_country")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Course)
                    .HasColumnName("ted_course")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("ted_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.School)
                    .HasColumnName("ted_school")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.TalentId).HasColumnName("ted_talent_id");

                entity.Property(e => e.SchoolId).HasColumnName("ted_school_id");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("ted_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Year)
                    .HasColumnName("ted_year")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.HasOne(d => d.SchoolNavigation)
                    .WithMany(p => p.TalentEducation)
                    .HasForeignKey(d => d.SchoolId)
                    .HasConstraintName("ftc_talent_education_ted_school_id");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentEducation)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_education_ted_talent_id_fkey");
            });

            modelBuilder.Entity<TalentSocialLink>(entity =>
            {
                entity.HasKey(e => new { e.TalentId, e.SocialLinkId })
                    .HasName("PK_ftc_talent_social_link");

                entity.ToTable("ftc_talent_social_link");

                entity.Property(e => e.TalentId).HasColumnName("tsl_talent_id");

                entity.Property(e => e.SocialLinkId).HasColumnName("tsl_social_link_id");

                entity.Property(e => e.Id)
                    .HasColumnName("tsl_id")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Link)
                    .HasColumnName("tsl_link")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.HasOne(d => d.SocialLink)
                    .WithMany(p => p.TalentSocialLink)
                    .HasForeignKey(d => d.SocialLinkId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("ftc_talent_social_link_tsl_social_link_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentSocialLink)
                    .HasForeignKey(d => d.TalentId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("ftc_talent_social_link_tsl_talent_id_fkey");
            });

            modelBuilder.Entity<MstSmsGateway>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_sms_gateway");

                entity.ToTable("ftc_mst_sms_gateway");

                entity.Property(e => e.Id)
                    .HasColumnName("sg_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.BaseUrl)
                    .HasColumnName("sg_base_url")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.DomesticDefault)
                    .HasColumnName("sg_domestic_default")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.DomesticPassword)
                    .HasColumnName("sg_domestic_password")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.DomesticUserid)
                    .HasColumnName("sg_domestic_userid")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.InternationalDefault)
                    .HasColumnName("sg_international_default")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.InternationalPassword)
                    .HasColumnName("sg_international_password")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.InternationalUserid)
                    .HasColumnName("sg_international_userid")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.Name)
                    .HasColumnName("sg_name")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.RequestUrl)
                    .HasColumnName("sg_request_url")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<SocialLink>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_social_link");

                entity.ToTable("ftc_mst_social_link");

                entity.Property(e => e.Id)
                    .HasColumnName("sl_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasColumnName("sl_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.IconImage)
                    .HasColumnName("sl_icon_image")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.IsAuxiliaryUserRelated)
                    .HasColumnName("sl_is_auxiliary_user_related")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.IsTalentRelated)
                    .HasColumnName("sl_is_talent_related")
                    .HasDefaultValueSql("false");

            });

            modelBuilder.Entity<JobTalentRecommended>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_job_talent_recommended");

                entity.ToTable("ftc_job_talent_recommended");
                entity.Property(e => e.Id).HasColumnName("jtr_id");

                entity.Property(e => e.CreatedBy).HasColumnName("jtr_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("jtr_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("jtr_job_id");
                entity.Property(e => e.Order).HasColumnName("jtr_order");
                entity.Property(e => e.TalentId).HasColumnName("jtr_talent_id");
                entity.Property(e => e.Invited).HasColumnName("jtr_invited").HasDefaultValueSql("false");
                entity.Property(e => e.InvitationDeclined).HasColumnName("jtr_invitation_declined").HasDefaultValueSql("false");
                
                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.JobTalentRecommended)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("ftc_job_talent_recommended_jtr_created_by_fkey");

                entity.Property(e => e.SortOrderTypeId)
                    .HasColumnName("jtr_sort_order_type_id")
                    .HasDefaultValueSql("2");


                entity.HasOne(d => d.Job)
                    .WithMany(p => p.JobTalentRecommended)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_job_talent_recommended_jtr_job_id_fkey");

                entity.HasOne(d => d.SortOrderType)
                   .WithMany(p => p.JobTalentRecommended)
                   .HasForeignKey(d => d.SortOrderTypeId)
                   .HasConstraintName("ftc_job_talent_recommended_jtr_sort_order_type_id");


                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.JobTalentRecommended)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_job_talent_recommended_jtr_talent_id_fkey");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("PK_ftc_mst_role");

                entity.ToTable("ftc_mst_role");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.RoleDesc)
                    .HasColumnName("role_desc")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TalentExperience>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_talent_experience");

                entity.ToTable("ftc_talent_experience");

                entity.Property(e => e.Id)
                    .HasColumnName("texp_id")
                    .HasDefaultValueSql("nextval('ftc_talent_experience_tex_id_seq'::regclass)");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("texp_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.InterestCategoryId).HasColumnName("texp_interest_category_id");

                entity.Property(e => e.ProjectTitle)
                    .HasColumnName("texp_project_title")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.ProductionHouse)
                    .HasColumnName("texp_production_house")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.Role)
                    .HasColumnName("texp_role")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.TalentCategoryId).HasColumnName("texp_talent_category_id");

                entity.Property(e => e.TalentId).HasColumnName("texp_talent_id");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("texp_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Year).HasColumnName("texp_year");

                entity.Property(e => e.ProductionHouseId).HasColumnName("texp_production_house_id");

                entity.Property(e => e.SubTalentCategoryId).HasColumnName("texp_sub_talent_category_id");

                entity.HasOne(d => d.InterestCategory)
                    .WithMany(p => p.TalentExperience)
                    .HasForeignKey(d => d.InterestCategoryId)
                    .HasConstraintName("ftc_talent_experience_texp_interest_category_id_fkey");

                entity.HasOne(d => d.SubTalentCategory)
                    .WithMany(p => p.SubTalentCategory)
                    .HasForeignKey(d => d.SubTalentCategoryId)
                    .HasConstraintName("ftc_talent_experience_texp_sub_talent_category_id");

                entity.HasOne(d => d.ProductionHouseNavigation)
                    .WithMany(p => p.TalentExperience)
                    .HasForeignKey(d => d.ProductionHouseId)
                    .HasConstraintName("ftc_talent_experience_texp_production_house_id");

                entity.HasOne(d => d.TalentCategory)
                    .WithMany(p => p.TalentExperience)
                    .HasForeignKey(d => d.TalentCategoryId)
                    .HasConstraintName("ftc_talent_experience_texp_talent_category_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TalentExperience)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_talent_experience_texp_talent_id_fkey");
            });
            modelBuilder.Entity<AuxiliarySecurityQuestion>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_auxiliary_security_question");

                entity.ToTable("ftc_auxiliary_security_question");

                entity.Property(e => e.Id).HasColumnName("asq_id");

                entity.Property(e => e.Answer)
                    .HasColumnName("asq_answer")
                    .HasColumnType("varchar")
                    .HasMaxLength(20);

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("asq_auxiliary_user_id");

                entity.Property(e => e.SecurityQuestionId).HasColumnName("asq_security_question_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.AuxiliarySecurityQuestion)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_auxiliary_security_question_asq_auxiliary_user_id_fkey");

                entity.HasOne(d => d.SecurityQuestion)
                    .WithMany(p => p.AuxiliarySecurityQuestion)
                    .HasForeignKey(d => d.SecurityQuestionId)
                    .HasConstraintName("ftc_auxiliary_security_question_asq_security_question_id_fkey");
            });

            modelBuilder.Entity<ProjectJob>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_mst_project_job");

                entity.ToTable("ftc_mst_project_job");

                entity.Property(e => e.Id).HasColumnName("job_id");

                entity.Property(e => e.AssociationRequired)
                    .HasColumnName("job_association_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.NumberOfRole).HasColumnName("job_number_of_role");



                entity.Property(e => e.CastRequired)
                    .HasColumnName("job_cast_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.CharacterDescription)
                    .HasColumnName("job_character_description")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.CreatedBy).HasColumnName("job_created_by");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("job_created_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.Property(e => e.Description).HasColumnName("job_description");

                entity.Property(e => e.EndDate).HasColumnName("job_end_date");

                entity.Property(e => e.ExperienceRequired)
                    .HasColumnName("job_experience_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.Gender)
                    .HasColumnName("job_gender")
                    .HasColumnType("varchar")
                    .HasMaxLength(15);

                entity.Property(e => e.HairLengthId).HasColumnName("job_hair_length_id");

                entity.Property(e => e.HairTypeId).HasColumnName("job_hair_type_id");

                entity.Property(e => e.HeadshotRequired).HasColumnName("job_headshot_required");

                entity.Property(e => e.InterestCategoryId).HasColumnName("job_interest_category_id");

                entity.Property(e => e.InternalEndDate).HasColumnName("job_internal_end_date");

                entity.Property(e => e.IntrovideoRequired)
                    .HasColumnName("job_introvideo_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.Keywords)
                    .HasColumnName("job_keywords")
                    .HasColumnType("varchar")
                    .HasMaxLength(500);

                entity.Property(e => e.MaxAge).HasColumnName("job_max_age");

                entity.Property(e => e.MaxBudget).HasColumnName("job_max_budget");

                entity.Property(e => e.MaxChestSizeId).HasColumnName("job_max_chest_id");


                entity.Property(e => e.MaxHeightId).HasColumnName("job_max_height");

                entity.Property(e => e.MaxWaistSizeId).HasColumnName("job_max_waist_id");

                entity.Property(e => e.MaxWeightId).HasColumnName("job_max_weight");

                entity.Property(e => e.MediaFiletypeId).HasColumnName("job_media_filetype_id");

                entity.Property(e => e.MinAge).HasColumnName("job_min_age");

                entity.Property(e => e.MinBudget).HasColumnName("job_min_budget");

                entity.Property(e => e.MinChestSizeId).HasColumnName("job_min_chest_id");

                entity.Property(e => e.MinHeightId).HasColumnName("job_min_height");

                entity.Property(e => e.MinWaistSizeId).HasColumnName("job_min_waist_id");

                entity.Property(e => e.MinWeightId).HasColumnName("job_min_weight");

                entity.Property(e => e.NationalityId).HasColumnName("job_nationality_id");

                entity.Property(e => e.ColloaboratorComments)
                          .HasColumnName("job_collaborator_comments")
                          .HasColumnType("varchar")
                          .HasMaxLength(1000);
                entity.Property(e => e.PassportRequired)
                    .HasColumnName("job_passport_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.IsFeaturedJob)
                         .HasColumnName("job_is_featured_job")
                         .HasDefaultValueSql("false");

                entity.Property(e => e.Token)
                   .HasColumnName("job_token")
                   .HasColumnType("varchar")
                   .HasMaxLength(100);

                entity.Property(e => e.ProjectId).HasColumnName("job_project_id");

                entity.Property(e => e.ReferenceMedia)
                    .HasColumnName("job_reference_media")
                    .HasColumnType("bpchar")
                    .HasMaxLength(255);

                entity.Property(e => e.RoleType)
                    .HasColumnName("job_role_type")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.SideprofileRequired)
                    .HasColumnName("job_sideprofile_required")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.StartDate).HasColumnName("job_start_date");

                entity.Property(e => e.StatusId)
                    .HasColumnName("job_status_id")
                    .HasDefaultValueSql("6");

                entity.Property(e => e.TalentCategoryId).HasColumnName("job_talent_category_id");

                entity.Property(e => e.Title)
                    .HasColumnName("job_title")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.UpdatedBy).HasColumnName("job_updated_by");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnName("job_updated_on")
                    .HasDefaultValueSql("('now'::text)::date");

                entity.HasOne(d => d.InterestCategory)
                    .WithMany(p => p.ProjectJob)
                    .HasForeignKey(d => d.InterestCategoryId)
                    .HasConstraintName("ftc_mst_project_job_job_interest_category_id_fkey");

                entity.HasOne(d => d.JobMediaFiletype)
                    .WithMany(p => p.ProjectJob)
                    .HasForeignKey(d => d.MediaFiletypeId)
                    .HasConstraintName("ftc_mst_project_job_job_media_filetype_id_fkey");

                entity.HasOne(d => d.JobNationality)
                    .WithMany(p => p.ProjectJob)
                    .HasForeignKey(d => d.NationalityId)
                    .HasConstraintName("ftc_mst_project_job_job_nationality_fkey");

                entity.HasOne(d => d.JobTalentCategory)
                    .WithMany(p => p.ProjectJob)
                    .HasForeignKey(d => d.TalentCategoryId)
                    .HasConstraintName("ftc_mst_project_job_job_talent_category_id_fkey");
            });

            modelBuilder.Entity<TraceActivity>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_trace_activity");

                entity.ToTable("ftc_trace_activity");

                entity.Property(e => e.Id).HasColumnName("ta_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("ta_auxiliary_user_id");

                entity.Property(e => e.Browser)
                    .HasColumnName("ta_browser")
                    .HasColumnType("varchar")
                    .HasMaxLength(255);

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("ta_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Functionality)
                    .HasColumnName("ta_functionality")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.IpAddress)
                    .HasColumnName("ta_ip_address")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Route)
                    .HasColumnName("ta_route")
                    .HasColumnType("varchar")
                    .HasMaxLength(200);

                entity.Property(e => e.TalentId).HasColumnName("ta_talent_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.TraceActivity)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_trace_activity_ta_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TraceActivity)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_trace_activity_ta_talent_id_fkey");
            });

            modelBuilder.Entity<TraceLogin>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_trace_login");

                entity.ToTable("ftc_trace_login");

                entity.Property(e => e.Id).HasColumnName("tl_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("tl_auxiliary_user_id");

                entity.Property(e => e.City)
                    .HasColumnName("tl_city")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.Country)
                    .HasColumnName("tl_country")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.IpAddress)
                    .HasColumnName("tl_ip_address")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Latitude)
                    .HasColumnName("tl_latitude")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.LogiinTime)
                    .HasColumnName("tl_logiin_time")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.LogoutTime).HasColumnName("tl_logout_time");

                entity.Property(e => e.Longitude)
                    .HasColumnName("tl_longitude")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.Region)
                    .HasColumnName("tl_region")
                    .HasColumnType("varchar")
                    .HasMaxLength(100);

                entity.Property(e => e.TalentId).HasColumnName("tl_talent_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.TraceLogin)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_trace_login_tl_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TraceLogin)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_trace_login_tl_talent_id_fkey");
            });

            modelBuilder.Entity<TraceSmsGateway>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_trace_sms_gateway");

                entity.ToTable("ftc_trace_sms_gateway");

                entity.Property(e => e.Id).HasColumnName("tsg_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("tsg_auxiliary_user_id");

                entity.Property(e => e.CountryCode)
                    .HasColumnName("tsg_country_code")
                    .HasColumnType("varchar")
                    .HasMaxLength(10);

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("tsg_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.Message)
                    .HasColumnName("tsg_message")
                    .HasColumnType("varchar")
                    .HasMaxLength(2000);

                entity.Property(e => e.Mobile)
                    .HasColumnName("tsg_mobile")
                    .HasColumnType("varchar")
                    .HasMaxLength(30);

                entity.Property(e => e.Sent)
                    .HasColumnName("tsg_sent")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.SmsGatewayId).HasColumnName("tsg_sms_gateway_id");

                entity.Property(e => e.SmsRequest).HasColumnName("tsg_sms_request");

                entity.Property(e => e.SmsResponse).HasColumnName("tsg_sms_response");

                entity.Property(e => e.TalentId).HasColumnName("tsg_talent_id");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.TraceSmsGateway)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_trace_sms_gateway_tsg_auxiliary_user_id_fkey");

                entity.HasOne(d => d.SmsGateway)
                    .WithMany(p => p.TraceSmsGateway)
                    .HasForeignKey(d => d.SmsGatewayId)
                    .HasConstraintName("ftc_trace_sms_gateway_tsg_sms_gateway_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.TraceSmsGateway)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_trace_sms_gateway_tsg_talent_id_fkey");
            });

            modelBuilder.Entity<WhitelistIp>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_whitelist_ip");

                entity.ToTable("ftc_whitelist_ip");

                entity.Property(e => e.Id).HasColumnName("wi_id");

                entity.Property(e => e.IpAddress)
                    .HasColumnName("wi_ip_address")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<UserNotification>(entity =>
            {
                entity.HasKey(e => e.Id)
                    .HasName("PK_ftc_user_notification");

                entity.ToTable("ftc_user_notification");

                entity.Property(e => e.Id).HasColumnName("un_id");

                entity.Property(e => e.AuxiliaryUserId).HasColumnName("un_auxiliary_user_id");

                entity.Property(e => e.ContestId).HasColumnName("un_contest_id");

                entity.Property(e => e.CreatedOn)
                    .HasColumnName("un_created_on")
                    .HasDefaultValueSql("now()");

                entity.Property(e => e.JobId).HasColumnName("un_job_id");

                entity.Property(e => e.ProjectId).HasColumnName("un_project_id");

                entity.Property(e => e.Read)
                    .HasColumnName("un_read")
                    .HasDefaultValueSql("false");

                entity.Property(e => e.TalentId).HasColumnName("un_talent_id");

                entity.Property(e => e.Text).HasColumnName("un_text");

                entity.HasOne(d => d.AuxiliaryUser)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.AuxiliaryUserId)
                    .HasConstraintName("ftc_user_notification_un_auxiliary_user_id_fkey");

                entity.HasOne(d => d.Contest)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.ContestId)
                    .HasConstraintName("ftc_user_notification_un_contest_id_fkey");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.JobId)
                    .HasConstraintName("ftc_user_notification_un_job_id_fkey");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("ftc_user_notification_un_project_id_fkey");

                entity.HasOne(d => d.Talent)
                    .WithMany(p => p.UserNotification)
                    .HasForeignKey(d => d.TalentId)
                    .HasConstraintName("ftc_user_notification_un_talent_id_fkey");
            });

            modelBuilder.HasSequence("ftc_mst_interest_int_id_seq");

            modelBuilder.HasSequence("ftc_mst_proejct_location_pl_id_seq");

            modelBuilder.HasSequence("ftc_mst_talent_tal_id_seq");

            modelBuilder.HasSequence("ftc_tags_tag_id_seq");


        }
    }
}