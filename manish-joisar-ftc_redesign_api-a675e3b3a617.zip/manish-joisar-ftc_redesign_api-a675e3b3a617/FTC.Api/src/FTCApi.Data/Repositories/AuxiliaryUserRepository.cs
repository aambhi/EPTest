﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserRepository : GenericRepository<AuxiliaryUser>, IAuxiliaryUserRepository
    {
        public AuxiliaryUserRepository(FTCDbContext context) : base(context)
        {

        }
        public override async Task<AuxiliaryUser> FindAsync(Expression<Func<AuxiliaryUser, bool>> match)
        {
            return await _context.Set<AuxiliaryUser>()
                .Include(x => x.AuxiliaryUserAssignedUaAuxiliaryUser).ThenInclude(x => x.Project)
                .Include(x => x.AuxiliaryUserAssignedUaAuxiliaryUser).ThenInclude(x => x.Job).ThenInclude(x => x.Project)
                .Include(x => x.AuxiliaryUserRole)
                .SingleOrDefaultAsync(match);
        }

        public async Task<List<AuxiliaryUser>> GetAllUsers(int userId)
        {
            var auxiliaryUserId = _context.Set<AuxiliaryUser>().Where(x => x.Id == userId).Select(x => x.ParentAuxiliaryUserId).FirstOrDefault();

            if (auxiliaryUserId!=null)
            {
                userId = auxiliaryUserId.Value;
            }
            
            return await _context.Set<AuxiliaryUser>().Where(x => x.ParentAuxiliaryUserId == userId)
                .Include(x => x.AuxiliaryUserAssignedUaAuxiliaryUser)
                .Include(x => x.AuxiliaryUserRole).ToListAsync();
        }

        public bool ValidateUser(string enteredPassword, string actualPassword)
        {
            if (BCrypt.Net.BCrypt.Verify(enteredPassword, actualPassword))
                return true;

            return false;
        }


        //IMPORTANT: recruiter id is the Recruiter for whom the operation is performed, sender ID => initiating the process
        public async Task<List<int>> NotifyListOfAuxiliaryUser(int recruiterId, int senderId, int? notificationEnum = 0, int? projectId = 0, int? jobId = 0)
        {
            List<int> notifyListOfAuxiliaryUser = GetAuthorizedAuxiliaryUsers(recruiterId, notificationEnum, projectId, jobId);

            // remove the sender from the list if found
            return notifyListOfAuxiliaryUser.Where(x => x != senderId).Distinct().ToList();
        }

        public List<int> GetAuthorizedAuxiliaryUsers(int recruiterId, int? notificationEnum, int? projectId, int? jobId)
        {

            // AuxiliaryUserId if it is null skip it
            //x.ProjectId == null && x.JobId == null to remove Project Admin & JobAdmin
            // return Recruiter Admin
            var lstAuxiliaryUserAssigned = _context.Set<AuxiliaryUserAssigned>().Where(x => x.AssignedAuxiliaryUserId == recruiterId
                                                                                            && x.AuxiliaryUserId != null
                                                                                            && x.ProjectId == null
                                                                                            && x.JobId == null);

            IQueryable<AuxiliaryUserAssigned> lstprojectAdmin = null;
            IQueryable<AuxiliaryUserAssigned> lstJobAdmin = null;
            //pass it in case of Contest All cases & In project  creation case only

            if (notificationEnum == (int)NotificationEnum.ContestCreation
                || notificationEnum == (int)NotificationEnum.ContestApproval
                || notificationEnum == (int)NotificationEnum.ContestPublish
                || notificationEnum == (int)NotificationEnum.ContestClose
                || notificationEnum == (int)NotificationEnum.WinnerManagement)
            {
                lstAuxiliaryUserAssigned = lstAuxiliaryUserAssigned.Where(x => x.ProjectId == null);

            }
            else if (notificationEnum == (int)NotificationEnum.ProjectCreation)
            {
                lstAuxiliaryUserAssigned = lstAuxiliaryUserAssigned.Where(x => x.JobId == null);
            }
            // For FTC PA & R PA
            else if (notificationEnum == (int)NotificationEnum.ProjectApproval
                    || notificationEnum == (int)NotificationEnum.JobCreation
                    || notificationEnum == (int)NotificationEnum.JobPublished
                    || notificationEnum == (int)NotificationEnum.JobClose
                    || notificationEnum == (int)NotificationEnum.JobCastingFinal
                    || notificationEnum == (int)NotificationEnum.CollaboratorFeedback)
            {
                lstprojectAdmin = _context.Set<AuxiliaryUserAssigned>().Where(x => x.ProjectId == projectId
                                                                                        && x.JobId == null
                                                                                        && x.AuxiliaryUserId != null);



                lstJobAdmin = _context.Set<AuxiliaryUserAssigned>().Where(x => x.ProjectId == projectId
                                                                                        && x.JobId == jobId
                                                                                        && x.AuxiliaryUserId != null);
            }



            // get system admin & super admin
            // x.AuxiliaryUserId!=null for null handilng
            var lstAdmin = _context.Set<AuxiliaryUserRole>().Where(x => ((x.RoleId == (int)AuxiliaryUserRoleEnum.SystemAdmin)
                                                                             || (x.RoleId == (int)AuxiliaryUserRoleEnum.SuperAdmin))
                                                                             && x.AuxiliaryUserId != null);

            var parentAdmin = _context.Set<AuxiliaryUser>().Where(x => x.Id == recruiterId && x.ParentAuxiliaryUserId == null);

            var notifyListOfAuxiliaryUser = new List<int>();
            notifyListOfAuxiliaryUser = lstAdmin.Select(x => (int)x.AuxiliaryUserId).ToList();

            // Select(x => (int)x.AuxiliaryUserId) -> returns recruiter admin
            notifyListOfAuxiliaryUser.AddRange(lstAuxiliaryUserAssigned.Select(x => (int)x.AuxiliaryUserId).ToList());
            if (parentAdmin.Any())
            {
                notifyListOfAuxiliaryUser.AddRange(parentAdmin.Select(x => x.Id).ToList());
            }

            // add Project Admin to the list if any
            if (lstprojectAdmin != null)
            {
                notifyListOfAuxiliaryUser.AddRange(lstprojectAdmin.Select(x => (int)x.AuxiliaryUserId).ToList());
            }
            // add job Admin to the list if any
            if (lstJobAdmin != null)
            {
                notifyListOfAuxiliaryUser.AddRange(lstJobAdmin.Select(x => (int)x.AuxiliaryUserId).ToList());
            }

            return notifyListOfAuxiliaryUser;
        }

        public bool CheckAuthorization(int recruiterId, int loggedInUserId, int? notificationEnum = 0, int? projectId = 0, int? jobId = 0)
        {
            bool isLoggedInUserAuthorized = false;

            var authorizedUsers = GetAuthorizedAuxiliaryUsers(recruiterId, notificationEnum, projectId, jobId);
            isLoggedInUserAuthorized = authorizedUsers.Contains(loggedInUserId) || (recruiterId == loggedInUserId);

            return isLoggedInUserAuthorized;
        }

        public async Task<List<int>> NotifyListOfAdmin()
        {
            var lstAdmin = _context.Set<AuxiliaryUserRole>().Where(x => ((x.RoleId == (int)AuxiliaryUserRoleEnum.SystemAdmin)
                                                                                 || (x.RoleId == (int)AuxiliaryUserRoleEnum.SuperAdmin))
                                                                                 && (x.AuxiliaryUserId != null));
            var notifyListOfAuxiliaryUser = new List<int>();
            notifyListOfAuxiliaryUser = lstAdmin.Select(x => (int)x.AuxiliaryUserId).Distinct().ToList();
            return notifyListOfAuxiliaryUser;

        }

    }
}
