﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentEthnicityRepository:GenericRepository<TalentEthnicity>, ITalentEthnicityRepository
    {
        public TalentEthnicityRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
