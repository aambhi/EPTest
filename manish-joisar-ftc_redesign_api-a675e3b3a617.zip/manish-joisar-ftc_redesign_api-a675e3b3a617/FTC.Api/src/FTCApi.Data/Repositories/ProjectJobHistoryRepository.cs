﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobHistoryRepository : GenericRepository<ProjectJobHistory>, IProjectJobHistoryRepository
    {
        public ProjectJobHistoryRepository(FTCDbContext context) : base(context)
        {

        }
    }
}
