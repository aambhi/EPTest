﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AddressRepository: GenericRepository<Address>,IAddressRepository
    {
        public AddressRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
