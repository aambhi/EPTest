﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class JobShareViewDetailRepository:GenericRepository<JobShareViewDetail>, IJobShareViewDetailRepository
    {
        public JobShareViewDetailRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
