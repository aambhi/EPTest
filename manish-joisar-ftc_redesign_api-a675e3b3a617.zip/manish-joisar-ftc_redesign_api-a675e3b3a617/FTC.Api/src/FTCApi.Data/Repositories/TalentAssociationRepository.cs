﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentAssociationRepository:GenericRepository<TalentAssociation>, ITalentAssociationRepository
    {
        public TalentAssociationRepository(FTCDbContext context):base(context)
        {

        }
    }
}
