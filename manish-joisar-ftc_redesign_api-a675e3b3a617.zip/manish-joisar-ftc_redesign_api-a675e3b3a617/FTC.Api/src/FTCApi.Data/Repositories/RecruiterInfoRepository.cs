﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class RecruiterInfoRepository : IRecruiterInfoRepository
    {

        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IAuxiliaryUserAddressRepository _auxiliaryUserAddressRepository;
        private IAddressRepository _addressRepository;
        private IAuxiliaryRecruiterRepository _auxiliaryRecruiterRepository;
        private IAuxiliaryUserExperienceRepository _auxiliaryUserExperienceRepository;
        private IAuxiliaryUserAwardRepository _auxiliaryUserAwardRepository;
        private IAuxiliaryUserSocialLinkRepository _auxiliaryUserSocialLinkRepository;
        private IAuxiliaryUserAssociationRepository _auxiliaryUserAssociationRepository;
        private IAuxiliarySecurityQuestionRepository _auxiliarySecurityQuestionRepository;
        private IAssociationRepository _associationRepository;
        private IAuxiliaryUserTokenRepository _auxiliaryUserTokenRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private ILogger<RecruiterInfoRepository> _logger;

        public RecruiterInfoRepository(IAuxiliaryUserRepository auxiliaryUserRepository,
            IAuxiliaryUserAddressRepository auxiliaryUserAddressRepository,
            IAddressRepository addressRepository,
            IAuxiliaryRecruiterRepository auxiliaryRecruiterRepository,
            IAuxiliaryUserExperienceRepository auxiliaryUserExperienceRepository,
            IAuxiliaryUserAwardRepository auxiliaryUserAwardRepository,
            IAuxiliaryUserSocialLinkRepository auxiliaryUserSocialLinkRepository,
            IAuxiliaryUserAssociationRepository auxiliaryUserAssociationRepository,
            IAuxiliarySecurityQuestionRepository auxiliarySecurityQuestionRepository,
            IAssociationRepository associationRepository,
            IAuxiliaryUserTokenRepository auxiliaryUserTokenRepository,
            ICityRepository cityRepository,
            ICountryRepository countryRepository,
            IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
            ILoggerFactory loggerFactory)
        {
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _auxiliaryUserAddressRepository = auxiliaryUserAddressRepository;
            _addressRepository = addressRepository;
            _auxiliaryRecruiterRepository = auxiliaryRecruiterRepository;
            _auxiliaryUserExperienceRepository = auxiliaryUserExperienceRepository;
            _auxiliaryUserAwardRepository = auxiliaryUserAwardRepository;
            _auxiliaryUserSocialLinkRepository = auxiliaryUserSocialLinkRepository;
            _auxiliaryUserAssociationRepository = auxiliaryUserAssociationRepository;
            _auxiliarySecurityQuestionRepository = auxiliarySecurityQuestionRepository;
            _associationRepository = associationRepository;
            _auxiliaryUserTokenRepository = auxiliaryUserTokenRepository;
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _logger = loggerFactory.CreateLogger<RecruiterInfoRepository>(); ;
        }

        public async Task<AuxiliaryUserDto> GetAuxiliaryUser(int recruiterId)
        {
            var auxillaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == recruiterId);
            AuxiliaryUserDto auxiliaryUserDto = new AuxiliaryUserDto();
            auxiliaryUserDto = await ConvertToAuxiliaryUserDto(auxiliaryUserDto, auxillaryUser);

            return auxiliaryUserDto;
        }

        public async Task<AuxiliaryRecruiterDto> GetAuxiliaryRecruiter(int recruiterId)
        {
            var auxiliaryRecruiter = await _auxiliaryRecruiterRepository.FindAsync(x => x.AuxiliaryId == recruiterId);
            if (auxiliaryRecruiter != null)
            {
                AuxiliaryRecruiterDto auxiliaryRecruiterDto = new AuxiliaryRecruiterDto();
                auxiliaryRecruiterDto = await ConvertToAuxiliaryRecruiterDto(auxiliaryRecruiterDto, auxiliaryRecruiter);

                return auxiliaryRecruiterDto;

            }
            return null;
        }


        public async Task<List<AuxiliaryUserExperienceDto>> GetAuxiliaryUserExperiences(int recruiterId)
        {
            var auxiliaryUserExperiences = await _auxiliaryUserExperienceRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId);
            if (auxiliaryUserExperiences != null)
            {
                List<AuxiliaryUserExperienceDto> lstauxiliaryUserExperiencesDto = new List<AuxiliaryUserExperienceDto>();
                foreach (var auxiliaryUserExperience in auxiliaryUserExperiences)
                {
                    AuxiliaryUserExperienceDto auxiliaryUserExperienceDto = new AuxiliaryUserExperienceDto();
                    auxiliaryUserExperienceDto = ConvertToAuxiliaryUserExperienceDto(auxiliaryUserExperienceDto, auxiliaryUserExperience);
                    lstauxiliaryUserExperiencesDto.Add(auxiliaryUserExperienceDto);
                }
                return lstauxiliaryUserExperiencesDto;
            }
            return null;
        }
        public async Task<List<AuxiliaryUserAwardDto>> GetAuxiliaryUserAwards(int recruiterId)
        {
            var auxiliaryUserAwards = await _auxiliaryUserAwardRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId);
            if (auxiliaryUserAwards != null)
            {
                List<AuxiliaryUserAwardDto> lstAuxiliaryUserAwardDto = new List<AuxiliaryUserAwardDto>();
                foreach (var auxiliaryUserAward in auxiliaryUserAwards)
                {
                    AuxiliaryUserAwardDto auxiliaryUserAwardDto = new AuxiliaryUserAwardDto();
                    auxiliaryUserAwardDto = ConvertToAuxiliaryUserAwardDto(auxiliaryUserAwardDto, auxiliaryUserAward);
                    lstAuxiliaryUserAwardDto.Add(auxiliaryUserAwardDto);
                }
                return lstAuxiliaryUserAwardDto;
            }
            return null;
        }
        public async Task<List<AuxiliaryUserSocialLinkDto>> GetAuxiliaryUserSocialLinks(int recruiterId)
        {
            var auxiliarySocialLinks = await _auxiliaryUserSocialLinkRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId);
            if (auxiliarySocialLinks != null)
            {
                List<AuxiliaryUserSocialLinkDto> lstAuxiliaryUserSocialLinkDto = new List<AuxiliaryUserSocialLinkDto>();
                foreach (var auxiliarySocialLink in auxiliarySocialLinks)
                {
                    AuxiliaryUserSocialLinkDto auxiliaryUserSocialLinkDto = new AuxiliaryUserSocialLinkDto();
                    auxiliaryUserSocialLinkDto = ConvertToAuxiliaryUserSocialLinkDto(auxiliaryUserSocialLinkDto, auxiliarySocialLink);
                    lstAuxiliaryUserSocialLinkDto.Add(auxiliaryUserSocialLinkDto);
                }
                return lstAuxiliaryUserSocialLinkDto;
            }
            return null;
        }


        public async Task<List<AuxiliarySecurityQuestionDto>> GetAuxiliarySecurityQuestions(int recruiterId)
        {
            var auxiliarySecurityQuestions = await _auxiliarySecurityQuestionRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId);
            if (auxiliarySecurityQuestions != null)
            {
                List<AuxiliarySecurityQuestionDto> lstAuxiliarySecurityQuestionDto = new List<AuxiliarySecurityQuestionDto>();
                foreach (var auxiliarySecurityQuestion in auxiliarySecurityQuestions)
                {
                    AuxiliarySecurityQuestionDto auxiliarySecurityQuestionDto = new AuxiliarySecurityQuestionDto();
                    auxiliarySecurityQuestionDto = ConvertToAuxiliarySecurityQuestionDto(auxiliarySecurityQuestionDto, auxiliarySecurityQuestion);
                    lstAuxiliarySecurityQuestionDto.Add(auxiliarySecurityQuestionDto);
                }
                return lstAuxiliarySecurityQuestionDto;
            }
            return null;
        }


        private AuxiliarySecurityQuestionDto ConvertToAuxiliarySecurityQuestionDto(AuxiliarySecurityQuestionDto auxiliarySecurityQuestionDto, AuxiliarySecurityQuestion auxiliarySecurityQuestion)
        {
            auxiliarySecurityQuestionDto.Id = auxiliarySecurityQuestion.Id;
            auxiliarySecurityQuestionDto.AuxiliaryUserId = auxiliarySecurityQuestion.AuxiliaryUserId;
            auxiliarySecurityQuestionDto.SecurityQuestionId = auxiliarySecurityQuestion.SecurityQuestionId;
            auxiliarySecurityQuestionDto.Answer = auxiliarySecurityQuestion.Answer;
            return auxiliarySecurityQuestionDto;
        }


        public async Task<List<AuxiliaryUserAssociationDto>> GetAuxiliaryUserAssociations(int recruiterId)
        {
            var auxiliaryUserAssociations = await _auxiliaryUserAssociationRepository.FindAllAsync(x => x.AuxiliaryUserId == recruiterId);
            if (auxiliaryUserAssociations != null)
            {
                List<AuxiliaryUserAssociationDto> lstAuxiliaryUserAssociationDto = new List<AuxiliaryUserAssociationDto>();
                foreach (var auxiliaryUserAssociation in auxiliaryUserAssociations)
                {
                    AuxiliaryUserAssociationDto auxiliaryUserAssociationDto = new AuxiliaryUserAssociationDto();
                    auxiliaryUserAssociationDto = await ConvertToAuxiliaryUserAssociationDto(auxiliaryUserAssociationDto, auxiliaryUserAssociation);
                    lstAuxiliaryUserAssociationDto.Add(auxiliaryUserAssociationDto);
                }
                return lstAuxiliaryUserAssociationDto;
            }
            return null;
        }


        public async Task<List<AuxiliaryUserAssociationDto>> SaveAuxiliaryUserAssociations(int recruiterId, List<AuxiliaryUserAssociationDto> lstAuxiliaryUserAssociationDto)
        {
            var auxiliaryUserAssociations = _auxiliaryUserAssociationRepository.FindAll(x => x.AuxiliaryUserId == recruiterId).ToList();
            foreach (var auxiliaryUserAssociationDto in lstAuxiliaryUserAssociationDto)
            {
                var auxiliaryUserAssociation = await _auxiliaryUserAssociationRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.AssociationId == auxiliaryUserAssociationDto.AssociationId);
                if (auxiliaryUserAssociation == null)
                {
                    AuxiliaryUserAssociation auxiliaryUserAssociationModel = new AuxiliaryUserAssociation();
                    auxiliaryUserAssociationModel = ConvertToAuxiliaryUserAssociationModel(recruiterId, auxiliaryUserAssociationModel, auxiliaryUserAssociationDto);
                    auxiliaryUserAssociationModel = await _auxiliaryUserAssociationRepository.AddAsync(auxiliaryUserAssociationModel);
                }
                else
                {
                    auxiliaryUserAssociation = ConvertToAuxiliaryUserAssociationModel(recruiterId, auxiliaryUserAssociation, auxiliaryUserAssociationDto);
                    auxiliaryUserAssociation = await _auxiliaryUserAssociationRepository.UpdateAsync(auxiliaryUserAssociation);
                }
                //auxiliaryUserAssociations = _auxiliaryUserAssociationRepository.FindAll(x => x.AssociationId == auxiliaryUserAssociationDto.AssociationId);
                auxiliaryUserAssociations.RemoveAll(x => x.AssociationId == auxiliaryUserAssociationDto.AssociationId && x.AuxiliaryUserId == recruiterId);
            }
            foreach (var auxiliaryUserAssociation in auxiliaryUserAssociations)
            {
                await _auxiliaryUserAssociationRepository.DeleteAsync(auxiliaryUserAssociation);
            }
            return lstAuxiliaryUserAssociationDto;
        }

        private AuxiliaryUserAssociation ConvertToAuxiliaryUserAssociationModel(int recruiterId, AuxiliaryUserAssociation auxiliaryUserAssociation, AuxiliaryUserAssociationDto auxiliaryUserAssociationDto)
        {
            auxiliaryUserAssociation.AuxiliaryUserId = recruiterId;
            auxiliaryUserAssociation.AssociationId = auxiliaryUserAssociationDto.AssociationId;
            auxiliaryUserAssociation.MembershipId = auxiliaryUserAssociationDto.MembershipId;
            return auxiliaryUserAssociation;
        }

        private async Task<AuxiliaryUserAssociationDto> ConvertToAuxiliaryUserAssociationDto(AuxiliaryUserAssociationDto auxiliaryUserAssociationDto, AuxiliaryUserAssociation auxiliaryUserAssociation)
        {
            auxiliaryUserAssociationDto.AuxiliaryUserId = auxiliaryUserAssociation.AuxiliaryUserId;
            auxiliaryUserAssociationDto.AssociationId = auxiliaryUserAssociation.AssociationId;
            auxiliaryUserAssociationDto.MembershipId = auxiliaryUserAssociation.MembershipId;


            var recruiterAssociationResponse = await _associationRepository.FindAsync(x => x.Id == auxiliaryUserAssociationDto.AssociationId);
            auxiliaryUserAssociationDto.AssociationDescription = recruiterAssociationResponse.Description;

            return auxiliaryUserAssociationDto;
        }
        public async Task<List<AuxiliaryUserSocialLinkDto>> SaveAuxiliarySocialLinks(int recruiterId, List<AuxiliaryUserSocialLinkDto> lstAuxiliaryUserSocialLinkDto)
        {
            foreach (var auxiliaryUserSocialLinkDto in lstAuxiliaryUserSocialLinkDto)
            {
                var auxiliaryUserSocialLink = await _auxiliaryUserSocialLinkRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.SocialLinkId == auxiliaryUserSocialLinkDto.SocialLinkId);
                if (auxiliaryUserSocialLink == null)
                {
                    AuxiliaryUserSocialLink auxiliaryUserSocialLinkModel = new AuxiliaryUserSocialLink();
                    auxiliaryUserSocialLinkModel = ConvertToauxiliaryUserSocialLinkModel(recruiterId, auxiliaryUserSocialLinkModel, auxiliaryUserSocialLinkDto);
                    auxiliaryUserSocialLinkModel = await _auxiliaryUserSocialLinkRepository.AddAsync(auxiliaryUserSocialLinkModel);
                }
                else
                {
                    auxiliaryUserSocialLink = ConvertToauxiliaryUserSocialLinkModel(recruiterId, auxiliaryUserSocialLink, auxiliaryUserSocialLinkDto);
                    auxiliaryUserSocialLink = await _auxiliaryUserSocialLinkRepository.UpdateAsync(auxiliaryUserSocialLink);
                }
            }
            return lstAuxiliaryUserSocialLinkDto;
        }

        public async Task<List<AuxiliarySecurityQuestionDto>> SaveAuxiliarySecurityQuestions(int recruiterId, List<AuxiliarySecurityQuestionDto> lstAuxiliarySecurityQuestionDto)
        {
            if (lstAuxiliarySecurityQuestionDto.Count > 0)
            {
                foreach (var auxiliarySecurityQuestionDto in lstAuxiliarySecurityQuestionDto)
                {
                    var auxiliarySecurityQuestion = await _auxiliarySecurityQuestionRepository.FindAsync(x => x.AuxiliaryUserId == recruiterId && x.SecurityQuestionId == auxiliarySecurityQuestionDto.SecurityQuestionId);
                    if (auxiliarySecurityQuestion == null)
                    {
                        AuxiliarySecurityQuestion auxiliarySecurityQuestionModel = new AuxiliarySecurityQuestion();
                        auxiliarySecurityQuestionModel = ConvertToAuxiliarySecurityQuestionModel(recruiterId, auxiliarySecurityQuestionModel, auxiliarySecurityQuestionDto);
                        auxiliarySecurityQuestionModel = await _auxiliarySecurityQuestionRepository.AddAsync(auxiliarySecurityQuestionModel);
                    }
                    else
                    {
                        auxiliarySecurityQuestion = ConvertToAuxiliarySecurityQuestionModel(recruiterId, auxiliarySecurityQuestion, auxiliarySecurityQuestionDto);
                        auxiliarySecurityQuestion = await _auxiliarySecurityQuestionRepository.UpdateAsync(auxiliarySecurityQuestion);
                    }
                }
            }
            return lstAuxiliarySecurityQuestionDto;
        }

        private AuxiliarySecurityQuestion ConvertToAuxiliarySecurityQuestionModel(int recruiterId, AuxiliarySecurityQuestion auxiliarySecurityQuestionModel, AuxiliarySecurityQuestionDto auxiliarySecurityQuestionDto)
        {
            auxiliarySecurityQuestionModel.AuxiliaryUserId = recruiterId;
            auxiliarySecurityQuestionModel.SecurityQuestionId = auxiliarySecurityQuestionDto.SecurityQuestionId;
            auxiliarySecurityQuestionModel.Answer = auxiliarySecurityQuestionDto.Answer;
            return auxiliarySecurityQuestionModel;
        }

        private AuxiliaryUserSocialLink ConvertToauxiliaryUserSocialLinkModel(int recruiterId, AuxiliaryUserSocialLink auxiliaryUserSocialLinkModel, AuxiliaryUserSocialLinkDto auxiliaryUserSocialLinkDto)
        {
            auxiliaryUserSocialLinkModel.AuxiliaryUserId = recruiterId;
            auxiliaryUserSocialLinkModel.SocialLinkId = auxiliaryUserSocialLinkDto.SocialLinkId;
            auxiliaryUserSocialLinkModel.Link = auxiliaryUserSocialLinkDto.Link; ;
            return auxiliaryUserSocialLinkModel;
        }

        public async Task<AuxiliaryUserDto> SaveAuxiliaryUser(int recruiterId, AuxiliaryUserDto auxiliaryUserDto)
        {
            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == recruiterId);
            auxiliaryUser = await ConvertToAuxiliaryRecruiterModel(recruiterId, auxiliaryUserDto, auxiliaryUser);
            auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
            return auxiliaryUserDto;
        }
        public async Task<AuxiliaryRecruiterDto> SaveAuxiliaryRecruiter(int recruiterId, AuxiliaryRecruiterDto auxiliaryRecruiterDto)
        {
            var auxiliaryRecruiter = await _auxiliaryRecruiterRepository.FindAsync(x => x.AuxiliaryId == recruiterId);
            if (auxiliaryRecruiter != null)
            {
                auxiliaryRecruiter = await ConvertToAuxiliaryRecruiterModel(recruiterId, auxiliaryRecruiterDto, auxiliaryRecruiter);
                auxiliaryRecruiter = await _auxiliaryRecruiterRepository.UpdateAsync(auxiliaryRecruiter);
                
            }
            else
            {
                AuxiliaryRecruiter auxiliaryRecruiterModel = new AuxiliaryRecruiter();
                auxiliaryRecruiterModel = await ConvertToAuxiliaryRecruiterModel(recruiterId, auxiliaryRecruiterDto, auxiliaryRecruiterModel);
                auxiliaryRecruiterModel = await _auxiliaryRecruiterRepository.AddAsync(auxiliaryRecruiterModel);                
            }

            return auxiliaryRecruiterDto;
        }
        public async Task GetAuxilaryUserCityCountryId(AuxiliaryUserDto auxiliaryUserDto, Address addressModel)
        {
            if (auxiliaryUserDto.CityId == 0 || auxiliaryUserDto.CityId == null)
            {
                City city = null;
                if (auxiliaryUserDto.CityName != null)
                {
                    city = await _cityRepository.FindAsync(x => x.CityDescription.ToLower() == auxiliaryUserDto.CityName.ToLower()
                                                                                    && x.CityStateCode.ToLower() == auxiliaryUserDto.StateCode.ToLower());
                }
                if (city == null)
                {
                    var cityModel = await AddCityMaster(auxiliaryUserDto);
                    addressModel.CityId = cityModel.CityId;
                    addressModel.CountryId = cityModel.CityCountryId;
                }
                else
                {
                    addressModel.CityId = city.CityId;
                    addressModel.CountryId = city.CityCountryId;
                }
            }
            else
            {
                addressModel.CityId = auxiliaryUserDto.CityId == 0 ? null : auxiliaryUserDto.CityId;
                addressModel.CountryId = auxiliaryUserDto.CountryId == 0 ? null : auxiliaryUserDto.CountryId;
            }
        }

        private async Task<City> AddCityMaster(AuxiliaryUserDto auxiliaryUserDto)
        {
            var country = new Country();
            if (auxiliaryUserDto.CountryName != null)
            {
                country = await _countryRepository.FindAsync(x => x.Name.ToLower() == auxiliaryUserDto.CountryName.ToLower());
            }

            if (country != null)
            {
                if (string.IsNullOrEmpty(country.Code) || string.IsNullOrEmpty(country.Nationality))
                {
                    country.Code = auxiliaryUserDto.CountryCode;
                    country.Nationality = auxiliaryUserDto.Nationality;
                    country = await _countryRepository.UpdateAsync(country);
                }
                // CHECK city & Country & State = null => update the record with state

                var lststateCountry = await _cityRepository.FindAllAsync(x => string.IsNullOrEmpty(x.CityStateCode)
                                                                            && x.CityCountryId == country.Id
                                                                            && x.CityDescription.ToLower() == auxiliaryUserDto.CityName.ToLower());
                // Update State if Country And City Exist
                if (lststateCountry.Count() > 0)
                {
                    var stateCountry = lststateCountry.First();
                    stateCountry.CityState = auxiliaryUserDto.StateName;
                    stateCountry.CityStateCode = auxiliaryUserDto.StateCode;

                    stateCountry = await _cityRepository.UpdateAsync(stateCountry);

                    return stateCountry;
                }
                else
                {
                    var cityModel = new City
                    {
                        CityDescription = auxiliaryUserDto.CityName,
                        CityCountryId = (country == null) ? null : (int?)country.Id,
                        CityState = auxiliaryUserDto.StateName,
                        CityStateCode = auxiliaryUserDto.StateCode
                    };
                    if (!string.IsNullOrEmpty(auxiliaryUserDto.CityName))
                    {
                        cityModel = await _cityRepository.AddAsync(cityModel);
                    }
                    return cityModel;
                }

            }
            else
            {
                _logger.LogError("The Country => " + auxiliaryUserDto.CountryName + " : does not exist ");
                return new City();
            }
            
        }

        

        public async Task<List<AuxiliaryUserExperienceDto>> SaveAuxiliaryUserExperiences(int recruiterId, List<AuxiliaryUserExperienceDto> lstAuxiliaryUserExperienceDto)
        {
            List<AuxiliaryUserExperienceDto> originalLstAuxiliaryUserExperienceDto = new List<AuxiliaryUserExperienceDto>(lstAuxiliaryUserExperienceDto);
            List<AuxiliaryUserExperienceDto> updatelLstAuxiliaryUserExperienceDto = new List<AuxiliaryUserExperienceDto>(lstAuxiliaryUserExperienceDto);

            var lstAuxiliaryUserExperience = _auxiliaryUserExperienceRepository.FindAll(x => x.AuxiliaryUserId == recruiterId).ToList();

            foreach (var auxiliaryUserExperience in lstAuxiliaryUserExperience)
            {
                lstAuxiliaryUserExperienceDto.RemoveAll(x => x.Id == auxiliaryUserExperience.Id);
            }

            foreach (var auxiliaryUserExperienceDto in lstAuxiliaryUserExperienceDto)
            {
                updatelLstAuxiliaryUserExperienceDto.RemoveAll(x => x.Id == auxiliaryUserExperienceDto.Id);
            }

            foreach (var auxiliaryUserExperienceDto in originalLstAuxiliaryUserExperienceDto)
            {
                lstAuxiliaryUserExperience.RemoveAll(x => x.Id == auxiliaryUserExperienceDto.Id);
            }

            if (lstAuxiliaryUserExperienceDto.Count > 0)
            {
                foreach (var auxiliaryUserExperienceDto in lstAuxiliaryUserExperienceDto)
                {
                    AuxiliaryUserExperience auxiliaryUserExperienceModel = new AuxiliaryUserExperience();
                    var auxiliaryUserExperience = ConvertToAuxiliaryUserExperienceModel(recruiterId, auxiliaryUserExperienceModel, auxiliaryUserExperienceDto);
                    auxiliaryUserExperience = await _auxiliaryUserExperienceRepository.AddAsync(auxiliaryUserExperience);
                }
            }

            if (updatelLstAuxiliaryUserExperienceDto.Count > 0)
            {
                foreach (var auxiliaryUserExperienceDto in updatelLstAuxiliaryUserExperienceDto)
                {
                    var auxiliaryUserExperience = await _auxiliaryUserExperienceRepository.FindAsync(x => x.Id == auxiliaryUserExperienceDto.Id);
                    auxiliaryUserExperience = ConvertToAuxiliaryUserExperienceModel(recruiterId, auxiliaryUserExperience, auxiliaryUserExperienceDto);

                    auxiliaryUserExperience = await _auxiliaryUserExperienceRepository.UpdateAsync(auxiliaryUserExperience);
                }
            }

            if (lstAuxiliaryUserExperience.Count > 0)
            {
                foreach (var auxiliaryUserExperience in lstAuxiliaryUserExperience)
                {
                    await _auxiliaryUserExperienceRepository.DeleteAsync(auxiliaryUserExperience);
                }
            }
            return originalLstAuxiliaryUserExperienceDto;
        }


        public async Task<List<AuxiliaryUserAwardDto>> SaveAuxiliaryUserAwards(int recruiterId, List<AuxiliaryUserAwardDto> lstAuxiliaryUserAwardDto)
        {
            List<AuxiliaryUserAwardDto> originalLstAuxiliaryUserAwardDto = new List<AuxiliaryUserAwardDto>(lstAuxiliaryUserAwardDto);
            List<AuxiliaryUserAwardDto> updatelLstAuxiliaryUserAwardDto = new List<AuxiliaryUserAwardDto>(lstAuxiliaryUserAwardDto);

            var lstAuxiliaryUserAward = _auxiliaryUserAwardRepository.FindAll(x => x.AuxiliaryUserId == recruiterId).ToList();

            foreach (var auxiliaryUserAward in lstAuxiliaryUserAward)
            {
                lstAuxiliaryUserAwardDto.RemoveAll(x => x.Id == auxiliaryUserAward.Id);
            }

            foreach (var auxiliaryUserAwardDto in lstAuxiliaryUserAwardDto)
            {
                updatelLstAuxiliaryUserAwardDto.RemoveAll(x => x.Id == auxiliaryUserAwardDto.Id);
            }

            foreach (var auxiliaryUserAwardDto in originalLstAuxiliaryUserAwardDto)
            {
                lstAuxiliaryUserAward.RemoveAll(x => x.Id == auxiliaryUserAwardDto.Id);
            }

            if (lstAuxiliaryUserAwardDto.Count > 0)
            {
                foreach (var auxiliaryUserAwardDto in lstAuxiliaryUserAwardDto)
                {
                    AuxiliaryUserAward auxiliaryUserAwardModel = new AuxiliaryUserAward();
                    var auxiliaryUserAward = ConvertToAuxiliaryUserAwardModel(recruiterId, auxiliaryUserAwardModel, auxiliaryUserAwardDto);
                    auxiliaryUserAward = await _auxiliaryUserAwardRepository.AddAsync(auxiliaryUserAward);
                }
            }

            if (updatelLstAuxiliaryUserAwardDto.Count > 0)
            {
                foreach (var auxiliaryUserAwardDto in updatelLstAuxiliaryUserAwardDto)
                {
                    var auxiliaryUserAward = await _auxiliaryUserAwardRepository.FindAsync(x => x.Id == auxiliaryUserAwardDto.Id);
                    auxiliaryUserAward = ConvertToAuxiliaryUserAwardModel(recruiterId, auxiliaryUserAward, auxiliaryUserAwardDto);

                    auxiliaryUserAward = await _auxiliaryUserAwardRepository.UpdateAsync(auxiliaryUserAward);
                }
            }

            if (lstAuxiliaryUserAward.Count > 0)
            {
                foreach (var auxiliaryUserAward in lstAuxiliaryUserAward)
                {
                    await _auxiliaryUserAwardRepository.DeleteAsync(auxiliaryUserAward);
                }
            }
            return originalLstAuxiliaryUserAwardDto;
        }



        private AuxiliaryUserSocialLinkDto ConvertToAuxiliaryUserSocialLinkDto(AuxiliaryUserSocialLinkDto auxiliaryUserSocialLinkDto, AuxiliaryUserSocialLink auxiliarySocialLink)
        {
            auxiliaryUserSocialLinkDto.AuxiliaryUserId = auxiliarySocialLink.AuxiliaryUserId;
            auxiliaryUserSocialLinkDto.SocialLinkId = auxiliarySocialLink.SocialLinkId;
            auxiliaryUserSocialLinkDto.Link = auxiliarySocialLink.Link;
            return auxiliaryUserSocialLinkDto;
        }

        private AuxiliaryUserAward ConvertToAuxiliaryUserAwardModel(int recruiterId, AuxiliaryUserAward auxiliaryUserAward, AuxiliaryUserAwardDto auxiliaryUserAwardDto)
        {
            auxiliaryUserAward.Id = auxiliaryUserAwardDto.Id;
            auxiliaryUserAward.AuxiliaryUserId = recruiterId;
            auxiliaryUserAward.Name = auxiliaryUserAwardDto.Name;
            auxiliaryUserAward.Criteria = auxiliaryUserAwardDto.Criteria;
            auxiliaryUserAward.Year = auxiliaryUserAwardDto.Year;
            auxiliaryUserAward.AddtionalDetails = auxiliaryUserAwardDto.AddtionalDetails;
            return auxiliaryUserAward;
        }
        private AuxiliaryUserAwardDto ConvertToAuxiliaryUserAwardDto(AuxiliaryUserAwardDto auxiliaryUserAwardDto, AuxiliaryUserAward auxiliaryUserAward)
        {
            auxiliaryUserAwardDto.Id = auxiliaryUserAward.Id;
            auxiliaryUserAwardDto.AuxiliaryUserId = auxiliaryUserAward.AuxiliaryUserId;
            auxiliaryUserAwardDto.Name = auxiliaryUserAward.Name;
            auxiliaryUserAwardDto.Criteria = auxiliaryUserAward.Criteria;
            auxiliaryUserAwardDto.Year = auxiliaryUserAward.Year;
            auxiliaryUserAwardDto.AddtionalDetails = auxiliaryUserAward.AddtionalDetails;
            return auxiliaryUserAwardDto;
        }

        private AuxiliaryUserExperience ConvertToAuxiliaryUserExperienceModel(int recruiterId, AuxiliaryUserExperience auxiliaryUserExperience, AuxiliaryUserExperienceDto auxiliaryUserExperienceDto)
        {
            auxiliaryUserExperience.Id = auxiliaryUserExperienceDto.Id;
            auxiliaryUserExperience.AuxiliaryUserId = recruiterId;
            auxiliaryUserExperience.InterestCategoryId = auxiliaryUserExperienceDto.InterestCategoryId;
            auxiliaryUserExperience.ProjectTitle = auxiliaryUserExperienceDto.ProjectTitle;
            auxiliaryUserExperience.CompanyName = auxiliaryUserExperienceDto.CompanyName;
            auxiliaryUserExperience.Year = auxiliaryUserExperienceDto.Year;
            auxiliaryUserExperience.AddtionalDetails = auxiliaryUserExperienceDto.AddtionalDetails;
            auxiliaryUserExperience.Link = auxiliaryUserExperienceDto.Link;
            return auxiliaryUserExperience;
        }

        private AuxiliaryUserExperienceDto ConvertToAuxiliaryUserExperienceDto(AuxiliaryUserExperienceDto auxiliaryUserExperienceDto, AuxiliaryUserExperience auxiliaryUserExperience)
        {
            auxiliaryUserExperienceDto.Id = auxiliaryUserExperience.Id;
            auxiliaryUserExperienceDto.AuxiliaryUserId = auxiliaryUserExperience.AuxiliaryUserId;
            auxiliaryUserExperienceDto.InterestCategoryId = auxiliaryUserExperience.InterestCategoryId;
            auxiliaryUserExperienceDto.ProjectTitle = auxiliaryUserExperience.ProjectTitle;
            auxiliaryUserExperienceDto.CompanyName = auxiliaryUserExperience.CompanyName;
            auxiliaryUserExperienceDto.Year = auxiliaryUserExperience.Year;
            auxiliaryUserExperienceDto.AddtionalDetails = auxiliaryUserExperience.AddtionalDetails;
            auxiliaryUserExperienceDto.Link = auxiliaryUserExperience.Link;
            return auxiliaryUserExperienceDto;
        }

        private async Task<AuxiliaryRecruiter> ConvertToAuxiliaryRecruiterModel(int recruiterId, AuxiliaryRecruiterDto auxiliaryRecruiterDto, AuxiliaryRecruiter auxiliaryRecruiter)
        {
            auxiliaryRecruiter.AuxiliaryId = recruiterId;
            auxiliaryRecruiter.BusinessPhoneNumber = auxiliaryRecruiterDto.BusinessPhoneNumber;
            auxiliaryRecruiter.Name = auxiliaryRecruiterDto.Name;
            auxiliaryRecruiter.Mobile = auxiliaryRecruiterDto.Mobile;
            auxiliaryRecruiter.Email = auxiliaryRecruiterDto.Email;
            auxiliaryRecruiter.RecruiterTypeId = auxiliaryRecruiterDto.RecruiterTypeId == 0 ? null : auxiliaryRecruiterDto.RecruiterTypeId;

            return auxiliaryRecruiter;
        }

        private async Task<AuxiliaryUser> ConvertToAuxiliaryRecruiterModel(int recruiterId, AuxiliaryUserDto auxiliaryUserDto, AuxiliaryUser auxiliaryUser)
        {
            auxiliaryUser.Id = recruiterId;
            auxiliaryUser.MobileCountryCode = auxiliaryUserDto.MobileCountryCode;
            auxiliaryUser.Mobile = auxiliaryUserDto.Mobile;
            auxiliaryUser.EmailId = auxiliaryUserDto.EmailId;
            auxiliaryUser.FullName = auxiliaryUserDto.FullName;
            auxiliaryUser.Verified = auxiliaryUserDto.Verified;
            auxiliaryUser.VerifiedBy = auxiliaryUserDto.VerifiedBy;
            auxiliaryUser.TypeId = auxiliaryUserDto.TypeId;
            auxiliaryUser.StatusId = auxiliaryUserDto.StatusId;
            auxiliaryUser.ParentAuxiliaryUserId = auxiliaryUserDto.ParentAuxiliaryUserId;
            auxiliaryUser.Onboarded = auxiliaryUserDto.Onboarded;
            auxiliaryUser.TermsConditionAccepted = auxiliaryUserDto.TermsConditionAccepted;
            auxiliaryUser.MobileCountryId = auxiliaryUserDto.MobileCountryId;
            auxiliaryUser.UpdatedOn = DateTime.Now;
            auxiliaryUser = await SaveAuxilaryUserAddress(recruiterId, auxiliaryUserDto, auxiliaryUser);
            
            return auxiliaryUser;
        }


        private async Task<AuxiliaryUser> SaveAuxilaryUserAddress(int recruiterId, AuxiliaryUserDto auxiliaryUserDto, AuxiliaryUser auxiliaryUser)
        {
            var lstAuxiliaryUserAddress = await _auxiliaryUserAddressRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);
            Address addressModel = new Address();
            AuxiliaryUserAddress auxiliaryUserAddressModel = new AuxiliaryUserAddress();
            if (lstAuxiliaryUserAddress != null && lstAuxiliaryUserAddress.Count() > 0)
            {
                foreach (var auxiliaryUserAddress in lstAuxiliaryUserAddress)
                {
                    var address = await _addressRepository.FindAsync(x => x.Id == auxiliaryUserAddress.AddressId && x.Type == "Permanent");
                    if (address != null)
                    {
                        auxiliaryUserAddressModel = auxiliaryUserAddress;
                        addressModel = address;
                    }
                }
            }

            if (auxiliaryUserAddressModel.Id != 0)
            {
                if (addressModel.Id != 0)
                {
                    addressModel.Line1 = auxiliaryUserDto.Line1;
                    addressModel.Line2 = auxiliaryUserDto.Line2;
                    await GetAuxilaryUserCityCountryId(auxiliaryUserDto, addressModel);
                    addressModel.ZipCode = auxiliaryUserDto.ZipCode;
                    addressModel.Type = "Permanent";
                    addressModel = await _addressRepository.UpdateAsync(addressModel);
                }
                else
                {
                    //Address addressModel = new Address();
                    addressModel.Line1 = auxiliaryUserDto.Line1;
                    addressModel.Line2 = auxiliaryUserDto.Line2;
                    await GetAuxilaryUserCityCountryId(auxiliaryUserDto, addressModel);
                    addressModel.ZipCode = auxiliaryUserDto.ZipCode;
                    addressModel.Type = "Permanent";
                    addressModel = await _addressRepository.AddAsync(addressModel);

                    auxiliaryUserAddressModel.AddressId = addressModel.Id;

                    auxiliaryUserAddressModel = await _auxiliaryUserAddressRepository.UpdateAsync(auxiliaryUserAddressModel);
                }
            }
            else
            {
                AuxiliaryUserAddress auxiliaryUserAddress = new AuxiliaryUserAddress();
                auxiliaryUserAddress.AuxiliaryUserId = recruiterId;

                Address address = new Address();
                address.Line1 = auxiliaryUserDto.Line1;
                address.Line2 = auxiliaryUserDto.Line2;
                await GetAuxilaryUserCityCountryId(auxiliaryUserDto, addressModel);
                address.ZipCode = auxiliaryUserDto.ZipCode;
                address.Type = "Permanent";
                address = await _addressRepository.AddAsync(address);

                auxiliaryUserAddress.AddressId = address.Id;
                auxiliaryUserAddress = await _auxiliaryUserAddressRepository.AddAsync(auxiliaryUserAddress);
            }

            return auxiliaryUser;
        }


        private async Task<AuxiliaryRecruiterDto> ConvertToAuxiliaryRecruiterDto(AuxiliaryRecruiterDto auxiliaryRecruiterDto, AuxiliaryRecruiter auxiliaryRecruiter)
        {
            auxiliaryRecruiterDto.AuxiliaryId = auxiliaryRecruiter.AuxiliaryId;
            auxiliaryRecruiterDto.BusinessPhoneNumber = auxiliaryRecruiter.BusinessPhoneNumber;
            auxiliaryRecruiterDto.RecruiterTypeId = auxiliaryRecruiter.RecruiterTypeId;
            auxiliaryRecruiterDto.Name = auxiliaryRecruiter.Name;
            auxiliaryRecruiterDto.Email = auxiliaryRecruiter.Email;
            auxiliaryRecruiterDto.Mobile = auxiliaryRecruiter.Mobile;

            var lstAuxiliaryRecruiterAddress = await _auxiliaryUserAddressRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryRecruiterDto.AuxiliaryId);
            if (lstAuxiliaryRecruiterAddress != null && lstAuxiliaryRecruiterAddress.Count() > 0)
            {
                foreach (var auxiliaryRecruiterAddress in lstAuxiliaryRecruiterAddress)
                {
                    var address = await _addressRepository.FindAsync(x => x.Id == auxiliaryRecruiterAddress.AddressId && x.Type == "Buisness");
                    if (address != null)
                    {
                        auxiliaryRecruiterDto.Line1 = address.Line1;
                        auxiliaryRecruiterDto.Line2 = address.Line2;
                        auxiliaryRecruiterDto.CityId = address.CityId == 0 ? null : address.CityId;
                        auxiliaryRecruiterDto.CountryId = address.CountryId == 0 ? null : address.CountryId;
                        if (address.CityId != null)
                        {
                            var city = await _cityRepository.FindAsync(x => x.CityId == address.CityId);
                            auxiliaryRecruiterDto.CityName = city.CityDescription;
                            auxiliaryRecruiterDto.StateName = city.CityState;
                            auxiliaryRecruiterDto.StateCode = city.CityStateCode;
                        }

                        if (address.CountryId != null)
                        {
                            var country = await _countryRepository.FindAsync(x => x.Id == address.CountryId);
                            auxiliaryRecruiterDto.CountryName = country.Name;
                        }
                        auxiliaryRecruiterDto.ZipCode = address.ZipCode;
                        auxiliaryRecruiterDto.Type = address.Type;
                    }
                }
            }

            return auxiliaryRecruiterDto;
        }
        private async Task<AuxiliaryUserDto> ConvertToAuxiliaryUserDto(AuxiliaryUserDto auxiliaryUserDto, AuxiliaryUser auxiliaryUser)
        {
            auxiliaryUserDto.Id = auxiliaryUser.Id;
            auxiliaryUserDto.MobileCountryCode = auxiliaryUser.MobileCountryCode;
            auxiliaryUserDto.Mobile = auxiliaryUser.Mobile;
            auxiliaryUserDto.EmailId = auxiliaryUser.EmailId;
            auxiliaryUserDto.FullName = auxiliaryUser.FullName;
            auxiliaryUserDto.Verified = auxiliaryUser.Verified;
            auxiliaryUserDto.VerifiedBy = auxiliaryUser.VerifiedBy;
            auxiliaryUserDto.TypeId = auxiliaryUser.TypeId;
            auxiliaryUserDto.StatusId = auxiliaryUser.StatusId;
            auxiliaryUserDto.ParentAuxiliaryUserId = auxiliaryUser.ParentAuxiliaryUserId;
            auxiliaryUserDto.TermsConditionAccepted = auxiliaryUser.TermsConditionAccepted;
            auxiliaryUserDto.ProfileURL = auxiliaryUser.ProfileURL;
            auxiliaryUserDto.Onboarded = auxiliaryUser.Onboarded;

            auxiliaryUserDto.MobileCountryId = auxiliaryUser.MobileCountryId;

            if (auxiliaryUser.ParentAuxiliaryUserId != null)
            {
                var parentAuxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == auxiliaryUser.ParentAuxiliaryUserId);
                auxiliaryUserDto.RecruiterFullName = parentAuxiliaryUser != null ? parentAuxiliaryUser.FullName : "";
            }


            var lstAuxiliaryUserAddress = await _auxiliaryUserAddressRepository.FindAllAsync(x => x.AuxiliaryUserId == auxiliaryUser.Id);
            if (lstAuxiliaryUserAddress != null && lstAuxiliaryUserAddress.Count() > 0)
            {
                foreach (var auxiliaryUserAddress in lstAuxiliaryUserAddress)
                {
                    var address = await _addressRepository.FindAsync(x => x.Id == auxiliaryUserAddress.AddressId && x.Type == "Permanent");
                    if (address != null)
                    {
                        auxiliaryUserDto.Line1 = address.Line1;
                        auxiliaryUserDto.Line2 = address.Line2;

                        auxiliaryUserDto.CityId = address.CityId == 0 ? null : address.CityId;
                        auxiliaryUserDto.CountryId = address.CountryId == 0 ? null : address.CountryId;
                        if (address.CityId != null)
                        {
                            var city = await _cityRepository.FindAsync(x => x.CityId == address.CityId);
                            auxiliaryUserDto.CityName = city.CityDescription;
                            auxiliaryUserDto.StateName = city.CityState;
                            auxiliaryUserDto.StateCode = city.CityStateCode;
                        }

                        if (address.CountryId != null)
                        {
                            var country = await _countryRepository.FindAsync(x => x.Id == address.CountryId);
                            auxiliaryUserDto.CountryName = country.Name;
                        }

                        auxiliaryUserDto.ZipCode = address.ZipCode;
                        auxiliaryUserDto.Type = address.Type;
                    }
                }
            }

            return auxiliaryUserDto;
        }
        public async Task<AuxiliaryUserDto> CreateRecruiter(int userId, AuxiliaryUserDto auxiliaryUserDto)
        {
            AuxiliaryUser auxiliaryUser = new AuxiliaryUser();
            auxiliaryUser = await ConvertToAuxiliaryUserModel(userId, auxiliaryUser, auxiliaryUserDto);
            auxiliaryUser = await _auxiliaryUserRepository.AddAsync(auxiliaryUser);


            //store address
            Address address = new Address();
            //auxiliaryUserAddress = await ConvertToAuxiliaryUserAddress(auxiliaryUserDto);
            address.Line1 = auxiliaryUserDto.Line1;
            address.Line2 = auxiliaryUserDto.Line2;
            //address.CountryId = auxiliaryUserDto.CountryId;
            //address.CityId = auxiliaryUserDto.CityId;

            await GetAuxilaryUserCityCountryId(auxiliaryUserDto, address);

            address = await _addressRepository.AddAsync(address);

            AuxiliaryUserAddress auxiliaryUserAddress = new AuxiliaryUserAddress();
            auxiliaryUserAddress.AuxiliaryUserId = auxiliaryUser.Id;
            auxiliaryUserAddress.AddressId = address.Id;
            auxiliaryUserAddress = await _auxiliaryUserAddressRepository.AddAsync(auxiliaryUserAddress);


            AuxiliaryUserToken auxiliaryUserToken = new AuxiliaryUserToken();
            auxiliaryUserToken.AuxiliaryUserId = auxiliaryUser.Id;
            auxiliaryUserToken.Email = "Activated";
            auxiliaryUserToken.SMS = "Activated";
            auxiliaryUserToken = await _auxiliaryUserTokenRepository.AddAsync(auxiliaryUserToken);
            auxiliaryUser = await SaveAuxilaryUserAddress(auxiliaryUser.Id, auxiliaryUserDto, auxiliaryUser);
            auxiliaryUser = await _auxiliaryUserRepository.UpdateAsync(auxiliaryUser);
            auxiliaryUserDto = await ConvertToAuxiliaryUserDto(auxiliaryUserDto, auxiliaryUser);

            var auxiliaryUserRole = new AuxiliaryUserRole()
            {
                AuxiliaryUserId = auxiliaryUser.Id,
                RoleId = (int)AuxiliaryUserRoleEnum.Recruiter
            };

            auxiliaryUserRole = await _auxiliaryUserRoleRepository.AddAsync(auxiliaryUserRole);

            return auxiliaryUserDto;
        }

        public string RandomString(int length)
        {
            Random random = new Random();
            string pool = Guid.NewGuid().ToString();
            var chars = Enumerable.Range(0, length)
                .Select(x => pool[random.Next(0, pool.Length)]);

            var randomString = new string(chars.ToArray());
            return Regex.Replace(randomString, "[^0-9A-Za-z]+", string.Empty); 
        }
        private async Task<AuxiliaryUser> ConvertToAuxiliaryUserModel(int userId, AuxiliaryUser auxiliaryUser, AuxiliaryUserDto auxiliaryUserDto)
        {
            auxiliaryUser.FullName = auxiliaryUserDto.FullName;
            auxiliaryUser.EmailId = auxiliaryUserDto.EmailId;
            auxiliaryUser.Password = auxiliaryUserDto.Password;
            auxiliaryUser.CreatedBy = userId;
            auxiliaryUser.CreatedOn = DateTime.UtcNow;
            auxiliaryUser.Verified = true;
            auxiliaryUser.VerifiedBy = userId;
            auxiliaryUser.VerifiedOn = DateTime.UtcNow;
            auxiliaryUser.TypeId = (int)LoginEnum.LoginUserType.Recruiter;
            auxiliaryUser.StatusId = (int)StatusEnum.Verified;
            auxiliaryUser.ParentAuxiliaryUserId = auxiliaryUserDto.ParentAuxiliaryUserId;
            auxiliaryUser.TermsConditionAccepted = auxiliaryUserDto.TermsConditionAccepted;
            auxiliaryUser.Mobile = auxiliaryUserDto.Mobile;
            auxiliaryUser.MobileCountryCode = auxiliaryUserDto.MobileCountryCode;
            auxiliaryUser.ProfileURL = auxiliaryUserDto.ProfileURL;
            auxiliaryUser.AuthToken = Guid.NewGuid().ToString();
            auxiliaryUser.MobileCountryId = auxiliaryUserDto.MobileCountryId;
            return auxiliaryUser;
        }
    }
}
