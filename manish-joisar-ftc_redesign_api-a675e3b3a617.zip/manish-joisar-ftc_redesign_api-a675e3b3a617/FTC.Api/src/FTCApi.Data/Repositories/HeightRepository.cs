﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class HeightRepository:GenericRepository<Height>, IHeightRepository
    {
        public HeightRepository(FTCDbContext context):base(context)
        {
                
        }
    }
}
