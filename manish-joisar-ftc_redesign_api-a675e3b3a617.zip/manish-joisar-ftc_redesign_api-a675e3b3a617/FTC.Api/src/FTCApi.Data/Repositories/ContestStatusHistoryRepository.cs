﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class ContestStatusHistoryRepository:GenericRepository<ContestStatusHistory>, IContestStatusHistoryRepository
    {
        public ContestStatusHistoryRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
