﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class RecruiterTypeRepository:GenericRepository<RecruiterType>, IRecruiterTypeRepository
    {
        public RecruiterTypeRepository(FTCDbContext context):base(context)
        {

        }
    }
}
