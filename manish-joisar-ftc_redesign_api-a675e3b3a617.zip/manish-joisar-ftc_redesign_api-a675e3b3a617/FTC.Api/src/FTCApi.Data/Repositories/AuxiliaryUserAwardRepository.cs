﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserAwardRepository:GenericRepository<AuxiliaryUserAward>, IAuxiliaryUserAwardRepository
    {
        public AuxiliaryUserAwardRepository(FTCDbContext context):base(context)
        {

        }
    }
}
