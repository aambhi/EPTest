﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliarySecurityQuestionRepository:GenericRepository<AuxiliarySecurityQuestion>, IAuxiliarySecurityQuestionRepository
    {
        public AuxiliarySecurityQuestionRepository(FTCDbContext context):base(context)
        {

        }
    }
}
