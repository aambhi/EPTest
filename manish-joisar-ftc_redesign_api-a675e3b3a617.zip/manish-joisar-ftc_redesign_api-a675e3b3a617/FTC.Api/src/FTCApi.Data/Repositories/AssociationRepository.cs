﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AssociationRepository:GenericRepository<Association>, IAssociationRepository
    {
        public AssociationRepository(FTCDbContext context): base(context)
        {

        }
    }
}
