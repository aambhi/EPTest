﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class BodyTypeRepository:GenericRepository<BodyType>, IBodyTypeRepository
    {
        public BodyTypeRepository(FTCDbContext context): base(context)
        {

        }
    }
}
