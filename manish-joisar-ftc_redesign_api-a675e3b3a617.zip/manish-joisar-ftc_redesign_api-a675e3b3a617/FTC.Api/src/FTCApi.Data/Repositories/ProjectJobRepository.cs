﻿using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Data.Extensions;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobRepository : GenericRepository<ProjectJob>, IProjectJobRepository
    {
        private IProjectRepository _projectRepository;

        public ProjectJobRepository(FTCDbContext context, IProjectRepository projectRepository) : base(context)
        {
            _projectRepository = projectRepository;
        }

        /// <summary>
        /// Search // All-applied-matching jobs
        /// </summary>
        public async Task<SearchResult<ProjectJob>> Search(SearchParameters searchParams, int jobSearchType, int talentUserId)
        {
            if (searchParams == null)
            {
                throw new ArgumentNullException("searchParams");
            }

            searchParams.SetDefaultsForUnsetProperties();
            IQueryable<ProjectJob> query = _context.Set<ProjectJob>().Where(x => x.StatusId == (int)StatusEnum.Active);

            #region //jobType(All-applied-matching jobs) // filter search conditions(interest & Advance filter)
            query = GetJobsByType(query, jobSearchType, talentUserId);
            query = JobFilters(query, searchParams, talentUserId);
            #endregion

            #region // common search conditions on model property
            if (searchParams.SearchFor.ContainsKey("sortType"))
            {
                var searchTerm = Convert.ToString(searchParams.SearchFor["sortType"]);
                if (searchTerm == "Popular")
                    query = query.Where(x => _context.TalentJob
                                                    .Where(tj => tj.JobId == x.Id).Select(tj => tj.JobId).Contains(x.Id))
                                                    .OrderByDescending(o => _context.TalentJob.Where(tj => tj.JobId == o.Id).Select(tj => tj.JobId).Contains(o.Id))
                                                    .ThenByDescending(x => x.CreatedOn);
                else if (searchTerm == "Featured")
                    query = query.Where(x => x.IsFeaturedJob == true).OrderByDescending(x => x.CreatedOn);
                else //if (searchTerm == "Latest")
                    query = query.OrderByDescending(x => x.CreatedOn);
            }
            #endregion

            var projectJobs = query.ApplySorting(searchParams.SortOn, searchParams.SortOrder).ApplyPaging(searchParams.PageIndex, searchParams.PageSize);
            projectJobs = projectJobs.Include(project => project.Project).ThenInclude(auxuser => auxuser.AuxiliaryUser)
                                .Include(jobLoc => jobLoc.ProjectJobLocation).ThenInclude(city => city.City)
                                .Include(talentjob => talentjob.TalentJob).ThenInclude(s => s.Status);

            var recordCount = query.Count();
            var previousPageIndex = searchParams.PageIndex - 1;
            var nextPageIndex = ((recordCount - (searchParams.PageSize * searchParams.PageIndex)) > searchParams.PageSize) ? (searchParams.PageIndex + 1) : 0;

            return new SearchResult<ProjectJob>
            {
                Results = projectJobs,
                TotalResults = recordCount,
                Previous = previousPageIndex,
                Next = nextPageIndex
            };
        }

        /// <summary>
        /// jobType // All-applied-matching jobs
        /// </summary>
        public IQueryable<ProjectJob> GetJobsByType(IQueryable<ProjectJob> query, int jobSearchType, int talentUserId)
        {
            var talentJobs = _context.TalentJob.Where(x => x.TalentId == talentUserId);
            if (jobSearchType == (int)JobSearchType.All)
            {
                //query = query.Where(projectJob => !talentJobs.Any(tj => tj.JobId == projectJob.Id) && (projectJob.EndDate >= DateTime.UtcNow.Date && projectJob.StatusId != (int)StatusEnum.Close));
                query = query.Where(projectJob => (projectJob.EndDate >= DateTime.UtcNow.Date && projectJob.StatusId != (int)StatusEnum.Close));
            }
            else if (jobSearchType == (int)JobSearchType.Applied)
            {
                query = query.Where(projectJob => talentJobs.Any(tj => tj.JobId == projectJob.Id));
            }
            else if (jobSearchType == (int)JobSearchType.Matching)
            {
                var talent = _context.Talent.Where(x => x.Id == talentUserId).FirstOrDefault();
                if (talent != null)
                {
                    DateTime DOB = talent.DOB ?? DateTime.Now;
                    var today = DateTime.Today;
                    var age = today.Year - DOB.Year;
                    if (DOB > today.AddYears(-age)) age--;      // Go back to the year the person was born in case of a leap year

                    var height = _context.Height;
                    var weight = _context.Weight;
                    var chestSize = _context.ChestSize;
                    var waistSize = _context.WaistSize;
                    var talentPhysicalAttribute = _context.TalentPhysicalAttribute.Where(x => x.TalentId == talentUserId).FirstOrDefault();
                    var talentChestSizeInInches = (talentPhysicalAttribute != null && talentPhysicalAttribute.ChestSizeId != null) ? chestSize.Where(cs => cs.Id == talentPhysicalAttribute.ChestSizeId).Select(cs => cs.Inches).FirstOrDefault() : 0;
                    var talentWaistSizeInInches = (talentPhysicalAttribute != null && talentPhysicalAttribute.WaistId != null) ? waistSize.Where(ws => ws.Id == talentPhysicalAttribute.WaistId).Select(ws => ws.Inches).FirstOrDefault() : 0;
                    var talentHeightInInches = (talentPhysicalAttribute != null && talentPhysicalAttribute.HeightId != null) ? height.Where(h => h.Id == talentPhysicalAttribute.HeightId).Select(h => (float)h.Inches).FirstOrDefault() : 0;
                    var talentWeightInKgs = (talentPhysicalAttribute != null && talentPhysicalAttribute.WeightSizeId != null) ? weight.Where(w => w.Id == talentPhysicalAttribute.WeightSizeId).Select(w => (int)w.Kgs).FirstOrDefault() : 0;
                    var talentPhysicalAttribute_HairLengthId = (talentPhysicalAttribute != null && talentPhysicalAttribute.HairLengthId != null) ? (int)talentPhysicalAttribute.HairLengthId : 0;
                    var talentPhysicalAttribute_BodyTypeId = (talentPhysicalAttribute != null && talentPhysicalAttribute.BodyTypeId != null) ? (int)talentPhysicalAttribute.BodyTypeId : 0;
                    var talentPhysicalAttribute_SkinColorId = (talentPhysicalAttribute != null && talentPhysicalAttribute.SkinColorId != null) ? (int)talentPhysicalAttribute.SkinColorId : 0;
                    var talentPhysicalAttribute_EyecolorId = (talentPhysicalAttribute != null && talentPhysicalAttribute.EyeColorId != null) ? (int)talentPhysicalAttribute.EyeColorId : 0;
                    var isTalentExperienced = _context.TalentExperience.Where(talExp => talExp.TalentId == talent.Id && talExp.InterestCategoryId != null & talExp.TalentCategoryId != null).FirstOrDefault() != null ? true : false;
                    var talentHoldingPassport = talent.PassportCountryId != null ? true : false;

                    #region matching job conditions
                    //var talentMatchingJobs = _context.TalentJob.Where(x => x.TalentId == talentUserId).Select(x => (int)x.JobId).Distinct().ToList();
                    //query = query.Where(projectJob => !talentMatchingJobs.Contains(projectJob.Id) && (projectJob.EndDate >= DateTime.UtcNow.Date && projectJob.StatusId != (int)StatusEnum.Close));
                    query = query.Where(projectJob => (projectJob.EndDate >= DateTime.UtcNow.Date && projectJob.StatusId != (int)StatusEnum.Close));
                    query = query.Where(x => (age > 0) ? x.Gender == talent.Gender && (age >= x.MinAge && age <= x.MaxAge) : false);

                    var talentTalentCategoryIds = _context.Set<TalentTalentCategory>().Where(ttc => ttc.TalentId == talent.Id).Select(ttc => ttc.TalentCategoryId).ToList();
                    query = query.Where(x => x.TalentCategoryId != null ? talentTalentCategoryIds.Contains((int)x.TalentCategoryId) : true);

                    var talentInterestCategoryIds = _context.Set<TalentInterestCategory>().Where(tic => tic.TalentId == talent.Id).Select(tic => tic.InterestCategoryId).ToList();
                    var lstProject = _context.Project.Where(p => p.InterestId != null).Select(p => new { Id = p.Id, InterestId = p.InterestId }).Distinct().ToList();
                    query = query.Where(x => lstProject.Select(p => p.Id).Contains(x.ProjectId) == true ?
                                             talentInterestCategoryIds.Contains((int)lstProject.Where(p => p.Id == x.ProjectId).Select(p => p.InterestId).FirstOrDefault()) : true);

                    var lstProjectJobLocation = _context.ProjectJobLocation.Where(jloc => jloc.JobId != null).Select(jloc => new { JobId = jloc.JobId, CityId = jloc.CityId }).ToList();
                    var lstTalentAddressIds = _context.TalentAddress.Where(talAdd => talAdd.TalentId == talent.Id).Select(talAdd => _context.Address.Where(add => add.Id == talAdd.AddressId).Select(add => (int)add.CityId).FirstOrDefault());
                    query = query.Where(x => lstProjectJobLocation.Select(jloc => jloc.JobId).Distinct().Contains(x.Id) == true ?
                                            lstProjectJobLocation.Where(jloc => jloc.JobId == x.Id).All(jloc => lstTalentAddressIds.Contains((int)jloc.CityId)) : true);

                    var lstProjectJobLanguage = _context.ProjectJobLanguage.Where(jlang => jlang.JobId != null).Select(jlang => new { JobId = jlang.JobId, LanguageId = jlang.LanguageId }).ToList();
                    var lstTalentLanguageIds = _context.TalentLanguage.Where(talLang => talLang.TalentId == talent.Id).Select(talLang => talLang.LanguageId).Distinct().ToList();
                    query = query.Where(x => lstProjectJobLanguage.Select(jlang => jlang.JobId).Distinct().Contains(x.Id) == true ?
                                            lstProjectJobLanguage.Where(jlang => jlang.JobId == x.Id)
                                                                        .All(jlang => lstTalentLanguageIds.Contains((int)jlang.LanguageId)) : true);

                    var lstProjectJobEthnicity = _context.ProjectJobEthnicity.Where(jEth => jEth.JobId != null).Select(jEth => new { jEth.JobId, EthnicityId = jEth.EthnicityId }).ToList();
                    var lstTalentEthnicityIds = _context.TalentEthnicity.Where(talEth => talEth.TalentId == talent.Id).Select(talEth => talEth.Ethnicity).Distinct().ToList();
                    query = query.Where(x => lstProjectJobEthnicity.Select(jEth => jEth.JobId).Distinct().Contains(x.Id) == true ?
                                            lstProjectJobEthnicity.Where(jEth => jEth.JobId == x.Id)
                                                                .All(jEth => lstTalentEthnicityIds.Contains((int)jEth.EthnicityId)) : true);

                    var lstProjectJobTag = _context.ProjectJobTag.Where(jTag => jTag.JobId != null).Select(jTag => new { JobId = jTag.JobId, TagId = jTag.TagId }).ToList();
                    var lstTalentTagIds = _context.TalentTag.Where(talTag => talTag.TalentId == talent.Id).Select(talTag => talTag.TagId).Distinct().ToList();
                    query = query.Where(x => lstProjectJobTag.Select(jTag => jTag.JobId).Distinct().Contains(x.Id) == true ?
                                            lstProjectJobTag.Where(jTag => jTag.JobId == x.Id)
                                                            .All(jTag => lstTalentTagIds.Contains((int)jTag.TagId)) : true);

                    var lstProjectJobBodytype = _context.ProjectJobBodytype.Where(bt => bt.JobId != null).Select(bt => new { JobId = bt.JobId, BodytypeId = bt.BodytypeId }).ToList();
                    query = query.Where(x => lstProjectJobBodytype.Select(bt => bt.JobId).Distinct().Contains(x.Id) == true ? lstProjectJobBodytype.Where(bt => bt.JobId == x.Id).Select(bt => bt.BodytypeId).Contains(talentPhysicalAttribute_BodyTypeId) : true);

                    var lstProjectJobSkinColor = _context.ProjectJobSkinColor.Where(sc => sc.JobId != null).Select(sc => new { JobId = sc.JobId, SkinColorId = sc.SkinColorId }).ToList();
                    query = query.Where(x => lstProjectJobSkinColor.Select(sc => sc.JobId).Distinct().Contains(x.Id) == true ? lstProjectJobSkinColor.Where(sc => sc.JobId == x.Id).Select(sc => sc.SkinColorId).Contains(talentPhysicalAttribute_SkinColorId) : true);

                    var lstProjectJobEyeColor = _context.ProjectJobEyeColor.Where(jec => jec.JobId != null).Select(ec => new { JobId = ec.JobId, EyecolorId = ec.EyecolorId }).ToList();
                    query = query.Where(x => lstProjectJobEyeColor.Select(jec => jec.JobId).Distinct().Contains(x.Id) == true ? lstProjectJobEyeColor.Where(ec => ec.JobId == x.Id).Select(ec => ec.EyecolorId).Contains(talentPhysicalAttribute_EyecolorId) : true);

                    query = query.Where(x => x.ExperienceRequired == true ? isTalentExperienced : true);
                    query = query.Where(x => x.PassportRequired == true ? talentHoldingPassport : true);
                    query = query.Where(hair => hair.HairLengthId != null ? hair.HairLengthId == talentPhysicalAttribute_HairLengthId : true);

                    query = query.Where(jobHeight => (jobHeight.MinHeightId != null && jobHeight.MaxHeightId != null) ?
                                                    (talentHeightInInches >= height.Where(h => h.Id == jobHeight.MinHeightId).Select(h => h.Inches).FirstOrDefault() &&
                                                    talentHeightInInches <= height.Where(h => h.Id == jobHeight.MaxHeightId).Select(h => h.Inches).FirstOrDefault()) : true);

                    query = query.Where(jobWeight => (jobWeight.MinWeightId != null && jobWeight.MaxWeightId != null) ?
                                                    (talentWeightInKgs >= weight.Where(w => w.Id == jobWeight.MinWeightId).Select(w => w.Kgs).FirstOrDefault() &&
                                                    talentWeightInKgs <= weight.Where(w => w.Id == jobWeight.MaxWeightId).Select(w => w.Kgs).FirstOrDefault()) : true);

                    query = query.Where(jobChestsize => (jobChestsize.MinChestSizeId != null && jobChestsize.MaxChestSizeId != null) ?
                                                        (talentChestSizeInInches >= chestSize.Where(cs => cs.Id == jobChestsize.MinChestSizeId).Select(cs => cs.Inches).FirstOrDefault() &&
                                                        talentChestSizeInInches <= chestSize.Where(cs => cs.Id == jobChestsize.MaxChestSizeId).Select(cs => cs.Inches).FirstOrDefault()) : true);

                    query = query.Where(jobWaistsize => (jobWaistsize.MinWaistSizeId != null && jobWaistsize.MaxWaistSizeId != null) ?
                                                        (talentWaistSizeInInches >= waistSize.Where(ws => ws.Id == jobWaistsize.MinWaistSizeId).Select(ws => ws.Inches).FirstOrDefault() &&
                                                        talentWaistSizeInInches <= waistSize.Where(ws => ws.Id == jobWaistsize.MaxWaistSizeId).Select(ws => ws.Inches).FirstOrDefault()) : true);

                    var sideProfile = new string[] { LoginEnum.FlagType.OnBoardingLeftSide.ToString(), LoginEnum.FlagType.OnBoardingRightSide.ToString() };
                    var flags = new List<string>();
                    foreach (var profile in sideProfile)
                    {
                        var flag = (int)Enum.Parse(typeof(LoginEnum.FlagType), profile);
                        flags.Add(flag.ToString());
                    }
                    query = query.Where(x => x.SideprofileRequired == true ? _context.TalentMedia
                                                                                    .Where(tm => tm.TalentId == talent.Id && flags.Contains(tm.Flag))
                                                                                    .Select(tm => (int)tm.TalentId)
                                                                                    .Distinct().Contains(talent.Id) : true);

                    query = query.Where(x => x.HeadshotRequired == true ? _context.TalentMedia
                                                                                    .Where(tm => tm.TalentId == talent.Id && tm.Flag == Enum.Parse(typeof(LoginEnum.FlagType), "OnBoardingHeadShot").ToString())
                                                                                    .Select(tm => (int)tm.TalentId)
                                                                                    .Distinct().Contains(talent.Id) : true);

                    query = query.Where(x => x.IntrovideoRequired == true ? _context.TalentMedia
                                                                                    .Where(tm => tm.TalentId == talent.Id && tm.Flag == Enum.Parse(typeof(LoginEnum.FlagType), "OnBoardingVideo").ToString())
                                                                                    .Select(tm => (int)tm.TalentId)
                                                                                    .Distinct().Contains(talent.Id) : true);

                    query = query.Where(x => x.AssociationRequired == true ? _context.TalentAssociation.Select(ta => (int)ta.TalentId).Distinct().Contains(talent.Id) : true);
                    #endregion
                }
            }
            return query;
        }

        /// <summary>
        /// TODO: This is temporary till we get the filter DS sorted out. Make filters immutable
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<string>> ToFilterDictionary(List<Dictionary<string, string>> searchFilterOld)
        {
            var filters = new Dictionary<string, List<string>>();
            foreach (var item in searchFilterOld)
            {
                var key = item.Keys.First();
                filters.Add(key, item.Values.First().Split(',').ToList());
            }

            return filters;
        }

        /// <summary>
        /// filter search conditions // interest & Advance filter
        /// </summary>
        public IQueryable<ProjectJob> JobFilters(IQueryable<ProjectJob> query, SearchParameters searchParams, int talentUserId)
        {
            if (searchParams.AdvanceFilter.Any() || searchParams.InterestFilter.Any())
            {
                var filters = ToFilterDictionary(searchParams.AdvanceFilter);
                foreach (var filter in filters)
                {
                    #region advance filter logic
                    switch (filter.Key)
                    {
                        case ("jobStatus"):
                            var jobStatusIds = filter.Value.Select(int.Parse).ToList();

                            if (jobStatusIds.Contains((int)ProjectJobStatusEnum.NotSelected))
                            {
                                query = query.Where(x => (_context.TalentJob
                                                    .Where(tj => tj.TalentId == talentUserId && (jobStatusIds.Contains(tj.StatusId) || tj.NotSelected == true))
                                                    .Select(tj => tj.JobId)
                                                    .Distinct()
                                                    .Contains(x.Id) &&
                                                    x.EndDate >= DateTime.UtcNow.Date));
                            }
                            else
                            {
                                query = query.Where(x => (_context.TalentJob
                                                    .Where(tj => tj.TalentId == talentUserId && jobStatusIds.Contains(tj.StatusId) && tj.NotSelected == false)
                                                    .Select(tj => tj.JobId)
                                                    .Distinct()
                                                    .Contains(x.Id) &&
                                                    x.EndDate >= DateTime.UtcNow.Date));
                            }
                            break;

                        case ("talentCategory"):
                            var talentCategoryIds = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(x => talentCategoryIds.Contains((int)x.TalentCategoryId));
                            break;

                        case ("recruiter"):
                            var recruiterIds = filter.Value.Select(int.Parse).ToList();

                            var lstProjectId = _context.Project.Where(x => recruiterIds.Contains(x.AuxiliaryUserId))
                                                               .Select(x => x.Id)
                                                               .ToList();

                            query = query.Where(x => lstProjectId.Contains(x.ProjectId));
                            break;

                        case ("project"):
                            var projectIds = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(x => projectIds.Contains(x.ProjectId));
                            break;

                        case ("jobLocation"):
                            var cityIds = filter.Value.Select(int.Parse).Select(val => (int?)val).ToList();

                            var lstProjectJobLocationId = _context.ProjectJobLocation.Where(x => cityIds.Contains(x.CityId))
                                                                                     .Select(x => (int)x.JobId)
                                                                                     .ToList();

                            query = query.Where(x => lstProjectJobLocationId.Contains(x.Id));

                            break;

                        case ("gender"):
                            query = query.Where(x => filter.Value.Contains(x.Gender));
                            break;

                        case ("age"):
                            var ageRange = filter.Value.First().Split('-').ToList();
                            var minAge = int.Parse(ageRange[0]);
                            var maxAge = int.Parse(ageRange[1]);
                            query = query.Where(x => !((minAge < x.MinAge && maxAge < x.MinAge) || (minAge > x.MaxAge && maxAge > x.MaxAge)));
                            break;

                        case ("interestCategory"):
                            //var interestCategoryIds = filter.Value.Select(int.Parse).Select(val => (int?)val).ToList();
                            var interestCategoryIds = filter.Value.Select(int.Parse).ToList();

                            query = query.Where(x => _context.Project
                                                            .Where(p => p.Id == x.ProjectId && interestCategoryIds.Contains((int)p.InterestId))
                                                            .Select(p => p.Id)
                                                            .Distinct()
                                                            .Contains(x.ProjectId));
                            break;

                        case ("searchText"):
                            query = query.Where(x => x.Title.ToLower().Contains(filter.Value.First().ToLower()) ||
                                                    _context.Project
                                                            .Where(p => p.Id == x.ProjectId)
                                                            .Select(p => p.Name.ToLower())
                                                            .Contains(filter.Value.First().ToLower()));
                            break;

                        case ("sortType"):
                            if (filter.Value.First() == "Popular")
                            {
                                var talentJob = _context.TalentJob.Select(x => (int)x.JobId).Distinct().ToList();

                                query = query.Where(x => talentJob.Contains(x.Id))
                                            .OrderByDescending(o => talentJob.Count(tj => tj == o.Id))
                                            .ThenByDescending(x => x.CreatedOn);
                            }
                            else if (filter.Value.First() == "Featured")
                                query = query.Where(x => x.IsFeaturedJob == true).OrderByDescending(x => x.CreatedOn);
                            else if (filter.Value.First() == "Latest")
                                query = query.OrderByDescending(x => x.CreatedOn);
                            else if (filter.Value.First() == "Invited")
                                query = query.Where(x => _context.JobTalentRecommended
                                                                .Where(jtr => jtr.TalentId == talentUserId && jtr.Invited == true)
                                                                .Select(jtr => jtr.JobId)
                                                                .Distinct()
                                                                .Contains(x.Id))
                                                .OrderByDescending(x => x.CreatedOn);
                            break;
                    }
                    #endregion
                }
            }
            return query.OrderByDescending(j => j.CreatedOn);
        }

        public async Task<ProjectJob> GetJobById(int Id, int talentId)
        {
            IQueryable<ProjectJob> query = _context.Set<ProjectJob>().Where(x => x.Id == Id);

            var projectJob = await query.Include(project => project.Project).ThenInclude(auxuser => auxuser.AuxiliaryUser).ThenInclude(rec => rec.AuxiliaryRecruiter)
                                        .Include(project => project.Project).ThenInclude(intr => intr.Interest)
                                        .Include(project => project.JobTalentCategory)
                                        .Include(intrestCat => intrestCat.InterestCategory)
                                        .Include(jobLoc => jobLoc.ProjectJobLocation).ThenInclude(city => city.City)
                                        .Include(lang => lang.ProjectJobLanguage).ThenInclude(l => l.Language)
                                        .Include(tag => tag.ProjectJobTag).ThenInclude(t => t.Tag)
                                        .Include(skin => skin.ProjectJobSkinColor).ThenInclude(s => s.SkinColor)
                                        .Include(eye => eye.ProjectJobEyecolor).ThenInclude(e => e.EyeColor)
                                        .Include(hairc => hairc.ProjectJobHairColor).ThenInclude(h => h.HairColor)
                                        .Include(bodyType => bodyType.ProjectJobBodytype).ThenInclude(b => b.BodyType)
                                        .Include(ethnicities => ethnicities.ProjectJobEthnicity).ThenInclude(e => e.Ethnicity)
                                        .Include(subTalent => subTalent.ProjectJobSubTalent).ThenInclude(e => e.TalentCategory)
                                        .Include(hairt => hairt.HairType)
                                        .Include(hairl => hairl.HairLength)
                                        .Include(minchest => minchest.MinChestSize).Include(maxchest => maxchest.MaxChestSize)
                                        .Include(minwaist => minwaist.MinWaistSize).Include(maxwaist => maxwaist.MaxWaistSize)
                                        .Include(minh => minh.MinHeight).Include(maxh => maxh.MaxHeight)
                                        .Include(minw => minw.MinWeight).Include(maxw => maxw.MaxWeight)
                                        .Include(jobstatus => jobstatus.Status)
                                        .Include(talj => talj.TalentJob).ThenInclude(s => s.Status)
                                        .FirstOrDefaultAsync();

            return projectJob;
        }

        public async Task<int> GetJobCountByCondition(int talentId, int conditionType)
        {
            IQueryable<ProjectJob> query = _context.Set<ProjectJob>().Where(x => (x.StatusId ?? 0) == (int)StatusEnum.Active);
            #region //jobType // All-applied-matching jobs
            try
            {
                query = GetJobsByType(query, conditionType, talentId);
                var count = query.Count();
                return count;
            }
            catch (Exception ex)
            {
                return 0;
            }
            #endregion
        }

        public async Task<bool> PushFtcRecommendedTalents(int projectId, int jobId, int userId)
        {
            var publishedJobs = await _context.Set<JobTalentRecommended>().Where(x => x.JobId == jobId && x.SortOrderTypeId == 2).ToListAsync();
            if (publishedJobs != null && publishedJobs.Count <= 0)
            {
                int interestCategoryId = 0, talentCategoryId = 0, recommendedCount = 0;
                var project = _context.Set<Project>().Include(p => p.Plan).Where(x => x.Id == projectId).FirstOrDefault();
                if (project != null)
                {
                    interestCategoryId = project.InterestId ?? 0;
                    recommendedCount = project.Plan.RecommendedCount ?? 0;
                }
                var job = _context.Set<ProjectJob>().Where(x => x.Id == jobId).FirstOrDefault();
                if (job != null)
                {
                    talentCategoryId = job.TalentCategoryId ?? 0;
                    recommendedCount = (job.NumberOfRole ?? 0) * recommendedCount;
                }

                IQueryable<TalentRatingRmark> queryTalentRatingRmark = _context.Set<TalentRatingRmark>();

                //we are filtering the talents based on the interest category,talentCategory,Gender,min and maxAge,isprofilePrivate and status of talents
                var recommendedTalents = await queryTalentRatingRmark.Include(t => t.Talent).ThenInclude(t => t.TalentRatingRmark)
                    .Include(t => t.Talent).ThenInclude(t => t.TalentRatingInterestCategory)
                    .Where(x => x.InterestCategoryId == interestCategoryId && x.TalentCategoryId == talentCategoryId &&
                           (x.Talent.Gender != null && x.Talent.Gender == job.Gender) && (x.Talent.DOB != null && CalculateAge(x.Talent.DOB.Value) >= job.MinAge) &&
                           (x.Talent.DOB != null && CalculateAge(x.Talent.DOB.Value) <= job.MaxAge) && x.Talent.IsProfilePrivate == false && x.Talent.StatusId == (int)StatusEnum.Active).ToListAsync();

                //order the recommendedTalents based on stackRanking interest ranking and UID
                var sortedRecommendedTalents = recommendedTalents.Select(x => new
                {
                    TalentId = x.TalentId,
                    JobId = jobId,
                    Order = 10,
                    Invited = false,
                    SortOrderTypeId = 2,
                    UID = (int)x.Talent.UID,
                    Rating = x.Talent.OverallRating,
                    Interest = x.Talent.TalentRatingInterestCategory.Where(p => p.TalentId == p.TalentId && p.InterestCategoryId == interestCategoryId).Select(p => p.Rating).FirstOrDefault(),
                }).Distinct().OrderByDescending(o => o.Rating)
                                .ThenByDescending(o => o.Interest)
                                .ThenBy(o => o.UID)
                                .Take(recommendedCount)
                                .ToList();

                List<JobTalentRecommended> recommendedJobTalents = new List<JobTalentRecommended>();
                foreach (var recommendedTalent in sortedRecommendedTalents)
                {
                    JobTalentRecommended talent = new JobTalentRecommended()
                    {
                        JobId = jobId,
                        TalentId = recommendedTalent.TalentId,
                        Order = 10,
                        Invited = false,
                        SortOrderTypeId = 2,
                        CreatedBy = userId,
                        CreatedOn = DateTime.UtcNow
                    };
                    recommendedJobTalents.Add(talent);
                }
                _context.Set<JobTalentRecommended>().AddRange(recommendedJobTalents);
                await _context.SaveChangesAsync();
            }
            return true;
        }

        private int CalculateAge(DateTime dateOfBirth)
        {
            var years = DateTime.Now.Year - dateOfBirth.Year;
            //get the date of the birthday this year
            var birthdayThisYear = dateOfBirth.AddYears(years);
            //if the birthday hasn't passed yet this year we need years - 1
            return birthdayThisYear > DateTime.Now ? years - 1 : years;
        }

        private float? GetHeightInInches(int? heightId)
        {
            return ((heightId.HasValue) ? _context.Height.Where(h => h.Id == heightId).Select(h => h.Inches).FirstOrDefault() : 0);
        }

        private float? GetWeightInKgs(int? weightId)
        {
            return ((weightId.HasValue) ? _context.Weight.Where(w => w.Id == weightId).Select(w => w.Kgs).FirstOrDefault() : 0);
        }

        private double GetChestSizeInInches(int? chestSizeId)
        {
            return ((chestSizeId.HasValue) ? _context.ChestSize.Where(c => c.Id == chestSizeId).Select(c => c.Inches).FirstOrDefault() : 0);
        }

        private double GetWaistInInches(int? waistId)
        {
            return ((waistId.HasValue) ? _context.WaistSize.Where(w => w.Id == waistId).Select(w => w.Inches).FirstOrDefault() : 0);
        }

        public async Task<List<ProjectJob>> GetAllJobs(int userId)
        {
            var projectsId = _context.Set<Project>().Where(x => x.AuxiliaryUserId == userId).Select(x => x.Id);
            return await _context.Set<ProjectJob>().Where(x => projectsId.Contains(x.ProjectId))
                .Include(x => x.Project)
                .ToListAsync();
        }

    }
}