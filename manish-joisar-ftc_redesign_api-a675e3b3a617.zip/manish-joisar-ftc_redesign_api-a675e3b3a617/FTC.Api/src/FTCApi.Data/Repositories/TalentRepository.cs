﻿using FTCApi.Core.Models;
using FTCApi.Core.Models.Report;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Data.Extensions;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class TalentRepository : GenericRepository<Talent>, ITalentRepository
    {
        #region Private Variables
        private ITalentRatingParameterRepository _talentRatingParameterRepository;
        private ITalentRatingInterestCategoryRepository _talentRatingInterestCategoryRepository;
        private ITalentRatingTalentCategoryRepository _talentRatingTalentCategoryRepository;
        private ITalentRatingRmarksRepository _talentRatingRmarksRepository;
        private ITalentPhysicalAttributeRepository _talentPhysicalAttributeRepository;
        private ITalentStatusHistoryRepository _talentStatusHistoryRepository;

        #endregion

        #region Constructor
        public TalentRepository(FTCDbContext context,
                                        ITalentRatingParameterRepository talentRatingParameterRepository,
                                        ITalentRatingInterestCategoryRepository talentRatingInterestCategoryRepository,
                                        ITalentRatingTalentCategoryRepository talentRatingTalentCategoryRepository,
                                        ITalentRatingRmarksRepository talentRatingRmarksRepository, ITalentPhysicalAttributeRepository talentPhysicalAttributeRepository,
                                        ITalentStatusHistoryRepository talentStatusHistoryRepository) : base(context)
        {
            _talentRatingParameterRepository = talentRatingParameterRepository;
            _talentRatingInterestCategoryRepository = talentRatingInterestCategoryRepository;
            _talentRatingTalentCategoryRepository = talentRatingTalentCategoryRepository;
            _talentRatingRmarksRepository = talentRatingRmarksRepository;
            _talentPhysicalAttributeRepository = talentPhysicalAttributeRepository;
            _talentStatusHistoryRepository = talentStatusHistoryRepository;

        }
        #endregion

        /// <summary>
        /// Get and Search Talents on conditions
        /// </summary>
        /// <param name="searchParams">todo: describe searchParams parameter on Search</param>
        /// <param name="ConditionType">todo: describe ConditionType parameter on Search</param>
        /// <param name="userId">todo: describe userId parameter on Search</param>
        public async Task<SearchResult<Talent>> Search(SearchParameters searchParams, string ConditionType, int userId)
        {
            //Note: any changes in this method needs to update in Export talent report
            if (searchParams == null)
            {
                throw new ArgumentNullException("searchParams");
            }

            searchParams.SetDefaultsForUnsetProperties();
            IQueryable<Talent> query = _context.Set<Talent>();

            query = query.Include(ta => ta.TalentAddress).ThenInclude(ad => ad.Address).ThenInclude(c => c.City).Include(rm => rm.TalentRatingRmark).Include(s => s.Status);

            #region //filter search conditions // manage talent directory filters
            #region // common search conditions on model property
            if (searchParams.SearchFor.ContainsKey("searchBoxTalent"))
            {
                var searchTerm = Convert.ToString(searchParams.SearchFor["searchBoxTalent"]).ToLower();
                query = query.Where(x => x.FullName.ToLower().Contains(searchTerm) || x.Email.ToLower().Contains(searchTerm) || x.Mobile.Contains(searchTerm));
            }
            if (searchParams.SearchFor.ContainsKey("searchBoxTalentUID"))
            {
                //var searchTerm = Convert.ToString(searchParams.SearchFor["searchBoxTalentUID"]).ToLower();
                //query = query.Where(x => (x.UID).ToString().Contains(searchTerm));
                var searchTerm = Convert.ToInt32(searchParams.SearchFor["searchBoxTalentUID"].Trim());
                query = query.Where(x => x.UID == searchTerm);
            }
            #endregion
            query = FilterTalents(query, searchParams);
            #endregion

            var talents = query.ApplyPaging(searchParams.PageIndex, searchParams.PageSize);
            var recordCount = query.Count();
            var previousPageIndex = searchParams.PageIndex - 1;
            var nextPageIndex = ((recordCount - (searchParams.PageSize * searchParams.PageIndex)) > searchParams.PageSize) ? (searchParams.PageIndex + 1) : 0;

            return new SearchResult<Talent> { Results = talents, TotalResults = recordCount, Previous = previousPageIndex, Next = nextPageIndex };
        }

        /// <summary>
        /// TODO: This is temporary till we get the filter DS sorted out. Make filters immutable
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<string>> ToFilterDictionary(List<Dictionary<string, string>> advanceFilterOld)
        {
            var filters = new Dictionary<string, List<string>>();
            foreach (var item in advanceFilterOld)
            {
                var key = item.Keys.First();
                filters.Add(key, item.Values.First().Split(',').ToList());
            }

            return filters;
        }

        public IQueryable<Talent> FilterTalents(IQueryable<Talent> query, SearchParameters searchParams)
        {
            if (searchParams.AdvanceFilter.Any())
            {
                var filters = ToFilterDictionary(searchParams.AdvanceFilter);

                foreach (var filter in filters)
                {
                    #region advance filter logic 
                    switch (filter.Key)
                    {
                        case "talentCategory":
                            var selectedCategories = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.Set<TalentTalentCategory>()
                                                             .Where(ttc => selectedCategories.Contains(ttc.TalentCategoryId))
                                                             .Select(ttc => ttc.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "interestCategory":
                            var selectedInterestCategories = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.Set<TalentInterestCategory>()
                                                             .Where(tic => selectedInterestCategories.Contains(tic.InterestCategoryId))
                                                             .Select(tic => tic.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;


                        case "tier":
                            var selectedTiers = filter.Value.Select(short.Parse).ToList();
                            query = query.Where(t => selectedTiers.Contains(t.TierId));
                            break;

                        case "tag":
                            var selectedTags = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.Set<TalentTag>()
                                                             .Where(tt => selectedTags.Contains(tt.TagId))
                                                             .Select(tt => tt.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "language":
                            var selectedLanguage = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.Set<TalentLanguage>()
                                                             .Where(tl => selectedLanguage.Contains(tl.LanguageId))
                                                             .Select(tl => tl.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "ethnicity":
                            var selectedEthnicity = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.Set<TalentEthnicity>()
                                                             .Where(te => selectedEthnicity.Contains(te.Ethnicity))
                                                             .Select(te => te.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "productionHouse":
                            var selectedProductionHouses = new List<int?>();
                            selectedProductionHouses.AddRange(filter.Value.Select(ToNullableInt));

                            query = query.Where(t => _context.Set<TalentExperience>()
                                                             .Where(te => selectedProductionHouses.Contains(te.ProductionHouseId))
                                                             .Select(te => te.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "agency":
                            var selectedAgencyIds = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.Set<AuxiliaryUser>()
                                                            .Where(au => selectedAgencyIds.Contains(au.Id))
                                                            .Select(au => au.Id)
                                                            .Contains((int)t.AgencyId));
                            break;

                        case "school":
                            var selectedSchools = new List<int?>();
                            selectedSchools.AddRange(filter.Value.Select(ToNullableInt));

                            query = query.Where(t => _context.Set<TalentEducation>()
                                                             .Where(te => selectedSchools.Contains(te.SchoolId))
                                                             .Select(te => te.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "association":
                            var selectedAssociations = new List<int?>();
                            selectedAssociations.AddRange(filter.Value.Select(ToNullableInt));

                            query = query.Where(t => _context.Set<TalentAssociation>()
                                                             .Where(ta => selectedAssociations.Contains(ta.AssociationId))
                                                             .Select(te => te.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "country":
                            var selectedCountries = new List<int?>();
                            selectedCountries.AddRange(filter.Value.Select(ToNullableInt));

                            var addressesWithSelectedCoutries = _context.Address
                                                                        .Where(a => selectedCountries.Contains(a.CountryId))
                                                                        .Select(a => a.Id);

                            query = query.Where(t => _context.Set<TalentAddress>()
                                                             .Where(ta => addressesWithSelectedCoutries.Contains((int)ta.AddressId))
                                                             .Select(ta => ta.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));

                            break;

                        case "city":
                            var selectedCities = new List<int?>();
                            selectedCities.AddRange(filter.Value.Select(ToNullableInt));

                            var addressesWithSelectedCities = _context.Address
                                                                      .Where(a => selectedCities.Contains(a.CityId))
                                                                      .Select(a => a.Id);

                            query = query.Where(t => _context.Set<TalentAddress>()
                                                             .Where(ta => addressesWithSelectedCities.Contains((int)ta.AddressId))
                                                             .Select(ta => ta.TalentId)
                                                             .Distinct()
                                                             .Contains(t.Id));
                            break;

                        case "gender":
                            query = query.Where(t => filter.Value.Contains(t.Gender));
                            break;

                        case "hairColor":
                            var selectedHairColors = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.HairColor.Select(hc => hc.Id).Where(hc => selectedHairColors.Contains(hc)).Contains((int)t.TalentPhysicalAttribute.HairColorId));
                            break;

                        case "hairType":
                            var selectedHairTypes = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.HairType.Select(ht => ht.Id).Where(ht => selectedHairTypes.Contains(ht)).Contains((int)t.TalentPhysicalAttribute.HairTypeId));
                            break;

                        case "hairLength":
                            var selectedHairLengths = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.HairLength.Select(hl => hl.Id).Where(hl => selectedHairLengths.Contains(hl)).Contains((int)t.TalentPhysicalAttribute.HairLengthId));
                            break;

                        case "eyeColor":
                            var selectedEyeColors = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.EyeColor.Select(ec => ec.Id).Where(ec => selectedEyeColors.Contains(ec)).Contains((int)t.TalentPhysicalAttribute.EyeColorId));
                            break;

                        case "skinColor":
                            var selectedSkinColors = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.SkinColor.Select(sc => sc.Id).Where(sc => selectedSkinColors.Contains(sc)).Contains((int)t.TalentPhysicalAttribute.SkinColorId));
                            break;

                        case "chestSize":
                            var selectedChestSizes = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.ChestSize.Select(cs => cs.Id).Where(cs => selectedChestSizes.Contains(cs)).Contains((int)t.TalentPhysicalAttribute.ChestSizeId));
                            break;

                        case "waistSize":
                            var selectedWaistSizes = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.WaistSize.Select(ws => ws.Id).Where(ws => selectedWaistSizes.Contains(ws)).Contains((int)t.TalentPhysicalAttribute.WaistId));
                            break;

                        case "bodyType":
                            var selectedBodyTypes = filter.Value.Select(int.Parse).ToList();
                            query = query.Where(t => _context.BodyType.Select(bt => bt.Id).Where(bt => selectedBodyTypes.Contains(bt)).Contains((int)t.TalentPhysicalAttribute.BodyTypeId));
                            break;

                        case "weightRange":
                            var weightRange = filter.Value.First().Split('-').ToList();
                            var minWeight = int.Parse(weightRange[0]);
                            var maxWeight = int.Parse(weightRange[1]);

                            var applicableWeights = _context.Weight
                                                             .Where(w => w.Kgs >= minWeight && w.Kgs <= maxWeight)
                                                             .Select(w => w.Id);

                            query = query.Where(t => applicableWeights.Contains((int)t.TalentPhysicalAttribute.WeightSizeId));
                            break;

                        case "heightRange":
                            var heightRange = filter.Value.First().Split('-').ToList();
                            var minHeight = int.Parse(heightRange[0]);
                            var maxHeight = int.Parse(heightRange[1]);

                            var applicableHeights = _context.Height
                                                             .Where(h => h.Inches >= minHeight && h.Inches <= maxHeight)
                                                             .Select(h => h.Id);

                            query = query.Where(t => applicableHeights.Contains((int)t.TalentPhysicalAttribute.HeightId));
                            break;

                        case "ageRange":
                            var ageRange = filter.Value.First().Split('-').ToList();
                            var minAge = int.Parse(ageRange[0]);
                            var maxAge = int.Parse(ageRange[1]);

                            var calculatedMinAge = DateTime.Now.AddYears(-1 * minAge);
                            var calculatedMaxAge = DateTime.Now.AddYears(-1 * maxAge);
                            query = query.Where(t => t.DOB >= calculatedMaxAge && t.DOB <= calculatedMinAge);
                            break;

                        case "budgetRange":
                            var budgetRange = filter.Value.First().Split('-').ToList();
                            var min = int.Parse(budgetRange[0]);
                            var max = int.Parse(budgetRange[1]);

                            query = query.Where(x => !((min < x.BudgetMin && max < x.BudgetMin) || (min > x.BudgetMax && max > x.BudgetMax)));
                            break;

                        case "FTCRating":
                            var ratingRange = filter.Value.First().Split('-').ToList();
                            var minRating = float.Parse(ratingRange[0]);
                            var maxRating = float.Parse(ratingRange[1]);

                            query = query.Where(t => t.OverallRating >= minRating && t.OverallRating <= maxRating);
                            break;

                        case "educationRating":
                            query = AddRatingFilter(query, filter.Value.First(), "Education");
                            break;

                        case "experienceRating":
                            query = AddRatingFilter(query, filter.Value.First(), "Experience");
                            break;

                        case "associationRating":
                            query = AddRatingFilter(query, filter.Value.First(), "Association");
                            break;

                        case "job":
                            var jobId = int.Parse(filter.Value.First());
                            var job = _context.ProjectJob.Where(j => j.Id == jobId).FirstOrDefault();
                            var jobMinAge = DateTime.Now.AddYears(-1 * job.MinAge.Value);
                            var jobMaxAge = DateTime.Now.AddYears(-1 * job.MaxAge.Value);

                            //query = query.Where(t => !_context.TalentJob.Where(tj => tj.JobId == jobId).Select(tj => tj.TalentId).Contains(t.Id));

                            var talentJobs = _context.TalentJob.Where(tj => tj.JobId == jobId && tj.TalentId != null).Select(tj => (int)tj.TalentId).ToList();
                            var jobTalentRecommended = _context.JobTalentRecommended.Where(jtr => jtr.JobId == jobId && jtr.TalentId != null).Select(jtr => (int)jtr.TalentId).ToList();
                            query = query.Where(t => !talentJobs.Contains(t.Id) && !jobTalentRecommended.Contains(t.Id));
                            query = query.Where(t => t.Gender == job.Gender && t.DOB >= jobMaxAge && t.DOB <= jobMinAge);
                            break;

                        default:
                            break;
                    }
                    #endregion
                }
            }

            // always display latest talents first
            query = query.OrderByDescending(t => t.CreatedOn);
            return query;
        }

        private IQueryable<Talent> AddRatingFilter(IQueryable<Talent> query, string range, string ratingType)
        {
            var rating = range.Split('-').ToList();
            var minRating = int.Parse(rating[0]);
            var maxRating = int.Parse(rating[1]);

            var expRatingParameter = _context.MstTalentRatingParameter
                                             .Where(x => x.Description.ToLower() == ratingType.ToLower())
                                             .Select(x => x.Id);

            return query.Where(t => _context.TalentRatingParameter
                                            .Where(trp => expRatingParameter.Contains((short)trp.RatingParameterId))
                                            .Where(trp => trp.Rating >= minRating && trp.Rating <= maxRating)
                                            .Select(trp => trp.TalentId)
                                            .Contains(t.Id));
        }

        public static int? ToNullableInt(string s)
        {
            int i;
            if (int.TryParse(s, out i)) return i;
            return null;
        }

        /// <summary>
        /// //filter search conditions // manage talent filters
        /// </summary>
        /// <param name="query">todo: describe query parameter on FilterBySearchParameters</param>
        /// <param name="searchParams">todo: describe searchParams parameter on FilterBySearchParameters</param>
        public IQueryable<Talent> FilterBySearchParameters(IQueryable<Talent> query, SearchParameters searchParams)
        {
            if (searchParams.AdvanceFilter.Count() > 0)
            {
                if (searchParams.AdvanceFilter.ToList().Count(x => !x.Keys.Contains("job")) > 0)
                {
                    query = query.Include(p => p.TalentPhysicalAttribute);

                    var allTalents = query;
                    var advanceFilteredTalents = new List<Talent>();
                    foreach (var searchFor in searchParams.AdvanceFilter.ToList())
                    {
                        #region advance filter logic 
                        var searchTerm = searchFor.Values.FirstOrDefault();
                        var ListOfSearchTerms = searchTerm.Split(',').Select(Int32.Parse).ToList();
                        switch (searchFor.Keys.FirstOrDefault())
                        {
                            //case ("searchBoxTalent"):
                            //    var TalentNameResult = allTalents.Where(x => x.FullName.ToLower().Contains(searchTerm.ToLower()));
                            //    var TalentUIDResult = allTalents.Where(x => (x.UID ?? 0).ToString().Contains(searchTerm));
                            //    var searchBoxTalentWise = TalentNameResult.Concat(TalentUIDResult).ToList();
                            //    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(searchBoxTalentWise).ToList() : searchBoxTalentWise;
                            //    break;
                            //case ("searchBoxTag"):
                            //    var searchBoxTagWise = allTalents.Include(tag => tag.TalentTag).Where(x => x.TalentTag.Any(t => t.Tag.Name.ToLower().Contains(searchTerm.ToLower()))).ToList();
                            //    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(searchBoxTagWise).ToList() : searchBoxTagWise;
                            //    break;

                            ////case ("talentCategory"):
                            ////    //var talentCategoryWise = allTalents.Include(ttc => ttc.TalentTalentCategory).Where(x => x.TalentTalentCategory.Any(tc => ListOfSearchTerms.Any(item => (tc.TalentCategoryId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var ttcList = this._context.Set<TalentTalentCategory>().Where(ttc => ListOfSearchTerms.Any(item => item == ttc.TalentCategoryId)).Select(tc => tc.TalentId).ToList();
                            ////    var talentCategoryWise = allTalents.Where(x => ttcList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentCategoryWise).ToList() : talentCategoryWise;
                            ////    break;

                            ////case ("interestCategory"):
                            ////    //var interestCategoryWise = allTalents.Include(ttc => ttc.TalentInterestCategory).Where(x => x.TalentInterestCategory.Any(ic => ListOfSearchTerms.Any(item => (ic.InterestCategoryId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var ticList = this._context.Set<TalentInterestCategory>().Where(tic => ListOfSearchTerms.Any(item => item == tic.InterestCategoryId)).Select(tc => tc.TalentId).ToList();
                            ////    var interestCategoryWise = allTalents.Where(x => ticList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(interestCategoryWise).ToList() : interestCategoryWise;
                            ////    break;

                            ////case ("tier"):
                            ////    var tierWise = allTalents.Where(x => ListOfSearchTerms.Any(item => x.TierId == item)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(tierWise).ToList() : tierWise;
                            ////    break;

                            ////case ("tag"):
                            ////    //var tagWise = allTalents.Include(tag => tag.TalentTag).Where(x => x.TalentTag.Any(tag => ListOfSearchTerms.Any(item => (tag.TagId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var tagList = this._context.Set<TalentTag>().Where(tt => ListOfSearchTerms.Any(item => item == tt.TagId)).Select(tc => tc.TalentId).ToList();
                            ////    var tagWise = allTalents.Where(x => tagList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(tagWise).ToList() : tagWise;
                            ////    break;

                            ////case ("language"):
                            ////    //var languageWise = allTalents.Where(x => x.TalentLanguage.Any(language => ListOfSearchTerms.Any(item => (language.LanguageId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var tlList = _context.Set<TalentLanguage>().Where(tl => ListOfSearchTerms.Any(item => item == tl.LanguageId)).Select(tc => tc.TalentId).ToList();
                            ////    var languageWise = allTalents.Where(x => tlList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(languageWise).ToList() : languageWise;
                            ////    break;
                            ////case ("ethnicity"):
                            ////    //var ethnicityWise = allTalents.Where(x => x.TalentEthnicity.Any(e => ListOfSearchTerms.Any(item => (e.Ethnicity ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var teList = _context.Set<TalentEthnicity>().Where(te => ListOfSearchTerms.Any(item => item == te.Ethnicity)).Select(tc => tc.TalentId).ToList();
                            ////    var ethnicityWise = allTalents.Where(x => teList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(ethnicityWise).ToList() : ethnicityWise;
                            ////    break;
                            ////case ("productionHouse"):
                            ////    //var productionHouseWise = allTalents.Where(x => x.TalentExperience.Any(e => ListOfSearchTerms.Any(item => (e.ProductionHouseId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var talExpList = _context.Set<TalentExperience>().Where(talExp => ListOfSearchTerms.Any(item => item == talExp.ProductionHouseId)).Select(tc => tc.TalentId).ToList();
                            ////    var productionHouseWise = allTalents.Where(x => talExpList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(productionHouseWise).ToList() : productionHouseWise;
                            ////    break;
                            ////case ("agency"):
                            ////    var agencyWise = allTalents.Where(x => ListOfSearchTerms.Any(item => x.AgencyId == item)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(agencyWise).ToList() : agencyWise;
                            ////    break;
                            ////case ("school"):
                            ////    //var schoolWise = allTalents.Where(x => x.TalentEducation.Any(e => ListOfSearchTerms.Any(item => (e.SchoolId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var talEduList = _context.Set<TalentEducation>().Where(talEdu => ListOfSearchTerms.Any(item => item == talEdu.SchoolId)).Select(tc => tc.TalentId).ToList();
                            ////    var schoolWise = allTalents.Where(x => talEduList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(schoolWise).ToList() : schoolWise;
                            ////    break;
                            ////case ("association"):
                            ////    //var associationWise = allTalents.Where(x => x.TalentAssociation.Any(e => ListOfSearchTerms.Any(item => (e.AssociationId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var talAsList = _context.Set<TalentAssociation>().Where(talAs => ListOfSearchTerms.Any(item => item == talAs.AssociationId)).Select(tc => tc.TalentId).ToList();
                            ////    var associationWise = allTalents.Where(x => talAsList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(associationWise).ToList() : associationWise;
                            ////    break;
                            ////case ("country"):
                            ////    //var countryWise = allTalents.Where(x => x.TalentAddress.Any(ad => ListOfSearchTerms.Any(item => (ad.Address.CountryId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var talAddList = _context.Set<TalentAddress>().Where(talAdd => ListOfSearchTerms.Any(item => item == talAdd.Address.CountryId)).Select(tc => tc.TalentId).ToList();
                            ////    var countryWise = allTalents.Where(x => talAddList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(countryWise).ToList() : countryWise;
                            ////    break;
                            ////case ("city"):
                            ////    //var cityWise = allTalents.Where(x => x.TalentAddress.Any(ad => ListOfSearchTerms.Any(item => (ad.Address.CityId ?? 0) == Convert.ToInt32(item)))).ToList();
                            ////    var talCityList = _context.Set<TalentAddress>().Where(talAdd => ListOfSearchTerms.Any(item => item == talAdd.Address.CityId)).Select(tc => tc.TalentId).ToList();
                            ////    var cityWise = allTalents.Where(x => talCityList.Any(talId => talId == x.Id)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(cityWise).ToList() : cityWise;
                            ////    break;
                            ////case ("gender"):
                            ////    //var genderWise = allTalents.Where(x => ListOfSearchTerms.Any(item => (!string.IsNullOrEmpty(x.Gender) ? x.Gender : "0") == item)).ToList();
                            ////    var genderWise = allTalents.Where(x => ListOfSearchTerms.Any(item => item.ToString() == x.Gender));
                            ////    // advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(genderWise).ToList() : genderWise;
                            ////    break;
                            ////case ("hairColor"):
                            ////    var hairColorWise = allTalents.Where(x => _context.HairColor.Any(hc => hc.Id == x.TalentPhysicalAttribute.HairColorId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.HairColorId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(hairColorWise).ToList() : hairColorWise;
                            ////    break;
                            ////case ("hairType"):
                            ////    var hairTypeWise = allTalents.Where(x => _context.HairType.Any(ht => ht.Id == x.TalentPhysicalAttribute.HairTypeId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.HairTypeId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(hairTypeWise).ToList() : hairTypeWise;
                            ////    break;
                            ////case ("hairLength"):
                            ////    var hairLengthWise = allTalents.Where(x => _context.HairLength.Any(hl => hl.Id == x.TalentPhysicalAttribute.HairLengthId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.HairLengthId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(hairLengthWise).ToList() : hairLengthWise;
                            ////    break;
                            ////case ("eyeColor"):
                            ////    var eyeColorWise = allTalents.Where(x => _context.EyeColor.Any(hc => hc.Id == x.TalentPhysicalAttribute.EyeColorId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.EyeColorId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(eyeColorWise).ToList() : eyeColorWise;
                            ////    break;
                            ////case ("skinColor"):
                            ////    var skinColorWise = allTalents.Where(x => _context.SkinColor.Any(hc => hc.Id == x.TalentPhysicalAttribute.SkinColorId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.SkinColorId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(skinColorWise).ToList() : skinColorWise;
                            ////    break;
                            ////case ("chestSize"):
                            ////    var chestSizeWise = allTalents.Where(x => _context.ChestSize.Any(hc => hc.Id == x.TalentPhysicalAttribute.ChestSizeId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.ChestSizeId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(chestSizeWise).ToList() : chestSizeWise;
                            ////    break;
                            ////case ("waistSize"):
                            ////    var waistSizeWise = allTalents.Where(x => _context.WaistSize.Any(hc => hc.Id == x.TalentPhysicalAttribute.WaistId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.WaistId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(waistSizeWise).ToList() : waistSizeWise;
                            ////    break;
                            ////case ("bodyType"):
                            ////    var bodyTypeWise = allTalents.Where(x => _context.BodyType.Any(ht => ht.Id == x.TalentPhysicalAttribute.BodyTypeId) && ListOfSearchTerms.Any(item => (x.TalentPhysicalAttribute.BodyTypeId ?? 0) == Convert.ToInt32(item))).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(bodyTypeWise).ToList() : bodyTypeWise;
                            ////    break;
                            ////case ("weightRange"):
                            ////    var weightRange = searchTerm.Split('-').ToList();
                            ////    var minWeight = weightRange[0];
                            ////    var maxWeight = weightRange[1];
                            ////    var talentsWithWeightFilter = allTalents.Where(x => _context.Weight.Where(w => w.Id == x.TalentPhysicalAttribute.WeightSizeId).FirstOrDefault().Kgs >= int.Parse(minWeight)
                            ////                                                    && _context.Weight.Where(w => w.Id == x.TalentPhysicalAttribute.WeightSizeId).FirstOrDefault().Kgs <= int.Parse(maxWeight)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithWeightFilter).ToList() : talentsWithWeightFilter;
                            ////    break;
                            ////case ("heightRange"):
                            ////    var heightRange = searchTerm.Split('-').ToList();
                            ////    var minHeight = heightRange[0];
                            ////    var maxHeight = heightRange[1];
                            ////    var talentsWithHeightFilter = allTalents.Where(x => _context.Height.Where(w => w.Id == x.TalentPhysicalAttribute.HeightId).FirstOrDefault().Inches >= int.Parse(minHeight)
                            ////                                                    && _context.Height.Where(w => w.Id == x.TalentPhysicalAttribute.HeightId).FirstOrDefault().Inches <= int.Parse(maxHeight)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithHeightFilter).ToList() : talentsWithHeightFilter;
                            ////    break;
                            ////case ("ageRange"):
                            ////    var ageRange = searchTerm.Split('-').ToList();
                            ////    var minAge = ageRange[0];
                            ////    var maxAge = ageRange[1];
                            ////    DateTime calculatedMinAge = DateTime.Now.AddYears(-1 * int.Parse(minAge));
                            ////    DateTime calculatedMaxAge = DateTime.Now.AddYears(-1 * int.Parse(maxAge));
                            ////    var talentsWithAgeFilter = allTalents.Where(x => (x.DOB ?? DateTime.Now) <= calculatedMinAge && (x.DOB ?? DateTime.Now) >= calculatedMaxAge).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithAgeFilter).ToList() : talentsWithAgeFilter;
                            ////    break;
                            ////case ("budgetRange"):
                            ////    var budgetRange = searchTerm.Split('-').ToList();
                            ////    var minbudget = budgetRange[0];
                            ////    var maxbudget = budgetRange[1];
                            ////    var talentsWithBudgetFilter = allTalents.Where(x => x.BudgetMin >= Convert.ToInt32(minbudget) && x.BudgetMax <= Convert.ToInt32(maxbudget)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithBudgetFilter).ToList() : talentsWithBudgetFilter;
                            ////    break;
                            ////case ("FTCRating"):
                            ////    var ratingRange = searchTerm.Split('-').ToList();
                            ////    var minRating = ratingRange[0];
                            ////    var maxRating = ratingRange[1];
                            ////    var talentsWithRatingFilter = allTalents.Where(x => x.OverallRating >= Convert.ToInt32(minRating) && x.OverallRating <= Convert.ToInt32(maxRating)).ToList();
                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithRatingFilter).ToList() : talentsWithRatingFilter;
                            ////    break;
                            ////case ("educationRating"):
                            ////    var eduRatingRange = searchTerm.Split('-').ToList();
                            ////    var minEduRating = eduRatingRange[0];
                            ////    var maxEduRating = eduRatingRange[1];
                            ////    var eduRatingParameter = _context.MstTalentRatingParameter.Where(x => x.Description.ToLower() == "Education".ToLower()).FirstOrDefault();

                            ////    var talentsWithEduRatingFilter = allTalents.Where(x =>
                            ////    (_context.TalentRatingParameter.Where(trp => trp.TalentId == x.Id && (trp.RatingParameterId ?? 0) == eduRatingParameter.Id).FirstOrDefault().Rating ?? 0) >= Convert.ToInt32(minEduRating)
                            ////    && (_context.TalentRatingParameter.Where(trp => trp.TalentId == x.Id && (trp.RatingParameterId ?? 0) == eduRatingParameter.Id).FirstOrDefault().Rating ?? 0) <= Convert.ToInt32(maxEduRating)).ToList();

                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithEduRatingFilter).ToList() : talentsWithEduRatingFilter;
                            ////    break;
                            ////case ("experienceRating"):
                            ////    var experienceRatingRange = searchTerm.Split('-').ToList();
                            ////    var minExpRating = experienceRatingRange[0];
                            ////    var maxExpRating = experienceRatingRange[1];
                            ////    var expRatingParameter = _context.MstTalentRatingParameter.Where(x => x.Description.ToLower() == "Experience".ToLower()).FirstOrDefault();

                            ////    var talentsWithExpRatingFilter = allTalents.Where(x =>
                            ////    (_context.TalentRatingParameter.Where(trp => trp.TalentId == x.Id && (trp.RatingParameterId ?? 0) == expRatingParameter.Id).FirstOrDefault().Rating ?? 0) >= Convert.ToInt32(minExpRating)
                            ////    && (_context.TalentRatingParameter.Where(trp => trp.TalentId == x.Id && (trp.RatingParameterId ?? 0) == expRatingParameter.Id).FirstOrDefault().Rating ?? 0) <= Convert.ToInt32(maxExpRating)).ToList();

                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithExpRatingFilter).ToList() : talentsWithExpRatingFilter;
                            ////    break;
                            ////case ("associationRating"):
                            ////    var associationRatingRange = searchTerm.Split('-').ToList();
                            ////    var minAssociationRating = associationRatingRange[0];
                            ////    var maxAssociationExpRating = associationRatingRange[1];
                            ////    var associationRatingParameter = _context.MstTalentRatingParameter.Where(x => x.Description.ToLower() == "Association".ToLower()).FirstOrDefault();

                            ////    var talentsWithAssociationRatingFilter = allTalents.Where(x =>
                            ////    (_context.TalentRatingParameter.Where(trp => trp.TalentId == x.Id && (trp.RatingParameterId ?? 0) == associationRatingParameter.Id).FirstOrDefault().Rating ?? 0) >= Convert.ToInt32(minAssociationRating)
                            ////    && (_context.TalentRatingParameter.Where(trp => trp.TalentId == x.Id && (trp.RatingParameterId ?? 0) == associationRatingParameter.Id).FirstOrDefault().Rating ?? 0) <= Convert.ToInt32(maxAssociationExpRating)).ToList();

                            ////    advanceFilteredTalents = (advanceFilteredTalents.Count() > 0) ? advanceFilteredTalents.Intersect(talentsWithAssociationRatingFilter).ToList() : talentsWithAssociationRatingFilter;
                            ////    break;
                        }
                        #endregion
                    }
                    query = allTalents.Intersect(advanceFilteredTalents);
                }

                if (searchParams.AdvanceFilter.ToList().Count(x => x.Keys.Contains("job")) > 0)
                {
                    var searchTerm = searchParams.AdvanceFilter.ToList().Where(x => x.Keys.Contains("job")).Select(x => x.Values.FirstOrDefault()).FirstOrDefault();
                    var job = _context.ProjectJob.Where(j => j.Id == Convert.ToInt32(searchTerm)).FirstOrDefault();

                    query = query.Include(tj => tj.TalentJob).Include(x => x.JobTalentRecommended)
                                        .Where(x => !x.TalentJob.Any(tj => tj.JobId == Convert.ToInt32(searchTerm)) && !x.JobTalentRecommended.Any(tjr => tjr.JobId == Convert.ToInt32(searchTerm))
                                                                                && x.Gender == job.Gender && (getAge(x.DOB) >= job.MinAge && getAge(x.DOB) <= job.MaxAge) && x.IsProfilePrivate == false);
                }
            }
            return query.OrderByDescending(x => x.CreatedOn);
        }

        private int getAge(DateTime? dateOfBirth)
        {
            DateTime DOB = dateOfBirth ?? DateTime.Now;
            var age = DateTime.Today.Year - DOB.Year;
            if (DOB > DateTime.Today.AddYears(-age)) age--;      // Go back to the year the person was born in case of a leap year
            return age;
        }

        /// <summary>
        /// //conditionType // All-selected talents
        /// </summary>
        /// <param name="query">todo: describe query parameter on GetTalentDetailsByConditionType</param>
        /// <param name="ConditionType">todo: describe ConditionType parameter on GetTalentDetailsByConditionType</param>
        /// <param name="userId">todo: describe userId parameter on GetTalentDetailsByConditionType</param>
        public IQueryable<Talent> GetTalentDetailsByConditionType(IQueryable<Talent> query, string ConditionType, int userId)
        {
            //TODO: if (ConditionType.Trim() == "all")
            return query;
        }

        #region Public Methods
        public bool ValidateUser(string enteredPassword, string actualPassword)
        {
            if (BCrypt.Net.BCrypt.Verify(enteredPassword, actualPassword))
                return true;

            return false;
        }

        /// <summary>
        /// This method is use to get talent rmarks.
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>returns talent rmarks</returns>
        public async Task<TalentRatingRmarks> GetTalentRmark(int talentId)
        {
            IQueryable<Talent> provider = _context.Set<Talent>();
            IQueryable<TalentInterestCategory> _talentInterestCategory = _context.Set<TalentInterestCategory>();
            IQueryable<TalentTalentCategory> _talentTalentCategory = _context.Set<TalentTalentCategory>();
            Talent talent = null;
            IQueryable<TalentCategory> _talentCategory = _context.Set<TalentCategory>();

            var includedCategory = _talentCategory.Where(e => e.ParentId == null).Select(c => c.Id).ToList();
            var listTalentCategory = _talentCategory.ToList();

            var talentRatingRmarks = new TalentRatingRmarks();

            talent = provider.Include(rmark => rmark.TalentRatingRmark).ThenInclude(intCat => intCat.InterestCategory)
                             .Include(rmark => rmark.TalentRatingRmark).ThenInclude(talCat => talCat.TalentCategory)
                             .Include(ic => ic.TalentInterestCategory)
                             .Include(talPhyAttr => talPhyAttr.TalentPhysicalAttribute)
                             .Include(tc => tc.TalentTalentCategory)
                             .FirstOrDefault(x => x.Id == talentId);

            talentRatingRmarks.TalentRatingRMarks = talent.TalentRatingRmark.Select(g => new TalentRatingRmarkDto { Id = g.Id, TalentCategoryId = g.TalentCategoryId, InterestCategoryId = g.InterestCategoryId }).ToList();
            talentRatingRmarks.TalentId = talentId;
            talentRatingRmarks.TalentProfileURL = talent.TalentProfileURL;
            talentRatingRmarks.TalentInterestCategory = await _talentInterestCategory.Include(g => g.InterestCategory).Where(g => g.TalentId == talentId).Select(g => new TalentInterestCategoryType { InterestCategoryId = g.InterestCategoryId, Description = g.InterestCategory.Description }).OrderBy(g => g.Description).ToListAsync();
            talentRatingRmarks.TalentTalentCategory = await _talentTalentCategory.Where(g => g.TalentId == talentId && includedCategory.Contains(g.TalentCategoryId)).Select(g => new TalentTalentCategoryType { TalentCategoryId = g.TalentCategoryId, Description = listTalentCategory.Where(p => p.Id == g.TalentCategoryId).Select(c => c.Description).First().ToString() }).OrderBy(g => g.Description).ToListAsync();

            if (talent.TalentPhysicalAttribute != null)
            {
                IQueryable<AuxiliaryUser> auxiliaryUser = _context.Set<AuxiliaryUser>();
                talentRatingRmarks.Verified = talent.TalentPhysicalAttribute.Verified;
                talentRatingRmarks.VerifiedBy = talent.TalentPhysicalAttribute.VerifiedBy;
                talentRatingRmarks.VerifiedOn = talent.TalentPhysicalAttribute.VerifiedOn;
                if (talentRatingRmarks.VerifiedBy != null)
                {
                    var verifiedByTalent = auxiliaryUser.FirstOrDefault(x => x.Id == talent.TalentPhysicalAttribute.VerifiedBy);
                    talentRatingRmarks.VerifiedByName = verifiedByTalent.FullName;
                }
            }

            return await Task.Run(() => talentRatingRmarks);
        }

        /// <summary>
        /// This method is use to get talent ratings
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>return talent ratings</returns>
        public async Task<TalentRatings> GetTalentRatings(int talentId)
        {
            IQueryable<Talent> provider = _context.Set<Talent>();

            Talent talent = null;
            var talentRatings = new TalentRatings();

            if (talentId > 0)
            {
                talent = provider.Include(parm => parm.TalentRatingParameter).ThenInclude(ratingParm => ratingParm.RatingParameter)
                    .Include(interest => interest.TalentRatingInterestCategory).ThenInclude(intCat => intCat.InterestCategory)
                    .Include(talPhyAttr => talPhyAttr.TalentPhysicalAttribute)
                    .Include(category => category.TalentRatingTalentCategory).ThenInclude(talCat => talCat.TalentCategory)
                    .FirstOrDefault(x => x.Id == talentId);
            }


            IQueryable<TalentInterestCategory> _talentInterestCategory = _context.Set<TalentInterestCategory>();
            talentRatings.TalentRatingInterestCategory = await _talentInterestCategory.Include(g => g.InterestCategory).Where(g => g.TalentId == talentId).Select(g => new TalentRatingInterestCategoryDto { InterestCategoryId = g.InterestCategoryId, Description = g.InterestCategory.Description, Rating = talent.TalentRatingInterestCategory.FirstOrDefault(c => c.InterestCategoryId == g.InterestCategoryId).Rating }).OrderBy(g => g.Description).ToListAsync();

            IQueryable<TalentCategory> _talentCategory = _context.Set<TalentCategory>();

            var listTalentCategory = _talentCategory.ToList();

            var includedCategory = _talentCategory.Where(e => e.ParentId == null).Select(c => c.Id).ToList();

            IQueryable<TalentTalentCategory> _talentTalentCategory = _context.Set<TalentTalentCategory>();
            talentRatings.TalentRatingTalentCategory = await _talentTalentCategory
                                                        .Where(g => g.TalentId == talentId && includedCategory.Contains(g.TalentCategoryId))
                                                        .Select(g => new TalentRatingTalentCategoryDto
                                                        {
                                                            TalentCategoryId = g.TalentCategoryId,
                                                            Description = listTalentCategory.Where(p => p.Id == g.TalentCategoryId).Select(c => c.Description).First().ToString(),
                                                            Rating = talent.TalentRatingTalentCategory.FirstOrDefault(c => c.TalentCategoryId == g.TalentCategoryId).Rating
                                                        })
                                                        .OrderBy(g => g.Description)
                                                        .ToListAsync();

            IQueryable<MstTalentRatingParameter> _talentRatingParameter = _context.Set<MstTalentRatingParameter>();
            talentRatings.TalentRatingParameter = await _talentRatingParameter.Select(g => new TalentRatingParameterDto { Description = g.Description, RatingParameterId = g.Id, Rating = talent.TalentRatingParameter.FirstOrDefault(c => c.RatingParameterId == g.Id).Rating }).OrderBy(g => g.Description).ToListAsync();

            talentRatings.FtcRating = talent.FtcRating;
            talentRatings.OverallRating = talent.OverallRating;
            talentRatings.RecruiterRating = talent.RecruiterRating;
            talentRatings.RatingNotes = talent.RatingNotes;
            talentRatings.RecruiterRatingCount = talent.RecruiterRatingCount;
            talentRatings.InterestRating = talent.InterestRating;
            talentRatings.TalentId = talent.Id;
            talentRatings.TalentProfileURL = talent.TalentProfileURL;

            if (talent.TalentPhysicalAttribute != null)
            {
                IQueryable<AuxiliaryUser> auxiliaryUser = _context.Set<AuxiliaryUser>();

                talentRatings.Verified = talent.TalentPhysicalAttribute.Verified;
                talentRatings.VerifiedBy = talent.TalentPhysicalAttribute.VerifiedBy;
                talentRatings.VerifiedOn = talent.TalentPhysicalAttribute.VerifiedOn;
                if (talentRatings.VerifiedBy != null)
                {
                    var verifiedByTalent = auxiliaryUser.FirstOrDefault(x => x.Id == talent.TalentPhysicalAttribute.VerifiedBy);
                    talentRatings.VerifiedByName = verifiedByTalent.FullName;
                }

            }
            return await Task.Run(() => talentRatings);
        }

        /// <summary>
        /// This method is use to get talent wise ratio
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>return talent ratings</returns>
        public async Task<List<KeyValueDto>> GetTalentRatio()
        {
            IQueryable<TalentTalentCategory> provider = _context.Set<TalentTalentCategory>();
            Decimal countTalentTalentCategory = (from talentCategory in _context.TalentCategory.Where(x => x.ParentId == null)
                                                 join talentTalentCategory in provider
                                                 on talentCategory.Id equals talentTalentCategory.TalentCategoryId
                                                 select 1
                                                 ).Count();
            // provider.Count();
            List<KeyValueDto> query = (from talentCategory in _context.TalentCategory.Where(x => x.ParentId == null)
                                       join talentTalentCategoryCount in (from talentTalentCategory in provider
                                                                          group talentTalentCategory by talentTalentCategory.TalentCategoryId into g
                                                                          select new
                                                                          {
                                                                              Key = g.Key,
                                                                              Value = (Convert.ToDecimal(g.Count()) * 100) / countTalentTalentCategory
                                                                          }) on talentCategory.Id equals talentTalentCategoryCount.Key
                                       select new KeyValueDto()
                                       {
                                           Key = talentCategory.Description,
                                           Value = talentTalentCategoryCount.Value.ToString()
                                       }).ToList();
            return await Task.Run(() => query);
        }

        /// <summary>
        /// This method is use to get talent Gender count
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>return talent ratings</returns>
        public async Task<List<KeyValueDto>> GetCountryCount()
        {
            List<KeyValueDto> query;
            IQueryable<TalentAddress> talentAddressProvider = _context.Set<TalentAddress>();
            query = (from talentAddress in (talentAddressProvider.Include(x => x.Address).Include(y => y.Address.City))
                     group talentAddress by talentAddress.Address.Country.Id into g
                     select new KeyValueDto
                     {
                         Key = g.Key.ToString(),
                         Value = g.Count().ToString()
                     }).ToList();
            List<KeyValueDto> queryJoinCityTable = (from countryQuery in query
                                                    join country in _context.Country
                                                    on countryQuery.Key equals country.Id.ToString()
                                                    select new KeyValueDto()
                                                    {
                                                        Key = country.Name,
                                                        Value = countryQuery.Value
                                                    }).ToList();
            return await Task.Run(() => queryJoinCityTable);
        }
        /// <summary>
        /// This method is use to get talent with cities count
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>return talent ratings</returns>
        public async Task<List<KeyValueDto>> GetGenderCount()
        {
            IQueryable<Talent> provider = _context.Set<Talent>();
            Decimal countTalentInterestCategory = provider.Count();
            List<KeyValueDto> query = (from talent in provider
                                       group talent by talent.Gender into g
                                       select new KeyValueDto
                                       {
                                           Key = g.Key,
                                           Value = g.Count().ToString()
                                       }).ToList();
            return await Task.Run(() => query);
        }
        /// <summary>
        /// This method is use to get talent interest wise ratio
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>return talent ratings</returns>
        public async Task<List<KeyValueDto>> GetInterestRatio()
        {
            IQueryable<TalentInterestCategory> provider = _context.Set<TalentInterestCategory>();
            Decimal countTalentInterestCategory = provider.Count();
            List<KeyValueDto> query = (from interestCategory in _context.InterestCategory
                                       join talentInterestCategoryCount in (from talentInterestCategory in provider
                                                                            group talentInterestCategory by talentInterestCategory.InterestCategoryId into g
                                                                            select new
                                                                            {
                                                                                Key = g.Key,
                                                                                Value = (Convert.ToDecimal(g.Count()) * 100) / countTalentInterestCategory
                                                                            }) on interestCategory.Id equals talentInterestCategoryCount.Key
                                       select new KeyValueDto()
                                       {
                                           Key = interestCategory.Description,
                                           Value = talentInterestCategoryCount.Value.ToString()
                                       }).ToList();
            return await Task.Run(() => query);
        }
        /// <summary>
        /// This method is use to update talent ratings
        /// </summary>
        /// <param name="talentRatings"></param>
        /// <returns>returns updated talent ratings object</returns>
        public async Task<bool> UpdateRatings(TalentRatings talentRatings, int userId)
        {
            var success = false;
            if (talentRatings != null)
            {
                var originalTalentObj = this.FindAll(x => x.Id == talentRatings.TalentId).FirstOrDefault();
                if (originalTalentObj != null)
                {
                    originalTalentObj.FtcRating = talentRatings.FtcRating;
                    originalTalentObj.OverallRating = talentRatings.OverallRating;
                    originalTalentObj.RatingNotes = talentRatings.RatingNotes;
                    originalTalentObj.InterestRating = talentRatings.InterestRating;
                    //This call is use to update FtcRating,RecruiterRating and RatingNotes in talent table.
                    var updatedTalentRating = await UpdateAsync(originalTalentObj);

                    //This call is use to save talent ratings parameter
                    await SaveTalentRatingParameter(talentRatings.TalentId, talentRatings.TalentRatingParameter);

                    //This call is use to save talent ratings for interest category.
                    await SaveTalentRatingInterestCategory(talentRatings.TalentId, talentRatings.TalentRatingInterestCategory);

                    // This call use to save talent ratings for talent category
                    await SaveTalentRatingTalentCategory(talentRatings.TalentId, talentRatings.TalentRatingTalentCategory);

                    await VerifyTalent(talentRatings.TalentId, talentRatings.Verified ?? false, talentRatings.VerifiedBy);

                    #region Add TalentStatusHistory when talent is Rated
                    await AddTalentRatingHistory(userId, talentRatings.TalentId);
                    #endregion

                    success = true;


                }
            }
            return await Task.Run(() => success);
        }

        private async Task VerifyTalent(int talentId, bool verified, int? verifiedBy)
        {
            var origPhysicalAttribute = _talentPhysicalAttributeRepository.FindAll(x => x.TalentId == talentId).FirstOrDefault();

            if (origPhysicalAttribute != null)
            {
                if (verified)
                {

                    origPhysicalAttribute.Verified = verified;
                    origPhysicalAttribute.VerifiedBy = verifiedBy;
                    origPhysicalAttribute.VerifiedOn = DateTime.UtcNow;
                }
                else
                {
                    origPhysicalAttribute.Verified = false;
                    origPhysicalAttribute.VerifiedBy = null;
                    origPhysicalAttribute.VerifiedOn = null;
                }
                var updatedPhysicalAttribute = await _talentPhysicalAttributeRepository.UpdateAsync(origPhysicalAttribute);
            }
        }

        /// <summary>
        /// This method is use to update talent rmarks.
        /// </summary>
        /// <param name="talentRatings"></param>
        /// <returns></returns>
        public async Task<bool> UpdateTalentRMark(TalentRatingRmarks talentRatings, int userId)
        {
            var success = false;
            if (talentRatings != null)
            {
                if (talentRatings.TalentRatingRMarks != null && talentRatings.TalentRatingRMarks.Count > 0)
                {
                    var origtalentRMarks = await _talentRatingRmarksRepository.FindAllAsync(x => x.TalentId == talentRatings.TalentId);

                    //Delete 
                    foreach (var talentRMark in origtalentRMarks)
                    {
                        var status = await _talentRatingRmarksRepository.DeleteAsync(talentRMark);
                    }

                    //insert
                    foreach (var talentRatingRmark in ConvertToTalentRatingRmark(talentRatings.TalentId, talentRatings.TalentRatingRMarks))
                    {
                        if (talentRatingRmark.InterestCategoryId > 0 && talentRatingRmark.TalentCategoryId > 0)
                        {
                            var addedtalentRatingRmark = await _talentRatingRmarksRepository.AddAsync(talentRatingRmark);
                        }
                    }

                    #region Add TalentStatusHistory when talent is Pushed to Recommended  OR REMOVED
                    await AddTalentRecommendedHistory(userId, talentRatings.TalentId);
                    #endregion

                }

                await VerifyTalent(talentRatings.TalentId, talentRatings.Verified ?? false, talentRatings.VerifiedBy);

                success = true;
            }
            return await Task.Run(() => success);
        }

        private async Task AddTalentRecommendedHistory(int userId, int? talentId)
        {
            var talentStatusHistory = new TalentStatusHistory()
            {
                CreatedBy = userId,
                TalentId = talentId,
                FeatureId = (int)AuthorizationFeaturesEnum.TalentRmark
            };

            await _talentStatusHistoryRepository.AddAsync(talentStatusHistory);
        }

        private async Task AddTalentRatingHistory(int userId, int? talentId)
        {
            var talentStatusHistory = new TalentStatusHistory()
            {
                CreatedBy = userId,
                TalentId = talentId,
                FeatureId = (int)AuthorizationFeaturesEnum.TalentRating
            };

            await _talentStatusHistoryRepository.AddAsync(talentStatusHistory);
        }
      
        /// <summary>
        /// [working method-] This method is use to export talent directory report.
        /// </summary>
        /// <returns>Talent directory report</returns>
        public async Task<object> TalentDataReport(SearchParameters searchParams, int userId)
        {
            if (searchParams == null)
            {
                throw new ArgumentNullException("searchParams");
            }
            searchParams.SetDefaultsForUnsetProperties();
            IQueryable<Talent> query = _context.Set<Talent>();

            query = query.Include(ta => ta.TalentAddress).ThenInclude(ad => ad.Address).ThenInclude(c => c.City)
                        .Include(tpa => tpa.TalentPhysicalAttribute)
                        .Include(rm => rm.TalentRatingRmark)
                        .Include(s => s.Status);

            #region //filter search conditions // manage talent directory filters
            if (searchParams.SearchFor.ContainsKey("searchBoxTalent"))
            {
                var searchTerm = Convert.ToString(searchParams.SearchFor["searchBoxTalent"]);
                query = query.Where(x => x.FullName.ToLower().Contains(searchTerm) || x.Email.ToLower().Contains(searchTerm) || x.Mobile.Contains(searchTerm));
            }
            if (searchParams.SearchFor.ContainsKey("searchBoxTalentUID"))
            {
                var searchTerm = Convert.ToInt32(searchParams.SearchFor["searchBoxTalentUID"]);
                query = query.Where(x => x.UID == searchTerm);
            }
            query = FilterTalents(query, searchParams);
            #endregion

            var country = _context.Country.ToList();
            var ethnicity = _context.Ethnicity.ToList();
            var language = _context.Language.ToList();
            var tag = _context.Tag.ToList();
            var interestCategory = _context.InterestCategory.ToList();
            var talentCategory = _context.TalentCategory.ToList();

            var talIds = query//.Take(50)
                        .Select(q => q.Id).ToList();

            var finalResult = _context.Talent.Where(t => talIds.Contains(t.Id))
                                    .Include(s => s.Status)
                                    .Include(ph => ph.TalentPhysicalAttribute)
                                    .Include(trm => trm.TalentRatingRmark)
                                    .Include(asso => asso.TalentAssociation).Include(edu => edu.TalentEducation).Include(exp => exp.TalentExperience)
                                    .Include(e => e.TalentEthnicity).Include(l => l.TalentLanguage).Include(t => t.TalentTag)
                                    .Include(tic => tic.TalentInterestCategory).Include(ttc => ttc.TalentTalentCategory)
                                .GroupJoin(_context.TalentAddress.Include(ad => ad.Address).ThenInclude(c => c.City), t => t.Id, ta => ta.TalentId, (t, ta) => new { t, ta })
                                .SelectMany(x => x.ta.DefaultIfEmpty(), (t, tadd) => new { t.t, t.ta, tadd })

                                //.GroupJoin(_context.TalentPhysicalAttribute, t => t.t.Id, ph => ph.TalentId, (t, ph) => new { t.t, t.ta, t.tadd, ph }).SelectMany(x => x.ph.DefaultIfEmpty(), (t, ph) => new { t.t, t.ta, t.tadd, ph })
                                //.GroupJoin(_context.Height, ph => ph.ph.HeightId, h => h.Id, (ph, h) => new { ph.t, ph.ta, ph.tadd, ph.ph, h }).SelectMany(x => x.h, (ph, h) => new { ph.t, ph.ta, ph.tadd, ph.ph, h })
                                .GroupJoin(_context.Height, ph => ph.t.TalentPhysicalAttribute.HeightId, h => h.Id, (ph, h) => new { ph.t, ph.ta, ph.tadd, h })
                                .GroupJoin(_context.Weight, ph => ph.t.TalentPhysicalAttribute.WeightSizeId, w => w.Id, (ph, w) => new { ph.t, ph.ta, ph.tadd, ph.h, w })
                                .GroupJoin(_context.ChestSize, ph => ph.t.TalentPhysicalAttribute.ChestSizeId, c => c.Id, (ph, c) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, c })
                                .GroupJoin(_context.WaistSize, ph => ph.t.TalentPhysicalAttribute.ChestSizeId, w => w.Id, (ph, waist) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, waist })
                                .GroupJoin(_context.BodyType, ph => ph.t.TalentPhysicalAttribute.BodyTypeId, b => b.Id, (ph, b) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, b })
                                .GroupJoin(_context.SkinColor, ph => ph.t.TalentPhysicalAttribute.SkinColorId, s => s.Id, (ph, s) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, s })
                                .GroupJoin(_context.EyeColor, ph => ph.t.TalentPhysicalAttribute.EyeColorId, e => e.Id, (ph, e) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, e })
                                .GroupJoin(_context.HairColor, ph => ph.t.TalentPhysicalAttribute.HairColorId, hc => hc.Id, (ph, hc) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, ph.e, hc })
                                .GroupJoin(_context.HairLength, ph => ph.t.TalentPhysicalAttribute.HairLengthId, hl => hl.Id, (ph, hl) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, ph.e, ph.hc, hl })
                                .GroupJoin(_context.HairType, ph => ph.t.TalentPhysicalAttribute.HairTypeId, ht => ht.Id, (ph, ht) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, ph.e, ph.hc, ph.hl, ht })
                                .Select(t => new
                                {
                                    id = t.t.Id,
                                    uid = t.t.UID,
                                    fullName = t.t.FullName,
                                    email = t.t.Email,
                                    gender = ((LoginEnum.Gender)Convert.ToDecimal(ZeroIfEmpty(t.t.Gender))).ToString(),
                                    dob = t.t.DOB != null ? t.t.DOB.GetValueOrDefault().ToString("MM/dd/yyyy") : "",
                                    mobile = string.IsNullOrEmpty(t.t.Mobile) ? "" : (string.IsNullOrEmpty(t.t.MobileCountryCode) ? t.t.Mobile : t.t.MobileCountryCode + " " + t.t.Mobile),
                                    whatsupMobile = string.IsNullOrEmpty(t.t.WhatsupMobile) ? "" : t.t.WhatsupMobile,
                                    talentProfileURL = string.IsNullOrEmpty(t.t.TalentProfileURL) ? "" : t.t.TalentProfileURL,
                                    onboarded = t.t.Onboarded == true ? "Yes" : "No",
                                    profileCompletionPercentage = t.t.CompletionPercentage != null ? t.t.CompletionPercentage : 0,
                                    termsConditionAccepted = t.t.TermsConditionAccepted == true ? "Yes" : "No",
                                    city = t.tadd.Address.City.CityDescription,
                                    status = t.t.Status != null ? t.t.Status.Description : "",
                                    passportCountry = t.t.PassportCountryId != null ? country.Where(x => x.Id == t.t.PassportCountryId).Select(x => x.Name).FirstOrDefault() : "",
                                    passportExpirationDate = t.t.PassportExpirationDate != null ? t.t.PassportExpirationDate.GetValueOrDefault().ToString("MM/dd/yyyy") : "",
                                    VisaYear = string.IsNullOrEmpty(t.t.VisaYear) ? "" : t.t.VisaYear,
                                    VisaType = t.t.VisaType,
                                    aboutMe = string.IsNullOrEmpty(t.t.AboutMe) ? "" : t.t.AboutMe,
                                    guardianName = string.IsNullOrEmpty(t.t.GuardianName) ? "" : t.t.GuardianName,
                                    guardianRelation = string.IsNullOrEmpty(t.t.GuardianRelation) ? "" : t.t.GuardianRelation,
                                    guardianMobile = string.IsNullOrEmpty(t.t.GuardianMobile) ? "" : t.t.GuardianMobile,
                                    guardianEmailId = string.IsNullOrEmpty(t.t.GuardianEmailId) ? "" : t.t.GuardianEmailId,
                                    sharedProfileName = string.IsNullOrEmpty(t.t.SharedProfileName) ? "" : t.t.SharedProfileName,
                                    ftcRating = t.t.FtcRating != null ? t.t.FtcRating : 0,
                                    overallRating = t.t.OverallRating != null ? t.t.OverallRating : 0,
                                    recruiterRating = t.t.RecruiterRating != null ? t.t.RecruiterRating : 0,
                                    interestRating = t.t.InterestRating != null ? t.t.InterestRating : 0,
                                    ratingNotes = string.IsNullOrEmpty(t.t.RatingNotes) ? "" : t.t.RatingNotes,
                                    talentRatingRmark = t.t.TalentRatingRmark.Where(trm => trm.InterestCategoryId != null).Select(trm => trm.TalentId).Contains(t.t.Id) ? "Yes" : "No",
                                    isProfilePrivate = t.t.IsProfilePrivate == true ? "Yes" : "No",
                                    tier = t.t.TierId != 0 ? t.t.Tier.TierDesc : "",

                                    heightInInches = t.h.FirstOrDefault().ShortDescription, //t.t.TalentPhysicalAttribute != null ? (t.t.TalentPhysicalAttribute.HeightId != null ? height.Where(x => x.Id == t.t.TalentPhysicalAttribute.HeightId).FirstOrDefault().ShortDescription : "") : "",
                                    weightInKgs = t.w.FirstOrDefault().Kgs, //t.t.TalentPhysicalAttribute != null ? (t.t.TalentPhysicalAttribute.WeightSizeId != null ? weight.Where(x => x.Id == t.t.TalentPhysicalAttribute.WeightSizeId).FirstOrDefault().Kgs.ToString() : "") : "",
                                    chestSizeInInches = t.c.FirstOrDefault().ShortDescription,
                                    waistSizeInInches = t.waist.FirstOrDefault().ShortDescription,
                                    bodyType = t.b.FirstOrDefault().Description, //t.TalentPhysicalAttribute != null ? (t.TalentPhysicalAttribute.BodyTypeId != null ? bodyType.Where(x => x.Id == t.TalentPhysicalAttribute.BodyTypeId).FirstOrDefault().Description : "") : "",
                                    skinColor = t.s.FirstOrDefault().Description,
                                    eyeColor = t.e.FirstOrDefault().Description,
                                    hairColor = t.hc.FirstOrDefault().Description,
                                    hairLength = t.hl.FirstOrDefault().Description,
                                    hairType = t.ht.FirstOrDefault().Description,
                                    isVerified = t.t.TalentPhysicalAttribute != null ? (t.t.TalentPhysicalAttribute.Verified == true ? "Yes" : "No") : "No",

                                    agencyAgentName = t.t.AgencyId != null ? t.t.AgencyAgentName : "",
                                    agencyAgentEmail = t.t.AgencyId != null ? t.t.AgencyAgentEmail : "",
                                    agencyAgentMobileNo = t.t.AgencyId != null ? t.t.AgencyAgentMobileNo : "",
                                    budget = ZeroIfEmpty(t.t.BudgetMin.ToString()) + "-" + ZeroIfEmpty(t.t.BudgetMax.ToString()),
                                    viewCount = t.t.ViewCount != null ? t.t.ViewCount.ToString() : "0",
                                    //address = string.Join(", ", talentAddress.Where(x => x.TalentId == t.Id).Select(x => address.Where(add => add.Id == x.AddressId).Select(add => add.Line1 + add.Line2 + add.ZipCode).FirstOrDefault()).ToList()),
                                    address = t.tadd.Address.Line1 + t.tadd.Address.Line2 + t.tadd.Address.ZipCode,

                                    ////ethnicity = string.Join(", ", talentEthnicity.Where(x => x.TalentId == t.Id).Select(x => ethnicity.Where(e => e.Id == x.Ethnicity).Select(e => e.Description).FirstOrDefault()).ToList()),
                                    //////interestcategory = string.Join(", ", talentInterestCategory.Where(x => x.TalentId == t.Id).Select(x => interestCategory.Where(i => i.Id == x.InterestCategoryId).Select(i => i.Description).FirstOrDefault()).ToList()),
                                    ethnicity = string.Join(", ", t.t.TalentEthnicity.Select(x => ethnicity.Where(e => e.Id == x.Ethnicity).Select(e => e.Description.Trim()).FirstOrDefault()).ToList()),
                                    language = string.Join(", ", t.t.TalentLanguage.Select(x => language.Where(l => l.Id == x.LanguageId).Select(l => l.Description.Trim()).FirstOrDefault()).ToList()),
                                    tag = string.Join(", ", t.t.TalentTag.Select(x => tag.Where(tg => tg.Id == x.TagId).Select(tg => tg.Name).FirstOrDefault()).ToList()),
                                    interestcategory = string.Join(", ", t.t.TalentInterestCategory.Select(x => interestCategory.Where(i => i.Id == x.InterestCategoryId).Select(i => i.Description.Trim()).FirstOrDefault()).ToList()),
                                    talentcategory = string.Join(", ", t.t.TalentTalentCategory.Select(x => talentCategory.Where(i => i.Id == x.TalentCategoryId).Select(i => i.Description.Trim()).FirstOrDefault()).ToList()),

                                    talentAssociation = t.t.TalentAssociation.Select(x => (int)x.TalentId).Distinct().Contains(t.t.Id) ? "Yes" : "No",
                                    talentEducation = t.t.TalentEducation.Select(x => (int)x.TalentId).Distinct().Contains(t.t.Id) ? "Yes" : "No",
                                    talentExperience = t.t.TalentExperience.Select(x => (int)x.TalentId).Distinct().Contains(t.t.Id) ? "Yes" : "No"
                                });

            return finalResult;
        }

        /// <summary>
        /// This method is use to export talent directory report.
        /// </summary>
        /// <returns>Talent directory report</returns>
        public async Task<IQueryable<TalentCsvModel>> TalentDataReportByModel(SearchParameters searchParams, int userId)
        {
            if (searchParams == null)
            {
                throw new ArgumentNullException("searchParams");
            }
            searchParams.SetDefaultsForUnsetProperties();
            IQueryable<Talent> query = _context.Set<Talent>();

            query = query.Include(ta => ta.TalentAddress).ThenInclude(ad => ad.Address).ThenInclude(c => c.City)
                        .Include(tpa => tpa.TalentPhysicalAttribute)
                        .Include(rm => rm.TalentRatingRmark)
                        .Include(s => s.Status);

            #region //filter search conditions // manage talent directory filters
            if (searchParams.SearchFor.ContainsKey("searchBoxTalent"))
            {
                var searchTerm = Convert.ToString(searchParams.SearchFor["searchBoxTalent"]);
                query = query.Where(x => x.FullName.ToLower().Contains(searchTerm) || x.Email.ToLower().Contains(searchTerm) || x.Mobile.Contains(searchTerm));
            }
            if (searchParams.SearchFor.ContainsKey("searchBoxTalentUID"))
            {
                var searchTerm = Convert.ToInt32(searchParams.SearchFor["searchBoxTalentUID"]);
                query = query.Where(x => x.UID == searchTerm);
            }
            query = FilterTalents(query, searchParams);
            #endregion

            var country = _context.Country.ToList();
            var ethnicity = _context.Ethnicity.ToList();
            var language = _context.Language.ToList();
            var tag = _context.Tag.ToList();
            var interestCategory = _context.InterestCategory.ToList();
            var talentCategory = _context.TalentCategory.ToList();

            var talIds = query.Select(q => q.Id).ToList();

            var finalResult = _context.Talent.Where(t => talIds.Contains(t.Id))
                                    .Include(s => s.Status)
                                    .Include(ph => ph.TalentPhysicalAttribute)
                                    .Include(trm => trm.TalentRatingRmark)
                                    .Include(asso => asso.TalentAssociation).Include(edu => edu.TalentEducation).Include(exp => exp.TalentExperience)
                                    .Include(e => e.TalentEthnicity).Include(l => l.TalentLanguage).Include(t => t.TalentTag)
                                    .Include(tic => tic.TalentInterestCategory).Include(ttc => ttc.TalentTalentCategory)
                                .GroupJoin(_context.TalentAddress.Include(ad => ad.Address).ThenInclude(c => c.City), t => t.Id, ta => ta.TalentId, (t, ta) => new { t, ta })
                                .SelectMany(x => x.ta.DefaultIfEmpty(), (t, tadd) => new { t.t, t.ta, tadd })
                                .GroupJoin(_context.Height, ph => ph.t.TalentPhysicalAttribute.HeightId, h => h.Id, (ph, h) => new { ph.t, ph.ta, ph.tadd, h })
                                .GroupJoin(_context.Weight, ph => ph.t.TalentPhysicalAttribute.WeightSizeId, w => w.Id, (ph, w) => new { ph.t, ph.ta, ph.tadd, ph.h, w })
                                .GroupJoin(_context.ChestSize, ph => ph.t.TalentPhysicalAttribute.ChestSizeId, c => c.Id, (ph, c) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, c })
                                .GroupJoin(_context.WaistSize, ph => ph.t.TalentPhysicalAttribute.ChestSizeId, w => w.Id, (ph, waist) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, waist })
                                .GroupJoin(_context.BodyType, ph => ph.t.TalentPhysicalAttribute.BodyTypeId, b => b.Id, (ph, b) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, b })
                                .GroupJoin(_context.SkinColor, ph => ph.t.TalentPhysicalAttribute.SkinColorId, s => s.Id, (ph, s) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, s })
                                .GroupJoin(_context.EyeColor, ph => ph.t.TalentPhysicalAttribute.EyeColorId, e => e.Id, (ph, e) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, e })
                                .GroupJoin(_context.HairColor, ph => ph.t.TalentPhysicalAttribute.HairColorId, hc => hc.Id, (ph, hc) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, ph.e, hc })
                                .GroupJoin(_context.HairLength, ph => ph.t.TalentPhysicalAttribute.HairLengthId, hl => hl.Id, (ph, hl) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, ph.e, ph.hc, hl })
                                .GroupJoin(_context.HairType, ph => ph.t.TalentPhysicalAttribute.HairTypeId, ht => ht.Id, (ph, ht) => new { ph.t, ph.ta, ph.tadd, ph.h, ph.w, ph.c, ph.waist, ph.b, ph.s, ph.e, ph.hc, ph.hl, ht })
                                .Select(t => new TalentCsvModel
                                {
                                    id = t.t.Id,
                                    uid = t.t.UID,
                                    fullName = t.t.FullName,
                                    email = t.t.Email,
                                    gender = ((LoginEnum.Gender)Convert.ToDecimal(ZeroIfEmpty(t.t.Gender))).ToString(),
                                    dob = t.t.DOB != null ? t.t.DOB.GetValueOrDefault().ToString("MM/dd/yyyy") : "",
                                    mobile = string.IsNullOrEmpty(t.t.Mobile) ? "" : (string.IsNullOrEmpty(t.t.MobileCountryCode) ? t.t.Mobile : t.t.MobileCountryCode + " " + t.t.Mobile),
                                    whatsupMobile = string.IsNullOrEmpty(t.t.WhatsupMobile) ? "" : t.t.WhatsupMobile,
                                    talentProfileURL = string.IsNullOrEmpty(t.t.TalentProfileURL) ? "" : t.t.TalentProfileURL,
                                    onboarded = t.t.Onboarded == true ? "Yes" : "No",
                                    profileCompletionPercentage = t.t.CompletionPercentage != null ? t.t.CompletionPercentage : 0,
                                    termsConditionAccepted = t.t.TermsConditionAccepted == true ? "Yes" : "No",
                                    city = t.tadd.Address.City.CityDescription,
                                    status = t.t.Status != null ? t.t.Status.Description : "",
                                    passportCountry = t.t.PassportCountryId != null ? country.Where(x => x.Id == t.t.PassportCountryId).Select(x => x.Name).FirstOrDefault() : "",
                                    passportExpirationDate = t.t.PassportExpirationDate != null ? t.t.PassportExpirationDate.GetValueOrDefault().ToString("MM/dd/yyyy") : "",
                                    VisaYear = string.IsNullOrEmpty(t.t.VisaYear) ? "" : t.t.VisaYear,
                                    VisaType = t.t.VisaType,
                                    aboutMe = string.IsNullOrEmpty(t.t.AboutMe) ? "" : t.t.AboutMe,
                                    guardianName = string.IsNullOrEmpty(t.t.GuardianName) ? "" : t.t.GuardianName,
                                    guardianRelation = string.IsNullOrEmpty(t.t.GuardianRelation) ? "" : t.t.GuardianRelation,
                                    guardianMobile = string.IsNullOrEmpty(t.t.GuardianMobile) ? "" : t.t.GuardianMobile,
                                    guardianEmailId = string.IsNullOrEmpty(t.t.GuardianEmailId) ? "" : t.t.GuardianEmailId,
                                    sharedProfileName = string.IsNullOrEmpty(t.t.SharedProfileName) ? "" : t.t.SharedProfileName,
                                    ftcRating = t.t.FtcRating != null ? t.t.FtcRating : 0,
                                    overallRating = t.t.OverallRating != null ? t.t.OverallRating : 0,
                                    recruiterRating = t.t.RecruiterRating != null ? t.t.RecruiterRating : 0,
                                    interestRating = t.t.InterestRating != null ? t.t.InterestRating : 0,
                                    ratingNotes = string.IsNullOrEmpty(t.t.RatingNotes) ? "" : t.t.RatingNotes,
                                    talentRatingRmark = t.t.TalentRatingRmark.Where(trm => trm.InterestCategoryId != null).Select(trm => trm.TalentId).Contains(t.t.Id) ? "Yes" : "No",
                                    isProfilePrivate = t.t.IsProfilePrivate == true ? "Yes" : "No",
                                    tier = t.t.TierId != 0 ? t.t.Tier.TierDesc : "",
                                    heightInInches = t.h.FirstOrDefault().ShortDescription, //t.t.TalentPhysicalAttribute != null ? (t.t.TalentPhysicalAttribute.HeightId != null ? height.Where(x => x.Id == t.t.TalentPhysicalAttribute.HeightId).FirstOrDefault().ShortDescription : "") : "",
                                    weightInKgs = t.w.FirstOrDefault().Kgs,
                                    chestSizeInInches = t.c.FirstOrDefault().ShortDescription,
                                    waistSizeInInches = t.waist.FirstOrDefault().ShortDescription,
                                    bodyType = t.b.FirstOrDefault().Description,
                                    skinColor = t.s.FirstOrDefault().Description,
                                    eyeColor = t.e.FirstOrDefault().Description,
                                    hairColor = t.hc.FirstOrDefault().Description,
                                    hairLength = t.hl.FirstOrDefault().Description,
                                    hairType = t.ht.FirstOrDefault().Description,
                                    isVerified = t.t.TalentPhysicalAttribute != null ? (t.t.TalentPhysicalAttribute.Verified == true ? "Yes" : "No") : "No",
                                    agencyAgentName = t.t.AgencyId != null ? t.t.AgencyAgentName : "",
                                    agencyAgentEmail = t.t.AgencyId != null ? t.t.AgencyAgentEmail : "",
                                    agencyAgentMobileNo = t.t.AgencyId != null ? t.t.AgencyAgentMobileNo : "",
                                    budget = ZeroIfEmpty(t.t.BudgetMin.ToString()) + "-" + ZeroIfEmpty(t.t.BudgetMax.ToString()),
                                    viewCount = t.t.ViewCount != null ? t.t.ViewCount.ToString() : "0",
                                    //address = string.Join(", ", talentAddress.Where(x => x.TalentId == t.Id).Select(x => address.Where(add => add.Id == x.AddressId).Select(add => add.Line1 + add.Line2 + add.ZipCode).FirstOrDefault()).ToList()),
                                    address = t.tadd.Address.Line1 + t.tadd.Address.Line2 + t.tadd.Address.ZipCode,
                                    ethnicity = string.Join(", ", t.t.TalentEthnicity.Select(x => ethnicity.Where(e => e.Id == x.Ethnicity).Select(e => e.Description).FirstOrDefault()).ToList()),
                                    language = string.Join(", ", t.t.TalentLanguage.Select(x => language.Where(l => l.Id == x.LanguageId).Select(l => l.Description).FirstOrDefault()).ToList()),
                                    tag = string.Join(", ", t.t.TalentTag.Select(x => tag.Where(tg => tg.Id == x.TagId).Select(tg => tg.Name).FirstOrDefault()).ToList()),
                                    interestcategory = string.Join(", ", t.t.TalentInterestCategory.Select(x => interestCategory.Where(i => i.Id == x.InterestCategoryId).Select(i => i.Description).FirstOrDefault()).ToList()),
                                    talentcategory = string.Join(", ", t.t.TalentTalentCategory.Select(x => talentCategory.Where(i => i.Id == x.TalentCategoryId).Select(i => i.Description).FirstOrDefault()).ToList()),
                                    talentAssociation = t.t.TalentAssociation.Select(x => (int)x.TalentId).Distinct().Contains(t.t.Id) ? "Yes" : "No",
                                    talentEducation = t.t.TalentEducation.Select(x => (int)x.TalentId).Distinct().Contains(t.t.Id) ? "Yes" : "No",
                                    talentExperience = t.t.TalentExperience.Select(x => (int)x.TalentId).Distinct().Contains(t.t.Id) ? "Yes" : "No"
                                });

            return finalResult;
        }
        #endregion

        #region Private Methods
        private async Task<bool> SaveTalentRatingParameter(int talentId, ICollection<TalentRatingParameterDto> listTalentRatingParametersDto)
        {
            var talentRatingParametersDto = listTalentRatingParametersDto.ToList();
            if (talentRatingParametersDto.Count > 0)
            {
                var lstRatingParameter = await _talentRatingParameterRepository.FindAllAsync(x => x.TalentId == talentId);

                foreach (var talentRatingParameterDto in ConvertToTalentRatingParameter(talentId, talentRatingParametersDto))
                {
                    var talentRatingParam = await _talentRatingParameterRepository.AddAsync(talentRatingParameterDto);
                }

                if (lstRatingParameter.Count() > 0)
                {
                    foreach (var talentTag in lstRatingParameter)
                    {
                        await _talentRatingParameterRepository.DeleteAsync(talentTag);
                    }
                }

            }
            return true;
        }

        public async Task<bool> SaveTalentRatingInterestCategory(int talentId, ICollection<TalentRatingInterestCategoryDto> talentRatingInterestCategoryDto)
        {
            if (talentRatingInterestCategoryDto != null && talentRatingInterestCategoryDto.Count > 0)
            {
                var origTalentRatingInterestCategoryParam = await _talentRatingInterestCategoryRepository.FindAllAsync(x => x.TalentId == talentId);

                //delete
                foreach (var talentRatingInterestCategory in origTalentRatingInterestCategoryParam)
                {
                    var status = await _talentRatingInterestCategoryRepository.DeleteAsync(talentRatingInterestCategory);
                }

                //insert
                foreach (var talentRatingInterestCategory in ConvertToTalentRatingInterestCategory(talentId, talentRatingInterestCategoryDto))
                {
                    var addedtalentRatingInterestCategory = await _talentRatingInterestCategoryRepository.AddAsync(talentRatingInterestCategory);

                }
            }
            return true;

        }

        private async Task<bool> SaveTalentRatingTalentCategory(int talentId, ICollection<TalentRatingTalentCategoryDto> talentRatingTalentCategoryDto)
        {
            if (talentRatingTalentCategoryDto != null && talentRatingTalentCategoryDto.Count > 0)
            {
                var origTalentRatingTalentCategoryParam = _talentRatingTalentCategoryRepository.FindAll(x => x.TalentId == talentId).ToList();

                //delete
                foreach (var talentRatingTalentCategory in origTalentRatingTalentCategoryParam)
                {
                    var status = await _talentRatingTalentCategoryRepository.DeleteAsync(talentRatingTalentCategory);
                }

                //insert
                foreach (var talentRatingTalentCategory in ConvertToTalentRatingTalentCategory(talentId, talentRatingTalentCategoryDto))
                {
                    var addedtalentRatingTalentCategory = await _talentRatingTalentCategoryRepository.AddAsync(talentRatingTalentCategory);
                }
            }
            return true;
        }

        private static List<TalentRatingParameter> ConvertToTalentRatingParameter(int talentId, ICollection<TalentRatingParameterDto> listTalentRatingParameterDto)
        {
            return listTalentRatingParameterDto.Select(g => new TalentRatingParameter { Rating = g.Rating, RatingParameterId = g.RatingParameterId, TalentId = talentId }).ToList();
        }

        private static List<TalentRatingInterestCategory> ConvertToTalentRatingInterestCategory(int talentId, ICollection<TalentRatingInterestCategoryDto> listTalentRatingInterestCategoryDto)
        {
            return listTalentRatingInterestCategoryDto.Select(g => new TalentRatingInterestCategory { Rating = g.Rating, TalentId = talentId, InterestCategoryId = g.InterestCategoryId }).ToList();
        }

        private static List<TalentRatingRmark> ConvertToTalentRatingRmark(int talentId, ICollection<TalentRatingRmarkDto> listTalentRatingRmarkDto)
        {
            return listTalentRatingRmarkDto.Select(g => new TalentRatingRmark { InterestCategoryId = g.InterestCategoryId, TalentCategoryId = g.TalentCategoryId, TalentId = talentId }).ToList();
        }

        private static List<TalentRatingTalentCategory> ConvertToTalentRatingTalentCategory(int talentId, ICollection<TalentRatingTalentCategoryDto> listTalentRatingTalentCategoryDto)
        {
            return listTalentRatingTalentCategoryDto.Select(g => new TalentRatingTalentCategory { Rating = g.Rating, TalentCategoryId = g.TalentCategoryId, TalentId = talentId }).ToList();
        }

        private string ZeroIfEmpty(string s)
        {
            return (string.IsNullOrEmpty(s) || s == null || s == "null") ? "0" : s;
        }
        #endregion
    }
}
