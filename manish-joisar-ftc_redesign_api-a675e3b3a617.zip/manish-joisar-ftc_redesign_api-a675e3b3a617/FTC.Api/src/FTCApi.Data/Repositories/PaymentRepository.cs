﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.AdminReports;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.PaymentDtos;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Razorpay;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTCApi.Data.Repositories
{
    public class PaymentRepository : GenericRepository<TalentPlan>, IPaymentRepository
    {

        #region Private Constants

        private const string AMOUNT = "amount";
        private const string STATUS = "status";
        private const string CREATED = "created";
        private const string CAPTURED = "captured";

        #endregion

        #region Private Variable

        private IRazorPayStagingRepository _razorPayStagingRepository;

        private ITalentTransactionRepository _talentTransactionRepository;

        private ITalentTransactionDetailRepository _talentTransactionDetailRepository;
        private IAuxiliaryRecruiterTransactionRepository _auxiliaryRecruiterTransactionRepository;
        private IProjectRepository _projectRepository;
        private ITalentPlanRepository _talentPlanRepository;
        private ITalentPlanFeatureRepository _talentPlanFeatureRepository;
        private ITalentRepository _talentRepository;
        private IRecruiterPlanRepository _recruiterPlanRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;


        #endregion

        #region Constructor

        public PaymentRepository(FTCDbContext context, IRazorPayStagingRepository razorPayStagingRepository, ITalentTransactionRepository talentTransactionRepository,
            ITalentTransactionDetailRepository talentTransactionDetailRepository, IAuxiliaryRecruiterTransactionRepository auxiliaryRecruiterTransactionRepository,
            ITalentPlanRepository talentPlanRepository, ITalentPlanFeatureRepository talentPlanFeatureRepository, IProjectRepository projectRepository,
            ITalentRepository talentRepository,
            IRecruiterPlanRepository recruiterPlanRepository,
            IAuxiliaryUserRepository auxiliaryUserRepository) : base(context)
        {
            _razorPayStagingRepository = razorPayStagingRepository;
            _talentTransactionRepository = talentTransactionRepository;
            _talentTransactionDetailRepository = talentTransactionDetailRepository;
            _auxiliaryRecruiterTransactionRepository = auxiliaryRecruiterTransactionRepository;
            _projectRepository = projectRepository;
            _talentPlanRepository = talentPlanRepository;
            _talentPlanFeatureRepository = talentPlanFeatureRepository;
            _talentRepository = talentRepository;
            _recruiterPlanRepository = recruiterPlanRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
        }

        #endregion

        #region Public Methods               

        /// <summary>
        /// 
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns></returns>
        public async Task<List<Dtos.PaymentDtos.TalentPlanDto>> GetTalentPlans(int talentId)
        {
            IQueryable<TalentPlan> planContext = _context.Set<TalentPlan>().Where(x => x.StatusId == (int)StatusEnum.Active);

            IQueryable<TalentTransactionDetail> talentTransactionDetailContext = _context.Set<TalentTransactionDetail>();

            var plans = planContext.Include(p => p.TalentPlanFeature).ThenInclude(g => g.TalentFeature).ToList();

            var transactionDetails = await talentTransactionDetailContext.Where(g => g.TalentTransaction.TalentId == talentId).ToListAsync();

            var plansDetails = plans.Select(g => new Dtos.PaymentDtos.TalentPlanDto
            {
                Amount = g.Amount,
                Description = g.Description,
                Brief = g.Brief,
                Name = g.Name,
                Period = g.Period,
                PlanId = g.Id,
                Features = g.TalentPlanFeature
                                  .Select(f => new TalentPlanFeatures
                                  {
                                      AudioCount = f.AudioCount,
                                      Description = f.TalentFeature.Desc,
                                      ImageCount = f.ImageCount,
                                      ScriptCount = f.ScriptCount,
                                      TalentFeatureId = f.TalentFeatureId,
                                      VideoCount = f.VideoCount
                                  }).ToList(),
                IsSubscribed = transactionDetails.Count > 0 ? transactionDetails.Any(p => (p.EndDate.HasValue ? p.EndDate >= DateTime.UtcNow.Date : false) && p.TalentPlanId == g.Id) : false,
                EndDate = transactionDetails.Count > 0 ? transactionDetails.Where(p => p.TalentPlanId == g.Id && (p.EndDate.HasValue ? p.EndDate >= DateTime.UtcNow.Date : false)).OrderByDescending(f => f.EndDate).Select(e => e.EndDate).FirstOrDefault() : null

            }).ToList();

            return await Task.Run(() => plansDetails);
        }

        public async Task<Order> CreateOrder(Credentials credentials, int userId, Dictionary<string, object> data, int userType)
        {
            var client = new RazorpayClient(credentials.Key, credentials.Secret);

            data[AMOUNT] = Convert.ToInt32(data[AMOUNT]) * 100; // The amount of payment in paisa. e.g. If amount = 100, it means Re 1

            var order = await client.Order.Create(data);

            //This call save talent staging details in FTC database
            await SaveStagingTransaction(userId, order, userType);

            return await Task.Run(() => order);
        }


        public async Task<Payment> CapturePayment(Credentials credentials, PaymentRequest paymentRequest)
        {
            var client = new RazorpayClient(credentials.Key, credentials.Secret);

            //This call is to verify payment signature
            VerifyPaymentSignature(paymentRequest);

            //This call is use to fetch payment 
            var payment = (Payment)await client.Payment.Fetch(paymentRequest.PaymentId);

            var planList = PopulatePlans(paymentRequest);

            var amount = planList.Sum(s => s.Amount);

            var options = new Dictionary<string, object>();
            options.Add(AMOUNT, amount * 100); //Important: amount need to pass razor api is in paisa

            //This call capture payment in Razorpay
            var paymentCaptured = await payment.Capture(options);

            var status = paymentCaptured.Attributes[STATUS];

            var paymentCapturResponse = JsonConvert.SerializeObject(paymentCaptured);

            //This call upddate paymentId in staging table in FTC database
            await UpdateStagingTransaction(paymentRequest.TalentId, paymentRequest.OrderId, paymentRequest.PaymentId, paymentCapturResponse);

            //This call insert transaction in FTC database
            await SaveTalentTransaction(paymentRequest, planList, amount, paymentCapturResponse, Convert.ToString(status));

            return await Task.Run(() => paymentCaptured);
        }

        public async Task<Payment> CaptureRecruiterPayment(Credentials credentials, PaymentRequest paymentRequest)
        {
            var client = new RazorpayClient(credentials.Key, credentials.Secret);

            //This call is to verify payment signature
            VerifyPaymentSignature(paymentRequest);

            //This call is use to fetch payment 
            var payment = (Payment)await client.Payment.Fetch(paymentRequest.PaymentId);

            var planList = PopulateRecruiterPlans(paymentRequest);

            //find the previous plan of project

            var project = await _projectRepository.FindAsync(x => x.Id == paymentRequest.ProjectId);
            var previousPlan = default(RecruiterPlan);
            if (project != null)
            {
                previousPlan = _context.Set<RecruiterPlan>().Where(x => x.Id == project.PlanId).FirstOrDefault();
            }

            var amount = planList.Sum(s => s.Amount);

            //check if the amount is same for selected plan and previous plan i.e user is paying first time
            if (amount != previousPlan.Amount)
            {
                amount = planList.Sum(s => s.Amount) - previousPlan.Amount;
            }

            var options = new Dictionary<string, object>();
            options.Add(AMOUNT, amount * 100); //Important: amount need to pass razor api is in paisa

            //This call capture payment in Razorpay
            var paymentCaptured = await payment.Capture(options);

            var status = paymentCaptured.Attributes[STATUS].ToString();

            var paymentCapturResponse = JsonConvert.SerializeObject(paymentCaptured);

            //This call upddate paymentId in staging table in FTC database
            await UpdateRecruiterStagingTransaction(paymentRequest.AuxiliaryUserId, paymentRequest.OrderId, paymentRequest.PaymentId, paymentCapturResponse);

            //This call insert transaction in FTC database
            await SaveRecruiterTransaction(paymentRequest, amount, paymentCapturResponse, status);

            return await Task.Run(() => paymentCaptured);
        }

        public async Task<TalentPlan> SaveTalentPlan(PlanFeatureDto planFeatureDto, int userId)
        {
            var talentPlan = new TalentPlan()
            {
                Name = planFeatureDto.Name,
                Period = planFeatureDto.Period,
                Amount = planFeatureDto.Amount,
                Brief = planFeatureDto.Brief,
                Description = planFeatureDto.Description,
                StatusId = (int)StatusEnum.Active,
                CreatedBy = userId
            };

            talentPlan = await _talentPlanRepository.AddAsync(talentPlan);
            return talentPlan;
        }

        public async Task<List<TalentPlanFeature>> SaveTalentPlanFeatures(short talentPlanId, PlanFeatureDto planFeatureDto)
        {
            var lstTalentPlanFeature = new List<TalentPlanFeature>();
            foreach (var feature in planFeatureDto.Features)
            {
                var talentPlanFeature = new TalentPlanFeature()
                {
                    TalentPlanId = talentPlanId,
                    TalentFeatureId = feature.TalentFeatureId,
                    ImageCount = feature.ImageCount,
                    VideoCount = feature.VideoCount,
                    AudioCount = feature.AudioCount,
                    ScriptCount = feature.ScriptCount
                };

                talentPlanFeature = await _talentPlanFeatureRepository.AddAsync(talentPlanFeature);
                lstTalentPlanFeature.Add(talentPlanFeature);
            }

            return lstTalentPlanFeature;
        }

        public async Task<PaymentStatsReport> GetTalentTransactions(DailyStats requestParam, int? talentId = 0)
        {
            IQueryable<TalentTransaction> query = _context.Set<TalentTransaction>();

            query = query.Include(talentTransaction => talentTransaction.TalentTransactionDetail)
                        .Include(talentTransaction => talentTransaction.Talent);


            if (talentId > 0)
            {
                query = query.Where(x => x.TalentId == talentId);
            }

            var talentTransactions = query.Where(x => x.CreatedOn.Date >= requestParam.FromDate.Date
                                            && x.CreatedOn.Date <= requestParam.ToDate.Date)
                                        .Select(tt => new
                                        {
                                            tt.Id,
                                            Talent = new { tt.Talent.Id, tt.Talent.FullName, tt.Talent.UID },
                                            //tt.TalentId,
                                            tt.CreatedOn,
                                            TalentTransactionDetail = tt.TalentTransactionDetail.Select(ttd => new
                                            {
                                                ttd.Id,
                                                ttd.TalentPlanId,
                                                ttd.EndDate,
                                                TalentPlan = new { ttd.TalentPlan.Id, ttd.TalentPlan.Name, ttd.TalentPlan.Amount }
                                            })
                                        })
                                        .OrderByDescending(x => x.CreatedOn);

            //.ToList();

            //talentTransactions = talentTransactions.OrderByDescending(x => x.CreatedOn);

            float totalAmount = 0;

            var lstTalentPaymentStats = new List<PaymentStats>();
            foreach (var talentTransaction in talentTransactions)
            {
                var talentTransactionDetails = talentTransaction.TalentTransactionDetail;
                foreach (var talentTransactionDetail in talentTransactionDetails)
                {
                    //var talentPlan = await GetPlanName(talentTransactionDetail.TalentPlanId);
                    var paymentStats = new PaymentStats()
                    {
                        Name = talentTransaction.Talent.FullName,
                        UID = talentTransaction.Talent.UID,
                        PlanName = talentTransactionDetail.TalentPlan.Name,
                        PurchaseDate = talentTransaction.CreatedOn,
                        ExpiryDate = talentTransactionDetail.EndDate,
                        Amount = talentTransactionDetail.TalentPlan.Amount                              // talent plan amount NOT talentTransaction amount
                    };
                    totalAmount += (float)talentTransactionDetail.TalentPlan.Amount;                 // talent plan amount NOT talentTransaction amount
                    lstTalentPaymentStats.Add(paymentStats);
                }
            }
            var paymentStatsReport = new PaymentStatsReport
            {
                TalentPaymentStats = lstTalentPaymentStats,
                TotalAmount = totalAmount
            };
            return paymentStatsReport;
        }

        public async Task<PaymentStatsReport> GetRecruiterTransactions(DailyStats requestParam)
        {
            IQueryable<AuxiliaryRecruiterTransaction> query = _context.Set<AuxiliaryRecruiterTransaction>();

            query = query.Include(art => art.Project).Include(art => art.TransactionType);

            var auxiliaryUserTransactions = query.Where(x => x.CreatedOn.Date >= requestParam.FromDate.Date
                                                    && x.CreatedOn.Date <= requestParam.ToDate.Date)
                                            .Select(art => new
                                            {
                                                art.Id,
                                                art.CreatedOn,
                                                art.Amount,
                                                art.ProjectId,
                                                art.PlanId,
                                                art.TransactionTypeId,
                                                art.TransactionType,
                                                Project = new { art.Project.Name, art.Project.PlanId },
                                                AuxiliaryUserName = art.Project.AuxiliaryUser.FullName
                                            })
                                            .OrderByDescending(x => x.CreatedOn)
                                            .ToList();

            float totalAmount = 0;

            var lstRecruiterPaymentStats = new List<PaymentStats>();
            foreach (var auxiliaryUserTransaction in auxiliaryUserTransactions)
            {
                var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == (auxiliaryUserTransaction.PlanId ?? 0));
                var paymentStats = new PaymentStats()
                {
                    PurchaseDate = auxiliaryUserTransaction.CreatedOn,
                    Amount = auxiliaryUserTransaction.Amount,
                    PlanName = (recruiterPlan != null) ? recruiterPlan.Name : "",
                    Name = auxiliaryUserTransaction.AuxiliaryUserName,
                    ProjectName = auxiliaryUserTransaction.Project.Name,
                    ExpiryDate = auxiliaryUserTransaction.CreatedOn.AddMonths((recruiterPlan != null) ? (int)recruiterPlan.ManageContract : 0),
                    TransactionType = auxiliaryUserTransaction.TransactionType != null ? auxiliaryUserTransaction.TransactionType.Description : ""

            };
            totalAmount += (float)auxiliaryUserTransaction.Amount;
            lstRecruiterPaymentStats.Add(paymentStats);
        }

        var paymentStatsReport = new PaymentStatsReport
        {
            RecruiterPaymentStats = lstRecruiterPaymentStats,
            TotalAmount = totalAmount
        };

            return paymentStatsReport;

        }

    #endregion

    #region Private Methods

    private async Task UpdateRecruiterStagingTransaction(int auxiliaryUserId, string orderId, string paymentId, string response)
    {
        var razorPayStaging = await _razorPayStagingRepository.FindAsync(s => s.OrderId == orderId && s.AuxiliaryUserId == auxiliaryUserId);
        if (razorPayStaging != null)
        {
            razorPayStaging.PaymentId = paymentId;
            razorPayStaging.Response = response;
        }

        await _razorPayStagingRepository.UpdateAsync(razorPayStaging);
    }
    private async Task UpdateStagingTransaction(int talentId, string orderId, string paymentId, string response)
    {
        var razorPayStaging = await _razorPayStagingRepository.FindAsync(s => s.OrderId == orderId && s.TalentId == talentId);
        if (razorPayStaging != null)
        {
            razorPayStaging.PaymentId = paymentId;
            razorPayStaging.Response = response;
        }

        await _razorPayStagingRepository.UpdateAsync(razorPayStaging);
    }

    private async Task SaveStagingTransaction(int userid, Order order, int userType)
    {
        var razorPayStaging = new RazorPayStaging
        {
            CreatedOn = DateTime.UtcNow,
            Response = JsonConvert.SerializeObject(order),
            StatusId = GetStatusId(order.Attributes[STATUS].ToString()),
            OrderId = order.Attributes["id"].ToString()
        };

        if (userType == Convert.ToInt32(LoginUserType.Talent))
        {
            razorPayStaging.TalentId = userid;
        }
        else
        {
            razorPayStaging.AuxiliaryUserId = userid;
        }

        var ordera = await _razorPayStagingRepository.AddAsync(razorPayStaging);
    }

    private static int GetStatusId(string status)
    {

        var statusId = 0;
        switch (status.ToLower())
        {
            case CREATED:
                statusId = (int)StatusEnum.Created;
                break;
            case CAPTURED:
                statusId = (int)StatusEnum.Paid;
                break;
            default:
                statusId = (int)StatusEnum.Attempted;
                break;
        }
        return statusId;
    }

    private async Task SaveTalentTransaction(PaymentRequest paymentRequest, List<TalentPlan> planList, float? amount, string paymentCaptured, string status)
    {
        var talentTransaction = new TalentTransaction
        {
            Amount = amount,
            OrderId = paymentRequest.OrderId,
            PaymentGatewayResponse = paymentCaptured,
            PaymentId = paymentRequest.PaymentId,
            TalentId = paymentRequest.TalentId,
            StatusId = GetStatusId(status)
        };

        var transaction = await _talentTransactionRepository.AddAsync(talentTransaction);

        if (planList != null)
        {
            foreach (TalentPlan plan in planList)
            {
                var talentTransactionDetail = new TalentTransactionDetail
                {
                    TalentPlanId = plan.Id,
                    TalentTransactionId = transaction.Id,
                    EndDate = DateTime.UtcNow.AddMonths(plan.Period.Value).Date //This calculate end date
                };
                await _talentTransactionDetailRepository.AddAsync(talentTransactionDetail);
            }
        }
    }
    private async Task SaveRecruiterTransaction(PaymentRequest paymentRequest, float? amount, string paymentCaptured, string status)
    {
        var recruiterTransaction = new AuxiliaryRecruiterTransaction
        {
            Amount = amount,
            OrderId = paymentRequest.OrderId,
            PlanId = paymentRequest.Plans[0],
            PaymentGatewayResponse = paymentCaptured,
            PaymentId = paymentRequest.PaymentId,
            ProjectId = paymentRequest.ProjectId,
            TransactionTypeId = (short)paymentRequest.TransactionTypeId,
            StatusId = GetStatusId(status)
        };

        var transaction = await _auxiliaryRecruiterTransactionRepository.AddAsync(recruiterTransaction);
        var project = await _projectRepository.FindAsync(x => x.Id == paymentRequest.ProjectId);
        project.IsPaid = true;
        project.StatusId = (int)StatusEnum.Active;
        project = await _projectRepository.UpdateAsync(project);
    }
    private List<TalentPlan> PopulatePlans(PaymentRequest paymentRequest)
    {
        var planList = new List<TalentPlan>();
        if (paymentRequest != null && paymentRequest.Plans.Any())
        {
            IQueryable<TalentPlan> planContext = _context.Set<TalentPlan>();

            foreach (int id in paymentRequest.Plans)
            {
                planList.Add(planContext.FirstOrDefault(s => s.Id == id));
            }
        }

        return planList;
    }


    private List<RecruiterPlan> PopulateRecruiterPlans(PaymentRequest paymentRequest)
    {
        var planList = new List<RecruiterPlan>();
        if (paymentRequest != null && paymentRequest.Plans.Any())
        {
            IQueryable<RecruiterPlan> planContext = _context.Set<RecruiterPlan>();

            foreach (int id in paymentRequest.Plans)
            {
                planList.Add(planContext.FirstOrDefault(s => s.Id == id));
            }
        }

        return planList;
    }

    private static void VerifyPaymentSignature(PaymentRequest paymentRequest)
    {
        var attributes = new Dictionary<string, string>();
        attributes.Add("razorpay_payment_id", paymentRequest.PaymentId);
        attributes.Add("razorpay_order_id", paymentRequest.OrderId);
        attributes.Add("razorpay_signature", paymentRequest.Signature);

        Utils.verifyPaymentSignature(attributes);
    }

    #region  Optimised code from admin Reports - payment
    //private async Task<string> GetRecruiterName(int? auxiliaryUserId)
    //{
    //    IQueryable<AuxiliaryUser> query = _context.Set<AuxiliaryUser>();

    //    var recruiterName = await query.Where(x => x.Id == auxiliaryUserId).Select(x => x.FullName).SingleOrDefaultAsync();
    //    return (recruiterName != null) ? recruiterName : String.Empty;
    //}

    //private async Task<string> GetRecruiterPlanName(int? planId)
    //{
    //    IQueryable<RecruiterPlan> query = _context.Set<RecruiterPlan>();

    //    var recruiterPlanName = await query.Where(x => x.Id == (planId ?? 0)).Select(x => x.Name).SingleOrDefaultAsync();
    //    return (recruiterPlanName != null) ? recruiterPlanName : String.Empty;
    //}

    //private async Task<dynamic> GetPlanName(short talentPlanId)
    //{
    //    IQueryable<TalentPlan> query = _context.Set<TalentPlan>();

    //    var talentPlanName = await query.Where(x => x.Id == talentPlanId).Select(x => new { x.Name, x.Amount }).SingleOrDefaultAsync();
    //    return talentPlanName;
    //}

    //private async Task<string> GetTalentName(int talentId)
    //{
    //    IQueryable<Talent> query = _context.Set<Talent>();
    //    var talentName = await query.Where(x => x.Id == talentId).Select(x => x.FullName).SingleOrDefaultAsync();
    //    return (talentName != null) ? talentName : String.Empty;
    //}
    #endregion

    #endregion

}
}
