﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentMediaRepository: GenericRepository<TalentMedia>,ITalentMediaRepository
    {
        public TalentMediaRepository(FTCDbContext context):base(context)
        {

        }   
    }
}
