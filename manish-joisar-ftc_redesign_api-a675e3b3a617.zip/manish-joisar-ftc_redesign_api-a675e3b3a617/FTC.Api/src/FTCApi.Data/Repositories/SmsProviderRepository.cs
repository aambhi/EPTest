﻿using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Notification;
using System;
using System.Threading.Tasks;
using static FTC.SMSProvider.SMSGatewayFactory;

namespace FTCApi.Data.Repositories
{
    public class SmsProviderRepository : GenericRepository<MstSmsGateway>, ISmsProviderRepository
    {

        #region Constants

        private const string DOMESTICCOUNTRYCODE = "91";
        private const string PHONON = "phonon";
        private const string TWILIO = "twilio";

        #endregion

        #region Private Variables

        private ITraceSmsGatewayRepository _traceSmsGatewayRepository;
        private ITraceEmailGatewayRepository _traceEmailGatewayRepository;

        #endregion

        #region Constructors

        public SmsProviderRepository(FTCDbContext context, ITraceSmsGatewayRepository traceSmsGatewayRepository, ITraceEmailGatewayRepository traceEmailGatewayRepository) : base(context)
        {
            _traceSmsGatewayRepository = traceSmsGatewayRepository;
            _traceEmailGatewayRepository = traceEmailGatewayRepository;
        }

        #endregion

        #region Public Methods

        public async Task<TraceEmailGateway> TraceEmail(TraceEmailGateway traceEmailGateway)
        {

            return await _traceEmailGatewayRepository.AddAsync(traceEmailGateway);
        }


        public async Task SendSMS(SMSGatewayParam smsGatewayParam)
        {
            var smsProvider = await GetProviderInfo(smsGatewayParam.MobileCountryCode);
            var gateway = ChooseGateway(smsProvider.Name);
            var factory = new SMSProviderFactory();
            var iProvider = factory.GetProvider(gateway);

            var traceSmsGateway = new TraceSmsGateway
            {
                AuxiliaryUserId = smsGatewayParam.AuxiliaryUserId == 0 ? null : smsGatewayParam.AuxiliaryUserId,
                TalentId = smsGatewayParam.TalentId == 0 ? null : smsGatewayParam.TalentId,
                CountryCode = smsGatewayParam.MobileCountryCode,
                Message = smsGatewayParam.Message,
                Mobile = smsGatewayParam.MobileNumber,
                CreatedOn = DateTime.UtcNow,
                SmsGatewayId = (short)gateway,
            };

            var traceSMSGateway = await _traceSmsGatewayRepository.AddAsync(traceSmsGateway);

            string response = string.Empty;
            try
            {
                response = await iProvider.SendMessage(smsProvider, smsGatewayParam, traceSMSGateway.Id);
                traceSMSGateway.Sent = true;
            }
            catch (Exception ex)
            {
                response = ex.ToString();
                traceSMSGateway.Sent = false;
                throw ex;
            }
            finally
            {
                var request = iProvider.GetRequestString(smsProvider, smsGatewayParam, traceSMSGateway.Id);
                //Update Response and status
                traceSMSGateway.SmsResponse = response;
                traceSMSGateway.SmsRequest = request;
                await _traceSmsGatewayRepository.UpdateAsync(traceSmsGateway);
            }
        }

        #endregion

        #region Private Methods

        private static bool IsDomesticNumber(string mobileCountryCode)
        {
            return mobileCountryCode.Contains(DOMESTICCOUNTRYCODE);

        }

        private static SMSGatways ChooseGateway(string name)
        {
            switch (name.ToLower())
            {
                case PHONON:
                    return SMSGatways.PHONON;
                case TWILIO:
                    return SMSGatways.TWILIO;
                default:
                    return SMSGatways.PHONON;
            }

        }

        private async Task<SMSGateway> GetProviderInfo(string mobileCountryCode)
        {
            var smsGateways = await this.FindAllAsync(c => c.DomesticDefault || c.InternationalDefault);

            SMSGateway smsGateway = null;
            foreach (var gateway in smsGateways)
            {
                if (IsDomesticNumber(mobileCountryCode))
                {
                    if (gateway.DomesticDefault)
                    {
                        smsGateway = new SMSGateway
                        {
                            BaseUrl = gateway.BaseUrl,
                            Name = gateway.Name,
                            Password = gateway.DomesticPassword,
                            RequestUrl = gateway.RequestUrl,
                            UserName = gateway.DomesticUserid,
                            IsDomestic = true

                        };
                    }
                }
                else
                {

                    if (gateway.InternationalDefault)
                    {
                        smsGateway = new SMSGateway
                        {
                            BaseUrl = gateway.BaseUrl,
                            Name = gateway.Name,
                            Password = gateway.InternationalPassword,
                            RequestUrl = gateway.RequestUrl,
                            UserName = gateway.InternationalUserid,
                            IsDomestic = false

                        };
                    }
                }
            }
            return smsGateway;
        }
        #endregion

    }
}
