﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentPhysicalAttributeRepository:GenericRepository<TalentPhysicalAttribute>, ITalentPhysicalAttributeRepository
    {
        public TalentPhysicalAttributeRepository(FTCDbContext context):base(context)
        {
                
        }
    }
}
