﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentAddressRepository: GenericRepository<TalentAddress>,ITalentAddressRepository
    {
        public TalentAddressRepository(FTCDbContext context):base(context)
        {

        }
    }
}
