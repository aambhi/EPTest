﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentInterestCategoryRepository:GenericRepository<TalentInterestCategory>, ITalentInterestCategoryRepository
    {
        public TalentInterestCategoryRepository(FTCDbContext context):base(context)
        {

        }
    }
}
