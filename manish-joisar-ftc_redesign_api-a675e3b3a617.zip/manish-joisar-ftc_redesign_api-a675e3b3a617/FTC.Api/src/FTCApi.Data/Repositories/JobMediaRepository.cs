﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class JobMediaRepository:GenericRepository<JobMedia>, IJobMediaRepository
    {
        public JobMediaRepository(FTCDbContext context):base(context)
        {

        }
    }
}
