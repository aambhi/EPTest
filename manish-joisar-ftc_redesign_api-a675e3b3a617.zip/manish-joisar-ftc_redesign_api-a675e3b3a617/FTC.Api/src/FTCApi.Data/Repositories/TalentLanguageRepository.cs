﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentLanguageRepository:GenericRepository<TalentLanguage>, ITalentLanguageRepository
    {
        public TalentLanguageRepository(FTCDbContext context):base(context)
        {

        }
    }
}
