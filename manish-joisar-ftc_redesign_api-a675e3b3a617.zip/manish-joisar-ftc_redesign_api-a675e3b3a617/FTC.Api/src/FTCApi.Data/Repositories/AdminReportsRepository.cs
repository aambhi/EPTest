﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FTCApi.Dtos.AdminReports;
using FTCApi.Dtos;

namespace FTCApi.Data.Repositories
{
    public class AdminReportsRepository : GenericRepository<Talent>, IAdminReportsRepository
    {
        public AdminReportsRepository(FTCDbContext context) : base(context)
        {
        }

        //public async Task<List<Talent>> GetNewTalents(DailyStats requestParam)
        //{
        //    IQueryable<Talent> query = _context.Set<Talent>().Include(x => x.TalentToken);

        //    var newTalent = await query.Where(x => x.CreatedOn.Date >= requestParam.FromDate.Date && x.CreatedOn.Date <= requestParam.ToDate.Date)
        //                               .ToListAsync();

        //    return newTalent;
        //}


        public async Task<List<TalentDailyStatsDto>> GetNewTalents(DailyStats requestParam)
        {
            IQueryable<Talent> query = _context.Set<Talent>().Include(x => x.TalentToken);

            var newTalent = await query.Where(x => x.CreatedOn.Date >= requestParam.FromDate.Date && x.CreatedOn.Date <= requestParam.ToDate.Date)
                                        .Select(x => new
                                        {
                                            TalentId = x.Id,
                                            UID = x.UID,
                                            CreatedOn = x.CreatedOn,
                                            x.TalentToken
                                        })
                                       .ToListAsync();

            var newTalentDto = newTalent.Select(x => new TalentDailyStatsDto()
            {
                CreatedOn = x.CreatedOn,
                TalentId = x.TalentId,
                UID = x.UID,
                LoginType = x.TalentToken.FirstOrDefault().LoginType
            }).ToList();

            return newTalentDto;
        }

    }
}
