﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobStatusRepository : GenericRepository<ProjectJobStatus>, IProjectJobStatusRepository
    {
        public ProjectJobStatusRepository(FTCDbContext context) : base(context)
        {

        }
    }
}
