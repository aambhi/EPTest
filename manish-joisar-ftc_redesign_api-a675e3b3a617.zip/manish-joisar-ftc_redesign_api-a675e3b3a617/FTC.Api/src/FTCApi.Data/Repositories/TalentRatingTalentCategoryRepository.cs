﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentRatingTalentCategoryRepository : GenericRepository<TalentRatingTalentCategory>, ITalentRatingTalentCategoryRepository
    {

        public TalentRatingTalentCategoryRepository(FTCDbContext context) : base(context)
        {

        }

    }
}
