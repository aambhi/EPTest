﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class TalentStatusHistoryRepository:GenericRepository<TalentStatusHistory>, ITalentStatusHistoryRepository
    {
        public TalentStatusHistoryRepository(FTCDbContext context):base(context)
        {

        }
    }
}
