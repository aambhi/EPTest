﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentTokenRepository:GenericRepository<TalentToken>, ITalentTokenRepository
    {
        public TalentTokenRepository(FTCDbContext context):base(context)
        {

        }
    }
}
