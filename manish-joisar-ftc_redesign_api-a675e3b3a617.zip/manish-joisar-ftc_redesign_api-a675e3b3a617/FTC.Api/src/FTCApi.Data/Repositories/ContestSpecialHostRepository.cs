﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ContestSpecialHostRepository:GenericRepository<ContestSpecialHost>, IContestSpecialHostRepository
    {
        public ContestSpecialHostRepository(FTCDbContext context):base(context)
        {

        }
    }
}
