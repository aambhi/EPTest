﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTCApi.Data.Repositories
{
    public class ContestRepository : GenericRepository<Contest>, IContestRepository
    {
        public ContestRepository(FTCDbContext context) : base(context)
        {

        }

        public async Task<Contest> GetContestById(int id, int userId, int userType)
        {
            IQueryable<Contest> query;
            if (userType == (int)LoginUserType.FTCAdmin)
            {
                query = _context.Set<Contest>().Where(x => x.Id == id);
            }
            else
            {
                query = _context.Set<Contest>().Where(x => x.Id == id && x.AuxiliaryUserId == userId);
            }
            
            var contest = await query.Include(x => x.Submission)
                                    .Include(x => x.Status)
                                    .Include(x => x.AuxiliaryUser)
                                    .Include(x => x.MediaFileType)
                                    .Include(x => x.Type)
                                    .Include(x => x.ContestProvider)
                                    .FirstOrDefaultAsync();

            return contest;
        }
    }
}
