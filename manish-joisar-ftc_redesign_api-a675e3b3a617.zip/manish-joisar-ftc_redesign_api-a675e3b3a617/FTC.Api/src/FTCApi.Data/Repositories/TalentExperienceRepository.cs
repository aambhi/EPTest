﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentExperienceRepository: GenericRepository<TalentExperience>, ITalentExperienceRepository
    {
        public TalentExperienceRepository(FTCDbContext context):base(context)
        {

        }
    }
}
