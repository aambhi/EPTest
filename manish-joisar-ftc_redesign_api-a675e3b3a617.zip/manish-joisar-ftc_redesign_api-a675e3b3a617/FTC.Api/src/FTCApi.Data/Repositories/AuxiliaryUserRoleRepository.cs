﻿using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserRoleRepository : GenericRepository<AuxiliaryUserRole>, IAuxiliaryUserRoleRepository
    {
        public AuxiliaryUserRoleRepository(FTCDbContext context) : base(context)
        {

        }


        public async Task<bool> CheckAssignedInRole(int userId)
        {
            var inRole = false;
            var userRole =await this.FindAllAsync(c => c.AuxiliaryUserId == userId);
            if (userRole != null)
            {
                inRole = userRole.Any(c => (c.RoleId == (int)UserRole.FTCProjectAdmin)
                || (c.RoleId == (int)UserRole.JobAdmin)
                || (c.RoleId == (int)UserRole.ProjectAdmin)
                || (c.RoleId == (int)UserRole.RecruiterAdmin));
            }

            return inRole;
        }


        public void CheckUserRole(IEnumerable<AuxiliaryUserRole> userRole, out bool isProjectAdmin, out bool isJobAdmin, out bool isFtcProjectAdmin)
        {
            isProjectAdmin = false;
            isFtcProjectAdmin = false;
            isJobAdmin = false;
            if (userRole != null)
            {
                isProjectAdmin = userRole.Any(c => (c.RoleId == (int)UserRole.ProjectAdmin));

                isJobAdmin = userRole.Any(c => (c.RoleId == (int)UserRole.JobAdmin));

                isFtcProjectAdmin = userRole.Any(c => (c.RoleId == (int)UserRole.FTCProjectAdmin));
            }
        }

        public void CheckUserRole(IEnumerable<AuxiliaryUserRole> userRole, out bool isFtcRecruiterAdmin)
        {
            isFtcRecruiterAdmin = false;
            

            if (userRole != null)
            {
                isFtcRecruiterAdmin = userRole.Any(c => (c.RoleId == (int)UserRole.RecruiterAdmin));
            }
        }

    }
}
