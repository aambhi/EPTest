﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentEducationRepository: GenericRepository<TalentEducation>, ITalentEducationRepository
    {
        public TalentEducationRepository(FTCDbContext context):base(context)
        {

        }   
    }
}
