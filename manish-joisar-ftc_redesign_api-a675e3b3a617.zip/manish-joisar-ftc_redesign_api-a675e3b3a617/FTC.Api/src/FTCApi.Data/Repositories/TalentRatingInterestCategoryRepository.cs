﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentRatingInterestCategoryRepository : GenericRepository<TalentRatingInterestCategory>, ITalentRatingInterestCategoryRepository
    {

        public TalentRatingInterestCategoryRepository(FTCDbContext context) : base(context)
        {

        }

    }
}
