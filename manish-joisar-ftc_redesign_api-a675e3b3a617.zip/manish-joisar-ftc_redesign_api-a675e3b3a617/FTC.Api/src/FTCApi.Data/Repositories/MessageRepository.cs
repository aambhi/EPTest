﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.ChatDtos;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTCApi.Data.Repositories
{
    public class MessageRepository : GenericRepository<Core.Models.Message>, IMessageRepository
    {
        #region Private variables

        private IAuxiliaryUserRepository _auxiliaryUserRepository;

        private ITalentRepository _talentRepository;


        #endregion

        #region Constructor

        public MessageRepository(FTCDbContext context, IAuxiliaryUserRepository auxiliaryUserRepository, ITalentRepository talentRepository) : base(context)
        {
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _talentRepository = talentRepository;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// This method is use to get talent messages
        /// </summary>
        /// <param name="talentId"></param>
        /// <param name="jobId"></param>
        /// <returns>returns list of talent message based on jobId</returns>
        public async Task<Job> GetTalentMessagesAsync(int talentId, int jobId)
        {
            var talentJob = GetTalentMessages(talentId, jobId, (int)LoginUserType.Recruiter);
            return await Task.Run(() => talentJob);
        }

        /// <summary>
        /// This method return list of unread count.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userType"></param>
        /// <returns></returns>
        public async Task<dynamic> GetMessageUnreadCount(int userId,int userType)
        {
            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();
            IQueryable<Core.Models.UserNotification> userNotificationContext = _context.Set<Core.Models.UserNotification>();

            var totalUnreadMessageCount = 0;
            var totalUnreadNotificationCount = 0;
            if (userType == (int)LoginUserType.Talent)
            {
                totalUnreadMessageCount = await messageContext.CountAsync(x => x.ToTalentId == userId && x.Read == false);
                totalUnreadNotificationCount = await userNotificationContext.CountAsync(c => c.TalentId == userId && !c.Read);
            }
            if (userType == (int)LoginUserType.Recruiter)
            {
                totalUnreadMessageCount =await messageContext.Include(c=>c.FromAuxiliary).CountAsync(x => x.ToAuxiliaryId == userId && ((x.FromAuxiliaryId > 0 && x.FromAuxiliary.TypeId == (int)LoginUserType.FTCAdmin) || x.FromTalentId > 0 ) && x.Read == false);
                totalUnreadNotificationCount = await userNotificationContext.CountAsync(c => c.AuxiliaryUserId == userId && !c.Read);
            }
            if (userType == (int)LoginUserType.FTCAdmin)
            {
                totalUnreadMessageCount =await messageContext.Include(c => c.FromAuxiliary).CountAsync(x => x.ToAuxiliaryId == userId && ((x.FromAuxiliaryId > 0 && x.FromAuxiliary.TypeId == (int)LoginUserType.Recruiter) || x.FromTalentId > 0) && x.Read == false);
                totalUnreadNotificationCount = await userNotificationContext.CountAsync(c => c.AuxiliaryUserId == userId && !c.Read);
            }

            return new { TotalUnreadMessageCount = totalUnreadMessageCount, TotalUnreadNotificationCount= totalUnreadNotificationCount };
        }

        /// <summary>
        /// This method is use to get job list
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>returns list of talent jobs</returns>
        public async Task<TalentMessages> GetTalentJobListAsync(int talentId)
        {
            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            messageContext = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project);


            var talentMessages = messageContext.Where(x => (x.FromTalentId == talentId || x.ToTalentId == talentId) && x.JobId != null).ToList();

            

            var adminMessages = messageContext.Include(frmAux => frmAux.FromAuxiliary)
                                               .Include(toAux => toAux.ToAuxiliary)
                                               .Where(x => (x.FromTalentId == talentId || x.ToTalentId == talentId)
                                                && ((x.FromAuxiliary != null && x.FromAuxiliary.TypeId == (int)LoginUserType.FTCAdmin ||
                                                (x.ToAuxiliary != null && x.ToAuxiliary.TypeId == (int)LoginUserType.FTCAdmin))) && x.JobId == null).ToList();

            //Group by based on jobid
            var groupByJob = talentMessages.GroupBy(x => new { x.Job.Id, x.Job.Title, x.Job.ProjectId, x.Job.Project.Name }).Select(g => new Job
            {
                JobId = g.Key.Id,
                JobTitle = g.Key.Title,
                ProjectId = g.Key.ProjectId,
                ProjectName = g.Key.Name,
                TotalUnreadMessages = g.Where(c => c.FromAuxiliaryId > 0).Count(x => x.Read == false)
            }).ToList();

            var talent = await _talentRepository.FindAsync(t => t.Id == talentId);
            var messages = new TalentMessages
            {
                Jobs = groupByJob.OrderByDescending(o => o.TotalUnreadMessages).ToList(),
                TotalUnreadMessages = talentMessages.Any()?talentMessages.Where(x => x.FromAuxiliaryId > 0).Count(x => x.Read == false): (int?)null,
                TotalUnreadAdminMessages = adminMessages.Any()?adminMessages.Where(x => x.FromAuxiliaryId > 0 && (x.FromAuxiliary != null && x.FromAuxiliary.TypeId == (int)LoginUserType.FTCAdmin)).Count(x => x.Read == false):(int?) null

            };

            return await Task.Run(() => messages);
        }

        public async Task<List<RecruiterMessages>> GetAdminRecruiterListAsync(int adminId)
        {
            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            var talentMessages = await messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                     .Include(frmAux => frmAux.FromAuxiliary)
                                                     .Include(toAux => toAux.ToAuxiliary)
              .Where(x => (x.FromAuxiliaryId.Value == adminId || x.ToAuxiliaryId.Value == adminId) && x.ToTalentId == null && x.FromTalentId == null).ToListAsync();

            var list = talentMessages.Select(g => new { Recruiter = (g.FromAuxiliary != null && g.FromAuxiliary.TypeId == (int)LoginUserType.Recruiter) ? g.FromAuxiliary : (g.ToAuxiliary != null && g.ToAuxiliary.TypeId == (int)LoginUserType.Recruiter) ? g.ToAuxiliary : null }).Distinct().ToList();

            var recruiterList = list.Any() ? list.Select(g => new RecruiterMessages { RecruiterId = g.Recruiter.Id, RecruiterProfileUrl = g.Recruiter.ProfileURL, RecruiterName = g.Recruiter.FullName, TotalUnreadMessages = talentMessages.Where(x => x.FromAuxiliaryId == g.Recruiter.Id ).Count(c => c.Read == false) }).ToList() : null;

            return await Task.Run(() => recruiterList);
        }


        public async Task<List<TalentInfo>> GetAdminTalentListAsync(int adminId)
        {
            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            var talentMessages = await messageContext.Include(frmAux => frmAux.FromAuxiliary)
                                                    .Include(toAux => toAux.ToAuxiliary)
                                                    .Include(frmTal => frmTal.FromTalent)
                                                    .Include(toTal => toTal.ToTalent)
              .Where(x => (x.FromAuxiliaryId == adminId && x.ToTalentId > 0) || (x.ToAuxiliaryId == adminId && x.FromTalentId > 0)).ToListAsync();

            var list = talentMessages.Select(g => new { Talent = (g.FromTalent != null) ? g.FromTalent : (g.ToTalent != null) ? g.ToTalent : null }).Distinct().ToList();

            var talents = list.Any() ? list.Select(g => new TalentInfo { TalentId = g.Talent.Id, TalentName = g.Talent.FullName, TalentProfileUrl = g.Talent.TalentProfileURL,
                TotalUnreadMessages = talentMessages.Where(x => x.FromTalentId == g.Talent.Id).Count(c => c.Read == false) }).ToList() : null;

            return await Task.Run(() => talents);
        }


        /// <summary>
        /// This method is use to save message
        /// </summary>
        /// <param name="message">message object</param>
        /// <returns>return saved message</returns>
        public async Task<Core.Models.Message> SendMessageAsync(MessageDto message)
        {
            Core.Models.Message chatMsg = null;
            if (message != null)
            {
                var msg = new Core.Models.Message
                {
                    MessageText = message.Message,
                    Read = false,
                    JobId = message.JobId,
                    FromAuxiliaryId = message.FromAuxiliaryId ?? null,
                    FromTalentId = message.FromTalentId ?? null,
                    ToAuxiliaryId = message.ToAuxiliaryId ?? null,
                    ToTalentId = message.ToTalentId ?? null,
                    CreatedOn = DateTime.UtcNow
                };
                chatMsg = await AddAsync(msg);
            }

            return await Task.Run(() => chatMsg);
        }

        /// <summary>
        /// This method is use to get talent admin messages
        /// </summary>
        /// <param name="talentId"></param>
        /// <returns>return talent admin messages</returns>
        public async Task<Job> GetTalentAdminMessagesAsync(int talentId)
        {
            var talentJob = GetTalentMessages(talentId, 0, (int)LoginUserType.FTCAdmin);
            return await Task.Run(() => talentJob);
        }

        /// <summary>
        /// This method is use to get recruiter talent messages
        /// </summary>
        /// <param name="recruiterId">recruiterId</param>
        /// <param name="talentId">talentId</param>
        /// <param name="jobId">jobId</param>
        /// <returns>returns messages</returns>
        public Task<Job> GetRecruiterTalentMessageAsync(int recruiterId, int talentId, int jobId)
        {

            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            var talentMessages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                .Include(frmAux => frmAux.FromAuxiliary)
                                                .Include(toAux => toAux.ToAuxiliary)
                                                .Include(frmTal => frmTal.FromTalent)
                                                .Include(toTal => toTal.ToTalent)
                                                .Where(x => (x.FromAuxiliaryId.Value == recruiterId || x.ToAuxiliaryId.Value == recruiterId)
                                                        && (x.FromTalentId.Value == talentId || x.ToTalentId.Value == talentId)
                                                        && (x.FromAuxiliary != null && x.FromAuxiliary.TypeId == (int)LoginUserType.Recruiter 
                                                            || (x.ToAuxiliary != null && x.ToAuxiliary.TypeId == (int)LoginUserType.Recruiter) 
                                                            && (x.FromTalent != null || x.ToTalent != null))
                                                        && x.JobId == jobId).ToList();

            // fetech subuser of a Recruiter
            List<int> ids = default(List<int>);

            ids = _auxiliaryUserRepository.FindAll(x => x.ParentAuxiliaryUserId == recruiterId).Select(p => p.Id).ToList();

            if (ids.Count == 0)
            {
                // Get Messages of parent recruiter for given talent and Job
                ids = _auxiliaryUserRepository.FindAll(x => x.Id == recruiterId).Select(p => p.ParentAuxiliaryUserId ?? 0).ToList();
            }

            // This condition checks if super recuritor is logged in then it fetch messages of sub recruitors.
            if (ids.Any())
            {
                foreach (int id in ids)
                {
                    var messages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                         .Include(frmAux => frmAux.FromAuxiliary)
                                                         .Include(toAux => toAux.ToAuxiliary)
                                                         .Include(frmTal => frmTal.FromTalent)
                                                         .Include(toTal => toTal.ToTalent)
                                                         .Where(x => (x.FromAuxiliaryId.Value == id || x.ToAuxiliaryId.Value == id)
                                                                  && (x.FromTalentId.Value == talentId || x.ToTalentId.Value == talentId)
                                                                  && (x.FromAuxiliary != null && x.FromAuxiliary.TypeId == (int)LoginUserType.Recruiter 
                                                                        || (x.ToAuxiliary != null && x.ToAuxiliary.TypeId == (int)LoginUserType.Recruiter)
                                                                        && (x.FromTalent != null || x.ToTalent != null))
                                                                  && x.JobId == jobId).ToList();

                    talentMessages.AddRange(messages);
                }
            }
            
            var updateReadStatus = talentMessages.Where(x => x.FromTalentId > 0).ToList();

            //This call update read status of the message.
            UpdateReadStatus(updateReadStatus);

            return Task.FromResult(ConvertToTalentMessageDto(talentMessages));
        }



        public Task<List<MessageDto>> GetAdminRecruiterMessage(int adminId, int recruiterId)
        {

            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            var recruiterJobs = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                .Include(frmAux => frmAux.FromAuxiliary)
                                                .Include(toAux => toAux.ToAuxiliary)
                                                .Where(x => ((x.FromAuxiliaryId.Value == adminId && x.ToAuxiliaryId.Value == recruiterId) || (x.ToAuxiliaryId.Value == adminId && x.FromAuxiliaryId.Value == recruiterId))
                                                   ).ToList();

            var ids = _auxiliaryUserRepository.FindAll(x => x.ParentAuxiliaryUserId == adminId).Select(p => p.Id).ToList();

            if (ids.Any())
            {
                foreach (int id in ids)
                {
                    var messages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                            .Include(frmAux => frmAux.FromAuxiliary)
                                            .Include(toAux => toAux.ToAuxiliary)
                                            .Where(x => ((x.FromAuxiliaryId.Value == id && x.ToAuxiliaryId.Value == recruiterId) || (x.ToAuxiliaryId.Value == id && x.FromAuxiliaryId.Value == recruiterId))
                                          ).ToList();

                    recruiterJobs.AddRange(messages);
                }
            }

            var updateReadStatus = recruiterJobs.Where(x => x.FromAuxiliaryId > 0 && (x.FromAuxiliary != null && x.FromAuxiliary.TypeId == (int)LoginUserType.Recruiter)).ToList();

            //This call update read status of the message.
            UpdateReadStatus(updateReadStatus);

            return Task.FromResult(ConvertToMessageDto(recruiterJobs));
        }


        public Task<List<MessageDto>> GetAdminTalentMessage(int adminId, int talentId)
        {

            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            var recruiterJobs = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                .Include(frmAux => frmAux.FromAuxiliary)
                                                .Include(toAux => toAux.ToAuxiliary)
                                                  .Include(frmTal => frmTal.FromTalent)
                                                         .Include(toTal => toTal.ToTalent)
                                                .Where(x => ((x.FromAuxiliaryId == adminId && x.ToTalentId == talentId) || (x.ToAuxiliaryId == adminId && x.FromTalentId == talentId))
                                                   ).ToList();

            var ids = _auxiliaryUserRepository.FindAll(x => x.ParentAuxiliaryUserId == adminId).Select(p => p.Id).ToList();

            if (ids.Any())
            {
                foreach (int id in ids)
                {
                    var messages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                            .Include(frmAux => frmAux.FromAuxiliary)
                                            .Include(toAux => toAux.ToAuxiliary)
                                            .Where(x => ((x.FromAuxiliaryId.Value == id && x.ToTalentId.Value == talentId) || (x.ToAuxiliaryId.Value == id && x.FromTalentId.Value == talentId))
                                          ).ToList();

                    recruiterJobs.AddRange(messages);
                }
            }

            var updateReadStatus = recruiterJobs.Where(x => x.FromTalentId > 0 && (x.ToAuxiliary != null && x.ToAuxiliary.TypeId == (int)LoginUserType.FTCAdmin)).ToList();

            //This call update read status of the message.
            UpdateReadStatus(updateReadStatus);

            return Task.FromResult(ConvertToMessageDto(recruiterJobs));
        }
        /// <summary>
        /// This method is use to get recruiter admin messages 
        /// </summary>
        /// <param name="recruiterId">recruiterId</param>
        /// <returns>returns messages</returns>
        public Task<Job> GetRecruiterAdminMessageAsync(int recruiterId)
        {

            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            var recruiterJobs = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                .Include(frmAux => frmAux.FromAuxiliary)
                                                .Include(toAux => toAux.ToAuxiliary)
                                                .Include(frmTal => frmTal.FromTalent)
                                                .Include(toTal => toTal.ToTalent)
                                                .Where(x => (x.FromAuxiliaryId.Value == recruiterId || x.ToAuxiliaryId.Value == recruiterId)
                                                   && (x.FromTalent == null && x.ToTalent == null)).ToList();

            var ids = _auxiliaryUserRepository.FindAll(x => x.ParentAuxiliaryUserId == recruiterId).Select(p => p.Id).ToList();

            if (ids.Any())
            {
                foreach (int id in ids)
                {
                    var messages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                            .Include(frmAux => frmAux.FromAuxiliary)
                                            .Include(toAux => toAux.ToAuxiliary)
                                            .Include(frmTal => frmTal.FromTalent)
                                            .Include(toTal => toTal.ToTalent)
                                            .Where(x => (x.FromAuxiliaryId.Value == id || x.ToAuxiliaryId.Value == id)
                                               && (x.FromTalent == null && x.ToTalent == null)).ToList();

                    recruiterJobs.AddRange(messages);
                }
            }
            var updateReadStatus = recruiterJobs.Where(x => x.FromAuxiliaryId > 0 && (x.FromAuxiliary != null && x.FromAuxiliary.TypeId == (int)LoginUserType.FTCAdmin)).ToList();

            //This call update read status of the message.
            UpdateReadStatus(updateReadStatus);

            return Task.FromResult(ConvertToTalentMessageDto(recruiterJobs));
        }

        /// <summary>
        /// This method is use to get recruiter job list
        /// </summary>
        /// <param name="recruiterId">recruiterId</param>
        /// <returns>returns job list</returns>
        public async Task<RecruiterMessages> GetRecruiterJobListAsync(int recruiterId)
        {
            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();

            messageContext = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project);


            var recruiterJobs = messageContext.Include(frmAux => frmAux.FromAuxiliary)
                 .Include(toAux => toAux.ToAuxiliary)
                 .Include(frmTal => frmTal.FromTalent)
                 .Include(toTal => toTal.ToTalent).Where(x => (x.FromAuxiliaryId.Value == recruiterId || x.ToAuxiliaryId.Value == recruiterId) && (!(x.FromTalent == null && x.ToTalent == null)) && (x.JobId != null)).ToList();

            var adminMessages = messageContext.Include(frmAux => frmAux.FromAuxiliary).Where(x => (x.FromAuxiliaryId.Value == recruiterId || x.ToAuxiliaryId.Value == recruiterId)
                                                   && (x.FromTalentId == null && x.ToTalentId == null)).ToList();

            var ids = _auxiliaryUserRepository.FindAll(x => x.ParentAuxiliaryUserId == recruiterId).Select(p => p.Id).ToList();


            if (ids.Any())
            {
                foreach (int id in ids)
                {
                    var message = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                              .Include(frmAux => frmAux.FromAuxiliary)
                                              .Include(toAux => toAux.ToAuxiliary)
                                              .Include(frmTal => frmTal.FromTalent)
                                              .Include(toTal => toTal.ToTalent)
                                              .Where(x => (x.FromAuxiliaryId.Value == id || x.ToAuxiliaryId.Value == id) && (!(x.FromTalent == null && x.ToTalent == null)) && x.JobId != null).ToList();

                    recruiterJobs.AddRange(message);
                }
            }

            var groupByJob = recruiterJobs.GroupBy(x => new { x.Job.Id, x.Job.Title, x.Job.ProjectId, x.Job.Project.Name }).Select(g => new Job
            {
                JobId = g.Key.Id,
                JobTitle = g.Key.Title,
                ProjectId = g.Key.ProjectId,
                ProjectName = g.Key.Name,
                Talents = g.Select(p => new TalentInfo
                {
                    TalentId = p.FromTalent == null ? p.ToTalent == null ? 0 : p.ToTalentId.Value : p.FromTalentId.Value,
                    TalentName = p.FromTalent == null ? p.ToTalent == null ? string.Empty : p.ToTalent.FullName : p.FromTalent.FullName,
                    TalentProfileUrl = p.FromTalent == null ? p.ToTalent == null ? string.Empty : p.ToTalent.TalentProfileURL : p.FromTalent.TalentProfileURL,
                    TotalUnreadMessages = g.Where(c => c.FromTalentId == (p.FromTalent == null ? p.ToTalent == null ? 0 : p.ToTalentId.Value : p.FromTalentId.Value)).Count(x => x.Read == false)
                })
                .GroupBy(x => x.TalentId)
                .Select(x => x.First()).ToList(),
                TotalUnreadMessages = g.Where(c => c.FromTalentId > 0).Count(x => x.Read == false)
            }).ToList();

            var messages = new RecruiterMessages
            {
                Jobs = groupByJob.OrderByDescending(o => o.TotalUnreadMessages).ToList(),
                RecruiterProfileUrl = recruiterJobs.Any()?recruiterJobs.Select(p => p.FromAuxiliary == null ? p.ToAuxiliary == null ? string.Empty : p.ToAuxiliary.ProfileURL : p.FromAuxiliary.ProfileURL).First():string.Empty,
                RecruiterId = recruiterJobs.Any()?recruiterJobs.Select(p => p.FromAuxiliary == null ? p.ToAuxiliary == null ? 0 : p.ToAuxiliary.Id : p.FromAuxiliary.Id).First():0,
                RecruiterName = recruiterJobs.Any()?recruiterJobs.Select(p => p.FromAuxiliary == null ? p.ToAuxiliary == null ? string.Empty : p.ToAuxiliary.FullName : p.FromAuxiliary.FullName).First():string.Empty,
                TotalUnreadMessages = recruiterJobs.Any()? recruiterJobs.Where(c => c.FromTalentId > 0).Count(x => x.Read == false): (int?)null,
                TotalUnreadAdminMessages = adminMessages.Any()? adminMessages.Where(c => c.FromAuxiliaryId > 0 && (c.FromAuxiliary != null && c.FromAuxiliary.TypeId == (int)LoginUserType.FTCAdmin)).Count(x => x.Read == false): (int?)null
            };

            return await Task.Run(() => messages);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// This method is use to get talent messages 
        /// </summary>
        /// <param name="talentId">talentId</param>
        /// <param name="jobId">jobId</param>
        /// <param name="userType">userType</param>
        /// <returns>return list of talent messages</returns>
        private Job GetTalentMessages(int talentId, int jobId, int userType)
        {
            IQueryable<Core.Models.Message> messageContext = _context.Set<Core.Models.Message>();
            List<Core.Models.Message> messages = null;

            if (userType == (int)LoginUserType.Recruiter)
            {
                messages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                .Include(frmAux => frmAux.FromAuxiliary)
                                                .Include(toAux => toAux.ToAuxiliary)
                                                .Include(frmTal => frmTal.FromTalent)
                                                .Include(toTal => toTal.ToTalent)
                                                .Where(x => (x.FromTalentId.Value == talentId || x.ToTalentId.Value == talentId)
                                                && (x.FromAuxiliary != null || x.ToAuxiliary != null )
                                                && x.JobId == jobId).ToList();
            }
            else
            {
                messages = messageContext.Include(job => job.Job).ThenInclude(proj => proj.Project)
                                                .Include(frmAux => frmAux.FromAuxiliary)
                                                .Include(toAux => toAux.ToAuxiliary)
                                                .Include(frmTal => frmTal.FromTalent)
                                                .Include(toTal => toTal.ToTalent)
                                                .Where(x => (x.FromTalentId.Value == talentId || x.ToTalentId.Value == talentId)
                                                && (x.FromAuxiliary != null  || x.ToAuxiliary != null )
                                                && x.JobId == null).ToList();

            }

            var updateReadStatus = messages.Where(x => x.FromAuxiliaryId > 0).ToList();

            //This call update read status of the message.
            UpdateReadStatus(updateReadStatus);

            return ConvertToTalentMessageDto(messages);
        }

        /// <summary>
        /// This call update message read status.
        /// </summary>
        /// <param name="messages"></param>
        private void UpdateReadStatus(List<Core.Models.Message> messages)
        {
            messages.ForEach(f => f.Read = true);

            foreach (Core.Models.Message message in messages)
            {
                Update(message);
            }
        }

        /// <summary>
        /// This method convert into message object 
        /// </summary>
        /// <param name="talentMessages"></param>
        /// <returns></returns>
        private Job ConvertToTalentMessageDto(List<Core.Models.Message> talentMessages)
        {

            var talentJob = new Job();

            MessageDto messageDto = null;
            talentMessages = talentMessages.OrderBy(c => c.CreatedOn).ToList();

            if (talentMessages!=null && talentMessages.Count > 0)
            {
                var message = talentMessages.FirstOrDefault();
                if (message.Job != null)
                {
                    talentJob.JobTitle = message.Job.Title;
                    talentJob.ProjectId = message.Job.ProjectId;
                    talentJob.ProjectName = message.Job.Project.Name;
                    talentJob.RecruiterId = message.Job.Project.AuxiliaryUserId;
                    talentJob.ProfileUrl = _context.Set<AuxiliaryUser>().FirstOrDefault(x => x.Id == message.Job.Project.AuxiliaryUserId).ProfileURL;
                }
            }           

            foreach (Core.Models.Message message in talentMessages)
            {
                talentJob.JobId = message.JobId;
               
                messageDto = new MessageDto
                {
                    JobId = message.JobId,
                    FromTalentId = message.FromTalentId,
                    ToTalentId = message.ToTalentId,
                    FromAuxiliaryId = message.FromAuxiliaryId,
                    ToAuxiliaryId = message.ToAuxiliaryId,
                    Message = message.MessageText,
                    Read = message.Read,
                    CreatedOn = message.CreatedOn,
                    FromName = message.FromAuxiliary != null ? message.FromAuxiliary.FullName : message.FromTalent != null ? message.FromTalent.FullName : string.Empty,
                    ToName = message.ToAuxiliary != null ? message.ToAuxiliary.FullName : message.ToTalent != null ? message.ToTalent.FullName : string.Empty,
                    FromRole = message.FromAuxiliary != null ? message.FromAuxiliary.TypeId == 1 ? LoginUserType.Recruiter.ToString() : LoginUserType.FTCAdmin.ToString() ?? LoginUserType.Talent.ToString() : LoginUserType.Talent.ToString(),
                    ToRole = message.ToAuxiliary != null ? message.ToAuxiliary.TypeId == 1 ? LoginUserType.Recruiter.ToString() : LoginUserType.FTCAdmin.ToString() ?? LoginUserType.Talent.ToString() : LoginUserType.Talent.ToString(),
                    FromProfileUrl = message.FromAuxiliary != null ? message.FromAuxiliary.ProfileURL : message.FromTalent != null ? message.FromTalent.TalentProfileURL : string.Empty,
                    ToProfileUrl = message.ToAuxiliary != null ? message.ToAuxiliary.ProfileURL : message.ToTalent != null ? message.ToTalent.TalentProfileURL : string.Empty,
                };

                talentJob.Messages.Add(messageDto);
            }

            return talentJob;
        }


        private static List<MessageDto> ConvertToMessageDto(List<Core.Models.Message> talentMessages)
        {

            var messages = new List<MessageDto>();

            MessageDto messageDto = null;
            talentMessages = talentMessages.OrderBy(c => c.CreatedOn).ToList();
            foreach (Core.Models.Message message in talentMessages)
            {

                messageDto = new MessageDto
                {
                    JobId = message.JobId,
                    FromTalentId = message.FromTalentId,
                    ToTalentId = message.ToTalentId,
                    FromAuxiliaryId = message.FromAuxiliaryId,
                    ToAuxiliaryId = message.ToAuxiliaryId,
                    Message = message.MessageText,
                    Read = message.Read,
                    CreatedOn = message.CreatedOn,
                    FromName = message.FromAuxiliary != null ? message.FromAuxiliary.FullName : message.FromTalent != null ? message.FromTalent.FullName : string.Empty,
                    ToName = message.ToAuxiliary != null ? message.ToAuxiliary.FullName : message.ToTalent != null ? message.ToTalent.FullName : string.Empty,
                    FromRole = message.FromAuxiliary != null ? message.FromAuxiliary.TypeId == 1 ? LoginUserType.Recruiter.ToString() : LoginUserType.FTCAdmin.ToString() ?? LoginUserType.Talent.ToString() : LoginUserType.Talent.ToString(),
                    ToRole = message.ToAuxiliary != null ? message.ToAuxiliary.TypeId == 1 ? LoginUserType.Recruiter.ToString() : LoginUserType.FTCAdmin.ToString() ?? LoginUserType.Talent.ToString() : LoginUserType.Talent.ToString(),
                    FromProfileUrl = message.FromAuxiliary != null ? message.FromAuxiliary.ProfileURL : message.FromTalent != null ? message.FromTalent.TalentProfileURL : string.Empty,
                    ToProfileUrl = message.ToAuxiliary != null ? message.ToAuxiliary.ProfileURL : message.ToTalent != null ? message.ToTalent.TalentProfileURL : string.Empty,
                };

                messages.Add(messageDto);
            }

            return messages;
        }

        #endregion
    }
}
