﻿using FTCApi.Core.RepositoryInterface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public abstract class GenericRepository<T> : IGenericRepository<T>, IDisposable where T : class
    {
        protected FTCDbContext _context;

        public GenericRepository(FTCDbContext context)
        {
            _context = context;
        }

        public virtual T Add(T t)
        {
            _context.Set<T>().Add(t);
            _context.SaveChanges();
            return t;
        }

        public virtual async Task<T> AddAsync(T t)
        {
            _context.Set<T>().Add(t);
            await _context.SaveChangesAsync();
            return t;
        }

        public virtual int Count()
        {
            return _context.Set<T>().Count();
        }

        public virtual async Task<int> CountAsync()
        {
            return await _context.Set<T>().CountAsync();
        }

        public virtual void Delete(T t)
        {
            _context.Set<T>().Remove(t);
            _context.SaveChanges();
        }
        public virtual void RemoveRange(IEnumerable<T> t)
        {
            _context.Set<T>().RemoveRange(t);
            _context.SaveChanges();
        }
        public virtual async Task<int> DeleteAsync(T t)
        {
            _context.Set<T>().Remove(t);
            return await _context.SaveChangesAsync();
        }

        public virtual T Find(Expression<Func<T, bool>> match)
        {
            return _context.Set<T>().SingleOrDefault(match);
        }

        public virtual IEnumerable<T> FindAll(Expression<Func<T, bool>> match)
        {
            return _context.Set<T>().Where(match).ToList();
        }

        public virtual async Task<IEnumerable<T>> FindAllAsync(Expression<Func<T, bool>> match)
        {
            return await _context.Set<T>().Where(match).ToListAsync();
        }

        public virtual async Task<T> FindAsync(Expression<Func<T, bool>> match)
        {            
            return await _context.Set<T>().SingleOrDefaultAsync(match);
        }

        public virtual async Task<int> MaxAsync(Expression<Func<T, int>> match)
        {   
            return await _context.Set<T>().MaxAsync(match); 
        }

        //public virtual T Get(int id)
        //{
        //    return _context.Set<T>().Find(id);
        //}

        public virtual IEnumerable<T> GetAll()
        {
            return _context.Set<T>().ToList();
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _context.Set<T>().ToListAsync();
        }

        public virtual async Task<T> GetAsync(int id)
        {
            //Problem: FindAsync method is missing in EF7
            //Todo: Write an extension method for FindAsync
            //Workaround for now: Use FindAsync method instead
            return await _context.Set<T>().FirstOrDefaultAsync();
        }

        public virtual T Update(T updated)//, int key)
        {
            if (updated == null)
                return null;

            //T existing = _context.Set<T>().Find(key);
            //if (existing != null)
            //{
            _context.Set<T>().Update(updated);
            _context.SaveChanges();
            //}
            //return existing;
            return updated;
        }

        public virtual async Task<T> UpdateAsync(T updated)//, Expression<Func<T, bool>> match)
        {
            if (updated == null)
                return null;

            //T existing = await _context.Set<T>().SingleOrDefaultAsync(match);
            //if (existing != null)
            //{
            //_context.Entry(existing).CurrentValues.SetValues(updated);
            _context.Set<T>().Update(updated);
            await _context.SaveChangesAsync();
            //}
            //return existing;
            return updated;
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
