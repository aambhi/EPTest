﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class JobAuditionRepository:GenericRepository<JobAudition>, IJobAuditionRepository
    {
        public JobAuditionRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
