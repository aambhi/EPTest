﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectLocationRepository : GenericRepository<ProjectLocation> ,IProjectLocationRepository
    {
        public ProjectLocationRepository(FTCDbContext context):base(context)
        {

        }
    }
}
