﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TagRepository:GenericRepository<Tag>, ITagRepository
    {
        public TagRepository(FTCDbContext context):base(context)
        {

        }
    }
}
