﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentTransactionDetailRepository:GenericRepository<TalentTransactionDetail>, ITalentTransactionDetailRepository
    {
        public TalentTransactionDetailRepository(FTCDbContext context):base(context)
        {

        }
    }
}
