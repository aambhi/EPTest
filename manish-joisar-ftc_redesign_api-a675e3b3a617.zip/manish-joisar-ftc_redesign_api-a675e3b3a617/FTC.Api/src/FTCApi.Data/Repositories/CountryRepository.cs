﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class CountryRepository: GenericRepository<Country>,ICountryRepository
    {
        public CountryRepository(FTCDbContext context):base(context)
        {

        }

    }
}
