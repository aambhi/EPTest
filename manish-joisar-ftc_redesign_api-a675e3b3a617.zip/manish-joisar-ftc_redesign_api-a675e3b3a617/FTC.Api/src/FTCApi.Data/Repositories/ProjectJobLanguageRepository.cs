﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobLanguageRepository : GenericRepository<ProjectJobLanguage> , IProjectJobLanguageRepository
    {
        public ProjectJobLanguageRepository(FTCDbContext context):base(context)
        {

        }
    }
}