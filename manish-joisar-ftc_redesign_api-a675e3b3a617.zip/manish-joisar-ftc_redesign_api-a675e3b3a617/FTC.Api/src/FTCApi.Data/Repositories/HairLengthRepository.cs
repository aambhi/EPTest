﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class HairLengthRepository:GenericRepository<HairLength>, IHairLengthRepository
    {
        public HairLengthRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
