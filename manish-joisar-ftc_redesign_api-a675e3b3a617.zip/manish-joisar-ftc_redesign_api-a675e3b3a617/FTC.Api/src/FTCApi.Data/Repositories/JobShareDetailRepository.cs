﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class JobShareDetailRepository: GenericRepository<JobShareDetail>, IJobShareDetailRepository
    {
        public JobShareDetailRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
