﻿using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.SpecialHost;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTCApi.Data.Repositories
{
    public class TalentInfoRepository : ITalentInfoRepository
    {

        private ITalentRepository _talentRepository;
        private ITalentAddressRepository _talentAddressRepository;
        private ITalentInterestCategoryRepository _talentInterestCategoryRepository;
        private IInterestCategoryRepository _interestCategoryRepository;
        private ITalentTalentCategoryRepository _talentTalentCategoryRepository;
        private ITalentCategoryRepository _talentCategoryRepository;
        private ITalentMediaRepository _talentMediaFileRepository;
        private IMediaFileRepository _mediaFileRepository;

        private ITalentPhysicalAttributeRepository _talentPhysicalAttributeRepository;
        private IBodyTypeRepository _bodyTypeRepository;
        private IChestSizeRepository _chestSizeRepository;
        private IEyeColorRepository _eyeColorRepository;
        private IHairColorRepository _hairColorRepository;
        private IHairLengthRepository _hairLengthRepository;
        private IHairTypeRepository _hairTypeRepository;
        private IHeightRepository _heightRepository;
        private ISkinColorRepository _skinColorRepository;
        private IWaistSizeRepository _waistSizeRepository;
        private IWeightRepository _weightRepository;

        private IAddressRepository _addressRepository;
        private ICountryRepository _countryRepository;
        private ICityRepository _cityRepository;
        private ITalentTagRepository _talentTagRepository;
        private ITagRepository _tagRepository;
        private ITalentLanguageRepository _talentLanguageRepository;
        private ILanguageRepository _languageRepository;
        private ITalentEthnicityRepository _talentEthnicityRepository;
        private IEthnicityRepository _ethnicityRepository;
        private ITalentExperienceRepository _talentExperienceRepository;

        private ITalentEducationRepository _talentEducationRepository;
        private ITalentAssociationRepository _talentAssociationRepository;
        private IAssociationRepository _associationRepository;
        private ITalentSecurityQuestionRepository _talentSecurityQuestionRepository;
        private ITalentSocialLinkRepository _talentSocialLinkRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private ISocialLinkRepository _socialLinkRepository;
        private ITalentTokenRepository _talentTokenRepository;
        private ITalentTransactionRepository _talentTransactionRepository;
        private ITalentTransactionDetailRepository _talentTransactionDetailRepository;
        private ITalentPlanFeatureRepository _talentPlanFeatureRepository;
        private ITalentFeatureRepository _talentFeatureRepository;
        private IParamRepository _paramRepository;
        private IProductionHouseRepository _productionHouseRepository;
        private ISchoolRepository _schoolRepository;
        private ITagCategoryRepository _tagCategoryRepository;
        private ITalentStatusHistoryRepository _talentStatusHistoryRepository;
        private ITalentSpecialHostRepository _talentSpecialHostRepository;
        //private IStateRepository _stateRepository;

        private ILogger<TalentInfoRepository> _logger;



        public TalentInfoRepository(ITalentRepository talentRepository,
                                        ITalentAddressRepository talentAddressRepository,
                                        ITalentInterestCategoryRepository talentInterestCategoryRepository,
                                        IInterestCategoryRepository interestCategoryRepository,
                                        ITalentTalentCategoryRepository talentTalentCategoryRepository,
                                        ITalentCategoryRepository talentCategoryRepository,
                                        ITalentMediaRepository talentMediaFileRepository,
                                        IMediaFileRepository mediaFileRepository,
                                        ITalentPhysicalAttributeRepository talentPhysicalAttributeRepository,
                                        IBodyTypeRepository bodyTypeRepository,
                                        IChestSizeRepository chestSizeRepository,
                                        IEyeColorRepository eyeColorRepository,
                                        IHairColorRepository hairColorRepository,
                                        IHairLengthRepository hairLengthRepository,
                                        IHairTypeRepository hairTypeRepository,
                                        IHeightRepository heightRepository,
                                        ISkinColorRepository skinColorRepository,
                                        IWaistSizeRepository waistSizeRepository,
                                        IWeightRepository weightRepository,
                                        IAddressRepository addressRepository,
                                        ICountryRepository countryRepository,
                                        ITalentLanguageRepository talentLanguageRepository,
                                        ITalentTagRepository talentTagRepository,
                                        ITalentEthnicityRepository talentEthnicityRepository,
                                         ILanguageRepository languageRepository,
                                         IEthnicityRepository ethnicityRepository,
                                         ITagRepository tagRepository,

                                        ITalentExperienceRepository talentExperienceRepository,
                                         ITalentEducationRepository talentEducationRepository,
                                        ICityRepository cityRepository,
                                        ITalentAssociationRepository talentAssociationRepository,
                                        IAssociationRepository associationRepository,
                                        ITalentSocialLinkRepository talentSocialLinkRepository,

                                        IAuxiliaryUserRepository auxiliaryUserRepository,
                                        ISocialLinkRepository socialLinkRepository,
                                        ITalentSecurityQuestionRepository talentSecurityQuestionRepository,
                                        ITalentTokenRepository talentTokenRepository,
                                        ITalentTransactionRepository talentTransactionRepository,
                                        ITalentTransactionDetailRepository talentTransactionDetailRepository,
                                        ITalentPlanFeatureRepository talentPlanFeatureRepository,
                                         ITalentFeatureRepository talentFeatureRepository,
                                         IParamRepository paramRepository,
                                         IProductionHouseRepository productionHouseRepository,
                                         ISchoolRepository schoolRepository,
                                         ITagCategoryRepository tagCategoryRepository,
                                         ITalentStatusHistoryRepository talentStatusHistoryRepository,
                                         ITalentSpecialHostRepository talentSpecialHostRepository,
                                         ILoggerFactory loggerFactory)
        //IStateRepository stateRepository)
        {
            _talentRepository = talentRepository;
            _talentAddressRepository = talentAddressRepository;
            _talentInterestCategoryRepository = talentInterestCategoryRepository;
            _interestCategoryRepository = interestCategoryRepository;
            _talentTalentCategoryRepository = talentTalentCategoryRepository;
            _talentCategoryRepository = talentCategoryRepository;
            _talentMediaFileRepository = talentMediaFileRepository;
            _mediaFileRepository = mediaFileRepository;

            _talentPhysicalAttributeRepository = talentPhysicalAttributeRepository;

            _bodyTypeRepository = bodyTypeRepository;
            _chestSizeRepository = chestSizeRepository;
            _eyeColorRepository = eyeColorRepository;
            _hairColorRepository = hairColorRepository;
            _hairLengthRepository = hairLengthRepository;
            _hairTypeRepository = hairTypeRepository;
            _heightRepository = heightRepository;
            _skinColorRepository = skinColorRepository;
            _waistSizeRepository = waistSizeRepository;
            _weightRepository = weightRepository;

            _addressRepository = addressRepository;
            _countryRepository = countryRepository;
            _cityRepository = cityRepository;

            _talentTagRepository = talentTagRepository;
            _talentLanguageRepository = talentLanguageRepository;
            _talentEthnicityRepository = talentEthnicityRepository;
            _ethnicityRepository = ethnicityRepository;
            _languageRepository = languageRepository;
            _tagRepository = tagRepository;
            _talentExperienceRepository = talentExperienceRepository;
            _talentEducationRepository = talentEducationRepository;
            _talentAssociationRepository = talentAssociationRepository;
            _associationRepository = associationRepository;
            _talentSecurityQuestionRepository = talentSecurityQuestionRepository;
            _talentSocialLinkRepository = talentSocialLinkRepository;
            _socialLinkRepository = socialLinkRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _talentTokenRepository = talentTokenRepository;
            _talentTransactionRepository = talentTransactionRepository;
            _talentTransactionDetailRepository = talentTransactionDetailRepository;
            _talentPlanFeatureRepository = talentPlanFeatureRepository;
            _talentFeatureRepository = talentFeatureRepository;
            _paramRepository = paramRepository;
            _productionHouseRepository = productionHouseRepository;
            _schoolRepository = schoolRepository;

            _tagCategoryRepository = tagCategoryRepository;
            _talentStatusHistoryRepository = talentStatusHistoryRepository;
            _talentSpecialHostRepository = talentSpecialHostRepository;

            _logger = loggerFactory.CreateLogger<TalentInfoRepository>();
            //_stateRepository = stateRepository;
        }

        public async Task<List<TalentSpecialHostDto>> GetTalentSpecialHost(int talentId)
        {            
            var tataSkySpecialHost = await _talentSpecialHostRepository.FindAsync(x => x.TalentId == talentId
                                                                                       && x.SpecialHostId == (int)ContestSpecialHostEnum.TataSky
                                                                                       && x.StatusId == (int)StatusEnum.Active);
            var tataSkyProviderId = _talentSpecialHostRepository.GetProviderId((int)ContestSpecialHostEnum.TataSky);
            if (tataSkySpecialHost == null)
            {
                var tataSkySpecialHostDto = new TalentSpecialHostDto
                {
                    providerId = tataSkyProviderId
                };
                return new List<TalentSpecialHostDto>() { tataSkySpecialHostDto };
            }

            var talentSpecialHostDto = _talentSpecialHostRepository.ConvertToTalentSpecialHostDto(tataSkySpecialHost);

            talentSpecialHostDto.providerId = tataSkyProviderId;

            return new List<TalentSpecialHostDto>() { talentSpecialHostDto };
            
        }

        public async Task<List<TalentSocialLinkDto>> GetTalentSocialLink(int talentId)
        {

            var talentSocialLinkResponse = await _talentSocialLinkRepository.FindAllAsync(x => x.TalentId == talentId);
            if (talentSocialLinkResponse != null)
            {
                List<TalentSocialLinkDto> talentSocialLinkList = new List<TalentSocialLinkDto>();

                foreach (var talentSocialLink in talentSocialLinkResponse)
                {
                    TalentSocialLinkDto talentSocialLinkDto = await ConvertToTalentSocialLinkDto(talentSocialLink);

                    talentSocialLinkList.Add(talentSocialLinkDto);
                }
                return talentSocialLinkList;
            }
            return null;
        }

        private async Task<TalentSocialLinkDto> ConvertToTalentSocialLinkDto(TalentSocialLink talentSocialLink)
        {
            TalentSocialLinkDto talentSocialLinkDto = new TalentSocialLinkDto();
            talentSocialLinkDto.Id = talentSocialLink.Id;
            talentSocialLinkDto.TalentId = talentSocialLink.TalentId;
            talentSocialLinkDto.SocialLinkId = talentSocialLink.SocialLinkId;

            if (talentSocialLink.SocialLinkId > 0)
            {
                var socialLinkResponse = await _socialLinkRepository.FindAsync(x => x.Id == talentSocialLink.SocialLinkId);
                talentSocialLinkDto.IconImage = (socialLinkResponse != null) ? socialLinkResponse.IconImage : "";
            }
            talentSocialLinkDto.Link = talentSocialLink.Link;
            return talentSocialLinkDto;
        }

        public async Task<List<TalentEducationDto>> GetTalentEducation(int talentId)
        {

            var talentEducationResponse = await _talentEducationRepository.FindAllAsync(x => x.TalentId == talentId);
            List<TalentEducationDto> talentEducationList = new List<TalentEducationDto>();

            foreach (var talentEducation in talentEducationResponse)
            {
                TalentEducationDto talentEducationDto = await ConvertToTalentEducationDto(talentEducation);

                talentEducationList.Add(talentEducationDto);
            }
            return talentEducationList;
        }


        public async Task<List<TalentExperienceDto>> GetTalentExperience(int talentId)
        {
            var talentExperienceResponse = await _talentExperienceRepository.FindAllAsync(x => x.TalentId == talentId);

            talentExperienceResponse = talentExperienceResponse.OrderByDescending(x => x.Year);
            if (talentExperienceResponse != null)
            {
                List<TalentExperienceDto> talentExperienceList = new List<TalentExperienceDto>();

                foreach (var talentExperience in talentExperienceResponse)
                {
                    TalentExperienceDto talentExperienceDto = await ConvertToTalentExperienceDto(talentExperience);

                    talentExperienceList.Add(talentExperienceDto);
                }
                return talentExperienceList;
            }
            return null;
        }


        public async Task<List<TalentAssociationDto>> GetTalentAssociations(int talentId)
        {

            var talentAssociationResponse = await _talentAssociationRepository.FindAllAsync(x => x.TalentId == talentId);
            if (talentAssociationResponse != null)
            {
                List<TalentAssociationDto> talentAssociationList = new List<TalentAssociationDto>();

                foreach (var talentAssociation in talentAssociationResponse)
                {
                    TalentAssociationDto talentAssociationDto = await ConvertToTalentAssociationDto(talentAssociation);

                    talentAssociationList.Add(talentAssociationDto);
                }
                return talentAssociationList;
            }
            return null;
        }

        public async Task<List<TalentSecurityQuestionDto>> GetTalentSecurityQuestions(int talentId)
        {

            var talentSecurityQuestionResponse = await _talentSecurityQuestionRepository.FindAllAsync(x => x.TalentId == talentId);
            if (talentSecurityQuestionResponse != null)
            {
                List<TalentSecurityQuestionDto> talentSecurityQuestionList = new List<TalentSecurityQuestionDto>();

                foreach (var talentSecurityQuestion in talentSecurityQuestionResponse)
                {
                    TalentSecurityQuestionDto talentSecurityQuestionDto = ConvertToTalentSecurityQuestionDto(talentSecurityQuestion);

                    talentSecurityQuestionList.Add(talentSecurityQuestionDto);
                }
                return talentSecurityQuestionList;
            }
            return null;
        }

        private TalentSecurityQuestionDto ConvertToTalentSecurityQuestionDto(TalentSecurityQuestion talentSecurityQuestion)
        {
            TalentSecurityQuestionDto talentSecurityQuestionDto = new TalentSecurityQuestionDto();
            talentSecurityQuestionDto.Id = talentSecurityQuestion.Id;
            talentSecurityQuestionDto.SecurityQuestionId = talentSecurityQuestion.SecurityQuestionId;
            talentSecurityQuestionDto.Answer = talentSecurityQuestion.Answer;
            return talentSecurityQuestionDto;
        }

        private async Task<TalentAssociationDto> ConvertToTalentAssociationDto(TalentAssociation talentAssociation)
        {
            TalentAssociationDto talentAssociationDto = new TalentAssociationDto();
            talentAssociationDto.Id = talentAssociation.Id;

            talentAssociationDto.AssociationId = talentAssociation.AssociationId;

            var talentAssociationResponse = await _associationRepository.FindAsync(x => x.Id == talentAssociation.AssociationId);
            talentAssociationDto.AssociationDescription = (talentAssociationResponse != null) ? talentAssociationResponse.Description : "";


            talentAssociationDto.MembershipId = talentAssociation.MembershipId;

            return talentAssociationDto;

        }
        private async Task<TalentExperienceDto> ConvertToTalentExperienceDto(TalentExperience talentExperience)
        {
            TalentExperienceDto talentExperienceDto = new TalentExperienceDto();
            talentExperienceDto.Id = talentExperience.Id;

            talentExperienceDto.InterestCategoryId = talentExperience.InterestCategoryId;

            var talentInterestResponse = await _interestCategoryRepository.FindAsync(x => x.Id == talentExperience.InterestCategoryId);
            talentExperienceDto.InterestDescription = talentInterestResponse == null ? "" : talentInterestResponse.Description;

            talentExperienceDto.TalentCategoryId = talentExperience.TalentCategoryId;
            var talentCategoryResponse = await _talentCategoryRepository.FindAsync(x => x.Id == talentExperience.TalentCategoryId);
            talentExperienceDto.TalentDescription = talentCategoryResponse == null ? "" : talentCategoryResponse.Description;

            talentExperienceDto.ProjectTitle = talentExperience.ProjectTitle;
            talentExperienceDto.Role = talentExperience.Role;
            talentExperienceDto.Year = talentExperience.Year;
            talentExperienceDto.ProductionHouse = talentExperience.ProductionHouse;

            talentExperienceDto.ProductionHouseId = talentExperience.ProductionHouseId;
            if (talentExperience.ProductionHouseId != null || talentExperience.ProductionHouseId > 0)
            {
                var productionHouseName = await _productionHouseRepository.FindAsync(x => x.Id == talentExperience.ProductionHouseId);
                talentExperienceDto.ProductionHouseName = productionHouseName != null ? productionHouseName.Description : "";
            }

            talentExperienceDto.SubTalentCategoryId = talentExperience.SubTalentCategoryId;

            if (talentExperience.SubTalentCategoryId != null || talentExperience.SubTalentCategoryId > 0)
            {
                var subTalentCategoryResponse = await _talentCategoryRepository.FindAsync(x => x.Id == talentExperience.SubTalentCategoryId);
                talentExperienceDto.SubTalentCategoryDescription = subTalentCategoryResponse != null ? subTalentCategoryResponse.Description : "";
            }
            return talentExperienceDto;

        }
        private async Task<TalentEducationDto> ConvertToTalentEducationDto(TalentEducation talentEducation)
        {
            TalentEducationDto talentEducationDto = new TalentEducationDto();
            talentEducationDto.Id = talentEducation.Id;
            talentEducationDto.School = talentEducation.School;
            talentEducationDto.Course = talentEducation.Course;
            talentEducationDto.City = talentEducation.City;
            talentEducationDto.Country = talentEducation.Country;
            talentEducationDto.SchoolId = talentEducation.SchoolId;
            talentEducationDto.Year = talentEducation.Year;

            if (talentEducation.SchoolId != null || talentEducation.SchoolId > 0)
            {
                var school = await _schoolRepository.FindAsync(x => x.Id == talentEducation.SchoolId);
                talentEducationDto.SchoolName = school != null ? school.Description : "";
            }

            return talentEducationDto;

        }


        public async Task<List<TalentEthnicityDto>> GetTalentEthnicity(int talentId)
        {

            var talentEthnicityResponse = await _talentEthnicityRepository.FindAllAsync(x => x.TalentId == talentId);
            List<TalentEthnicityDto> talentEthnicityList = new List<TalentEthnicityDto>();

            foreach (var talentEthnicity in talentEthnicityResponse)
            {
                TalentEthnicityDto talentEthnicityDto = await ConvertToTalentEthnicityDto(talentEthnicity);

                talentEthnicityList.Add(talentEthnicityDto);
            }
            return talentEthnicityList;
        }

        private async Task<TalentEthnicityDto> ConvertToTalentEthnicityDto(TalentEthnicity talentEthnicity)
        {
            TalentEthnicityDto talentEthnicityDto = new TalentEthnicityDto();
            talentEthnicityDto.TalentId = talentEthnicity.TalentId;
            talentEthnicityDto.EthnicityId = talentEthnicity.Ethnicity;
            talentEthnicityDto.Id = talentEthnicity.Id;

            var ethnicityResponse = await _ethnicityRepository.FindAsync(x => x.Id == talentEthnicity.Ethnicity);
            talentEthnicityDto.EthnicityDescription = (ethnicityResponse != null) ? ethnicityResponse.Description : "";

            return talentEthnicityDto;
        }


        public async Task<List<TalentLanguageDto>> GetTalentLanguages(int talentId)
        {

            var talentLanguageResponse = await _talentLanguageRepository.FindAllAsync(x => x.TalentId == talentId);
            List<TalentLanguageDto> talentLanguagesList = new List<TalentLanguageDto>();

            foreach (var talentLanguage in talentLanguageResponse)
            {
                TalentLanguageDto talentLanguageDto = await ConvertToTalentLanguageDto(talentLanguage);

                talentLanguagesList.Add(talentLanguageDto);
            }
            return talentLanguagesList;
        }

        public async Task<List<TalentTagDto>> GetTalentTags(int talentId)
        {
            var talentTagsResponse = await _talentTagRepository.FindAllAsync(x => x.TalentId == talentId);

            // find Talent related tags
            var tagCategory = await _tagCategoryRepository.FindAllAsync(x => x.TagTalentRelated == true);
            var talentRelatedTagCategoryIds = tagCategory.Select(x => x.Id);

            //Remove Admin tags from the list
            var lstTalentTagId = talentTagsResponse.Select(x => x.TagId);
            var tags = await _tagRepository.FindAllAsync(x => lstTalentTagId.Contains(x.Id) && talentRelatedTagCategoryIds.Contains(x.TagCategoryId));
            var talentTags = tags.Select(x => x.Id);

            talentTagsResponse = talentTagsResponse.Where(x => talentTags.Contains(x.TagId)).ToList();


            List<TalentTagDto> talentTagsList = new List<TalentTagDto>();

            foreach (var talentTag in talentTagsResponse)
            {
                TalentTagDto talentTagDto = await ConvertToTalentTagDto(talentTag);

                talentTagsList.Add(talentTagDto);
            }
            return talentTagsList;



        }


        private async Task<TalentTagDto> ConvertToTalentTagDto(TalentTag talentTag)
        {
            TalentTagDto talentTagDto = new TalentTagDto();
            talentTagDto.Id = talentTag.Id;
            talentTagDto.TalentId = talentTag.TalentId;
            talentTagDto.TagId = talentTag.TagId;

            var tagResponse = await _tagRepository.FindAsync(x => x.Id == talentTag.TagId);
            talentTagDto.TagName = tagResponse != null ? tagResponse.Name : "";

            return talentTagDto;
        }

        private async Task<TalentLanguageDto> ConvertToTalentLanguageDto(TalentLanguage talentLanguage)
        {
            TalentLanguageDto talentLanguageDto = new TalentLanguageDto();
            talentLanguageDto.Id = talentLanguage.Id;
            talentLanguageDto.TalentId = talentLanguage.TalentId;
            talentLanguageDto.LanguageId = talentLanguage.LanguageId;

            var languageResponse = await _languageRepository.FindAsync(x => x.Id == talentLanguage.LanguageId);
            talentLanguageDto.LanguageDescription = languageResponse != null ? languageResponse.Description : "";
            return talentLanguageDto;
        }

        public async Task<TalentAddressDto> GetTalentAddressDetails(int talentId)
        {
            var talentAddressResponse = await _talentAddressRepository.FindAsync(x => x.TalentId == talentId);
            if (talentAddressResponse != null)
            {
                return await ConvertToTalentAddressDto(talentAddressResponse);
            }
            return null;
        }

        private async Task<TalentAddressDto> ConvertToTalentAddressDto(TalentAddress talentAddressResponse)
        {
            TalentAddressDto talentAddressDto = new TalentAddressDto();
            talentAddressDto.AddressId = talentAddressResponse.AddressId;   //   AddressId? is nullable in DTO => is it needed

            var addressResponse = await _addressRepository.FindAsync(x => x.Id == talentAddressResponse.AddressId);
            if (addressResponse != null)
            {
                talentAddressDto.Line1 = addressResponse.Line1;
                talentAddressDto.Line2 = addressResponse.Line2;
                talentAddressDto.ZipCode = addressResponse.ZipCode;
                talentAddressDto.CountryId = addressResponse.CountryId;

                talentAddressDto.CityId = addressResponse.CityId;

                talentAddressDto.Type = addressResponse.Type;
            }

            var countryResponse = await _countryRepository.FindAsync(x => x.Id == addressResponse.CountryId);
            if (countryResponse != null)
            {
                talentAddressDto.CountryName = countryResponse.Name;
                talentAddressDto.CountryCode = countryResponse.Code;
                talentAddressDto.CountryMobileCode = countryResponse.MobileCode;
                talentAddressDto.Nationality = countryResponse.Nationality;
            }

            var cityResponse = await _cityRepository.FindAsync(x => x.CityId == addressResponse.CityId);
            if (cityResponse != null)
            {
                talentAddressDto.CityDescription = cityResponse.CityDescription;
                talentAddressDto.StateName = cityResponse.CityState;
                talentAddressDto.StateCode = cityResponse.CityStateCode;
            }

            return talentAddressDto;
        }

        public async Task<PhysicalAttributesDto> GetPhysicalAttributes(int talentId)
        {
            var physicalAttributeResponse = await _talentPhysicalAttributeRepository.FindAsync(x => x.TalentId == talentId);
            if (physicalAttributeResponse != null)
            {
                return await ConvertToTalentPhysicalAttributeDto(physicalAttributeResponse);
            }
            return null;
        }

        private async Task<PhysicalAttributesDto> ConvertToTalentPhysicalAttributeDto(TalentPhysicalAttribute physicalAttributeResponse)
        {
            PhysicalAttributesDto physicalAttributesDto = new PhysicalAttributesDto();

            physicalAttributesDto.BodyTypeId = physicalAttributeResponse.BodyTypeId;
            var bodyTypeResponse = await _bodyTypeRepository.FindAsync(x => x.Id == physicalAttributeResponse.BodyTypeId);
            if (bodyTypeResponse != null)
            {
                physicalAttributesDto.BodyTypeDescription = bodyTypeResponse.Description;
                physicalAttributesDto.BodyTypeStatus = bodyTypeResponse.Status;
            }

            physicalAttributesDto.ChestSizeId = physicalAttributeResponse.ChestSizeId;
            var chestSizeResponse = await _chestSizeRepository.FindAsync(x => x.Id == physicalAttributeResponse.ChestSizeId);
            if (chestSizeResponse != null)
            {
                physicalAttributesDto.ChestSizeDescription = chestSizeResponse.Description;
                physicalAttributesDto.ChestSizeStatus = chestSizeResponse.Status;
            }


            physicalAttributesDto.HairColorId = physicalAttributeResponse.HairColorId;
            var hairColorResponse = await _hairColorRepository.FindAsync(x => x.Id == physicalAttributeResponse.HairColorId);
            if (hairColorResponse != null)
            {
                physicalAttributesDto.HairColorDescription = hairColorResponse.Description;
                physicalAttributesDto.HairColorRGB = hairColorResponse.RGB;
                physicalAttributesDto.HairColorStatus = hairColorResponse.Status;
            }


            physicalAttributesDto.HairLengthId = physicalAttributeResponse.HairLengthId;
            var hairLengthResponse = await _hairLengthRepository.FindAsync(x => x.Id == physicalAttributeResponse.HairLengthId);
            if (hairLengthResponse != null)
            {
                physicalAttributesDto.HairLengthDescription = hairLengthResponse.Description;
                physicalAttributesDto.HairLengthStatus = hairLengthResponse.Status;
            }


            physicalAttributesDto.HairTypeId = physicalAttributeResponse.HairTypeId;
            var hairTypeResponse = await _hairTypeRepository.FindAsync(x => x.Id == physicalAttributeResponse.HairTypeId);
            if (hairTypeResponse != null)
            {
                physicalAttributesDto.HairTypeDescription = hairTypeResponse.Description;
                physicalAttributesDto.HairTypeStatus = hairTypeResponse.Status;
            }


            physicalAttributesDto.HeightId = physicalAttributeResponse.HeightId;
            var heightResponse = await _heightRepository.FindAsync(x => x.Id == physicalAttributeResponse.HeightId);
            if (heightResponse != null)
            {
                physicalAttributesDto.HeightDescription = heightResponse.Description;
                physicalAttributesDto.HeightInches = heightResponse.Inches;
                physicalAttributesDto.HeightCms = heightResponse.Cms;
            }


            physicalAttributesDto.SkinColorId = physicalAttributeResponse.SkinColorId;
            var skinColorResponse = await _skinColorRepository.FindAsync(x => x.Id == physicalAttributeResponse.SkinColorId);
            if (skinColorResponse != null)
            {
                physicalAttributesDto.SkinColorDescription = skinColorResponse.Description;
                physicalAttributesDto.SkinColorRGB = skinColorResponse.RGB;
                physicalAttributesDto.SkinColorStatus = skinColorResponse.Status;
            }


            physicalAttributesDto.WeightSizeId = physicalAttributeResponse.WeightSizeId;
            var weightResponse = await _weightRepository.FindAsync(x => x.Id == physicalAttributeResponse.WeightSizeId);
            if (weightResponse != null)
            {
                physicalAttributesDto.WeightDescription = weightResponse.Description;
                physicalAttributesDto.WeightKgs = weightResponse.Kgs;
                physicalAttributesDto.WeightLbs = weightResponse.Lbs;
            }

            physicalAttributesDto.WaistId = physicalAttributeResponse.WaistId;
            var waistSizeResponse = await _waistSizeRepository.FindAsync(x => x.Id == physicalAttributeResponse.WaistId);
            if (waistSizeResponse != null)
            {
                physicalAttributesDto.WaistSizeDescription = waistSizeResponse.Description;
                physicalAttributesDto.WaistSizeStatus = waistSizeResponse.Status;
            }

            physicalAttributesDto.EyeColorId = physicalAttributeResponse.EyeColorId;
            var eyeColorResponse = await _eyeColorRepository.FindAsync(x => x.Id == physicalAttributeResponse.EyeColorId);
            if (eyeColorResponse != null)
            {
                physicalAttributesDto.EyeColorDescription = eyeColorResponse.Description;
                physicalAttributesDto.EyeColorRGB = eyeColorResponse.RGB;
                physicalAttributesDto.EyeColorStatus = eyeColorResponse.Status;
            }

            physicalAttributesDto.Verified = physicalAttributeResponse.Verified;
            physicalAttributesDto.VerifiedOn = physicalAttributeResponse.VerifiedOn;
            return physicalAttributesDto;
        }

        public async Task<TalentMediaDto> ConvertToTalentMediaDto(int talentId, TalentMedia talentMedia)
        {
            TalentMediaDto talentMediaDto = new TalentMediaDto();
            talentMediaDto.Id = talentMedia.Id;
            //talentMediaDto.TalentId = talentId;
            talentMediaDto.MediaFileId = talentMedia.MediaFileId;
            talentMediaDto.Flag = (LoginEnum.FlagType)Convert.ToInt32(talentMedia.Flag);


            var talentMediaResponse = await _mediaFileRepository.FindAsync(x => x.Id == talentMedia.MediaFileId);
            //fetch fileName from FileTypeTable if required..for that again hit the repo of FileType and get name and set it to DTo
            if (talentMediaResponse != null)
            {
                talentMediaDto.FileTypeId = (LoginEnum.FileType)talentMediaResponse.FileTypeId;
                talentMediaDto.FileName = talentMediaResponse.FileName;
                talentMediaDto.FilePath = talentMediaResponse.FilePath;
                talentMediaDto.FileMimeType = talentMediaResponse.FileMimeType;
                talentMediaDto.StatusId = talentMediaResponse.StatusId;
                talentMediaDto.IsExternalUrl = talentMediaResponse.IsExternalUrl;
                talentMediaDto.CreatedOn = talentMediaResponse.CreatedOn;
            }
            return talentMediaDto;
        }

        public async Task<List<TalentTalentCategoryDto>> GetTalentTalentCategories(int talentId)
        {
            var talentTalentCategoryResponse = await _talentTalentCategoryRepository.FindAllAsync(x => x.TalentId == talentId);


            // set the [TalentInterestCategoryDto] Dto to the response received
            List<TalentTalentCategoryDto> talentTalentCategoriesList = new List<TalentTalentCategoryDto>();

            foreach (var talentTalentCategory in talentTalentCategoryResponse)
            {
                TalentTalentCategoryDto talentTalentCategoryDto = await ConvertToTalentTalentCategoryDto(talentTalentCategory);

                talentTalentCategoriesList.Add(talentTalentCategoryDto);
            }



            //contains my final response with categories and their subcategories within
            List<TalentTalentCategoryDto> talentTalentCategoriesListResponse = new List<TalentTalentCategoryDto>();

            // subcategories list
            List<TalentTalentCategoryDto> talentTalentSubCategoriesList = new List<TalentTalentCategoryDto>();

            //filtering parent and sub categories in different list
            foreach (var talentTalentCategory in talentTalentCategoriesList)
            {
                if (talentTalentCategory.ParentId == null)
                {
                    talentTalentCategoriesListResponse.Add(talentTalentCategory);
                }
                else
                {
                    talentTalentSubCategoriesList.Add(talentTalentCategory);
                }

            }

            //adding subcategory to parent id ID matches
            foreach (var talentTalentCategory in talentTalentCategoriesListResponse)
            {

                var subCategory = talentTalentSubCategoriesList.Where(x => x.ParentId == talentTalentCategory.TalentCategoryId).ToList();

                if (subCategory.Count > 0)
                {
                    talentTalentCategory.TalentSubCategory = subCategory;
                }

            }


            //// list of all categories & subCategory
            //return talentTalentCategoriesList;

            //Formatted categories
            return talentTalentCategoriesListResponse;
        }

        public async Task<TalentTalentCategoryDto> ConvertToTalentTalentCategoryDto(TalentTalentCategory talentTalentCategory)
        {
            TalentTalentCategoryDto talentTalentCategoryDto = new TalentTalentCategoryDto();
            talentTalentCategoryDto.Id = talentTalentCategory.Id;
            talentTalentCategoryDto.TalentCategoryId = talentTalentCategory.TalentCategoryId;

            //fetch talentCategory from using it TalentCategoryId
            var talentCategoriesResponse = await _talentCategoryRepository.FindAsync(x => x.Id == talentTalentCategoryDto.TalentCategoryId);

            if (talentCategoriesResponse != null)
            {
                talentTalentCategoryDto.Description = talentCategoriesResponse.Description;
                talentTalentCategoryDto.SelectedIcon = talentCategoriesResponse.SelectedIcon;
                talentTalentCategoryDto.NotSelectedIcon = talentCategoriesResponse.NotSelectedIcon;
                talentTalentCategoryDto.StatusId = talentCategoriesResponse.StatusId;
                talentTalentCategoryDto.ParentId = talentCategoriesResponse.ParentId;
            }

            return talentTalentCategoryDto;
        }

        public async Task<bool> CheckMobileVerified(int talentId)
        {
            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talentId);
            if (talentToken.SMS == "Activated")
            {
                return true;
            }
            return false;
        }

        public async Task<TalentDto> GetPersonalDetails(int talentId)
        {

            var talentResponse = await _talentRepository.FindAsync(x => x.Id == talentId);
            return await ConvertToTalentDto(talentResponse);


        }

        public async Task<TalentDto> ConvertToTalentDto(Talent talent)
        {
            TalentDto talentDto = new TalentDto();
            talentDto.Id = talent.Id;
            talentDto.FullName = talent.FullName;
            talentDto.Email = talent.Email;
            talentDto.Gender = talent.Gender;
            talentDto.DOB = talent.DOB;
            talentDto.StatusId = talent.StatusId;
            talentDto.MobileCountryCode = talent.MobileCountryCode;
            talentDto.Mobile = talent.Mobile;
            talentDto.UID = talent.UID;
            talentDto.WhatsAppNumber = talent.WhatsupMobile;
            talentDto.WhatsAppCountryCode = talent.WhatsupCountryCode;
            talentDto.OnBoarded = talent.Onboarded;
            talentDto.LastTabNo = talent.LastTabNo;
            talentDto.CompletionPercentage = talent.CompletionPercentage;
            talentDto.TermsConditionAccepted = talent.TermsConditionAccepted;


            talentDto.GuardianEmailId = talent.GuardianEmailId;
            talentDto.GuardianMobile = talent.GuardianMobile;
            talentDto.GuardianName = talent.GuardianName;
            talentDto.GuardianRelation = talent.GuardianRelation;

            talentDto.PassportCountryId = talent.PassportCountryId;
            var countryResponse = await _countryRepository.FindAsync(x => x.Id == talent.PassportCountryId);
            talentDto.TalentPassportCountryName = (countryResponse != null) ? countryResponse.Name : "";

            talentDto.PassportExpirationDate = talent.PassportExpirationDate;
            talentDto.VisaType = talent.VisaType;
            talentDto.VisaYear = talent.VisaYear;

            talentDto.AgencyId = talent.AgencyId;
            talentDto.AgencyStartDate = talent.AgencyStartDate;
            talentDto.AgencyEndDate = talent.AgencyEndDate;
            talentDto.AgencyAgentName = talent.AgencyAgentName;
            talentDto.AgencyAgentMobileNo = talent.AgencyAgentMobileNo;
            talentDto.AgencyAgentEmail = talent.AgencyAgentEmail;

            var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == talent.AgencyId);
            talentDto.AgencyName = (auxiliaryUser != null) ? auxiliaryUser.FullName : "";

            talentDto.BudgetMax = talent.BudgetMax;
            talentDto.BudgetMin = talent.BudgetMin;
            talentDto.AboutMe = talent.AboutMe;
            talentDto.TalentProfileURL = talent.TalentProfileURL;

            var talentToken = await _talentTokenRepository.FindAsync(x => x.TalentId == talent.Id);
            talentDto.IsMobileVerified = talentToken.SMS == "Activated" ? true : false;

            talentDto.IsProfilePrivate = talent.IsProfilePrivate;

            talentDto.MobileCountryId = talent.MobileCountryId;
            talentDto.WhatsupCountryId = talent.WhatsupCountryId;

            talentDto.DeviceOsId = talent.DeviceOsId;
            talentDto.DeviceRegistrationId = talent.DeviceRegistrationId;

            talentDto.isTalentCreatedByAdmin = await GetTalentCreatedBy(talent.Id);

            return talentDto;
        }

        private async Task<bool> GetTalentCreatedBy(int talentId)
        {
            // If talent is created by admin
            var talentStatusHistory = await _talentStatusHistoryRepository.FindAsync(x => x.TalentId == talentId && x.FeatureId == (int)AuthorizationFeaturesEnum.CreateTalent);
            if (talentStatusHistory != null)
            {
                return true;
            }
            return false;
        }

        public async Task<List<TalentInterestCategoryDto>> GetInterestDetails(int talentId)
        {
            //fetch data from model
            var talentInterestCategoriesResponse = await _talentInterestCategoryRepository.FindAllAsync(x => x.TalentId == talentId);

            // set the [TalentInterestCategoryDto] Dto to the response received
            List<TalentInterestCategoryDto> talentInterestCategoriesList = new List<TalentInterestCategoryDto>();

            foreach (var talentInterestCategory in talentInterestCategoriesResponse)
            {
                TalentInterestCategoryDto talentInterestCategoryDto = await ConvertToTalentInterestCategoryDto(talentInterestCategory);

                talentInterestCategoriesList.Add(talentInterestCategoryDto);
            }
            return talentInterestCategoriesList;
        }

        public async Task<TalentInterestCategoryDto> ConvertToTalentInterestCategoryDto(TalentInterestCategory talentInterestCategory)
        {
            TalentInterestCategoryDto talentInterestCategoryDto = new TalentInterestCategoryDto();
            talentInterestCategoryDto.Id = talentInterestCategory.Id;
            talentInterestCategoryDto.InterestCategoryId = talentInterestCategory.InterestCategoryId;

            //fetch interest from using it InterestCategoryId
            var interestCategoriesResponse = await _interestCategoryRepository.FindAsync(x => x.Id == talentInterestCategory.InterestCategoryId);

            if (interestCategoriesResponse != null)
            {
                talentInterestCategoryDto.Description = interestCategoriesResponse.Description;
                talentInterestCategoryDto.SelectedIcon = interestCategoriesResponse.SelectedIcon;
                talentInterestCategoryDto.NotselectedIcon = interestCategoriesResponse.NotselectedIcon;
                talentInterestCategoryDto.StatusId = interestCategoriesResponse.StatusId;
            }

            return talentInterestCategoryDto;
        }

        public async Task<TalentDto> SavePersonalDetail(TalentDto talentDto)
        {
            //Talent updateTalent = new Talent();
            var talent = await _talentRepository.FindAsync(x => x.Id == talentDto.Id);
            var updatedTalent = ConvertToTalentModel(talent, talentDto);

            updatedTalent = await _talentRepository.UpdateAsync(updatedTalent);

            return await ConvertToTalentDto(updatedTalent);
            //return updatedTalent;
        }


        public async Task<TalentAddressDto> SaveTalentAddress(int talentId, TalentAddressDto talentAddressDto)
        {
            if (talentAddressDto != null)
            {
                var talentAddress = await _talentAddressRepository.FindAsync(x => x.TalentId == talentId);
                if (talentAddress == null)
                {
                    TalentAddress talentAddressModel = new TalentAddress();
                    talentAddressModel = await ConvertToTalentAddressModel(talentId, talentAddressModel, talentAddressDto);
                    talentAddressModel = await _talentAddressRepository.AddAsync(talentAddressModel);
                    talentAddressDto = await ConvertToTalentAddressDto(talentAddressModel);
                }
                else
                {
                    var address = await _addressRepository.FindAsync(x => x.Id == talentAddress.AddressId);
                    address.Line1 = talentAddressDto.Line1;
                    address.Line2 = talentAddressDto.Line2;
                    //address.CountryId = talentAddressDto.CountryId;
                    //address.CityId = talentAddressDto.CityId;
                    await GetTalentCityCountryId(talentAddressDto, address);

                    address.ZipCode = talentAddressDto.ZipCode;
                    address.Type = talentAddressDto.Type;
                    address = await _addressRepository.UpdateAsync(address);
                }
                return talentAddressDto;
            }
            return null;
        }


        private async Task<TalentAddress> ConvertToTalentAddressModel(int talentId, TalentAddress talentAddress, TalentAddressDto talentAddressDto)
        {
            talentAddress.AddressId = talentAddressDto.AddressId;
            talentAddress.TalentId = talentId;
            Address address = new Address();
            address.Line1 = talentAddressDto.Line1;
            address.Line2 = talentAddressDto.Line2;
            //address.CountryId = talentAddressDto.CountryId;
            //address.CityId = talentAddressDto.CityId;
            await GetTalentCityCountryId(talentAddressDto, address);

            address.ZipCode = talentAddressDto.ZipCode;
            address.Type = talentAddressDto.Type;
            address = await _addressRepository.AddAsync(address);
            talentAddress.AddressId = address.Id;
            return talentAddress;
        }


        private async Task GetTalentCityCountryId(TalentAddressDto talentAddressDto, Address addressModel)
        {
            if (talentAddressDto.CityId == 0 || talentAddressDto.CityId == null)
            {
                City city = null;
                if (talentAddressDto.CityDescription != null)
                {
                    city = await _cityRepository.FindAsync(x => x.CityDescription.ToLower() == talentAddressDto.CityDescription.ToLower()
                                                                                   && x.CityStateCode.ToLower() == talentAddressDto.StateCode.ToLower());
                }
                // Check if State And Country Exists - if so, update the city Record

                if (city == null)
                {
                    var cityModel = await AddCityMaster(talentAddressDto);
                    addressModel.CityId = cityModel.CityId;
                    addressModel.CountryId = cityModel.CityCountryId;
                }
                else
                {
                    addressModel.CityId = city.CityId;
                    addressModel.CountryId = city.CityCountryId;
                }
            }
            else
            {
                addressModel.CityId = talentAddressDto.CityId == 0 ? null : talentAddressDto.CityId;
                addressModel.CountryId = talentAddressDto.CountryId == 0 ? null : talentAddressDto.CountryId;
            }
        }

        private async Task<City> AddCityMaster(TalentAddressDto talentAddressDto)
        {
            Country country = null;
            if (talentAddressDto.CountryName != null)
            {
                country = await _countryRepository.FindAsync(x => x.Name.ToLower() == talentAddressDto.CountryName.ToLower());
            }

            if (country != null)
            {
                if (string.IsNullOrEmpty(country.Code) || string.IsNullOrEmpty(country.Nationality))
                {
                    country.Code = talentAddressDto.CountryCode;
                    country.Nationality = talentAddressDto.Nationality;
                    country = await _countryRepository.UpdateAsync(country);
                }

                // CHECK city & Country & State = null => update the record with state

                var lststateCountry = await _cityRepository.FindAllAsync(x => string.IsNullOrEmpty(x.CityStateCode)
                                                                            && x.CityCountryId == country.Id
                                                                            && x.CityDescription.ToLower() == talentAddressDto.CityDescription.ToLower());
                // Update State if Country And City Exist
                if (lststateCountry.Count() > 0)
                {
                    var stateCountry = lststateCountry.First();
                    stateCountry.CityState = talentAddressDto.StateName;
                    stateCountry.CityStateCode = talentAddressDto.StateCode;

                    stateCountry = await _cityRepository.UpdateAsync(stateCountry);

                    return stateCountry;
                }
                else
                {
                    // Add City State new Record
                    var cityModel = new City
                    {
                        CityDescription = talentAddressDto.CityDescription,
                        CityCountryId = (country == null) ? null : (int?)country.Id,
                        CityState = talentAddressDto.StateName,
                        CityStateCode = talentAddressDto.StateCode
                    };

                    if (!string.IsNullOrEmpty(talentAddressDto.CityDescription))
                    {
                        cityModel = await _cityRepository.AddAsync(cityModel);
                    }
                    return cityModel;
                }
            }
            else
            {
                _logger.LogError("The Country => " + talentAddressDto.CountryName + " : does not exist ");
                return new City();
            }
        }

        public async Task<List<TalentTalentCategoryDto>> SaveTalentTalentCategory(int talentId, List<TalentTalentCategoryDto> lstTalentCategoryDto)
        {
            List<TalentTalentCategoryDto> returnLstTalentCategoryDto = new List<TalentTalentCategoryDto>(lstTalentCategoryDto);
            var parentTalentCategories = lstTalentCategoryDto.Where(x => x.TalentSubCategory != null).ToList();
            foreach (var talentCategoryDto in parentTalentCategories)
            {
                foreach (var talentSubCategory in talentCategoryDto.TalentSubCategory)
                {
                    lstTalentCategoryDto.Add(talentSubCategory);
                }
            }

            List<TalentTalentCategoryDto> originalLstTalentCategoryDto = new List<TalentTalentCategoryDto>(lstTalentCategoryDto);

            var lstTalentTalentCategory = _talentTalentCategoryRepository.FindAll(x => x.TalentId == talentId).ToList();

            //from the DTO remove the categories matching what is already has
            foreach (var talentTalentCategory in lstTalentTalentCategory)
            {
                lstTalentCategoryDto.RemoveAll(x => x.TalentCategoryId == talentTalentCategory.TalentCategoryId);
            }

            //from the talentCategory of the talent remove the one matching with DTO
            foreach (var talentCategoryDto in originalLstTalentCategoryDto)
            {
                lstTalentTalentCategory.RemoveAll(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId);
            }


            if (lstTalentTalentCategory.Count > 0)
            {
                foreach (var talentTalentCategory in lstTalentTalentCategory)
                {
                    await _talentTalentCategoryRepository.DeleteAsync(talentTalentCategory);
                }
            }


            if (lstTalentCategoryDto.Count > 0)
            {
                foreach (var talentCategoryDto in lstTalentCategoryDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentTalentCategory = ConvertToTalentCategoryModel(talentId, talentCategoryDto);
                    await _talentTalentCategoryRepository.AddAsync(talentTalentCategory);

                }
            }
            return returnLstTalentCategoryDto;
        }

        public async Task<List<TalentInterestCategoryDto>> SaveTalentInterestCategory(int talentId, List<TalentInterestCategoryDto> lstTalentInterestCategoriesDto)
        {
            List<TalentInterestCategoryDto> originalLstTalentInterestCategoryDto = new List<TalentInterestCategoryDto>(lstTalentInterestCategoriesDto);

            var lstTalentInterestCategory = _talentInterestCategoryRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentInterestCategory in lstTalentInterestCategory)
            {
                lstTalentInterestCategoriesDto.RemoveAll(x => x.InterestCategoryId == talentInterestCategory.InterestCategoryId);
            }

            foreach (var talentInterestCategoryDto in originalLstTalentInterestCategoryDto)
            {
                lstTalentInterestCategory.RemoveAll(x => x.InterestCategoryId == talentInterestCategoryDto.InterestCategoryId);
            }

            if (lstTalentInterestCategoriesDto.Count > 0)
            {
                foreach (var talentInterestCategoryDto in lstTalentInterestCategoriesDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentInterestCategory = ConvertToTalentInterestCategoryModel(talentId, talentInterestCategoryDto);
                    talentInterestCategory = await _talentInterestCategoryRepository.AddAsync(talentInterestCategory);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (lstTalentInterestCategory.Count > 0)
            {
                foreach (var talentInterestCategory in lstTalentInterestCategory)
                {
                    await _talentInterestCategoryRepository.DeleteAsync(talentInterestCategory);
                }
            }
            return originalLstTalentInterestCategoryDto;
        }

        public async Task<List<TalentMediaDto>> SaveTalentMedia(int talentId, List<TalentMediaDto> lstTalentMediaDto)
        {
            List<TalentMediaDto> originalLstTalentMediaDto = new List<TalentMediaDto>(lstTalentMediaDto);

            var lstTalentMedia = _talentMediaFileRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentMediaCategory in lstTalentMedia)
            {
                lstTalentMediaDto.RemoveAll(x => x.MediaFileId == talentMediaCategory.MediaFileId);
            }

            foreach (var talentInterestCategoryDto in originalLstTalentMediaDto)
            {
                lstTalentMedia.RemoveAll(x => x.MediaFileId == talentInterestCategoryDto.MediaFileId);
            }

            if (lstTalentMediaDto.Count > 0)
            {
                foreach (var talentMediaDtoDto in lstTalentMediaDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentMedia = ConvertToTalentMediaModel(talentId, talentMediaDtoDto);
                    talentMedia = await _talentMediaFileRepository.AddAsync(talentMedia);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (lstTalentMedia.Count > 0)
            {
                foreach (var talentMedia in lstTalentMedia)
                {
                    await _talentMediaFileRepository.DeleteAsync(talentMedia);
                }
            }
            return originalLstTalentMediaDto;
        }



        public async Task<PhysicalAttributesDto> SaveTalentPhysicalAttribute(int talentId, PhysicalAttributesDto physicalAttributesDto)
        {
            if (physicalAttributesDto != null)
            {
                var talentPhysicalAttribute = await _talentPhysicalAttributeRepository.FindAsync(x => x.TalentId == talentId);
                if (talentPhysicalAttribute != null)
                {
                    var talentPhysicalAttributeModel = ConvertToTalentPhysicalAttributesModel(talentId, talentPhysicalAttribute, physicalAttributesDto);
                    talentPhysicalAttributeModel = await _talentPhysicalAttributeRepository.UpdateAsync(talentPhysicalAttributeModel);
                }
                else
                {
                    TalentPhysicalAttribute talentPhysicalAttributeModel = new TalentPhysicalAttribute();
                    talentPhysicalAttributeModel = ConvertToTalentPhysicalAttributesModel(talentId, talentPhysicalAttributeModel, physicalAttributesDto);
                    talentPhysicalAttributeModel = await _talentPhysicalAttributeRepository.AddAsync(talentPhysicalAttributeModel);
                }
            }
            return physicalAttributesDto;

        }


        public async Task<List<TalentLanguageDto>> SaveTalentLanguages(int talentId, List<TalentLanguageDto> lstTalentLanguageDto)
        {
            List<TalentLanguageDto> originalLstTalentLanguageDto = new List<TalentLanguageDto>(lstTalentLanguageDto);

            var lstTalentLanguage = _talentLanguageRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentLanguage in lstTalentLanguage)
            {
                lstTalentLanguageDto.RemoveAll(x => x.LanguageId == talentLanguage.LanguageId);
            }

            foreach (var talentLanguageDto in originalLstTalentLanguageDto)
            {
                lstTalentLanguage.RemoveAll(x => x.LanguageId == talentLanguageDto.LanguageId);
            }

            if (lstTalentLanguageDto.Count > 0)
            {
                foreach (var talentLanguageDto in lstTalentLanguageDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentLanguage = ConvertToTalentLanguageModel(talentId, talentLanguageDto);
                    talentLanguage = await _talentLanguageRepository.AddAsync(talentLanguage);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (lstTalentLanguage.Count > 0)
            {
                foreach (var talentLanguage in lstTalentLanguage)
                {
                    await _talentLanguageRepository.DeleteAsync(talentLanguage);
                }
            }
            return originalLstTalentLanguageDto;
        }

        public async Task<List<TalentTagDto>> SaveTalentTags(int talentId, List<TalentTagDto> lstTalentTagDto)
        {
            List<TalentTagDto> originalLstTalentTagDto = new List<TalentTagDto>(lstTalentTagDto);

            var lstTalentTag = _talentTagRepository.FindAll(x => x.TalentId == talentId).ToList();

            // find Talent related tags
            var tagCategory = await _tagCategoryRepository.FindAllAsync(x => x.TagTalentRelated == true);
            var talentRelatedTagCategoryIds = tagCategory.Select(x => x.Id);

            //Remove Admin tags from the list
            var lstTalentTagId = lstTalentTag.Select(x => x.TagId);
            var tags = await _tagRepository.FindAllAsync(x => lstTalentTagId.Contains(x.Id) && talentRelatedTagCategoryIds.Contains(x.TagCategoryId));
            var talentTags = tags.Select(x => x.Id);


            lstTalentTag = lstTalentTag.Where(x => talentTags.Contains(x.TagId)).ToList();

            foreach (var talentTag in lstTalentTag)
            {
                lstTalentTagDto.RemoveAll(x => x.TagId == talentTag.TagId);
            }

            foreach (var talentTagDto in originalLstTalentTagDto)
            {
                lstTalentTag.RemoveAll(x => x.TagId == talentTagDto.TagId);
            }

            if (lstTalentTagDto.Count > 0)
            {
                foreach (var talentTagDto in lstTalentTagDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentTag = ConvertToTalentTagModel(talentId, talentTagDto);
                    talentTag = await _talentTagRepository.AddAsync(talentTag);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (lstTalentTag.Count > 0)
            {
                foreach (var talentTag in lstTalentTag)
                {
                    await _talentTagRepository.DeleteAsync(talentTag);
                }
            }
            return originalLstTalentTagDto;
        }
        public async Task<List<TalentEthnicityDto>> SaveTalentEthnicities(int talentId, List<TalentEthnicityDto> lstTalentEthnicityDto)
        {
            List<TalentEthnicityDto> originalLstTalentEthnicityDto = new List<TalentEthnicityDto>(lstTalentEthnicityDto);

            var lstTalentEthnicity = _talentEthnicityRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentEthnicity in lstTalentEthnicity)
            {
                lstTalentEthnicityDto.RemoveAll(x => x.EthnicityId == talentEthnicity.Ethnicity);
            }

            foreach (var talentEthnicityDto in originalLstTalentEthnicityDto)
            {
                lstTalentEthnicity.RemoveAll(x => x.Ethnicity == talentEthnicityDto.EthnicityId);
            }

            if (lstTalentEthnicityDto.Count > 0)
            {
                foreach (var talentEthnicityDto in lstTalentEthnicityDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentEthnicity = ConvertToTalentEthnicityModel(talentId, talentEthnicityDto);
                    talentEthnicity = await _talentEthnicityRepository.AddAsync(talentEthnicity);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (lstTalentEthnicity.Count > 0)
            {
                foreach (var talentEthnicity in lstTalentEthnicity)
                {
                    await _talentEthnicityRepository.DeleteAsync(talentEthnicity);
                }
            }
            return originalLstTalentEthnicityDto;
        }

        public async Task<List<TalentExperienceDto>> SaveTalentExperiences(int talentId, List<TalentExperienceDto> lstTalentExperienceDto)
        {
            List<TalentExperienceDto> originalLstTalentExperienceDto = new List<TalentExperienceDto>(lstTalentExperienceDto);
            List<TalentExperienceDto> updateLstTalentExperienceDto = new List<TalentExperienceDto>(lstTalentExperienceDto);

            var lstTalentExperience = _talentExperienceRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentExperience in lstTalentExperience)
            {
                lstTalentExperienceDto.RemoveAll(x => x.Id == talentExperience.Id);
            }

            foreach (var talentExperience in lstTalentExperienceDto)
            {
                updateLstTalentExperienceDto.RemoveAll(x => x.Id == talentExperience.Id);
            }

            foreach (var talentExperienceDto in originalLstTalentExperienceDto)
            {
                lstTalentExperience.RemoveAll(x => x.Id == talentExperienceDto.Id);
            }

            if (lstTalentExperienceDto.Count > 0)
            {
                foreach (var talentExperienceDto in lstTalentExperienceDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    TalentExperience talentExperienceModel = new TalentExperience();
                    var talentExperience = ConvertToTalentExperienceModel(talentId, talentExperienceModel, talentExperienceDto);
                    talentExperience = await _talentExperienceRepository.AddAsync(talentExperience);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (updateLstTalentExperienceDto.Count > 0)
            {
                foreach (var talentExperienceDto in updateLstTalentExperienceDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentExperience = await _talentExperienceRepository.FindAsync(x => x.Id == talentExperienceDto.Id);
                    talentExperience = ConvertToTalentExperienceModel(talentId, talentExperience, talentExperienceDto);
                    talentExperience = await _talentExperienceRepository.UpdateAsync(talentExperience);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }
            if (lstTalentExperience.Count > 0)
            {
                foreach (var talentEthnicity in lstTalentExperience)
                {
                    await _talentExperienceRepository.DeleteAsync(talentEthnicity);
                }
            }
            return originalLstTalentExperienceDto;
        }


        public async Task<List<TalentEducationDto>> SaveTalentEducation(int talentId, List<TalentEducationDto> lstTalentEducationDto)
        {
            List<TalentEducationDto> originalLstTalentEducationDto = new List<TalentEducationDto>(lstTalentEducationDto);
            List<TalentEducationDto> updatelLstTalentEducationDto = new List<TalentEducationDto>(lstTalentEducationDto);

            var lstTalentEducation = _talentEducationRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentEducation in lstTalentEducation)
            {
                lstTalentEducationDto.RemoveAll(x => x.Id == talentEducation.Id);
            }

            foreach (var talentEducation in lstTalentEducationDto)
            {
                updatelLstTalentEducationDto.RemoveAll(x => x.Id == talentEducation.Id);
            }

            foreach (var talentEducationDto in originalLstTalentEducationDto)
            {
                lstTalentEducation.RemoveAll(x => x.Id == talentEducationDto.Id);
            }

            if (lstTalentEducationDto.Count > 0)
            {
                foreach (var talentEducationDto in lstTalentEducationDto)
                {
                    TalentEducation talentEducationModel = new TalentEducation();
                    var talentEducation = ConvertToTalentEducationModel(talentId, talentEducationModel, talentEducationDto);
                    talentEducation = await _talentEducationRepository.AddAsync(talentEducation);
                }
            }

            if (updatelLstTalentEducationDto.Count > 0)
            {
                foreach (var talentEducationDto in updatelLstTalentEducationDto)
                {
                    var talentEducation = await _talentEducationRepository.FindAsync(x => x.Id == talentEducationDto.Id);
                    talentEducation = ConvertToTalentEducationModel(talentId, talentEducation, talentEducationDto);

                    talentEducation = await _talentEducationRepository.UpdateAsync(talentEducation);
                }
            }

            if (lstTalentEducation.Count > 0)
            {
                foreach (var talentEducation in lstTalentEducation)
                {
                    await _talentEducationRepository.DeleteAsync(talentEducation);
                }
            }
            return originalLstTalentEducationDto;
        }

        public async Task<List<TalentAssociationDto>> SaveTalentAssociation(int talentId, List<TalentAssociationDto> lstTalentAssociationDto)
        {
            List<TalentAssociationDto> originalLstTalentAssociationDto = new List<TalentAssociationDto>(lstTalentAssociationDto);
            List<TalentAssociationDto> updateLstTalentAssociationDto = new List<TalentAssociationDto>(lstTalentAssociationDto);

            var lstTalentAssociation = _talentAssociationRepository.FindAll(x => x.TalentId == talentId).ToList();

            foreach (var talentAssociation in lstTalentAssociation)
            {
                lstTalentAssociationDto.RemoveAll(x => x.Id == talentAssociation.Id);
            }

            foreach (var talentAssociation in lstTalentAssociationDto)
            {
                updateLstTalentAssociationDto.RemoveAll(x => x.Id == talentAssociation.Id);
            }

            foreach (var talentAssociationDto in originalLstTalentAssociationDto)
            {
                lstTalentAssociation.RemoveAll(x => x.Id == talentAssociationDto.Id);
            }

            if (lstTalentAssociationDto.Count > 0)
            {
                foreach (var talentAssociationDto in lstTalentAssociationDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    TalentAssociation talentAssociationModel = new TalentAssociation();
                    var talentAssociation = ConvertToTalentAssociationModel(talentId, talentAssociationModel, talentAssociationDto);
                    talentAssociation = await _talentAssociationRepository.AddAsync(talentAssociation);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }

            }

            if (updateLstTalentAssociationDto.Count > 0)
            {
                foreach (var updtalentAssociationDto in updateLstTalentAssociationDto)
                {
                    //var talentTalentCategory = await _talentTalentCategoryRepository.FindAsync(x => x.TalentCategoryId == talentCategoryDto.TalentCategoryId && x.TalentId == talentCategoryDto.TalentId);
                    var talentAssociation = await _talentAssociationRepository.FindAsync(x => x.Id == updtalentAssociationDto.Id);
                    talentAssociation = ConvertToTalentAssociationModel(talentId, talentAssociation, updtalentAssociationDto);
                    talentAssociation = await _talentAssociationRepository.UpdateAsync(talentAssociation);

                    //lstTalentTalentCategory.RemoveAll(s => s.TalentCategoryId == talentTalentCategory.TalentCategoryId);
                }


            }
            if (lstTalentAssociation.Count > 0)
            {
                foreach (var talentAssociation in lstTalentAssociation)
                {
                    await _talentAssociationRepository.DeleteAsync(talentAssociation);
                }
            }
            return originalLstTalentAssociationDto;
        }

        public async Task<List<TalentSecurityQuestionDto>> SaveTalentSecurityQuestion(int talentId, List<TalentSecurityQuestionDto> lstTalentSecurityQuestionDto)
        {
            if (lstTalentSecurityQuestionDto.Count > 0)
            {
                foreach (var talentSecurityQuestionDto in lstTalentSecurityQuestionDto)
                {
                    var talentSecurityQuestion = await _talentSecurityQuestionRepository.FindAsync(x => x.TalentId == talentId && x.SecurityQuestionId == talentSecurityQuestionDto.SecurityQuestionId);
                    if (talentSecurityQuestion == null)
                    {
                        talentSecurityQuestion = ConvertToTalentSecurityModel(talentId, talentSecurityQuestionDto);
                        talentSecurityQuestion = await _talentSecurityQuestionRepository.AddAsync(talentSecurityQuestion);
                    }
                    else
                    {
                        talentSecurityQuestion.Answer = talentSecurityQuestionDto.Answer;
                        talentSecurityQuestion = await _talentSecurityQuestionRepository.UpdateAsync(talentSecurityQuestion);
                    }
                }
            }
            return lstTalentSecurityQuestionDto;
        }

        private TalentSecurityQuestion ConvertToTalentSecurityModel(int talentId, TalentSecurityQuestionDto talentSecurityQuestionDto)
        {
            TalentSecurityQuestion talentSecurityQuestion = new TalentSecurityQuestion();
            talentSecurityQuestion.Id = talentSecurityQuestionDto.Id;
            talentSecurityQuestion.TalentId = talentId;
            talentSecurityQuestion.SecurityQuestionId = talentSecurityQuestionDto.SecurityQuestionId;
            talentSecurityQuestion.Answer = talentSecurityQuestionDto.Answer;
            return talentSecurityQuestion;
        }
        private TalentAssociation ConvertToTalentAssociationModel(int talentId, TalentAssociation talentAssociation, TalentAssociationDto talentAssociationDto)
        {

            talentAssociation.Id = talentAssociationDto.Id;
            talentAssociation.TalentId = talentId;
            talentAssociation.AssociationId = talentAssociationDto.AssociationId;
            talentAssociation.MembershipId = talentAssociationDto.MembershipId;
            return talentAssociation;
        }
        private TalentEducation ConvertToTalentEducationModel(int talentId, TalentEducation talentEducation, TalentEducationDto talentEducationDto)
        {

            talentEducation.Id = talentEducationDto.Id;
            talentEducation.TalentId = talentId;
            talentEducation.School = talentEducationDto.School;
            talentEducation.Course = talentEducationDto.Course;
            talentEducation.City = talentEducationDto.City;
            talentEducation.Country = talentEducationDto.Country;
            talentEducation.Year = talentEducationDto.Year;
            talentEducation.SchoolId = talentEducationDto.SchoolId;
            return talentEducation;
        }

        private TalentExperience ConvertToTalentExperienceModel(int talentId, TalentExperience talentExperience, TalentExperienceDto talentExperienceDto)
        {
            talentExperience.Id = talentExperienceDto.Id;
            talentExperience.TalentId = talentId;
            talentExperience.InterestCategoryId = talentExperienceDto.InterestCategoryId;
            talentExperience.TalentCategoryId = talentExperienceDto.TalentCategoryId;
            talentExperience.ProjectTitle = talentExperienceDto.ProjectTitle;
            talentExperience.Role = talentExperienceDto.Role;
            talentExperience.Year = talentExperienceDto.Year;
            talentExperience.ProductionHouse = talentExperienceDto.ProductionHouse;
            talentExperience.ProductionHouseId = talentExperienceDto.ProductionHouseId;
            talentExperience.SubTalentCategoryId = talentExperienceDto.SubTalentCategoryId;
            return talentExperience;
        }
        private TalentEthnicity ConvertToTalentEthnicityModel(int talentId, TalentEthnicityDto talentEthnicityDto)
        {
            TalentEthnicity talentEthnicity = new TalentEthnicity();
            talentEthnicity.Id = talentEthnicityDto.Id;
            talentEthnicity.TalentId = talentId;
            talentEthnicity.Ethnicity = talentEthnicityDto.EthnicityId;
            return talentEthnicity;
        }
        private TalentTag ConvertToTalentTagModel(int talentId, TalentTagDto talentTagDto)
        {
            TalentTag talentTag = new TalentTag();
            talentTag.Id = talentTagDto.Id;
            talentTag.TalentId = talentId;
            talentTag.TagId = talentTagDto.TagId;
            return talentTag;
        }
        private TalentLanguage ConvertToTalentLanguageModel(int talentId, TalentLanguageDto talentLanguageDto)
        {
            TalentLanguage talentLanguage = new TalentLanguage();
            talentLanguage.Id = talentLanguageDto.Id;
            talentLanguage.TalentId = talentId;
            talentLanguage.LanguageId = talentLanguageDto.LanguageId;
            return talentLanguage;
        }

        public TalentPhysicalAttribute ConvertToTalentPhysicalAttributesModel(int talentId, TalentPhysicalAttribute talentPhysicalAttribute, PhysicalAttributesDto physicalAttributesDto)
        {
            //TalentPhysicalAttribute talentPhysicalAttributes = new TalentPhysicalAttribute();
            //talentPhysicalAttributes.Id = physicalAttributesDto.Id;

            talentPhysicalAttribute.TalentId = talentId;
            talentPhysicalAttribute.BodyTypeId = physicalAttributesDto.BodyTypeId;
            talentPhysicalAttribute.ChestSizeId = physicalAttributesDto.ChestSizeId;
            talentPhysicalAttribute.EyeColorId = physicalAttributesDto.EyeColorId;
            talentPhysicalAttribute.HairColorId = physicalAttributesDto.HairColorId;
            talentPhysicalAttribute.HairLengthId = physicalAttributesDto.HairLengthId;
            talentPhysicalAttribute.HairTypeId = physicalAttributesDto.HairTypeId;
            talentPhysicalAttribute.HeightId = physicalAttributesDto.HeightId;
            talentPhysicalAttribute.SkinColorId = physicalAttributesDto.SkinColorId;
            talentPhysicalAttribute.WaistId = physicalAttributesDto.WaistId;
            talentPhysicalAttribute.WeightSizeId = physicalAttributesDto.WeightSizeId;
            return talentPhysicalAttribute;
        }
        public Talent ConvertToTalentModel(Talent talent, TalentDto talentDto)
        {
            //Talent talent = new Talent();
            //talent.Id = talentDto.Id;
            talent.FullName = talentDto.FullName;
            talent.Email = talentDto.Email;
            talent.Mobile = talentDto.Mobile;
            talent.MobileCountryCode = talentDto.MobileCountryCode;
            talent.WhatsupCountryCode = talentDto.WhatsAppCountryCode;
            talent.WhatsupMobile = talentDto.WhatsAppNumber;
            talent.Onboarded = talentDto.OnBoarded;
            talent.CompletionPercentage = talentDto.CompletionPercentage;
            talent.Gender = talentDto.Gender;
            talent.LastTabNo = talentDto.LastTabNo;
            talent.StatusId = talentDto.StatusId;
            talent.DOB = talentDto.DOB;
            talent.GuardianEmailId = talentDto.GuardianEmailId;
            talent.GuardianMobile = talentDto.GuardianMobile;
            talent.GuardianName = talentDto.GuardianName;
            talent.GuardianRelation = talentDto.GuardianRelation;

            talent.PassportCountryId = talentDto.PassportCountryId;
            talent.PassportExpirationDate = talentDto.PassportExpirationDate;
            talent.VisaType = talentDto.VisaType;
            talent.VisaYear = talentDto.VisaYear;



            talent.AgencyId = talentDto.AgencyId;
            talent.AgencyStartDate = talentDto.AgencyStartDate;
            talent.AgencyEndDate = talentDto.AgencyEndDate;
            talent.AgencyAgentName = talentDto.AgencyAgentName;
            talent.AgencyAgentMobileNo = talentDto.AgencyAgentMobileNo;
            talent.AgencyAgentEmail = talentDto.AgencyAgentEmail;
            talent.TermsConditionAccepted = talentDto.TermsConditionAccepted;
            talent.BudgetMax = talentDto.BudgetMax;
            talent.BudgetMin = talentDto.BudgetMin;

            talent.IsProfilePrivate = talentDto.IsProfilePrivate;

            talent.AboutMe = talentDto.AboutMe;
            talent.MobileCountryId = talentDto.MobileCountryId;
            talent.WhatsupCountryId = talentDto.WhatsupCountryId;
            talent.UpdatedOn = DateTime.Now;
            return talent;
        }

        public TalentTalentCategory ConvertToTalentCategoryModel(int talentId, TalentTalentCategoryDto talentCategoryDto)
        {
            TalentTalentCategory talentCategory = new TalentTalentCategory();
            talentCategory.TalentCategoryId = talentCategoryDto.TalentCategoryId;
            talentCategory.TalentId = talentId;
            return talentCategory;
        }

        public TalentInterestCategory ConvertToTalentInterestCategoryModel(int talentId, TalentInterestCategoryDto talentInterestCategoryDto)
        {
            TalentInterestCategory talentInterestCategory = new TalentInterestCategory();
            talentInterestCategory.InterestCategoryId = talentInterestCategoryDto.InterestCategoryId;
            talentInterestCategory.TalentId = talentId;
            return talentInterestCategory;
        }

        public TalentMedia ConvertToTalentMediaModel(int talentId, TalentMediaDto talentMediaDto)
        {
            TalentMedia talentMedia = new TalentMedia();
            talentMedia.MediaFileId = talentMediaDto.MediaFileId;
            talentMedia.TalentId = talentMediaDto.TalentId;
            return talentMedia;
        }
        public async Task<string> GetAgencyName(int? agencyId)
        {
            if (agencyId != null)
            {
                var auxiliaryUser = await _auxiliaryUserRepository.FindAsync(x => x.Id == agencyId);
                if (auxiliaryUser != null)
                {
                    return auxiliaryUser.FullName;
                }
            }
            return null;
        }

        public async Task<int?> CalculatePercentageCompleted(int talentId, TalentInfoDto talentInfoDto)
        {
            int? talentCompletionPercentage = 0;
            if (talentInfoDto.Talent != null)
            {
                talentCompletionPercentage = talentCompletionPercentage + 10;
            }
            if (talentInfoDto.TalentTalentCategories.Count > 0)
            {
                talentCompletionPercentage = talentCompletionPercentage + 10;
            }
            if (talentInfoDto.TalentInterestCategories.Count > 0)
            {
                talentCompletionPercentage = talentCompletionPercentage + 10;
            }
            if (talentInfoDto.PhysicalAttributes != null || talentInfoDto.TalentEthnicity.Count > 0)
            {
                if (talentInfoDto.PhysicalAttributes.WeightSizeId != null || talentInfoDto.PhysicalAttributes.HeightId != null)
                    talentCompletionPercentage = talentCompletionPercentage + 10;
            }
            if (talentInfoDto.TalentTags.Count > 0 || talentInfoDto.TalentLanguages.Count > 0)
            {
                talentCompletionPercentage = talentCompletionPercentage + 10;
            }
            if (talentInfoDto.TalentEducation.Count > 0)
            {
                talentCompletionPercentage = talentCompletionPercentage + 15;
            }
            if (talentInfoDto.TalentExperience.Count > 0)
            {
                talentCompletionPercentage = talentCompletionPercentage + 10;
            }
            if (talentInfoDto.TalentMedias.Count > 0 || talentInfoDto.TalentSocialLink.Count > 0)
            {
                talentCompletionPercentage = talentCompletionPercentage + 10;
            }

            if (talentInfoDto.TalentAssociations.Count > 0 || talentInfoDto.TalentSecurityQuestions.Count > 0 || talentInfoDto.Talent.PassportCountryId != null || talentInfoDto.Talent.PassportExpirationDate != null
                || !string.IsNullOrEmpty(talentInfoDto.Talent.VisaType) || !string.IsNullOrEmpty(talentInfoDto.Talent.VisaYear) || talentInfoDto.Talent.AgencyId != null || !string.IsNullOrEmpty(talentInfoDto.Talent.AgencyName)
                || !string.IsNullOrEmpty(talentInfoDto.Talent.AgencyAgentEmail) || !string.IsNullOrEmpty(talentInfoDto.Talent.AgencyAgentMobileNo) || talentInfoDto.Talent.AgencyStartDate != null || talentInfoDto.Talent.AgencyEndDate != null
                || talentInfoDto.Talent.BudgetMin != null || talentInfoDto.Talent.BudgetMax != null || !string.IsNullOrEmpty(talentInfoDto.Talent.AboutMe))
            {
                talentCompletionPercentage = talentCompletionPercentage + 15;
            }

            var talent = await _talentRepository.FindAsync(x => x.Id == talentId);
            talent.CompletionPercentage = talentCompletionPercentage;
            talent = await _talentRepository.UpdateAsync(talent);

            return talentCompletionPercentage;
        }

        public TalentTransactionDetailDto ConvertToTalentTransactionDetailDto(TalentTransactionDetail talentTransactionDetail)
        {
            TalentTransactionDetailDto talentTransactionDetailDto = new TalentTransactionDetailDto();
            talentTransactionDetailDto.Id = talentTransactionDetail.Id;
            talentTransactionDetailDto.TalentTransactionId = talentTransactionDetail.TalentTransactionId;
            talentTransactionDetailDto.TalentPlanId = talentTransactionDetail.TalentPlanId;
            talentTransactionDetailDto.EndDate = talentTransactionDetail.EndDate;
            return talentTransactionDetailDto;
        }

        public async Task<List<TalentMediaDto>> GetTalentMedias(int talentId)
        {
            var talentMediaResponse = await _talentMediaFileRepository.FindAllAsync(x => x.TalentId == talentId);

            List<TalentMediaDto> talentMediaList = new List<TalentMediaDto>();

            foreach (var talentMedia in talentMediaResponse)
            {
                TalentMediaDto talentMediaDto = await ConvertToTalentMediaDto(talentId, talentMedia);

                talentMediaList.Add(talentMediaDto);
            }
            return talentMediaList;

        }

        public async Task<List<TalentMediaDto>> GetTalentMediasBySubscription(int talentId)
        {
            var talentMediaResponse = await _talentMediaFileRepository.FindAllAsync(x => x.TalentId == talentId);

            List<TalentMediaDto> talentMediaList = new List<TalentMediaDto>();

            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            dictionary = await GetSubscribedMediaCount(talentId);

            int subscribedImageCount = dictionary["ImageCount"];
            int subscribedVideoCount = dictionary["VideoCount"];
            int subscribedAudioCount = dictionary["AudioCount"];
            int subscribedScriptCount = dictionary["ScriptCount"];

            List<string> lstOfOnboardingImagesFlagIds = GetFlagIdsOfOnboardingImages();
            var subscribedImages = GetTalentSuscribedImages(talentMediaResponse.ToList(), lstOfOnboardingImagesFlagIds, subscribedImageCount);

            var subscribedVideos = GetTalentSuscribedVideos(talentMediaResponse.ToList(), subscribedVideoCount);

            var subscribedAudios = GetTalentSuscribedAudios(talentMediaResponse.ToList(), subscribedAudioCount);

            var subscribedScripts = GetTalentSuscribedScripts(talentMediaResponse.ToList(), subscribedScriptCount);

            var talentMedias = subscribedImages.Concat(subscribedVideos)
                                                    .Concat(subscribedAudios)
                                                    .Concat(subscribedScripts).ToList();
            foreach (var talentMedia in talentMedias)
            {
                TalentMediaDto talentMediaDto = await ConvertToTalentMediaDto(talentId, talentMedia);

                talentMediaList.Add(talentMediaDto);
            }
            return talentMediaList;

        }

        public async Task<Dictionary<string, int>> GetSubscribedMediaCount(int talentId)
        {
            int subscribedImageCount = 0;
            int subscribedVideoCount = 0;
            int subscribedAudioCount = 0;
            int subscribedScriptCount = 0;

            var talentTransactions = await _talentTransactionRepository.FindAllAsync(x => x.TalentId == talentId);

            if (talentTransactions != null)
            {
                List<TalentTransactionDetail> lstTalentTransactionDetail = new List<TalentTransactionDetail>();
                foreach (var talentTransaction in talentTransactions)
                {
                    var talentTransactionDetail = await _talentTransactionDetailRepository.FindAllAsync(x => x.TalentTransactionId == talentTransaction.Id && x.EndDate > DateTime.Now);
                    if (talentTransactionDetail != null && talentTransactionDetail.Count() > 0)
                    {
                        // there are multiple transaction for talent - on each upgrade a new entry is added...pick the latest plan
                        var lstestTalentTransactionDetail = talentTransactionDetail.OrderByDescending(x => x.Id).FirstOrDefault();

                        lstTalentTransactionDetail.Add(lstestTalentTransactionDetail);
                    }
                }

                if (lstTalentTransactionDetail.Count > 0)
                {
                    foreach (var talentTransactionDetail in lstTalentTransactionDetail)
                    {
                        TalentPlanFeature talentPlanFeature = new TalentPlanFeature();
                        talentPlanFeature = await _talentPlanFeatureRepository.FindAsync(x => x.TalentPlanId == talentTransactionDetail.TalentPlanId && x.TalentFeatureId == (int)TalentFeatures.MediaHosting);

                        if (talentPlanFeature != null)
                        {
                            var talentFeature = await _talentFeatureRepository.FindAsync(x => x.Id == talentPlanFeature.TalentFeatureId);
                            subscribedImageCount = talentFeature.ImageCount;
                            subscribedVideoCount = talentFeature.VideoCount;
                            subscribedAudioCount = talentFeature.AudioCount;
                            subscribedScriptCount = talentFeature.ScriptCount;
                        }
                    }
                }
            }
            var lstParam = await _paramRepository.GetAllAsync();
            var param = lstParam.First();
            subscribedImageCount = subscribedImageCount + param.ImageCount;
            subscribedVideoCount = subscribedVideoCount + param.VideoCount;
            subscribedAudioCount = subscribedAudioCount + param.AudioCount;
            subscribedScriptCount = subscribedScriptCount + param.ScriptCount;
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            dictionary.Add("ImageCount", subscribedImageCount);
            dictionary.Add("VideoCount", subscribedVideoCount);
            dictionary.Add("AudioCount", subscribedAudioCount);
            dictionary.Add("ScriptCount", subscribedScriptCount);
            return dictionary;
        }


        private List<TalentMedia> GetTalentSuscribedImages(List<TalentMedia> talentMediaResponse, List<string> lstOfOnboardingImagesFlagIds, int subscribedImageCount)
        {
            var talentOnboardingImages = talentMediaResponse.Where(x => lstOfOnboardingImagesFlagIds.Contains(x.Flag)).ToList();
            int numberOFGeneralImages = subscribedImageCount - talentOnboardingImages.Count();
            var talentGeneralImages = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.GeneralImages).ToString()).OrderBy(x => x.MediaFileId).Take(numberOFGeneralImages).ToList();
            return talentOnboardingImages.Concat(talentGeneralImages).ToList();
        }

        private List<TalentMedia> GetTalentSuscribedVideos(List<TalentMedia> talentMediaResponse, int subscribedVideoCount)
        {
            var talentOnboardingVideo = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.OnBoardingVideo).ToString() || x.Flag == ((int)FlagType.OnBoardingExternalURL).ToString()).ToList();
            int numberOFGeneralVideos = subscribedVideoCount - talentOnboardingVideo.Count();
            var talentGeneralVideos = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.GeneralVideos).ToString()).OrderBy(x => x.MediaFileId).Take(numberOFGeneralVideos).ToList();
            return talentOnboardingVideo.Concat(talentGeneralVideos).ToList();
        }

        private List<TalentMedia> GetTalentSuscribedAudios(List<TalentMedia> talentMediaResponse, int subscribedAudioCount)
        {
            var talentOnboardingAudio = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.OnBoardingAudio).ToString()).ToList();
            int numberOFGeneralAudios = subscribedAudioCount - talentOnboardingAudio.Count();
            var talentGeneralAudios = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.GeneralAudios).ToString()).OrderBy(x => x.MediaFileId).Take(numberOFGeneralAudios).ToList();
            return talentOnboardingAudio.Concat(talentGeneralAudios).ToList();
        }

        private List<TalentMedia> GetTalentSuscribedScripts(List<TalentMedia> talentMediaResponse, int subscribedScriptCount)
        {
            var talentOnboardingScript = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.OnBoardingScript).ToString()).ToList();
            int numberOFGeneralScripts = subscribedScriptCount - talentOnboardingScript.Count();
            var talentGeneralScripts = talentMediaResponse.Where(x => x.Flag == ((int)FlagType.GeneralScripts).ToString()).OrderBy(x => x.MediaFileId).Take(numberOFGeneralScripts).ToList();
            return talentOnboardingScript.Concat(talentGeneralScripts).ToList();
        }

        private List<string> GetFlagIdsOfOnboardingImages()
        {
            List<string> lstOfFlags = new List<string>();
            lstOfFlags.Add(((int)FlagType.OnBoardingFull).ToString());
            lstOfFlags.Add(((int)FlagType.OnBoardingHeadShot).ToString());
            lstOfFlags.Add(((int)FlagType.OnBoardingLeftSide).ToString());
            lstOfFlags.Add(((int)FlagType.OnBoardingRightSide).ToString());
            return lstOfFlags;
        }
    }
}

