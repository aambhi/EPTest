﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProductionHouseRepository:GenericRepository<ProductionHouse>, IProductionHouseRepository
    {
        public ProductionHouseRepository(FTCDbContext context):base(context)
        {

        }
    }
}
