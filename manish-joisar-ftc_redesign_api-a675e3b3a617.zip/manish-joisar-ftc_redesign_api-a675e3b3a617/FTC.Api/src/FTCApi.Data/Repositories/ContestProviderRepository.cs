﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ContestProviderRepository:GenericRepository<ContestProvider>, IContestProviderRepository
    {
        public ContestProviderRepository(FTCDbContext context): base(context)
        {

        }
    }
}
