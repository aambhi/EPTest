﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobSubTalentRepository : GenericRepository<ProjectJobSubTalent>, IProjectJobSubTalentRepository
    {
        public ProjectJobSubTalentRepository(FTCDbContext context) : base(context)
        {
        }
    }
}