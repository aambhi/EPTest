﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class HairColorRepository: GenericRepository<HairColor>, IHairColorRepository
    {
        public HairColorRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
