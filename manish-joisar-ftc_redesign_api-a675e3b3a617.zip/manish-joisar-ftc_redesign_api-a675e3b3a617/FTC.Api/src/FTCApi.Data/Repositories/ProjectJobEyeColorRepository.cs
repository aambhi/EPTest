﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobEyeColorRepository : GenericRepository<ProjectJobEyeColor> , IProjectJobEyeColorRepository
    {
        public ProjectJobEyeColorRepository(FTCDbContext context):base(context)
        {

        }
    }
}
