﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class EthnicityRepository: GenericRepository<Ethnicity>,IEthnicityRepository
    {
        public EthnicityRepository(FTCDbContext context):base(context)
        {

        }
    }
}
