﻿using FTCApi.Core.RepositoryInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FTCApi.Dtos.DashboardDtos;
using FTCApi.Core.Models;
using FTCApi.Dtos.Enum;
using static FTCApi.Dtos.LoginEnum;
using FTCApi.Dtos;
using Microsoft.EntityFrameworkCore;

namespace FTCApi.Data.Repositories
{
    public class AdminDashboardRepository : GenericRepository<Talent>, IAdminDashboardRepository
    {
        private ITalentRepository _talentRepository;
        private IContestRepository _contestRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IAuxiliaryUserRepository _auxiliaryUserRepository;
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;



        public AdminDashboardRepository(FTCDbContext context,
                                        ITalentRepository talentRepository,
                                        IContestRepository contestRepository,
                                        IProjectRepository projectRepository,
                                        IProjectJobRepository projectJobRepository,
                                        IAuxiliaryUserRepository auxiliaryUserRepository,
                                        IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository) : base(context)

        {
            _talentRepository = talentRepository;
            _contestRepository = contestRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _auxiliaryUserRepository = auxiliaryUserRepository;
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
        }

        public async Task<ContestStatsDto> GetContestStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin)
        {
            IQueryable<Contest> contests = _context.Set<Contest>();

            if (isFtcProjectAdmin || isFtcRecruiterAdmin)
            {
                var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);                
                contests = contests.Where(c => assignedRecruiters.Contains(c.AuxiliaryUserId));                                    
            }

            var contestList = contests.Select(x => new { x.Id, x.StatusId, x.EndDate });

            var activeContestCount =  await contestList.CountAsync(x => (x.StatusId == (int)StatusEnum.Active || x.StatusId == (int)StatusEnum.Published)
                                                                        && x.EndDate >= DateTime.Now.Date);

            var closedCountestCount = await contestList.CountAsync(x => x.StatusId == (int)StatusEnum.Close || x.EndDate < DateTime.Now.Date);

            var discardCountestCount = await contestList.CountAsync(x => x.StatusId == (int)StatusEnum.Discard);

            var  underVerificationContestCount = await contestList.CountAsync(x => x.StatusId == (int)StatusEnum.Draft && x.EndDate >= DateTime.Now.Date);

           var  verifiedContestCount = await contestList.CountAsync(x => x.StatusId == (int)StatusEnum.Verified && x.EndDate >= DateTime.Now.Date);

            var totalCountContestCount = await contestList.CountAsync();

            var contestStatsDto = new ContestStatsDto
            {
             Active = activeContestCount,
             Closed = closedCountestCount,
             Discard = discardCountestCount,
             TotalCount = totalCountContestCount,
             UnderVerification = underVerificationContestCount,
             Verified = verifiedContestCount
            };
            return contestStatsDto;
        }

        public async Task<ProjectJobStatsDto> GetProjectJobStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin)
        {            
            IQueryable<ProjectJob> projectJobsContext = _context.Set<ProjectJob>();
            if (isFtcProjectAdmin)
            {
                // only for the specified project -> show the jobs stats
                var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userId);
                projectJobsContext = projectJobsContext.Where(c => assignedProjects.ContainsKey(c.ProjectId));
            }
            else if (isFtcRecruiterAdmin)
            {
                //get recruiters - and all their jobs
                var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);
                var projects = await _projectRepository.FindAllAsync(x => assignedRecruiters.Contains(x.AuxiliaryUserId));
                var lstProjectsId = projects.Select(x => x.Id).ToList();

                projectJobsContext = projectJobsContext.Where(c => lstProjectsId.Contains(c.ProjectId));
            }

            var projectJobs = projectJobsContext.Select(x => new { x.StatusId, x.EndDate });

            var projectJobStatsDto = new ProjectJobStatsDto
            {
                Active = await projectJobs.CountAsync(x => x.StatusId == (int)StatusEnum.Active && x.EndDate >= DateTime.Now.Date),
                Closed = await projectJobs.CountAsync(x => x.StatusId == (int)StatusEnum.Close || x.EndDate < DateTime.Now.Date),
                Draft = await projectJobs.CountAsync(x => x.StatusId == (int)StatusEnum.Draft && x.EndDate >= DateTime.Now.Date),
                TotalCount = await projectJobs.CountAsync()
            };
            return projectJobStatsDto;
        }

        public async Task<ProjectStatsDto> GetProjectStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin)
        {            
            IQueryable<Project> projectsContext = _context.Set<Project>();
            // job admin us not needed
            if (isFtcProjectAdmin)
            {
                var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userId);
                projectsContext = projectsContext.Where(x => x.AuxiliaryUserId == userId || assignedProjects.ContainsKey(x.Id));
            }
            else if (isFtcRecruiterAdmin)
            {
                // get assigned recruiters & of those recruiters get all projects
                var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);
                projectsContext = projectsContext.Where(p => p.AuxiliaryUserId == userId || assignedRecruiters.Contains(p.AuxiliaryUserId));
            }

            var projects = projectsContext.Select(x => new {x.StatusId,x.EndDate });

            var projectStatsDto = new ProjectStatsDto
            {
                //Project is active when status is active and end date is more than equal to Today's date
                Active = await projects.CountAsync(x => x.StatusId == (int)StatusEnum.Active && x.EndDate >= DateTime.Now.Date),
                Closed = await projects.CountAsync(x => x.StatusId == (int)StatusEnum.Close || x.EndDate < DateTime.Now.Date),
                UnderVerification = await projects.CountAsync(x => x.StatusId == (int)StatusEnum.Draft && x.EndDate >= DateTime.Now.Date),
                Verified = await projects.CountAsync(x => x.StatusId == (int)StatusEnum.Verified && x.EndDate >= DateTime.Now.Date),
                TotalCount = await projects.CountAsync()
            };
            return projectStatsDto;
        }

        public async Task<RecruiterStatsDto> GetRecruiterStats(int userId, bool isFtcProjectAdmin, bool isFtcRecruiterAdmin)
        {
            IQueryable<AuxiliaryUser> recruitersContext = _context.Set<AuxiliaryUser>();
            if (isFtcProjectAdmin || isFtcRecruiterAdmin)
            {
                var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);
                recruitersContext = recruitersContext.Where(x => x.TypeId == (int)LoginUserType.Recruiter && assignedRecruiters.Contains(x.Id));
            }
            else
            {
                recruitersContext = recruitersContext.Where(x => x.TypeId == (int)LoginUserType.Recruiter);
            }

            var recruiters = recruitersContext.Select(x => new{ x.Verified, x.StatusId});

            var recruiterStatsDto = new RecruiterStatsDto
            {
                Verified = await recruitersContext.CountAsync(x => x.Verified == true 
                                                                && x.StatusId != (int)StatusEnum.Blocked),

                NotVerified = await recruitersContext.CountAsync(x => x.Verified == false
                                                                    && x.StatusId != (int)StatusEnum.Blocked),

                Blocked = await recruitersContext.CountAsync(x => x.StatusId == (int)StatusEnum.Blocked),

                TotalCount = await recruitersContext.CountAsync()
            };
            return recruiterStatsDto;
        }

        public async Task<TalentStatsDto> GetTalentStats()
        {
            IQueryable<Talent> talentContext = _context.Set<Talent>();
            var talent = talentContext.Select(x => new { x.Gender, x.StatusId });
            //var talents = await _talentRepository.GetAllAsync();

            var gender = new
            {
                Male = ((int)LoginEnum.Gender.Male).ToString(),
                Female = ((int)LoginEnum.Gender.Female).ToString(),
                Transgender = ((int)LoginEnum.Gender.Transgender).ToString()
            };

            var talentStatsDto = new TalentStatsDto
            {
                Male = await talent.CountAsync(x => x.Gender == gender.Male && x.StatusId == (int)StatusEnum.Active),
                Female = await talent.CountAsync(x => x.Gender == gender.Female && x.StatusId == (int)StatusEnum.Active),
                Transgender = await talent.CountAsync(x => x.Gender == gender.Transgender && x.StatusId == (int)StatusEnum.Active),
                InActive = await talent.CountAsync(x => x.StatusId == (int)StatusEnum.InActive),
                NotSpecified = await talent.CountAsync(x => string.IsNullOrEmpty(x.Gender) && x.StatusId == (int)StatusEnum.Active),
                TotalCount = await talent.CountAsync()
            };
            return talentStatsDto;
        }
    }
}
