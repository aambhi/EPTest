﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentSocialLinkRepository:GenericRepository<TalentSocialLink>, ITalentSocialLinkRepository
    {
        public TalentSocialLinkRepository(FTCDbContext context):base(context)
        {

        }
    }
}
