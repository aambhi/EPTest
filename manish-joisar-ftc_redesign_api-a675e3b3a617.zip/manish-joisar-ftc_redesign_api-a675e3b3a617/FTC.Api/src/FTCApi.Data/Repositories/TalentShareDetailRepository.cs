﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentShareDetailRepository:GenericRepository<TalentShareDetail>, ITalentShareDetailRepository
    {
        public TalentShareDetailRepository(FTCDbContext context):base(context)
        {

        }
    }
}
