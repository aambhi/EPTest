﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TagCategoryRepository:  GenericRepository<TagCategory>, ITagCategoryRepository
    {
        public TagCategoryRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
