﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class FileTypeRepository:GenericRepository<FileType>, IFileTypeRepository
    {
        public FileTypeRepository(FTCDbContext context):base(context)
        {
                
        }
    }
}
