﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ContestSubmissionMediaRepository : GenericRepository<ContestSubmissionMedia>, IContestSubmissionMediaRepository
    {
        public ContestSubmissionMediaRepository(FTCDbContext context):base(context)
        {

        }
    }
}
