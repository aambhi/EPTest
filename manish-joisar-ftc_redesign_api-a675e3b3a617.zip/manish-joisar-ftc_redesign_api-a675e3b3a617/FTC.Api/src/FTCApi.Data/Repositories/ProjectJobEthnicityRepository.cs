﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobEthnicityRepository : GenericRepository<ProjectJobEthnicity>, IProjectJobEthnicityRepository
    {
        public ProjectJobEthnicityRepository(FTCDbContext context) : base(context)
        {

        }
    }
}
