﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentPlanFeatureRepository:GenericRepository<TalentPlanFeature>, ITalentPlanFeatureRepository
    {
        public TalentPlanFeatureRepository(FTCDbContext context):base(context)
        {

        }
    }
}
