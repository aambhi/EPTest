﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryRecruiterTransactionRepository:GenericRepository<AuxiliaryRecruiterTransaction>, IAuxiliaryRecruiterTransactionRepository
    {
        public AuxiliaryRecruiterTransactionRepository(FTCDbContext context):base(context)
        {

        }
    }
}
