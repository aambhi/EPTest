﻿using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.Models.Provider;
using FTCApi.Core.RepositoryInterface;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static FTC.Provider.ProviderFactory;

namespace FTCApi.Data.Repositories
{
    public class ProviderRepository : GenericRepository<ContestProvider>, IProviderRepository
    {

        #region Constants

        private const string SubsciberIdAlreadyInUse = "Subscriber Id is already in use for this contest"; 
        #endregion

        #region Constructor

        private IContestSubmissionRepository _contestSubmissionRepository;

        public ProviderRepository(FTCDbContext context, IContestSubmissionRepository contestSubmissionRepository) : base(context)
        {
            _contestSubmissionRepository = contestSubmissionRepository;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// This method authenticate based on subscriberId
        /// </summary>
        /// <param name="providerDetails"></param>
        /// <returns>return response wheather subscriberId is valid or not</returns>
        public async Task<ProviderResponse> Authenticate(ProviderDetails providerDetails)
        {
            //get providerInfo based on contest id
            providerDetails.ContestProvider = await GetProviderInfo(providerDetails.ContestId, providerDetails.ProviderId);

            var factory = new ConcreteProviderFactory();
            var auxId = providerDetails.ContestProvider == null ? null : providerDetails.ContestProvider.AuxiliaryUserId;

            var provider = ChooseProvider(auxId);
            var iProvider = factory.GetProvider(provider);

            ProviderResponse providerResponse = null;
            if (await CheckValidSubscriber(providerDetails.ContestId, providerDetails.TalentId, providerDetails.SubscriberId, provider))
            {
                providerResponse = new ProviderResponse
                {
                    IsValid = false,
                    Status = StatusCode.SubsciberIdAlreadyInUse,
                    Message = SubsciberIdAlreadyInUse
                };
            }
            else
            {
                //This make call to provider endpoint to authenticate.
                providerResponse = await iProvider.Authenticate(providerDetails);
            }
            return await Task.Run(() => providerResponse);
        }

        /// <summary>
        /// This method get active subscription list
        /// </summary>
        /// <param name="rmn"></param>
        /// <param name="contestId"></param>
        /// <param name="providerId"></param>
        /// <returns>returns subscription list</returns>
        public async Task<List<AccountDetail>> GetSubscriptions(string rmn, int contestId, int providerId)
        {
            var providerDetails = new ProviderDetails
            {
                rmn = rmn,

                //get providerInfo based on contest id
                ContestProvider = await GetProviderInfo(contestId, providerId)
            };

            var factory = new ConcreteProviderFactory();
            var auxId = providerDetails.ContestProvider == null ? null : providerDetails.ContestProvider.AuxiliaryUserId;
            var provider = ChooseProvider(auxId);
            var iProvider = factory.GetProvider(provider);

            //This make call to provider endpoint to get list of active subscriptions. 
            var listSubscription = iProvider.GetSubscriptions(providerDetails);
            return await Task.Run(() => listSubscription);
        }

        /// <summary>
        /// This method dummy method check subscriber code is valid if subscriber id length equal to 10 and starts with '300'
        /// </summary>
        /// <param name="subscriberId"></param>
        /// <returns></returns>
        public async Task<ProviderResponse> CheckProvider(string subscriberId)
        {
            ProviderResponse providerResponse = null;
            if (CheckValidCode(subscriberId))
            {
                providerResponse = new ProviderResponse
                {
                    IsValid = true,
                    Status = StatusCode.Success,
                    Message = "Valid Response"
                };
               
            }
            else
            {
                providerResponse = new ProviderResponse
                {
                    IsValid = false,
                    Status = StatusCode.Error,
                    Message = "Package is Deactivated."
                };
            }
            return await Task.Run(() => providerResponse);
        }

        /// <summary>
        /// This is dummy logic which will check valid code if code start with 300 and length is equal to 10.
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        private static bool CheckValidCode(string code)
        {
            if (code.Length == 10 && code.StartsWith("300"))
            {
                return true;
            }
            return false;
        }

        #endregion

        #region Private Methods

        private async Task<bool> CheckValidSubscriber(int contestId, int talentId, string subscriberId, Providers provider)
        {
            var status = false;
            List<ContestSubmission> listContestSubmission = null;
            if (provider == Providers.TATASKY)
            {
                listContestSubmission = _contestSubmissionRepository.FindAll(x => x.ContestId == contestId  && x.Value2.ToLower() == subscriberId.ToLower()).ToList();
            }
            else
            {
                listContestSubmission = _contestSubmissionRepository.FindAll(x => x.ContestId == contestId && x.Value1.ToLower() == subscriberId.ToLower()).ToList();
            }

            if (listContestSubmission != null && listContestSubmission.Count() >= 1)
            {
                status = true;
            }

            return await Task.Run(() => status);
        }

        /// <summary>
        /// This method is use to get provider details
        /// </summary>
        /// <param name="contestId">contestId</param>
        /// <param name="providerId">providerId</param>
        /// <returns>returns provider details</returns>
        private async Task<ContestProvider> GetProviderInfo(int contestId, int providerId)
        {
            IQueryable<ContestProvider> provider = _context.Set<ContestProvider>();

            ContestProvider contestProvider = null;
            //Get provider information based on providerId and contestId
            if (providerId > 0 && contestId > 0)
            {
                contestProvider = provider.Include(project => project.Contest).Include(auxUser => auxUser.AuxiliaryUser)
                .FirstOrDefault(x => x.AuxiliaryUserId == providerId && x.ContestId == contestId);

            }

            if (contestProvider == null)
            {
                //Get provider information based on providerId
                if (providerId > 0)
                {
                    contestProvider = provider.Include(project => project.Contest).Include(auxUser => auxUser.AuxiliaryUser)
                   .FirstOrDefault(x => x.AuxiliaryUserId == providerId);
                }
            }

            return await Task.Run(() => contestProvider);

        }

        /// <summary>
        /// This metho choose provider based on auxId
        /// </summary>
        /// <param name="auxId"></param>
        /// <returns></returns>
        private Providers ChooseProvider(int? auxId = 0)
        {
            IQueryable<ContestSpecialHost> contestSpecialHost = _context.Set<ContestSpecialHost>();

           var cshost = contestSpecialHost.Include(auxUser => auxUser.AuxiliaryUser)
              .FirstOrDefault(x => x.AuxiliaryUserId == auxId);

           if (cshost != null)
            {
                switch (cshost.Id)
                {
                    case 1:
                        return Providers.TATASKY;
                    case 2:
                        return Providers.ZEETV;
                    default:
                        return Providers.DEFAULT;
                }
            }
            else
            {
                return Providers.DEFAULT;
            }
        }

        #endregion
    }
}
