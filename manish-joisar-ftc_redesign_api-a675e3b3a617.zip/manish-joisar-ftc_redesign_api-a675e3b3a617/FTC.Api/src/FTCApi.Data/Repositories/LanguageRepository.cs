﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class LanguageRepository : GenericRepository<Language>, ILanguageRepository
    {
        public LanguageRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
