﻿using FTCApi.Core.Enums;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Data.Extensions;
using FTCApi.Dtos;
using FTCApi.Dtos.JobAuditionsDtos;

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class TalentJobRepository : GenericRepository<TalentJob>, ITalentJobRepository
    {
        #region Private methods

        private ITalentJobHistoryRepository _talentJobHistoryRepository;
        private IJobTalentRecommendedRepository _JobTalentRecommendedRepository;
        private IProjectRepository _projectRepository;
        private IProjectJobRepository _projectJobRepository;
        private IJobAuditionRepository _jobAuditionRepository;
        private IJobAuditionTalentRepository _jobAuditionTalentRepository;
        private ITalentCalendarRepository _talentCalendarRepository;
        private ITalentSocialLinkRepository _talentSocialLinkRepository;
        private ITalentMediaRepository _talentMediaFileRepository;
        private IJobMediaRepository _jobMediaRepository;

        #endregion

        #region Constructor

        public TalentJobRepository(FTCDbContext context,
                                    ITalentJobHistoryRepository talentJobHistoryRepository,
                                    IJobTalentRecommendedRepository JobTalentRecommendedRepository,
                                    IProjectRepository projectRepository,
                                    IProjectJobRepository projectJobRepository,
                                    IJobAuditionRepository jobAuditionRepository,
                                    ITalentSocialLinkRepository talentSocialLinkRepository,
                                    IJobAuditionTalentRepository jobAuditionTalentRepository,
                                    ITalentMediaRepository talentMediaFileRepository,
                                    IJobMediaRepository jobMediaRepository,
                                    ITalentCalendarRepository talentCalendarRepository) : base(context)
        {
            _talentJobHistoryRepository = talentJobHistoryRepository;
            _JobTalentRecommendedRepository = JobTalentRecommendedRepository;
            _projectRepository = projectRepository;
            _projectJobRepository = projectJobRepository;
            _jobAuditionRepository = jobAuditionRepository;
            _jobAuditionTalentRepository = jobAuditionTalentRepository;
            _talentCalendarRepository = talentCalendarRepository;
            _talentSocialLinkRepository = talentSocialLinkRepository;
            _talentMediaFileRepository = talentMediaFileRepository;
            _jobMediaRepository = jobMediaRepository;

        }

        #endregion

        #region Public Methods
        public async Task<SearchResult<TalentJob>> Search(SearchParameters searchParams)
        {
            if (searchParams == null)
            {
                throw new ArgumentNullException("searchParams");
            }

            searchParams.SetDefaultsForUnsetProperties();

            IQueryable<TalentJob> query = _context.Set<TalentJob>();

            if (searchParams.SearchFor.ContainsKey("Id"))
            {
                var id = searchParams.SearchFor["Id"];
                query = query.Where(talentJob => talentJob.Id.ToString().Contains(id));
            }

            //switch (searchParams.SortOn)
            //{
            //    case "Job Title":
            //        searchParams.SortOn = "Title";
            //        break;
            //}

            var recordCount = query.Count();
            var talentJobs = await query.ApplySorting(searchParams.SortOn, searchParams.SortOrder)
                                    .ApplyPaging(searchParams.PageIndex, searchParams.PageSize)
                                    .ToListAsync();

            return new SearchResult<TalentJob>
            {
                Results = talentJobs,
                TotalResults = recordCount
            };
        }

        public async Task<JobAuditionResults<Auditions>> GetSelectedForAuditions(JobAuditionsRequest jobAuditionsRequest)
        {
            IQueryable<JobAuditionTalent> query = _context.Set<JobAuditionTalent>();

            //set default pagesize.
            jobAuditionsRequest.SetDefaultsForUnsetProperties();

            var auditions = query.Include(t => t.Talent).ThenInclude(ta => ta.TalentAddress).ThenInclude(a => a.Address).ThenInclude(c => c.City)
                            .Include(j => j.JobAudition)
                            .Include(t => t.Talent).ThenInclude(t => t.TalentRatingRmark)
                            .Include(t => t.Talent).ThenInclude(t => t.TalentRatingInterestCategory).AsQueryable();
            // .Include(t => t.Talent).ThenInclude(t => t.JobTalentRecommended).ThenInclude(t => t.SortOrderType).AsQueryable();

            auditions = ApplyAuditionFilter(jobAuditionsRequest, auditions);

            var talentsJobAuditions = await auditions.Where(g => g.JobAudition.JobId == jobAuditionsRequest.JobId && g.NotSelected == jobAuditionsRequest.NotSelected && g.JobAuditionId == jobAuditionsRequest.AuditionId && g.MovedToNextStage == false && g.MoveToAudition == null).ToListAsync();

            var project = _projectJobRepository.FindAll(g => g.Id == jobAuditionsRequest.JobId).Select(c => new { ProjectId = c.ProjectId, InterestId = c.InterestCategoryId, TalentCategoryId = c.TalentCategoryId, EndDate = c.EndDate }).FirstOrDefault();
            var projectPlan = _context.Set<Project>().Include(plan => plan.Plan).Where(c => c.Id == project.ProjectId).Select(p => new { ProvideNotesRating = p.Plan.ProvideNotesRating, ViewAuditionHistory = p.Plan.ViewAuditionHistory }).FirstOrDefault();

            var jobTalentRecommended = await _context.JobTalentRecommended.Where(c => c.JobId == jobAuditionsRequest.JobId).Include(t => t.SortOrderType).ToListAsync();

            //This talent list order based on stack ranking
            var orderJobAuditions = talentsJobAuditions.Select(g => new Auditions
            {
                FullName = g.Talent.FullName,
                Age = CalculateAge(g.Talent.DOB),
                City = GetCity(g.Talent.TalentAddress.FirstOrDefault()),
                StatusDescription = ProjectJobStatusEnum.SelectedForAudition.ToString(),
                StatusId = (int)ProjectJobStatusEnum.SelectedForAudition,
                UID = g.Talent.UID ?? 0,
                TalentId = g.TalentId,
                TalentProfileURL = g.Talent.TalentProfileURL,
                RMark = GetRmarkOrder(g.TalentId, jobAuditionsRequest.JobId, jobTalentRecommended, g.Talent.TalentRatingRmark.ToList(), project.InterestId, project.TalentCategoryId),
                Rating = g.Talent.OverallRating,
                Interest = g.Talent.TalentRatingInterestCategory.Where(p => p.TalentId == g.TalentId && p.InterestCategoryId == project.InterestId).Average(p => p.Rating),
                IsRecommended = jobTalentRecommended.Count(c => c.TalentId == g.TalentId) > 0
            })
                            .OrderBy(o => o.RMark)
                            .ThenByDescending(o => o.Rating)
                            .ThenByDescending(o => o.Interest)
                            .ThenBy(o => o.UID)
                            .ToList();

            //return talents based on requested pageindex.
            var jobAuditions = orderJobAuditions.Any() ? orderJobAuditions.AsQueryable()
                                .ApplyPaging(jobAuditionsRequest.PageIndex, jobAuditionsRequest.PageSize).ToList() : null;

            var recordCount = talentsJobAuditions.Count();

            await CheckMediaAvailable(jobAuditions,jobAuditionsRequest.JobId);

            return new JobAuditionResults<Auditions>
            {
                Results = jobAuditions,
                TotalResults = recordCount,
                PendingAuditionSelectionCount = 0,
                ProvideNotesRating = projectPlan.ProvideNotesRating,
                ViewAuditionHistory = projectPlan.ViewAuditionHistory,
                JobEndDate = project.EndDate,
                ViewAuditions = IsViewAuditions(project.EndDate, projectPlan.ViewAuditionHistory)
            };
        }

        /// <summary>
        /// This method is use to get talents for auditions based on status.
        /// </summary>
        /// <param name="jobAuditionsRequest"></param>
        /// <returns></returns>
        public async Task<JobAuditionResults<Auditions>> GetJobAuditions(JobAuditionsRequest jobAuditionsRequest)
        {
            JobAuditionResults<Auditions> auditions = null;
            if (jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition)
            {
                if (jobAuditionsRequest.AuditionId > 0)
                {
                    //This return auditions if talent is in selected auditions stage and is in audition round(online/offline)
                    auditions = await GetSelectedForAuditions(jobAuditionsRequest);
                }
                else
                {
                    auditions = await GetTalentJobAuditions(jobAuditionsRequest);
                }

                var projectJobStatus = new List<ProjectJobStatusDto>();
                var rounds = await _jobAuditionRepository.FindAllAsync(a => a.JobId == jobAuditionsRequest.JobId);
                if (rounds.Any())
                {
                    IQueryable<AuditionType> queryAuditionType = _context.Set<AuditionType>();
                    var auditionTypeList = queryAuditionType.ToList();

                    foreach (JobAudition round in rounds)
                    {
                        var auditionTypDesc = auditionTypeList.Where(c => c.Id == round.AuditionTypeId).Select(c => c.Description).First();
                        projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.SelectedForAudition, IsOnline = round.RoundNumber.HasValue, Description = FormatRoundTabText(round.RoundNumber, auditionTypDesc), JobAuditionId = round.Id });
                    }
                }
                auditions.SelectedForAuditionTabs = projectJobStatus;
            }
            else
            {
                auditions = await GetTalentJobAuditions(jobAuditionsRequest);
            }
            return auditions;
        }

        /// <summary>
        /// This method return list of matching talents.
        /// </summary>
        /// <param name="jobAuditionsRequest"></param>
        /// <returns></returns>
        public async Task<JobAuditionResults<Auditions>> GetTalentMatchingTabJobAuditions(JobAuditionsRequest jobAuditionsRequest)
        {

            //set default pagesize.
            jobAuditionsRequest.SetDefaultsForUnsetProperties();

            var projectJob = await GetJobById(jobAuditionsRequest.JobId);

            //age and gender
            var query = _context.Talent.Where(x => x.Gender == projectJob.Gender && (CalculateAge(x.DOB) >= projectJob.MinAge && CalculateAge(x.DOB) <= projectJob.MaxAge) && x.IsProfilePrivate == false);

            var talentJobs = await _context.TalentJob.Where(x => x.JobId == jobAuditionsRequest.JobId).Select(x => x.TalentId).ToListAsync();

            var recommendedTalents = await _context.JobTalentRecommended.Where(x => x.JobId == jobAuditionsRequest.JobId && x.Invited == false).Select(c => c.TalentId).ToListAsync();

            query = query.Where(x => !talentJobs.Contains(x.Id) && x.StatusId == 1);

            query = query.Where(x => !recommendedTalents.Contains(x.Id));


            //Category
            if (projectJob.TalentCategoryId.HasValue)
            {
                IQueryable<TalentTalentCategory> talentTalentCategory = _context.Set<TalentTalentCategory>();
                var talents = await talentTalentCategory.Where(y => y.TalentCategoryId == projectJob.TalentCategoryId).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //Interest
            if (projectJob.Project.InterestId.HasValue)
            {
                IQueryable<TalentInterestCategory> talentInterestCategory = _context.Set<TalentInterestCategory>();

                var talents = await talentInterestCategory.Where(y => y.InterestCategoryId == projectJob.Project.InterestId).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            var talentAddress = await _context.TalentAddress.Select(c => new { c.TalentId, c.Address.City.CityDescription, c.Address.CityId }).ToListAsync();
            //project job location
            if (projectJob.ProjectJobLocation.Any())
            {
                var talents = talentAddress.Where(y => projectJob.ProjectJobLocation.Any(c => c.CityId == y.CityId)).Select(c => c.TalentId).ToList();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //project job language
            if (projectJob.ProjectJobLanguage.Any())
            {
                var talents = await _context.TalentLanguage.Where(d => projectJob.ProjectJobLanguage.Any(p => p.LanguageId == d.LanguageId)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //project job ethnicity
            if (projectJob.ProjectJobEthnicity.Any())
            {

                var talents = await _context.TalentEthnicity.Where(d => projectJob.ProjectJobEthnicity.Any(p => p.EthnicityId == d.Ethnicity)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //project job tag
            if (projectJob.ProjectJobTag.Any())
            {
                var talents = await _context.TalentTag.Where(d => projectJob.ProjectJobTag.Any(p => p.TagId == d.TagId)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //experience required
            if (projectJob.ExperienceRequired ?? false)
            {
                query = query.Where(x => x.TalentExperience.Count() > 0);
            }

            //passport required
            if (projectJob.PassportRequired ?? false)
            {
                query = query.Where(x => x.PassportCountryId != null);
            }

            //project job body type
            if (projectJob.ProjectJobBodytype.Any())
            {

                var talents = await _context.TalentPhysicalAttribute.Where(d => projectJob.ProjectJobBodytype.Any(p => p.BodytypeId == d.BodyTypeId)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //project job skin type
            if (projectJob.ProjectJobSkinColor.Any())
            {
                var talents = await _context.TalentPhysicalAttribute.Where(d => projectJob.ProjectJobSkinColor.Any(p => p.SkinColorId == d.SkinColorId)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //project job eye color
            if (projectJob.ProjectJobEyecolor.Any())
            {
                var talents = await _context.TalentPhysicalAttribute.Where(d => projectJob.ProjectJobEyecolor.Any(p => p.EyecolorId == d.EyeColorId)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));

            }

            //hair length
            if (projectJob.HairLengthId.HasValue)
            {
                var talents = await _context.TalentPhysicalAttribute.Where(x => projectJob.HairLengthId == x.HairLengthId).Select(c => c.TalentId).ToListAsync();
                query = query.Where(x => talents.Contains(x.Id));
            }

            //height
            if (projectJob.MaxHeightId.HasValue && projectJob.MinHeightId.HasValue)
            {
                var height = await _context.Height.ToListAsync();
                var talents = await _context.TalentPhysicalAttribute.Where(x => GetHeightInInclues(x.HeightId, height) >= GetHeightInInclues(projectJob.MinHeightId, height)
                    && GetHeightInInclues(x.HeightId, height) <= GetHeightInInclues(projectJob.MaxHeightId, height)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(c => talents.Contains(c.Id));
            }

            //weight
            if (projectJob.MaxWeightId.HasValue && projectJob.MinWeightId.HasValue)
            {
                var weight = await _context.Weight.ToListAsync();
                var talents = await _context.TalentPhysicalAttribute.Where(x => GetWeightInKgs(x.WeightSizeId, weight) >= GetWeightInKgs(projectJob.MinWeightId, weight) && GetWeightInKgs(x.WeightSizeId, weight) <= GetWeightInKgs(projectJob.MaxWeightId, weight)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(c => talents.Contains(c.Id));
            }

            //chestsize
            if (projectJob.MaxChestSizeId.HasValue && projectJob.MaxChestSizeId.HasValue)
            {
                var chestSize = await _context.ChestSize.ToListAsync();

                var talents = await _context.TalentPhysicalAttribute.Where(x => GetChestSizeInInches(x.ChestSizeId, chestSize) >= GetChestSizeInInches(projectJob.MinChestSizeId, chestSize) && GetChestSizeInInches(x.ChestSizeId, chestSize) <= GetChestSizeInInches(projectJob.MaxChestSizeId, chestSize)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(c => talents.Contains(c.Id));

            }

            //waist size
            if (projectJob.MaxWaistSizeId.HasValue && projectJob.MaxWaistSizeId.HasValue)
            {
                var waistSize = await _context.WaistSize.ToListAsync();
                //query = query.Include(bodytype => bodytype.TalentPhysicalAttribute).Where(x => GetWaistInInches(x.TalentPhysicalAttribute.WaistId, waistSize) >= GetWaistInInches(projectJob.MinWaistSizeId, waistSize) && GetWaistInInches(x.TalentPhysicalAttribute.WaistId, waistSize) <= GetWaistInInches(projectJob.MaxWaistSizeId, waistSize));

                var talents = await _context.TalentPhysicalAttribute.Where(x => GetWaistInInches(x.WaistId, waistSize) >= GetWaistInInches(projectJob.MinWaistSizeId, waistSize) && GetWaistInInches(x.WaistId, waistSize) <= GetWaistInInches(projectJob.MaxWaistSizeId, waistSize)).Select(c => c.TalentId).ToListAsync();
                query = query.Where(c => talents.Contains(c.Id));

            }

            //headshot required
            if (projectJob.HeadshotRequired ?? false)
            {
                query = query.Where(x => x.TalentMedia.Any(y => y.Flag == Convert.ToString((int)LoginEnum.FlagType.OnBoardingHeadShot)));
            }

            //side profile required
            if (projectJob.SideprofileRequired ?? false)
            {
                var sideProfile = new string[] { LoginEnum.FlagType.OnBoardingLeftSide.ToString(), LoginEnum.FlagType.OnBoardingRightSide.ToString() };
                var flags = new List<string>();
                foreach (var profile in sideProfile)
                {
                    var flag = (int)Enum.Parse(typeof(LoginEnum.FlagType), profile);
                    flags.Add(flag.ToString());
                }
                query = query.Where(x => x.TalentMedia.Any(y => flags.Contains(y.Flag)));
            }

            //intor video required
            if (projectJob.IntrovideoRequired ?? false)
            {
                query = query.Where(x => x.TalentMedia.Any(y => y.Flag == Convert.ToString((int)LoginEnum.FlagType.OnBoardingVideo)));
            }
            if (projectJob.AssociationRequired ?? false)
            {
                query = query.Where(x => x.TalentAssociation.Count() > 0);
            }

            //filter for city
            if (jobAuditionsRequest.CityId != null && jobAuditionsRequest.CityId.Any(c => c > 0))
            {
                var talents = talentAddress.Where(c => c.CityId != null && jobAuditionsRequest.CityId.Contains(c.CityId ?? 0)).Select(c => c.TalentId).ToList();
                query = query.Where(c => talents.Contains(c.Id));
            }

            //Filter for age range
            query = query.Where(x => CalculateAge(x.DOB) >= jobAuditionsRequest.MinAge && CalculateAge(x.DOB) <= jobAuditionsRequest.MaxAge);

            //Filter for budget range
            query = query.Where(x => (x.BudgetMin.HasValue ? x.BudgetMin.Value : 0) >= jobAuditionsRequest.MinBudget && (x.BudgetMax.HasValue ? x.BudgetMax.Value : 0) <= jobAuditionsRequest.MaxBudget);


            var project = _projectJobRepository.FindAll(g => g.Id == jobAuditionsRequest.JobId).Select(c => new { ProjectId = c.ProjectId, InterestId = c.InterestCategoryId, TalentCategoryId = c.TalentCategoryId, EndDate = c.EndDate }).FirstOrDefault();
            var projectPlan = _context.Set<Project>().Include(plan => plan.Plan).Where(c => c.Id == project.ProjectId).Select(p => new { ProvideNotesRating = p.Plan.ProvideNotesRating, ViewAuditionHistory = p.Plan.ViewAuditionHistory }).FirstOrDefault();

            var talentRatingRmark = await _context.TalentRatingRmark.Where(c => c.TalentCategoryId == project.TalentCategoryId && c.InterestCategoryId == project.InterestId).Select(p => p.TalentId).ToListAsync();
            var talentRatingInterestCategory = await _context.TalentRatingInterestCategory.Where(p => p.InterestCategoryId == project.InterestId).Select(c => new { c.TalentId, c.Rating }).ToListAsync();



            //This talent list order based on stack ranking
            var orderJobAuditions = query.Select(g => new Auditions
            {
                Age = CalculateAge(g.DOB),
                City = talentAddress.FirstOrDefault(c => c.TalentId == g.Id).CityDescription,
                UID = g.UID ?? 0,
                TalentId = g.Id,
                TalentProfileURL = g.TalentProfileURL,
                RMark = talentRatingRmark.Count > 0 ? talentRatingRmark.Contains(g.Id) ? (int)MstSortOrderTypeEnum.RMark : (int)MstSortOrderTypeEnum.Applied : (int)MstSortOrderTypeEnum.Applied,
                Rating = g.OverallRating,
                Interest = talentRatingInterestCategory.Count > 0 ? talentRatingInterestCategory.Where(p => p.TalentId == g.Id).Average(p => p.Rating) : 0,
            })
                            .OrderBy(o => o.RMark)
                            .ThenByDescending(o => o.Rating)
                            .ThenByDescending(o => o.Interest)
                            .ThenBy(o => o.UID);


            //return talents based on requested pageindex.
            var jobAuditions = (orderJobAuditions != null) ? await orderJobAuditions.AsQueryable()
                                .ApplyPaging(jobAuditionsRequest.PageIndex, jobAuditionsRequest.PageSize).ToListAsync() : null;

            var recordCount = await query.Select(c => c.Id).CountAsync();

            await CheckMediaAvailable(jobAuditions,jobAuditionsRequest.JobId);

            return new JobAuditionResults<Auditions>
            {
                Results = jobAuditions,
                TotalResults = recordCount,
                ProvideNotesRating = projectPlan.ProvideNotesRating,
                ViewAuditionHistory = projectPlan.ViewAuditionHistory,
                JobEndDate = projectJob.EndDate,
                ViewAuditions = IsViewAuditions(projectJob.EndDate, projectPlan.ViewAuditionHistory)
            };
        }

        /// <summary>
        /// This method is use to get list of recommended auditions
        /// </summary>
        /// <param name="jobAuditionsRequest"></param>
        /// <returns></returns>
        public async Task<JobAuditionResults<Auditions>> GetJobAuditionRecommended(JobAuditionsRequest jobAuditionsRequest)
        {
            IQueryable<JobTalentRecommended> query = _context.Set<JobTalentRecommended>();

            jobAuditionsRequest.SetDefaultsForUnsetProperties();

            IQueryable<TalentJob> queryTalentJob = _context.Set<TalentJob>();
            var talentJob = await queryTalentJob.Where(g => g.JobId == jobAuditionsRequest.JobId).Select(c => c.TalentId).ToListAsync();

            var resultExcluded = await query.Where(g => g.JobId == jobAuditionsRequest.JobId && g.Invited == false && !talentJob.Contains(g.TalentId)).Select(c => new { TalentId = c.TalentId, Invited = c.Invited }).ToListAsync();

            IQueryable<Talent> talentQuery = _context.Set<Talent>();
            var recommended = talentQuery.Where(g => resultExcluded.Select(c => c.TalentId).Contains(g.Id));

            recommended = ApplyRecommendedTalentFilter(jobAuditionsRequest, recommended);

            var talentAddress = await _context.TalentAddress.Where(c => resultExcluded.Select(p => p.TalentId).Contains(c.TalentId)).Select(c => new { c.TalentId, c.Address.City.CityDescription, c.Address.CityId }).ToListAsync();

            if (jobAuditionsRequest.CityId != null && jobAuditionsRequest.CityId.Any(c => c > 0))
            {
                recommended = recommended.Where(x => talentAddress.Any(p => jobAuditionsRequest.CityId.Contains(p.CityId ?? 0)));
            }

            var recommendedResult = recommended.Select(s => new
            {
                DOB = s.DOB,
                City = talentAddress.Where(p => p.TalentId == s.Id).Select(c => c.CityDescription),
                TalentId = s.Id,
                UID = s.UID,
                TalentProfileURL = s.TalentProfileURL,
                OverallRating = s.OverallRating
            });

            var project = _projectJobRepository.FindAll(g => g.Id == jobAuditionsRequest.JobId).Select(c => new { ProjectId = c.ProjectId, InterestId = c.InterestCategoryId, TalentCategoryId = c.TalentCategoryId, EndDate = c.EndDate }).FirstOrDefault();
            var projectPlan = _context.Set<Project>().Include(plan => plan.Plan).Where(c => c.Id == project.ProjectId).Select(p => new { ProvideNotesRating = p.Plan.ProvideNotesRating, ViewAuditionHistory = p.Plan.ViewAuditionHistory }).FirstOrDefault();

            var taskJobTalentRecommended = _context.JobTalentRecommended.Include(t => t.SortOrderType).Where(c => resultExcluded.Select(p => p.TalentId).Contains(c.TalentId) && c.JobId == jobAuditionsRequest.JobId).ToListAsync();
            var taskTalentRatingRmark = _context.TalentRatingRmark.Where(c => resultExcluded.Select(p => p.TalentId).Contains(c.TalentId)).ToListAsync();
            var taskTalentRatingInterestCategory = _context.TalentRatingInterestCategory.Where(c => resultExcluded.Select(p => p.TalentId).Contains(c.TalentId)).ToListAsync();

            var jobTalentRecommended = await taskJobTalentRecommended;
            var talentRatingRmark = await taskTalentRatingRmark;
            var talentRatingInterestCategory = await taskTalentRatingInterestCategory;

            var sortJobAuditions = recommendedResult.Select(g => new Auditions
            {
                Age = CalculateAge(g.DOB),
                City = g.City.FirstOrDefault(),
                TalentId = g.TalentId,
                UID = g.UID ?? 0,
                TalentProfileURL = g.TalentProfileURL,
                RMark = GetRmark(g.TalentId, jobTalentRecommended.FirstOrDefault(c => c.TalentId == g.TalentId),
                      talentRatingRmark.FirstOrDefault(r => r.TalentCategoryId == project.TalentCategoryId
                      && r.InterestCategoryId == project.InterestId && r.TalentId == g.TalentId)),
                Rating = g.OverallRating,
                Interest = talentRatingInterestCategory.Where(p => p.TalentId == g.TalentId && p.InterestCategoryId == project.InterestId).Average(p => p.Rating),
                IsRecommended = true
            })
            .OrderBy(o => o.RMark)
                            .ThenByDescending(o => o.Rating)
                            .ThenByDescending(o => o.Interest)
                            .ThenBy(o => o.UID);


            var jobAuditions = (sortJobAuditions != null) ? await sortJobAuditions.ApplyPaging(jobAuditionsRequest.PageIndex, jobAuditionsRequest.PageSize).ToListAsync() : null;

            var recordCount = await recommendedResult.Select(c => c.TalentId).CountAsync();

            await CheckMediaAvailable(jobAuditions,jobAuditionsRequest.JobId);

            return new JobAuditionResults<Auditions>
            {
                Results = jobAuditions,
                TotalResults = recordCount,
                ProvideNotesRating = projectPlan.ProvideNotesRating,
                ViewAuditionHistory = projectPlan.ViewAuditionHistory,
                JobEndDate = project.EndDate,
                ViewAuditions = IsViewAuditions(project.EndDate, projectPlan.ViewAuditionHistory)
            };
        }

        /// <summary>
        /// This method is use to get intransit auditions
        /// </summary>
        /// <param name="jobAuditionsRequest"></param>
        /// <returns></returns>
        public async Task<JobAuditionResults<Auditions>> GetJobAuditionInTransit(JobAuditionsRequest jobAuditionsRequest)
        {
            IQueryable<JobTalentRecommended> query = _context.Set<JobTalentRecommended>();

            jobAuditionsRequest.SetDefaultsForUnsetProperties();

            var inTransit = query.Include(s => s.Talent.Status).AsQueryable();

            var invitedTalent = await inTransit.Where(g => g.Invited == true && g.JobId == jobAuditionsRequest.JobId).Select(c => new { TalentId = c.TalentId, Invited = c.Invited }).ToListAsync();

            var recommendedTalents = inTransit.Where(g => g.Invited == false);

            IQueryable<TalentJob> queryTalentJob = _context.Set<TalentJob>();

            var talentJob = await queryTalentJob.Include(s => s.Status).Where(g => g.JobId == jobAuditionsRequest.JobId).Select(g => new { TalentId = g.TalentId, StatusId = g.StatusId, NotSelected = g.NotSelected, Status = g.Status }).ToListAsync();

            var resultInclude = await recommendedTalents.Where(p => talentJob.Select(c => c.TalentId).Contains(p.TalentId) && p.JobId == jobAuditionsRequest.JobId).Select(c => new { TalentId = c.TalentId, Invited = c.Invited }).ToListAsync();

            resultInclude.ForEach(o => invitedTalent.Add(o));

            var invitedTalents = invitedTalent.Distinct();


            IQueryable<Talent> talentQuery = _context.Set<Talent>();
            var talentsResult = talentQuery.Where(g => invitedTalents.Select(c => c.TalentId).Contains(g.Id));

            talentsResult = ApplyRecommendedTalentFilter(jobAuditionsRequest, talentsResult);

            var talentAddress = await _context.TalentAddress.Where(c => resultInclude.Select(p => p.TalentId).Contains(c.TalentId)).Select(c => new { c.TalentId, c.Address.City.CityDescription, c.Address.CityId }).ToListAsync();

            if (jobAuditionsRequest.CityId != null && jobAuditionsRequest.CityId.Any(c => c > 0))
            {
                talentsResult = talentsResult.Where(x => talentAddress.Any(p => jobAuditionsRequest.CityId.Contains(p.CityId ?? 0)));
            }
            var recommended = talentsResult.Select(s => new { DOB = s.DOB, City = talentAddress.Where(c => c.TalentId == s.Id).Select(c => c.CityDescription), TalentId = s.Id, UID = s.UID, TalentProfileURL = s.TalentProfileURL, OverallRating = s.OverallRating });

            var taskJobTalentRecommended = _context.JobTalentRecommended.Include(t => t.SortOrderType).Where(c => invitedTalents.Select(p => p.TalentId).Contains(c.TalentId) && c.JobId == jobAuditionsRequest.JobId).ToListAsync();
            var taskTalentRatingRmark = _context.TalentRatingRmark.Where(c => invitedTalents.Select(p => p.TalentId).Contains(c.TalentId)).ToListAsync();
            var taskTalentRatingInterestCategory = _context.TalentRatingInterestCategory.Where(c => invitedTalents.Select(p => p.TalentId).Contains(c.TalentId)).ToListAsync();

            var jobTalentRecommended = await taskJobTalentRecommended;
            var talentRatingRmark = await taskTalentRatingRmark;
            var talentRatingInterestCategory = await taskTalentRatingInterestCategory;

            var project = _projectJobRepository.FindAll(g => g.Id == jobAuditionsRequest.JobId).Select(c => new { ProjectId = c.ProjectId, InterestId = c.InterestCategoryId, TalentCategoryId = c.TalentCategoryId, EndDate = c.EndDate }).FirstOrDefault();
            var projectPlan = _context.Set<Project>().Include(plan => plan.Plan).Where(c => c.Id == project.ProjectId).Select(p => new { ProvideNotesRating = p.Plan.ProvideNotesRating, ViewAuditionHistory = p.Plan.ViewAuditionHistory }).FirstOrDefault();

            var sortJobAuditions = recommended.Select(g => new Auditions
            {
                StatusDescription = GetStatusDescription(talentJob.FirstOrDefault(p => p.TalentId == (int)g.TalentId), jobTalentRecommended.FirstOrDefault(c => c.TalentId == g.TalentId)),
                StatusId = talentJob.Where(p => p.TalentId == g.TalentId).Select(c => c.StatusId).FirstOrDefault(),
                Age = CalculateAge(g.DOB),
                City = g.City.FirstOrDefault(),
                TalentId = g.TalentId,
                UID = g.UID ?? 0,
                TalentProfileURL = g.TalentProfileURL,
                RMark = GetRmark(g.TalentId, jobTalentRecommended.FirstOrDefault(c => c.TalentId == g.TalentId),
                      talentRatingRmark.FirstOrDefault(r => r.TalentCategoryId == project.TalentCategoryId
                      && r.InterestCategoryId == project.InterestId && r.TalentId == g.TalentId)),
                Rating = g.OverallRating,
                Interest = talentRatingInterestCategory.Where(p => p.TalentId == g.TalentId && p.InterestCategoryId == project.InterestId).Average(p => p.Rating),
                IsRecommended = jobTalentRecommended.Count(c => c.TalentId == g.TalentId) > 0

            }).OrderBy(o => o.RMark)
                            .ThenByDescending(o => o.Rating)
                            .ThenByDescending(o => o.Interest)
                            .ThenBy(o => o.UID);

            var jobAuditions = (sortJobAuditions != null) ? await sortJobAuditions.AsQueryable()
                                .ApplyPaging(jobAuditionsRequest.PageIndex, jobAuditionsRequest.PageSize).ToListAsync() : null;

            var recordCount = await recommended.Select(c => c.TalentId).CountAsync();

            await CheckMediaAvailable(jobAuditions,jobAuditionsRequest.JobId);

            return new JobAuditionResults<Auditions>
            {
                Results = jobAuditions,
                TotalResults = recordCount,
                ProvideNotesRating = projectPlan.ProvideNotesRating,
                ViewAuditionHistory = projectPlan.ViewAuditionHistory,
                JobEndDate = project.EndDate,
                ViewAuditions = IsViewAuditions(project.EndDate, projectPlan.ViewAuditionHistory)
            };
        }

        /// <summary>
        /// This method is use to invite talents 
        /// </summary>
        /// <param name="recommendedTalents"></param>
        /// <returns></returns>
        public async Task<bool> InviteRecommendedJobAuditions(List<JobTalentRecommendedDto> recommendedTalents)
        {
            foreach (JobTalentRecommendedDto talent in recommendedTalents)
            {
                var recommendedTalent = _JobTalentRecommendedRepository.Find(g => g.TalentId == talent.TalentId && g.JobId == talent.JobId);

                if (recommendedTalent != null)
                {
                    recommendedTalent.Invited = true;

                    await _JobTalentRecommendedRepository.UpdateAsync(recommendedTalent);
                }
            }

            return true;
        }

        /// <summary>
        /// This metho is return status based on selected tab 
        /// </summary>
        /// <param name="statusId"></param>
        /// <param name="jobId"></param>
        /// <param name="auditionId"></param>
        /// <param name="notSelected"></param>
        /// <returns></returns>
        public async Task<List<ProjectJobStatusDto>> GetAuditionStatusList(int statusId, int jobId, int? auditionId, bool notSelected)
        {
            var projectJobStatus = new List<ProjectJobStatusDto>();

            switch (statusId)
            {
                case (int)ProjectJobStatusEnum.UnderReview:
                    {
                        if (notSelected)
                        {
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.MoveToUnderReview, Description = "Under review" });
                        }
                        else
                        {
                            var catRequired = _context.ProjectJob.Where(c => c.Id == jobId).Select(c => c.CastRequired).FirstOrDefault();
                            if (catRequired ?? false)
                            {
                                projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.SelectedForAudition, Description = "Selected for audition" });
                            }
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.Shortlisted, Description = "Shortlist" });
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.NotSelected, Description = "Not selected" });
                        }
                        break;
                    }
                case (int)ProjectJobStatusEnum.SelectedForAudition:
                    {
                        if (notSelected)
                        {
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.MoveToLastAuditionStage, Description = "Last audition stage" });
                        }
                        else
                        {

                            var rounds = await _jobAuditionRepository.FindAllAsync(a => a.JobId == jobId);

                            //If talent is in offline round then he can't move in online round
                            //If talent is in x online round then he can move x+1 audition round
                            if (rounds != null && rounds.Any())
                            {
                                IQueryable<AuditionType> queryAuditionType = _context.Set<AuditionType>();
                                var auditionTypeList = queryAuditionType.ToList();


                                if (auditionId > 0)
                                {
                                    var roundNumber = rounds.Where(c => c.Id == auditionId).Select(c => c.RoundNumber).FirstOrDefault();
                                    if (roundNumber != null)
                                    {
                                        rounds = rounds.Where(c => (Convert.ToInt32(c.RoundNumber) > Convert.ToInt32(roundNumber)) || c.RoundNumber == null);
                                    }
                                    else
                                    {
                                        rounds = null;
                                    }
                                }
                                if (rounds != null && rounds.Any())
                                {
                                    foreach (JobAudition round in rounds)
                                    {
                                        var auditionTypDesc = auditionTypeList.Where(c => c.Id == round.AuditionTypeId).Select(c => c.Description).FirstOrDefault();
                                        projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.SelectedForAudition, IsOnline = round.RoundNumber.HasValue, Description = FormatRoundText(round.RoundNumber, auditionTypDesc), JobAuditionId = round.Id });
                                    }
                                }
                            }

                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.Shortlisted, Description = "Shortlist" });
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.NotSelected, Description = "Not selected" });
                        }
                        break;
                    }
                case (int)ProjectJobStatusEnum.Shortlisted:
                    {
                        if (notSelected)
                        {
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.MoveToShortListed, Description = "Shortlist" });
                        }
                        else
                        {
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.Cast, Description = "Cast" });
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.NotSelected, Description = "Not selected" });
                        }
                        break;
                    }
                case (int)ProjectJobStatusEnum.Cast:
                    {
                        if (notSelected)
                        {
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.MoveToCasted, Description = "Cast" });
                        }
                        else
                        {
                            projectJobStatus.Add(new ProjectJobStatusDto { StatusId = (int)ProjectJobStatusEnum.Shortlisted, Description = "Shortlist" });
                        }
                        break;
                    }
            }

            return projectJobStatus;

        }

        /// <summary>
        /// This method save selected audition status.
        /// </summary>
        /// <param name="talentJob"></param>
        /// <returns></returns>
        public async Task<bool> SaveSelectedAuditionStatus(TalentJobAuditionStatus talentJob, string projectName, string jobName)
        {
            var auditionJob = await _jobAuditionTalentRepository.FindAsync(c => c.TalentId == talentJob.TalentId && c.JobAuditionId == talentJob.AuditionId);

            if (auditionJob == null)
            {
                IQueryable<JobAuditionTalent> query = _context.Set<JobAuditionTalent>();

                //This get last audition record to update MoveToAuditionId
                var currentTalentAudition = await query.Include(j => j.JobAudition).ThenInclude(j => j.Job)
                      .Where(g => g.JobAudition.JobId == talentJob.JobId && g.TalentId == talentJob.TalentId).OrderByDescending(c => c.CreatedOn).ToListAsync();

                if (currentTalentAudition != null && currentTalentAudition.Any())
                {
                    var audition = currentTalentAudition.First();
                    audition.UpdatedOn = DateTime.UtcNow;
                    audition.MoveToAuditionId = talentJob.AuditionId;
                    await _jobAuditionTalentRepository.UpdateAsync(audition);
                }

                var jobAuditionTalent = new JobAuditionTalent
                {
                    JobAuditionId = talentJob.AuditionId,
                    NotSelected = false,
                    TalentId = talentJob.TalentId,
                    CreatedOn = DateTime.UtcNow,
                    UpdatedOn = DateTime.UtcNow,
                    MovedToNextStage = false,
                };

                var jobAuditionDetail = await _jobAuditionRepository.FindAsync(x => x.Id == talentJob.AuditionId);

                // Add an event of the Job Audition in Talent Calendar                
                var talentCalendar = new TalentCalendar()
                {
                    TalentId = talentJob.TalentId,
                    Title = jobAuditionDetail.Brief,
                    Description = "Project Name: " + projectName + Environment.NewLine + " Job Name: " + jobName,
                    FromDateTime = (jobAuditionDetail.StartTime != null) ? jobAuditionDetail.StartDate + jobAuditionDetail.StartTime : jobAuditionDetail.StartDate,
                    ToDateTime = (jobAuditionDetail.EndTime != null) ? jobAuditionDetail.EndDate + jobAuditionDetail.EndTime : jobAuditionDetail.EndDate
                };

                var calendarResponse = await _talentCalendarRepository.AddAsync(talentCalendar);

                UpdateNotSelectedStatus(talentJob.TalentId, talentJob.AuditionId, false);

                //This add new record if talent move to next audition.
                await _jobAuditionTalentRepository.AddAsync(jobAuditionTalent);
            }

            await UpdateTalentJobHistory(talentJob);

            return true;
        }

        /// <summary>
        /// This method is use to save talent audition status
        /// </summary>
        /// <param name="talentJobs"></param>
        /// <returns></returns>
        public async Task<bool> SaveJobAuditionStatus(List<TalentJobAuditionStatus> talentJobs)
        {
            IQueryable<TalentJob> queryTalentJob = _context.Set<TalentJob>();
            if (talentJobs != null && talentJobs.Any())
            {

                IQueryable<ProjectJob> queryProjectJob = _context.Set<ProjectJob>();

                var projectPlan = await queryProjectJob.Include(p => p.Project)
                                                 .ThenInclude(plan => plan.Plan)
                                                 .Where(g => g.Id == talentJobs.First().JobId)
                                                 .Select(x => new { JobName = x.Title, ProjectName = x.Project.Name, Plan = x.Project.Plan })
                                                 .ToListAsync();

                var auditionSelectionCount = projectPlan.Any() ? projectPlan.First().Plan == null ? 0 : projectPlan.First().Plan.AuditionSelectionCount : 0;

                var totalAuditionSelectionCount = queryTalentJob.Count(g => g.StatusId != (int)ProjectJobStatusEnum.UnderReview);

                //if (totalAuditionSelectionCount > auditionSelectionCount)
                //{
                //    throw new ArgumentException("You have exceeded your limit.Please upgrade your plan.");
                //}

                foreach (TalentJobAuditionStatus talentJob in talentJobs)
                {
                    talentJob.NotSelected = talentJob.NotSelected ?? false;
                    talentJob.SelectedForAudition = talentJob.SelectedForAudition ?? false;

                    if ((talentJob.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition && (talentJob.AuditionId != null || talentJob.AuditionId > 0)) && talentJob.NotSelected == false)
                    {
                        await SaveSelectedAuditionStatus(talentJob, projectPlan.First().ProjectName, projectPlan.First().JobName);
                    }
                    else
                    {
                        var job = Find(g => g.TalentId == talentJob.TalentId && g.JobId == talentJob.JobId);

                        if (job != null)
                        {
                            UpdatedStatusObject(talentJob, job);

                            //If talent is moving from casted to shortlisted then enabled emailsent status as false.
                            if (talentJob.StatusId == (int)ProjectJobStatusEnum.Shortlisted && job.StatusId == (int)ProjectJobStatusEnum.Cast)
                            {
                                job.EmailSent = false;
                            }
                            job.StatusId = talentJob.StatusId;
                            job.UpdatedOn = DateTime.UtcNow;
                            job.SelectedForAudition = talentJob.SelectedForAudition ?? false;
                            job.NotSelected = talentJob.NotSelected ?? false;

                            await UpdateAsync(job);

                            if (talentJob.StatusId == (int)ProjectJobStatusEnum.Shortlisted)
                            {
                                //If talent is moving from selected audition status to shortlisted then updated moved to next status flag as 'true'
                                UpdateMoveToNextStatus(talentJob.TalentId, talentJob.JobId);
                            }

                            if (talentJob.NotSelected == true && talentJob.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition)
                            {
                                //If talent is not selected in selected audition then updated not selected flag as 'true'
                                UpdateNotSelectedStatus(talentJob.TalentId, talentJob.JobId, true);
                            }

                            //This will update talent job history
                            await UpdateTalentJobHistory(talentJob);
                        }

                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Update collabrator feedback 
        /// </summary>
        /// <param name="collabratorFeedback"></param>
        /// <returns>retrurn true of success</returns>
        public async Task<ProjectJob> UpdateCollaboratorFeedback(CollabratorFeedback collabratorFeedback)
        {
            IQueryable<TalentJob> queryTalentJob = _context.Set<TalentJob>();

            ProjectJob projectJob = null;

            if (collabratorFeedback != null)
            {
                int? jobId = 0;
                if (collabratorFeedback.TalentJobs.Any())
                {
                    foreach (TalentJobAuditionStatus talentJob in collabratorFeedback.TalentJobs)
                    {
                        var job = Find(g => g.TalentId == talentJob.TalentId && g.JobId == talentJob.JobId);
                        jobId = job.JobId;
                        if (job != null)
                        {
                            //update collabrator talent feedback
                            job.UpdatedOn = DateTime.UtcNow;
                            job.CollaboratorFeedback = talentJob.CollaboratorFeedback;

                            await UpdateAsync(job);

                        }
                    }
                }
                //if (!string.IsNullOrEmpty(collabratorFeedback.FeedbackMessage))
                //{
                //Update collabrator feedback message
                projectJob = await _projectJobRepository.FindAsync(c => c.Id == jobId);
                projectJob.ColloaboratorComments = collabratorFeedback.FeedbackMessage;
                projectJob.UpdatedOn = DateTime.UtcNow;
                projectJob = await _projectJobRepository.UpdateAsync(projectJob);

                //}
                return projectJob;
            }
            return projectJob;
        }

        public async Task<List<TalentJob>> GetTalentJobsByJobId(JobAuditionsRequest jobAuditionsRequest)
        {
            IQueryable<TalentJob> query = _context.Set<TalentJob>();
            var auditions = query.Where(x => x.JobId == jobAuditionsRequest.JobId).Include(t => t.Talent).AsQueryable();

            //Filter for city, age, budget
            auditions = ApplyFilter(jobAuditionsRequest, auditions);
            return auditions.ToList();
        }


        public async Task<int> GetTalentRecommendedJobsByJobId(JobAuditionsRequest jobAuditionsRequest)
        {
            IQueryable<JobTalentRecommended> query = _context.Set<JobTalentRecommended>();
            var auditions = query.Where(x => x.JobId == jobAuditionsRequest.JobId).Include(t => t.Talent).AsQueryable();

            //Filter for city, age, budget
            auditions = ApplyRecommendedFilter(jobAuditionsRequest, auditions);
            return auditions.Count();
        }

        #endregion

        #region Private Methods

        private async Task<bool> IsTalentMediaAvailable(int? talentId,int jobId)
        {
            var isMediaAvailable = false;

            var countTalentMedia = await _jobMediaRepository.FindAllAsync(x => x.TalentId == talentId && x.JobId == jobId);
            
            if (countTalentMedia != null && countTalentMedia.Count() > 0)
            {
                isMediaAvailable = true;
            }

            return isMediaAvailable;

        }
        private void UpdatedStatusObject(TalentJobAuditionStatus talentJob, TalentJob job)
        {
            if (talentJob.StatusId == (int)ProjectJobStatusEnum.MoveToUnderReview)
            {
                job.NotSelected = false;
                talentJob.NotSelected = false;
                job.StatusId = (int)ProjectJobStatusEnum.UnderReview;
                talentJob.StatusId = (int)ProjectJobStatusEnum.UnderReview;

            }

            if (talentJob.StatusId == (int)ProjectJobStatusEnum.MoveToShortListed)
            {
                talentJob.NotSelected = false;
                talentJob.StatusId = (int)ProjectJobStatusEnum.Shortlisted;
                job.NotSelected = false;
                job.StatusId = (int)ProjectJobStatusEnum.Shortlisted;
            }

            if (talentJob.StatusId == (int)ProjectJobStatusEnum.MoveToCasted)
            {
                talentJob.NotSelected = false;
                talentJob.StatusId = (int)ProjectJobStatusEnum.Cast;

                job.NotSelected = false;
                job.StatusId = (int)ProjectJobStatusEnum.Cast;
            }

            if (talentJob.StatusId == (int)ProjectJobStatusEnum.MoveToLastAuditionStage)
            {
                talentJob.NotSelected = false;
                talentJob.StatusId = (int)ProjectJobStatusEnum.SelectedForAudition;
                job.NotSelected = false;
                UpdateonLastAuditionStage(talentJob.TalentId, talentJob.JobId);
                job.StatusId = (int)ProjectJobStatusEnum.SelectedForAudition;
            }
        }

        private async Task UpdateTalentJobHistory(TalentJobAuditionStatus talentJob)
        {
            if (talentJob.AuditionId == 0) { talentJob.AuditionId = null; }

            var talentJobHistory = new TalentJobHistory
            {
                CreatedOn = DateTime.UtcNow,
                JobId = talentJob.JobId,
                JobStatusId = talentJob.StatusId,
                TalentId = talentJob.TalentId,
                AuditionId = talentJob.AuditionId,
            };

            await _talentJobHistoryRepository.AddAsync(talentJobHistory);
        }

        /// <summary>
        /// This method move talents to next stage
        /// </summary>
        /// <param name="talentId"></param>
        /// <param name="jobId"></param>
        private void UpdateMoveToNextStatus(int? talentId, int? jobId)
        {
            if (talentId.HasValue && jobId.HasValue)
            {
                var auditions = _jobAuditionRepository.FindAll(c => c.JobId == jobId).Select(c => c.Id).ToList();

                var jobAuditionTalents = _jobAuditionTalentRepository.FindAll(c => c.TalentId == talentId && auditions.Contains(c.JobAuditionId ?? 0)).ToList();

                jobAuditionTalents.ForEach(f => { f.MovedToNextStage = true; f.UpdatedOn = DateTime.UtcNow; });

                //update flag 'MovedToNextStage' as true
                foreach (JobAuditionTalent talent in jobAuditionTalents)
                {
                    _jobAuditionTalentRepository.Update(talent);
                }
            }
        }

        private static string FormatRoundTabText(short? roundNumber, string auditionType)
        {

            var text = auditionType;

            if (roundNumber.HasValue)
            {
                text = string.Format("{0} Round {1}", auditionType, Convert.ToString(roundNumber));
            }
            return text;
        }

        private static string FormatRoundText(short? roundNumber, string auditionType)
        {
            var text = string.Format("{0} Round", auditionType != null ? auditionType : string.Empty);

            if (roundNumber.HasValue)
            {
                text = string.Format("{0} Round {1}", auditionType != null ? auditionType : string.Empty, Convert.ToString(roundNumber));
            }
            return text;
        }

        private void UpdateNotSelectedStatus(int? talentId, int? jobId, bool status)
        {
            if (talentId.HasValue && jobId.HasValue)
            {
                var auditions = _jobAuditionRepository.FindAll(c => c.JobId == jobId).Select(c => c.Id).ToList();

                var jobAuditionTalents = _jobAuditionTalentRepository.FindAll(c => c.TalentId == talentId && auditions.Contains(c.JobAuditionId ?? 0)).ToList();

                jobAuditionTalents.ForEach(f => { f.NotSelected = status; f.UpdatedOn = DateTime.UtcNow; });

                foreach (JobAuditionTalent talent in jobAuditionTalents)
                {
                    _jobAuditionTalentRepository.Update(talent);
                }
            }
        }


        /// <summary>
        /// This method move talents to last audition stage.
        /// </summary>
        /// <param name="talentId"></param>
        /// <param name="jobId"></param>
        private void UpdateonLastAuditionStage(int? talentId, int? jobId)
        {
            if (talentId.HasValue && jobId.HasValue)
            {

                var auditions = _jobAuditionRepository.FindAll(c => c.JobId == jobId).Select(c => c.Id).ToList();

                var jobAuditionTalents = _jobAuditionTalentRepository.FindAll(c => c.TalentId == talentId && auditions.Contains(c.JobAuditionId ?? 0) && c.MoveToAuditionId == null).ToList();

                jobAuditionTalents.ForEach(f => { f.NotSelected = false; f.UpdatedOn = DateTime.UtcNow; });

                foreach (JobAuditionTalent talent in jobAuditionTalents)
                {
                    _jobAuditionTalentRepository.Update(talent);
                }
            }
        }

        /// <summary>
        /// This method get city 
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        private static string GetCity(TalentAddress address)
        {
            if (address == null)
            {
                return string.Empty;
            }

            return address.Address == null ? string.Empty : address.Address.City == null ? string.Empty : address.Address.City.CityDescription;

        }

        /// <summary>
        /// This method is use to calculate age.
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        private static int CalculateAge(DateTime? date)
        {
            var age = 0;
            var birthDate = DateTime.MinValue;

            if (date.HasValue)
            {
                birthDate = date.Value;
            }

            if (birthDate != DateTime.MinValue)
            {

                var now = DateTime.Now;
                age = now.Year - birthDate.Year;


                if (now.Month < birthDate.Month || (now.Month == birthDate.Month && now.Day < birthDate.Day))
                    age--;
            }
            return age;
        }

        /// <summary>
        /// This method is use to get ranking order
        /// </summary>
        /// <param name="talentId"></param>
        /// <param name="jobId"></param>
        /// <param name="jobTalentRecommended"></param>
        /// <param name="rmark"></param>
        /// <returns></returns>
        private int GetRmarkOrder(int? talentId, int jobId, List<JobTalentRecommended> jobTalentRecommended, List<TalentRatingRmark> rmark, int? interestId, int? talentCategoryId)
        {
            var rating = (int)MstSortOrderTypeEnum.Applied;

            if (jobTalentRecommended != null && jobTalentRecommended.Any())
            {
                rating = jobTalentRecommended.Where(c => c.TalentId == talentId && (c.SortOrderTypeId == 1 || c.SortOrderTypeId == 2)).Select(c => c.SortOrderType == null ? 100 : c.SortOrderType.SotOrder).FirstOrDefault() ?? (int)MstSortOrderTypeEnum.Applied;
            }

            if (rating == (int)MstSortOrderTypeEnum.Applied)
            {
                if (rmark != null && rmark.Count() > 0)
                {
                    rating = rmark.Where(g => g.TalentCategoryId == talentCategoryId && g.InterestCategoryId == interestId).Select(p => p.TalentId).Contains(talentId) ? (int)MstSortOrderTypeEnum.RMark : (int)MstSortOrderTypeEnum.Applied;
                }
            }
            return rating;
        }


        private string GetStatusDescription(dynamic talentJob, JobTalentRecommended jobTalentRecommended)
        {

            var statusDescription = string.Empty;

            if (talentJob != null)
            {
                statusDescription = (talentJob.NotSelected ?? false) ? "Not selected" : talentJob.Status.Description;
            }
            else
            {
                if (jobTalentRecommended != null && (bool)jobTalentRecommended.InvitationDeclined)
                {
                    statusDescription = "Declined invite";

                }
                else
                {
                    statusDescription = "Invited";
                }
            }
            return statusDescription;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="talentId"></param>
        /// <param name="jobTalentRecommended"></param>
        /// <param name="rmark"></param>
        /// <param name="interestId"></param>
        /// <param name="talentCategoryId"></param>
        /// <returns></returns>
        private int GetRmark(int? talentId, JobTalentRecommended jobTalentRecommended, TalentRatingRmark rmark)
        {
            var rating = (int)MstSortOrderTypeEnum.Applied;

            if (jobTalentRecommended != null)
            {
                if (jobTalentRecommended.SortOrderTypeId == 1 || jobTalentRecommended.SortOrderTypeId == 2)
                {
                    rating = jobTalentRecommended.SortOrderType == null ? 100 : (short)jobTalentRecommended.SortOrderType.SotOrder;
                }
            }

            if (rating == (int)MstSortOrderTypeEnum.Applied)
            {
                rating = (rmark != null) ? (int)MstSortOrderTypeEnum.RMark : (int)MstSortOrderTypeEnum.Applied;
            }

            return rating;

        }


        /// <summary>
        /// This method is use to get project interest id
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        private int? GetProjectInterestId(int jobId)
        {
            var projectJob = _projectJobRepository.FindAll(g => g.Id == jobId);
            var projectId = projectJob.Select(c => c.ProjectId).First();
            return _projectRepository.Find(g => g.Id == projectId).InterestId;
        }

        /// <summary>
        /// This method returns project interest and job category
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="talentCategoryId"></param>
        /// <param name="interestId"></param>
        private void GetProjectInterest(int jobId, out int? talentCategoryId, out int? interestId)
        {
            var projectJob = _projectJobRepository.FindAll(g => g.Id == jobId);
            var projectId = projectJob.Select(c => c.ProjectId).First();
            interestId = _projectRepository.Find(g => g.Id == projectId).InterestId;
            talentCategoryId = projectJob.Select(c => c.TalentCategoryId).First();
        }

        private async Task<ProjectJob> GetJobById(int Id)
        {
            var query = _context.Set<ProjectJob>();

            var projectJob = await query.Include(project => project.Project).ThenInclude(auxuser => auxuser.AuxiliaryUser).ThenInclude(rec => rec.AuxiliaryRecruiter)
                                         .Include(project => project.Project).ThenInclude(intr => intr.Interest)
                                         .Include(project => project.JobTalentCategory)
                                         .Include(intrestCat => intrestCat.InterestCategory)
                                         .Include(jobLoc => jobLoc.ProjectJobLocation).ThenInclude(city => city.City)
                                         .Include(lang => lang.ProjectJobLanguage).ThenInclude(l => l.Language)
                                         .Include(tag => tag.ProjectJobTag).ThenInclude(t => t.Tag)
                                         .Include(skin => skin.ProjectJobSkinColor).ThenInclude(s => s.SkinColor)
                                         .Include(eye => eye.ProjectJobEyecolor).ThenInclude(e => e.EyeColor)
                                         .Include(hairc => hairc.ProjectJobHairColor).ThenInclude(h => h.HairColor)
                                         .Include(bodyType => bodyType.ProjectJobBodytype).ThenInclude(b => b.BodyType)
                                         .Include(ethnicities => ethnicities.ProjectJobEthnicity).ThenInclude(e => e.Ethnicity).Include(subTalent => subTalent.ProjectJobSubTalent).ThenInclude(e => e.TalentCategory)
                                         .Include(hairt => hairt.HairType)
                                         .Include(hairl => hairl.HairLength)
                                         .Include(hairl => hairl.HairLength)
                                         .Include(minchest => minchest.MinChestSize).Include(maxchest => maxchest.MaxChestSize)
                                         .Include(minwaist => minwaist.MinWaistSize).Include(maxwaist => maxwaist.MaxWaistSize)
                                         .Include(minh => minh.MinHeight).Include(maxh => maxh.MaxHeight)
                                         .Include(minw => minw.MinWeight).Include(maxw => maxw.MaxWeight)
                                         .Include(jobstatus => jobstatus.Status)
                                         .Include(talj => talj.TalentJob).ThenInclude(s => s.Status)
                                         .Where(x => x.Id == Id)
                                         .FirstOrDefaultAsync();

            return projectJob;
        }

        private float? GetHeightInInclues(int? heightId, List<Height> height)
        {
            if (heightId.HasValue)
            {
                return height.Where(p => p.Id == heightId).Select(p => p.Inches).FirstOrDefault();
            }

            return 0;
        }

        private float? GetWeightInKgs(int? weightId, List<Weight> weight)
        {
            if (weightId.HasValue)
            {
                return weight.Where(p => p.Id == weightId).Select(p => p.Kgs).FirstOrDefault();
            }

            return 0;
        }

        private double GetChestSizeInInches(int? chestSizeId, List<ChestSize> chestSize)
        {
            if (chestSizeId.HasValue)
            {
                return chestSize.Where(p => p.Id == chestSizeId).Select(p => p.Inches).FirstOrDefault();
            }

            return 0;
        }

        private double GetWaistInInches(int? waistId, List<WaistSize> waistSize)
        {
            if (waistId.HasValue)
            {
                return waistSize.Where(p => p.Id == waistId).Select(p => p.Inches).FirstOrDefault();
            }

            return 0;
        }
        private static IQueryable<JobAuditionTalent> ApplyAuditionFilter(JobAuditionsRequest jobAuditionsRequest, IQueryable<JobAuditionTalent> auditions)
        {
            //get only activated talents 
            auditions = auditions.Where(x => x.Talent.StatusId == 1);

            //filter for city
            if (jobAuditionsRequest.CityId != null && jobAuditionsRequest.CityId.Any(c => c > 0))
            {
                auditions = auditions.Where(x => x.Talent.TalentAddress.Any(p => jobAuditionsRequest.CityId.Contains(p.Address.CityId ?? 0)));
            }

            if (jobAuditionsRequest.MaxAge > 0)
            {
                //Filter for age range
                auditions = auditions.Where(x => CalculateAge(x.Talent.DOB) >= jobAuditionsRequest.MinAge && CalculateAge(x.Talent.DOB) <= jobAuditionsRequest.MaxAge);
            }

            if (jobAuditionsRequest.MaxBudget > 0)
            {
                auditions = auditions.Where(x =>
                ((x.Talent.BudgetMin.HasValue ? x.Talent.BudgetMin.Value : 0) >= jobAuditionsRequest.MinBudget && (x.Talent.BudgetMin.HasValue ? x.Talent.BudgetMin.Value : 0) <= jobAuditionsRequest.MaxBudget) ||
                ((x.Talent.BudgetMax.HasValue ? x.Talent.BudgetMax.Value : 0) >= jobAuditionsRequest.MinBudget && (x.Talent.BudgetMax.HasValue ? x.Talent.BudgetMax.Value : 0) <= jobAuditionsRequest.MaxBudget));
            }

            return auditions;
        }


        private async Task<JobAuditionResults<Auditions>> GetTalentJobAuditions(JobAuditionsRequest jobAuditionsRequest)
        {
            int? pendingSelectionCount = null;
            int? pendingNumberOfRole = null;

            string collabratorComments = string.Empty;
            IQueryable<TalentJob> query = _context.Set<TalentJob>();

            //set default pagesize.
            jobAuditionsRequest.SetDefaultsForUnsetProperties();

            var auditions = query.Where(g => g.JobId == jobAuditionsRequest.JobId && g.StatusId == jobAuditionsRequest.StatusId && g.NotSelected == jobAuditionsRequest.NotSelected)
                            .Include(t => t.Talent).ThenInclude(ta => ta.TalentAddress).ThenInclude(a => a.Address).ThenInclude(c => c.City)
                            .Include(t => t.Talent).ThenInclude(t => t.TalentRatingRmark)
                            .Include(t => t.Talent).ThenInclude(t => t.TalentRatingInterestCategory)
                            .Include(s => s.Status).AsQueryable();

            //Filter for city, age, budget
            auditions = ApplyFilter(jobAuditionsRequest, auditions);

            var talentsJobAuditions = await auditions.ToListAsync();

            var jobTalentRecommended = await _context.JobTalentRecommended.Where(c => c.JobId == jobAuditionsRequest.JobId).Include(t => t.SortOrderType).ToListAsync();

            if (jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.SelectedForAudition && jobAuditionsRequest.NotSelected == false)
            {
                IQueryable<JobAuditionTalent> auditionsQuery = _context.Set<JobAuditionTalent>();

                var talentIds = await auditionsQuery
                                .Include(j => j.JobAudition).ThenInclude(j => j.Job)
                                .Where(g => g.JobAudition.JobId == jobAuditionsRequest.JobId && g.JobAuditionId > 0 && g.MovedToNextStage == false).Select(c => c.TalentId).ToListAsync();

                if (talentIds != null && talentIds.Any())
                {
                    talentsJobAuditions.RemoveAll(x => talentIds.Any(y => y == x.TalentId));
                }

            }

            var project = _projectJobRepository.FindAll(g => g.Id == jobAuditionsRequest.JobId).Select(c => new { ProjectId = c.ProjectId, InterestId = c.InterestCategoryId, TalentCategoryId = c.TalentCategoryId, EndDate = c.EndDate, NumberOfRole = c.NumberOfRole }).FirstOrDefault();
            var projectPlan = _context.Set<Project>().Include(plan => plan.Plan).Where(c => c.Id == project.ProjectId).Select(p => new { ProvideNotesRating = p.Plan.ProvideNotesRating, ViewAuditionHistory = p.Plan.ViewAuditionHistory, AuditionSelectionCount = p.Plan.AuditionSelectionCount }).FirstOrDefault();



            //This talent list order based on stack ranking
            var orderJobAuditions = talentsJobAuditions.Select(g => new Auditions
            {
                FullName = jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.UnderReview ? string.Empty : g.Talent.FullName,
                Age = CalculateAge(g.Talent.DOB),
                City = GetCity(g.Talent.TalentAddress.FirstOrDefault()),
                StatusDescription = (g.StatusId == (int)ProjectJobStatusEnum.Shortlisted) ? GetCollabratorFeedback(g.CollaboratorFeedback) : g.Status.Description,
                StatusId = g.StatusId,
                UID = g.Talent.UID ?? 0,
                TalentId = g.TalentId,
                TalentProfileURL = g.Talent.TalentProfileURL,
                RMark = GetRmarkOrder(g.TalentId, jobAuditionsRequest.JobId, jobTalentRecommended, g.Talent.TalentRatingRmark.ToList(), project.InterestId, project.TalentCategoryId),
                Rating = g.Talent.OverallRating,
                Interest = g.Talent.TalentRatingInterestCategory.Where(p => p.TalentId == g.TalentId && p.InterestCategoryId == project.InterestId).Average(p => p.Rating),
                IsRecommended = jobTalentRecommended.Count(c => c.TalentId == g.TalentId) > 0
            })
                            .OrderBy(o => o.RMark)
                            .ThenByDescending(o => o.Rating)
                            .ThenByDescending(o => o.Interest)
                            .ThenBy(o => o.UID);

            //get talents based on requested pageindex.
            var jobAuditions = (orderJobAuditions != null && orderJobAuditions.Any()) ? orderJobAuditions.AsQueryable()
                                .ApplyPaging(jobAuditionsRequest.PageIndex, jobAuditionsRequest.PageSize).ToList() : null;

            if (jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.UnderReview)
            {
                var auditionSelectionCount = projectPlan.AuditionSelectionCount;

                var jobs = _projectJobRepository.FindAll(g => g.ProjectId == project.ProjectId).Distinct().Select(j => j.Id).ToList();

                if (auditionSelectionCount > 0)
                {
                    var totalAuditionSelectionCount = query.Count(g => g.StatusId != (int)ProjectJobStatusEnum.UnderReview && jobs.Contains((int)g.JobId));
                    pendingSelectionCount = Math.Max(0, (Convert.ToInt32(auditionSelectionCount) - Convert.ToInt32(totalAuditionSelectionCount)));
                }
            }

            if (jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.Shortlisted || jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.MoveToCasted)
            {
                var numberOfRole = project.NumberOfRole;

                if (numberOfRole > 0)
                {
                    var totalCastCount = query.Count(g => g.StatusId == (int)ProjectJobStatusEnum.Cast && g.JobId == jobAuditionsRequest.JobId);
                    pendingNumberOfRole = Math.Max(0, (Convert.ToInt32(numberOfRole) - Convert.ToInt32(totalCastCount)));
                }
            }

            var recordCount = talentsJobAuditions.Count();

            //Get collabrator comments in case of shortlisted.
            if (jobAuditionsRequest.StatusId == (int)ProjectJobStatusEnum.Shortlisted)
            {
                collabratorComments = _context.ProjectJob.Where(c => c.Id == jobAuditionsRequest.JobId).Select(c => c.ColloaboratorComments).FirstOrDefault();
            }

            await CheckMediaAvailable(jobAuditions,jobAuditionsRequest.JobId);

            return new JobAuditionResults<Auditions>
            {
                CollabratorComments = collabratorComments,
                Results = jobAuditions,
                TotalResults = recordCount,
                PendingAuditionSelectionCount = pendingSelectionCount,
                JobNumberOfRole = pendingNumberOfRole,
                ProvideNotesRating = projectPlan.ProvideNotesRating,
                ViewAuditionHistory = projectPlan.ViewAuditionHistory,
                JobEndDate = project.EndDate,
                ViewAuditions = IsViewAuditions(project.EndDate, projectPlan.ViewAuditionHistory)
            };
        }

        private static bool IsViewAuditions(DateTime? endDate, short? viewAuditionsHistory)
        {
            var viewAuditions = (endDate.HasValue) ? endDate.Value.AddMonths((short)viewAuditionsHistory) >= DateTime.UtcNow.Date : false;
            return viewAuditions;
        }

        private static IQueryable<TalentJob> ApplyFilter(JobAuditionsRequest jobAuditionsRequest, IQueryable<TalentJob> auditions)
        {

            auditions = auditions.Where(x => x.Talent.StatusId == 1);

            //filter for city
            if (jobAuditionsRequest.CityId != null && jobAuditionsRequest.CityId.Any(c => c > 0))
            {
                auditions = auditions.Where(x => x.Talent.TalentAddress.Any(p => jobAuditionsRequest.CityId.Contains(p.Address.CityId ?? 0)));
            }

            if (jobAuditionsRequest.MaxAge > 0)
            {
                //Filter for age range
                auditions = auditions.Where(x => CalculateAge(x.Talent.DOB) >= jobAuditionsRequest.MinAge && CalculateAge(x.Talent.DOB) <= jobAuditionsRequest.MaxAge);
            }

            if (jobAuditionsRequest.MaxBudget > 0)
            {
                auditions = auditions.Where(x =>
                ((x.Talent.BudgetMin.HasValue ? x.Talent.BudgetMin.Value : 0) >= jobAuditionsRequest.MinBudget && (x.Talent.BudgetMin.HasValue ? x.Talent.BudgetMin.Value : 0) <= jobAuditionsRequest.MaxBudget) ||
                ((x.Talent.BudgetMax.HasValue ? x.Talent.BudgetMax.Value : 0) >= jobAuditionsRequest.MinBudget && (x.Talent.BudgetMax.HasValue ? x.Talent.BudgetMax.Value : 0) <= jobAuditionsRequest.MaxBudget));
            }

            return auditions;
        }

        private string GetCollabratorFeedback(short? collaboratorFeedback)
        {
            string description = collaboratorFeedback > 0 ? collaboratorFeedback == 1 ? CollabratorFeedbackEnum.Yes.ToString() : CollabratorFeedbackEnum.No.ToString() : string.Empty;
            return description;
        }

        private IQueryable<JobTalentRecommended> ApplyRecommendedFilter(JobAuditionsRequest jobAuditionsRequest, IQueryable<JobTalentRecommended> recommended)
        {
            recommended = recommended.Where(x => x.Talent.StatusId == 1);

            //filter for city
            if (jobAuditionsRequest.CityId != null && jobAuditionsRequest.CityId.Any(c => c > 0))
            {
                recommended = recommended.Where(x => x.Talent.TalentAddress.Any(p => jobAuditionsRequest.CityId.Contains(p.Address.CityId ?? 0)));
            }

            if (jobAuditionsRequest.MaxAge > 0)
            {
                recommended = recommended.Where(x => CalculateAge(x.Talent.DOB) >= jobAuditionsRequest.MinAge && CalculateAge(x.Talent.DOB) <= jobAuditionsRequest.MaxAge);
            }


            if (jobAuditionsRequest.MaxBudget > 0)
            {
                recommended = recommended.Where(x =>
                ((x.Talent.BudgetMin.HasValue ? x.Talent.BudgetMin.Value : 0) >= jobAuditionsRequest.MinBudget && (x.Talent.BudgetMin.HasValue ? x.Talent.BudgetMin.Value : 0) <= jobAuditionsRequest.MaxBudget) ||
                ((x.Talent.BudgetMax.HasValue ? x.Talent.BudgetMax.Value : 0) >= jobAuditionsRequest.MinBudget && (x.Talent.BudgetMax.HasValue ? x.Talent.BudgetMax.Value : 0) <= jobAuditionsRequest.MaxBudget));
            }

            return recommended;
        }



        private IQueryable<Talent> ApplyRecommendedTalentFilter(JobAuditionsRequest jobAuditionsRequest, IQueryable<Talent> talent)
        {
            talent = talent.Where(x => x.StatusId == 1);

            if (jobAuditionsRequest.MaxAge > 0)
            {
                talent = talent.Where(x => CalculateAge(x.DOB) >= jobAuditionsRequest.MinAge && CalculateAge(x.DOB) <= jobAuditionsRequest.MaxAge);
            }


            if (jobAuditionsRequest.MaxBudget > 0)
            {
                talent = talent.Where(x =>
                ((x.BudgetMin.HasValue ? x.BudgetMin.Value : 0) >= jobAuditionsRequest.MinBudget && (x.BudgetMin.HasValue ? x.BudgetMin.Value : 0) <= jobAuditionsRequest.MaxBudget) ||
                ((x.BudgetMax.HasValue ? x.BudgetMax.Value : 0) >= jobAuditionsRequest.MinBudget && (x.BudgetMax.HasValue ? x.BudgetMax.Value : 0) <= jobAuditionsRequest.MaxBudget));
            }

            return talent;
        }


        private async Task CheckMediaAvailable(List<Auditions> jobAuditions,int JobId)
        {
            if (jobAuditions != null && jobAuditions.Count > 0)
            {
                foreach (var audition in jobAuditions)
                {
                    audition.IsMediaAvailable = await IsTalentMediaAvailable(audition.TalentId,JobId);
                }
            }
        }


        #endregion

    }
}
