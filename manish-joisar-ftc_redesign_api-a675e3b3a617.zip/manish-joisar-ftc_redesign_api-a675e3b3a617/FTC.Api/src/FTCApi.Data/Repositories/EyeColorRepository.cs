﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class EyeColorRepository : GenericRepository<EyeColor>,IEyeColorRepository
    {
        public EyeColorRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
