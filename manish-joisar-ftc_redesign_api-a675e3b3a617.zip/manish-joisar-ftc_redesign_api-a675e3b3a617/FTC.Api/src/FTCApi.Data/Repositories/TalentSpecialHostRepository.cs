﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.SpecialHost;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTCApi.Data.Repositories
{
    public class TalentSpecialHostRepository : GenericRepository<TalentSpecialHost>, ITalentSpecialHostRepository
    {
        public TalentSpecialHostRepository(FTCDbContext context) : base(context)
        {
        }
        private TalentSpecialHost ConvertToTalentSpecialHost(TalentSpecialHostDto talentSpecialHostDto, int userId, int userType)
        {
            return new TalentSpecialHost()
            {
                TalentId = talentSpecialHostDto.TalentId,
                SpecialHostId = talentSpecialHostDto.SpecialHostId,
                Value1 = talentSpecialHostDto.RMN,
                //Value2 = talentSpecialHostDto.SubscriberNumber,
                Value2 = GetSubscriberNumber(talentSpecialHostDto),
                CreatedBy = (userType == (int)LoginUserType.FTCAdmin) ? userId : talentSpecialHostDto.CreatedBy,
                // StatusId,CreatedOn & UpdatedOn is set to default value in DB 
                StatusId = talentSpecialHostDto.StatusId
            };
        }

        private string GetSubscriberNumber(TalentSpecialHostDto talentSpecialHostDto)
        {
            return string.IsNullOrEmpty(talentSpecialHostDto.RMN) ? talentSpecialHostDto.SubscriberIdText : talentSpecialHostDto.SubscriberNumber;
        }
        
        public TalentSpecialHostDto ConvertToTalentSpecialHostDto(TalentSpecialHost talentSpecialHost)
        {
            return new TalentSpecialHostDto()
            {
                Id = talentSpecialHost.Id,
                TalentId = talentSpecialHost.TalentId,
                SpecialHostId = talentSpecialHost.SpecialHostId,
                RMN = talentSpecialHost.Value1,
                //SubscriberNumber = talentSpecialHostDto.Value2,                
                SubscriberNumber = string.IsNullOrEmpty(talentSpecialHost.Value1) ? string.Empty : talentSpecialHost.Value2,
                SubscriberIdText = string.IsNullOrEmpty(talentSpecialHost.Value1) ? talentSpecialHost.Value2 : string.Empty,
                StatusId = talentSpecialHost.StatusId,
                CreatedBy = talentSpecialHost.CreatedBy
            };
        }

        public async Task<TalentSpecialHostDto> SaveTalentSpecialHost(TalentSpecialHostDto talentSpecialHostDto,int userId, int userType)
        {
            var talentSpecialHost = this.ConvertToTalentSpecialHost(talentSpecialHostDto, userId, userType);

            talentSpecialHost = await this.AddAsync(talentSpecialHost);
            return this.ConvertToTalentSpecialHostDto(talentSpecialHost);

        }

        public async Task UpdateTalentSpecialHost(TalentSpecialHostDto talentSpecialHostDto, int userId, int userType)
        {
            var talentSpecialHost = await this.FindAsync(x => x.TalentId == talentSpecialHostDto.TalentId
                                                                  && x.StatusId == (int)StatusEnum.Active
                                                                  && x.SpecialHostId == talentSpecialHostDto.SpecialHostId);

            if (talentSpecialHost != null)
            {
                talentSpecialHost.StatusId = (int)StatusEnum.InActive;

                if (userType == (int)LoginUserType.FTCAdmin)
                    talentSpecialHost.UpdatedBy = userId;

                talentSpecialHost = await this.UpdateAsync(talentSpecialHost);
            }
        }

        public int GetProviderId(int specialHostId)
        {
            IQueryable<ContestSpecialHost> query = _context.Set<ContestSpecialHost>();
            query = query.Where(x => x.Id == specialHostId);
            var providerId = query.Select(x => x.AuxiliaryUserId).FirstOrDefault();

            if (providerId == null)
                providerId = 0;

            return (int)providerId;
        }
    }
}
