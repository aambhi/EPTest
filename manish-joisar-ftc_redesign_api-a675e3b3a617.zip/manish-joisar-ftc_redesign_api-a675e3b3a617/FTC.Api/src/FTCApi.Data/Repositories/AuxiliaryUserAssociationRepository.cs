﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserAssociationRepository:GenericRepository<AuxiliaryUserAssociation>, IAuxiliaryUserAssociationRepository
    {
        public AuxiliaryUserAssociationRepository(FTCDbContext context):base(context)
        {

        }
    }
}
