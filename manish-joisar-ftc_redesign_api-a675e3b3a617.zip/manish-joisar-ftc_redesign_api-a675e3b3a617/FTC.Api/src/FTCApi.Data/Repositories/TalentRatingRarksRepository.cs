﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentRatingRmarksRepository : GenericRepository<TalentRatingRmark>, ITalentRatingRmarksRepository
    {

        public TalentRatingRmarksRepository(FTCDbContext context) : base(context)
        {
          
        }
    }
}
