﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class MediaFileRepository:GenericRepository<MediaFile>,IMediaFileRepository
    {
        public MediaFileRepository(FTCDbContext context):base(context)
        {
            
        }
    }
}
