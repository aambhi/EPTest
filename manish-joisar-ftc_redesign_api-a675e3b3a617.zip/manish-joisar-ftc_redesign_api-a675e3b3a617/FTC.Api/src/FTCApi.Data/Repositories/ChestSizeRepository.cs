﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ChestSizeRepository:GenericRepository<ChestSize>, IChestSizeRepository
    {
        public ChestSizeRepository(FTCDbContext context):base(context)
        {

        }
    }
}
