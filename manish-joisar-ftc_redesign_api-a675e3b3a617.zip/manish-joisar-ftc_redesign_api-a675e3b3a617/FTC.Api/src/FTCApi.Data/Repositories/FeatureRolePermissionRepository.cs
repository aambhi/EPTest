﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class FeatureRolePermissionRepository : GenericRepository<FeatureRolePermission>, IFeatureRolePermissionRepository
    {

        public FeatureRolePermissionRepository(FTCDbContext context) : base(context)
        {

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<List<Features>> GetPermissions(int? userId)
        {
            var roles = _context.AuxiliaryUserRole.Where(r => r.AuxiliaryUserId == userId).Select(r => r.RoleId).ToList();

            if(roles !=null && roles.Count()==0)
            {
                roles = new List<int?>{ 9 };
            }

            List<Features> features = null;
            if (roles.Any())
            {
                var query = await _context.FeatureRolePermission.Include(fp => fp.FeaturePermission).ThenInclude(c => c.FeatureOperation)
                             .Include(fp => fp.FeaturePermission).ThenInclude(c => c.Feature)
                             .Where(g => roles.Contains(g.RoleId)).ToListAsync();


                features = query.GroupBy(g => g.FeaturePermission.FeatureId).Select(p => new
                Features
                {
                    featureId = p.Key,
                    featureName = query.Where(c => c.FeaturePermission.FeatureId == p.Key).Select(f => f.FeaturePermission.Feature.Desc).FirstOrDefault(),
                    operations = p.Select(c => new
                    Operation
                    {
                        operationId = c.FeaturePermission.FeatureOperationId,
                        operation = c.FeaturePermission.FeatureOperation.Desc
                    }).GroupBy(o => o.operationId).Select(g => g.First()).ToList()

                }).ToList();
              

            }
            return features;
        }
    }
}
