﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentTagRepository:GenericRepository<TalentTag>, ITalentTagRepository
    {
        public TalentTagRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
