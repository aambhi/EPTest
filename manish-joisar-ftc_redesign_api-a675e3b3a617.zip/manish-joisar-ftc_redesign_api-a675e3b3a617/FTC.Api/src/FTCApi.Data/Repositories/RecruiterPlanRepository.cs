﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class RecruiterPlanRepository : GenericRepository<RecruiterPlan>, IRecruiterPlanRepository
    {
        public RecruiterPlanRepository(FTCDbContext context) : base(context)
        {

        }

        public async Task<List<RecruiterPlan>> GetAllPlans()
        {
            return await _context.Set<RecruiterPlan>()
                .Include(x => x.RecruiterPlanUser)
                .ThenInclude(x=>x.AuxiliaryUser).OrderBy(x=>x.Amount).ToListAsync();
        }
    }
}
