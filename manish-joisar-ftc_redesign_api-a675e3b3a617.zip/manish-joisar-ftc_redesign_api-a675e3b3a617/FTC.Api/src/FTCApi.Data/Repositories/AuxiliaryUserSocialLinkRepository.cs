﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserSocialLinkRepository : GenericRepository<AuxiliaryUserSocialLink>, IAuxiliaryUserSocialLinkRepository
    {
        public AuxiliaryUserSocialLinkRepository(FTCDbContext context) : base(context)
        {

        }
    }
}
