﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentTalentCategoryRepository:GenericRepository<TalentTalentCategory>, ITalentTalentCategoryRepository
    {
        public TalentTalentCategoryRepository(FTCDbContext context):base(context)
        {

        }
    }
}
