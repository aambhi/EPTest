﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class CityRepository : GenericRepository<City>, ICityRepository
    {
        public CityRepository(FTCDbContext context) : base(context)
        {

        }

        public async Task<List<City>> GetCitiesWithCountry()
        {
            IQueryable<City> query = _context.Set<City>().Include(x => x.CityCountry);

            var city = await query.Select(x => new City
                                            {
                                                CityId = x.CityId,
                                                CityDescription = x.CityDescription + ", " + x.CityCountry.Name,
                                                CityCountryId = x.CityCountryId,
                                                CityState = x.CityState,
                                                CityStateCode = x.CityStateCode
                                            }).ToListAsync();

            return city;
        }
    }
}
