﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentCategoryRepository: GenericRepository<TalentCategory>,ITalentCategoryRepository
    {
        public TalentCategoryRepository(FTCDbContext context):base(context)
        {

        }
    }
}
