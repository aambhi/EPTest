﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class RazorPayStagingRepository: GenericRepository<RazorPayStaging>, IRazorPayStagingRepository
    {
        public RazorPayStagingRepository(FTCDbContext context):base(context)
        {

        }
    }
}
