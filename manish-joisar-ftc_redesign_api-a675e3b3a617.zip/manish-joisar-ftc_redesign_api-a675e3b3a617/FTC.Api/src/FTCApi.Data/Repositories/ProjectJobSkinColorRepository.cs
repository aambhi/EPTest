﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobSkinColorRepository : GenericRepository<ProjectJobSkinColor> , IProjectJobSkinColorRepository
    {
        public ProjectJobSkinColorRepository(FTCDbContext context):base(context)
        {

        }
    }
}
