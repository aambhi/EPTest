﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserAddressRepository:GenericRepository<AuxiliaryUserAddress>, IAuxiliaryUserAddressRepository
    {
        public AuxiliaryUserAddressRepository(FTCDbContext context):base(context)
        {

        }
    }
}
