﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class SchoolRepository:GenericRepository<School>, ISchoolRepository
    {
        public SchoolRepository(FTCDbContext context):base(context)
        {

        }
    }
}
