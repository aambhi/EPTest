﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class JobTalentRecommendedRepository : GenericRepository<JobTalentRecommended>, IJobTalentRecommendedRepository
    {
        public JobTalentRecommendedRepository(FTCDbContext context) : base(context)
        {
        }
    }
}