﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserTypeRepository: GenericRepository<AuxiliaryUserType>, IAuxiliaryUserTypeRepository
    {
        public AuxiliaryUserTypeRepository(FTCDbContext context):base(context)
        {

        }
    }
}
