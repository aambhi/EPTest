﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class TalentJobSpecialHostRepository : GenericRepository<TalentJobSpecialHost>, ITalentJobSpecialHostRepository
    {
        public TalentJobSpecialHostRepository(FTCDbContext context) : base(context)
        {
        }

        public async Task AddTalentJobSpecialHost(int talentId, int talentJobId)
        {
            IQueryable<TalentSpecialHost> query = _context.Set<TalentSpecialHost>();

            var talentSpecialHost = query.Where(x => x.TalentId == talentId && x.StatusId == (int)StatusEnum.Active)
                                         .Select(x => new { x.TalentId, x.SpecialHostId })
                                         .FirstOrDefault();

            if (talentSpecialHost == null)
                return;

            var talentJobSpecialHost = new TalentJobSpecialHost()
            {
                SpecialHostId = talentSpecialHost.SpecialHostId,                
                TalentJobId = talentJobId
            };

            talentJobSpecialHost = await this.AddAsync(talentJobSpecialHost);

            return;
        }
    }
}
