﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class InterestCategoryRepository:GenericRepository<InterestCategory>, IInterestCategoryRepository
    {
        public InterestCategoryRepository(FTCDbContext context):base(context)
        {

        }
    }
}
