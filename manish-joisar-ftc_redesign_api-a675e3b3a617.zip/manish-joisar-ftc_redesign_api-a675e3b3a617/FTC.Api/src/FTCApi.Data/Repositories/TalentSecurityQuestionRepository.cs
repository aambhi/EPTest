﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentSecurityQuestionRepository: GenericRepository<TalentSecurityQuestion>,ITalentSecurityQuestionRepository
    {
        public TalentSecurityQuestionRepository(FTCDbContext context):base(context)
        {

        }
    }
}
