﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProductionHouseCategoryRepository:GenericRepository<ProductionHouseCategory>, IProductionHouseCategoryRepository
    {
        public ProductionHouseCategoryRepository(FTCDbContext context):base(context)
        {

        }
    }
}
