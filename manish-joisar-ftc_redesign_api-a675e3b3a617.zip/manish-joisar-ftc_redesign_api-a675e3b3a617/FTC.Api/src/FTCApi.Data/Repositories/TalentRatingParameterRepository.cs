﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentRatingParameterRepository : GenericRepository<TalentRatingParameter>, ITalentRatingParameterRepository
    {
        public TalentRatingParameterRepository(FTCDbContext context):base(context)
        {
        }

    }
}
