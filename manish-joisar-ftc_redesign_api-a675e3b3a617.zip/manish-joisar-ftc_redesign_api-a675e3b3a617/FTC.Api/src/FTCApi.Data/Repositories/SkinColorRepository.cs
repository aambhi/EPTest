﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class SkinColorRepository: GenericRepository<SkinColor>,ISkinColorRepository
    {
        public SkinColorRepository(FTCDbContext context):base(context)
        {

        }
    }
}
