﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentPlanRepository : GenericRepository<TalentPlan>, ITalentPlanRepository
    {
        public TalentPlanRepository(FTCDbContext context) : base(context)
        {

        }
    }
}
