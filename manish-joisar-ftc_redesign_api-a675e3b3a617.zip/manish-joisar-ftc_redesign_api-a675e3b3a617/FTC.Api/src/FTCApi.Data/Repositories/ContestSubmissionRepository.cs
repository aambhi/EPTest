﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Data.Extensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class ContestSubmissionRepository : GenericRepository<ContestSubmission>, IContestSubmissionRepository
    {
        public ContestSubmissionRepository(FTCDbContext context) : base(context)
        {

        }

        public async Task<SearchResult<ContestSubmission>> GetContestSubmissionByType(SearchParameters searchParams, int contestId, string submissionType)
        {
            if (searchParams == null)
            {
                throw new ArgumentNullException("searchParams");
            }

            searchParams.SetDefaultsForUnsetProperties();
            IQueryable<ContestSubmission> query = _context.Set<ContestSubmission>();

            if (submissionType.Trim() == "submitted")
                query = query.Where(x => x.ContestId == contestId && x.Selected == false);
            else if (submissionType.Trim() == "selected")
                query = query.Where(x => x.ContestId == contestId && x.Selected == true);
            else if (submissionType.Trim() == "winners")
                //query = query.Where(x => x.ContestId == contestId && x.Selected == true && x.ContestResult.Count() > 0);
                query = query.Where(x => x.ContestId == contestId && x.Selected == true && _context.ContestResult.Select(r => r.ContestSubmissionId).Contains(x.Id));

            var contestSubmissions = await query.Include(x => x.ContestSubmissionMedia).ThenInclude(y => y.MediaFile).ThenInclude(z => z.FileType)
                                                .Include(x => x.Talent)
                                                .Include(x => x.ContestResult)
                                                .ApplySorting(searchParams.SortOn, searchParams.SortOrder)
                                                .ApplyPaging(searchParams.PageIndex, searchParams.PageSize)
                                                .ToListAsync();

            var recordCount = query.Count();
            var previousPageIndex = searchParams.PageIndex - 1;
            var nextPageIndex = ((recordCount - (searchParams.PageSize * searchParams.PageIndex)) > searchParams.PageSize) ? (searchParams.PageIndex + 1) : 0;

            return new SearchResult<ContestSubmission>
            {
                Results = contestSubmissions,
                TotalResults = recordCount,
                Previous = previousPageIndex,
                Next = nextPageIndex
            };
        }
    }
}
