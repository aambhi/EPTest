﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class SocialLinkRepository:GenericRepository<SocialLink>, ISocialLinkRepository
    {
        public SocialLinkRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
