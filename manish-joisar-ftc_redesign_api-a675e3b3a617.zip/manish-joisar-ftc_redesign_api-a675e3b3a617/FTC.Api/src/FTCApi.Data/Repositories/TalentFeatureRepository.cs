﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class TalentFeatureRepository:GenericRepository<TalentFeature>, ITalentFeatureRepository
    {
        public TalentFeatureRepository(FTCDbContext context):base(context)
        {

        }
    }
}
