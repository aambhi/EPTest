﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserTokenRepository:GenericRepository<AuxiliaryUserToken>, IAuxiliaryUserTokenRepository
    {
        public AuxiliaryUserTokenRepository(FTCDbContext context):base(context)
        {

        }
    }
}
