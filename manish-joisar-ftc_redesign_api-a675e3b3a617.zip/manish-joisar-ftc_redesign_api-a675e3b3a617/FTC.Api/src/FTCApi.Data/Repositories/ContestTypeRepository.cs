﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ContestTypeRepository:GenericRepository<ContestType>, IContestTypeRepository
    {
        public ContestTypeRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
