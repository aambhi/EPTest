﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class ParamRepository:GenericRepository<Param>, IParamRepository
    {
        public ParamRepository(FTCDbContext context):base(context)
        {

        }

        public async Task<Param> GetUserSettings()
        {
            var userSettings = await this.GetAllAsync();

            Param userSetting = new Param();

            if(userSettings!=null && userSettings.Count() >0)
            {
                userSetting = userSettings.FirstOrDefault();
            }

            return userSetting;
        }

    }
}
