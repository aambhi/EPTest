﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryUserAssignedRepository : GenericRepository<AuxiliaryUserAssigned>, IAuxiliaryUserAssignedRepository
    {
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        public AuxiliaryUserAssignedRepository(FTCDbContext context, IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository) : base(context)
        {
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
        }

        public async Task<List<int?>> GetAssignedRecruiters(int userId, bool? checkRole = false)
        {
            //get recruiters,
            var allAssignedProjectsAndJobs = await this.FindAllAsync(x => x.AuxiliaryUserId == userId && x.AssignedAuxiliaryUserId != null);

            //assigned recruiter
            var assignedRecruiters = allAssignedProjectsAndJobs.Select(x => x.AssignedAuxiliaryUserId).Distinct().ToList();

        
            return assignedRecruiters;
        }

    public async Task<Dictionary<int?, bool>> GetAssignedProjects(int loggedInUserId, int? selectedUserId = 0, bool? checkRole = false)
    {
        var assignedProjects = new Dictionary<int?, bool>();

        IEnumerable<AuxiliaryUserAssigned> allAssignedProjectsAndJobs = default(IEnumerable<AuxiliaryUserAssigned>);
        if (selectedUserId > 0)
        {
            //get projectIds 
            allAssignedProjectsAndJobs = await this.FindAllAsync(x => x.AuxiliaryUserId == loggedInUserId
                                                                        && x.AssignedAuxiliaryUserId == selectedUserId
                                                                        && x.ProjectId != null);
        }
        else
        {
            //get projectIds 
            allAssignedProjectsAndJobs = await this.FindAllAsync(x => x.AuxiliaryUserId == loggedInUserId && x.ProjectId != null);
        }

        //assigned projects
        assignedProjects = allAssignedProjectsAndJobs.Distinct().ToDictionary(x => x.ProjectId, x => x.JobId == null ? true : false);

        return assignedProjects;
    }

    public async Task<Dictionary<int?, bool>> GetAssignedProjectsForJobAmin(int loggedInUserId)
    {
        IEnumerable<AuxiliaryUserAssigned> allAssignedProjectsAndJobs = default(IEnumerable<AuxiliaryUserAssigned>);

        //get projectIds 
        allAssignedProjectsAndJobs = await this.FindAllAsync(x => x.AuxiliaryUserId == loggedInUserId && x.ProjectId != null);


        //assigned projects
        var assignedProjects = allAssignedProjectsAndJobs.Select(x => x.ProjectId).Distinct().ToDictionary(x => x, x => false);

        return assignedProjects;
    }

    public async Task<List<int?>> GetAssignedJobs(int userId, bool? checkRole = false)
    {
        var assignedJobs = new List<int?>();

        if ((bool)checkRole)
        {
            if (await _auxiliaryUserRoleRepository.CheckAssignedInRole(userId))
            {
                //get Job IDs
                var allAssignedProjectsAndJobs = await this.FindAllAsync(x => x.AuxiliaryUserId == userId && x.JobId != null);
                //assigned jobs
                assignedJobs = allAssignedProjectsAndJobs.Select(x => x.JobId).Distinct().ToList();
            }

        }
        else
        {
            //get Job IDs
            var allAssignedProjectsAndJobs = await this.FindAllAsync(x => x.AuxiliaryUserId == userId && x.JobId != null);
            //assigned jobs
            assignedJobs = allAssignedProjectsAndJobs.Select(x => x.JobId).Distinct().ToList();

        }

        return assignedJobs;
    }
}


}
