﻿using System;
using System.Threading.Tasks;
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace FTCApi.Data.Repositories
{
    public class ProjectHistoryRepository : GenericRepository<ProjectHistory>,IProjectHistoryRepository
    {
        public ProjectHistoryRepository(FTCDbContext context) : base(context)
        {

        }

        public int getTotalRenewedMonths(int projectId)
        {

            //get all history details from the history table to get all the previous plans
            IQueryable<ProjectHistory> query = _context.Set<ProjectHistory>();
            var totalPreviousMonths = query.Where(x => x.ProjectId == projectId)
                                            .Include(x => x.Plan)
                                            .Select(x => x.Plan.ProjectValidity).Sum(x=>x);

            return (int)totalPreviousMonths;
        }

        
    }

}
