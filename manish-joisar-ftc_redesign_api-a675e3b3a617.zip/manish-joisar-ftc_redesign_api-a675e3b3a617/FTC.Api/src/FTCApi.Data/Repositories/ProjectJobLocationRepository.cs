﻿
using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class ProjectJobLocationRepository : GenericRepository<ProjectJobLocation> , IProjectJobLocationRepository
    {
        public ProjectJobLocationRepository(FTCDbContext context):base(context)
        {

        }
    }
}