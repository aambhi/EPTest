﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class StatusRepository:GenericRepository<Status>,IStatusRepository
    {
        public StatusRepository(FTCDbContext context):base(context)
        {

        }
    }
}
