﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class AuxiliaryRecruiterRepository : GenericRepository<AuxiliaryRecruiter>, IAuxiliaryRecruiterRepository
    {
        public AuxiliaryRecruiterRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
