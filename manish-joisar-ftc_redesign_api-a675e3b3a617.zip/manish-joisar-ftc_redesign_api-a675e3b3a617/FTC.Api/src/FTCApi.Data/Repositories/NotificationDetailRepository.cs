﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class NotificationDetailRepository:GenericRepository<NotificationDetail>, INotificationDetailRepository
    {
        public NotificationDetailRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
