﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;

namespace FTCApi.Data.Repositories
{
    public class SecurityQuestionRepository: GenericRepository<SecurityQuestion>,ISecurityQuestionRepository
    {
        public SecurityQuestionRepository(FTCDbContext context):base(context)
        {

        }
        
    }
}
