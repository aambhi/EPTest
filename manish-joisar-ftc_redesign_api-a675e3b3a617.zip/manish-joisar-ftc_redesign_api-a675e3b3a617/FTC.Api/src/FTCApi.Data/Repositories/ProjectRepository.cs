﻿using FTCApi.Core.Models;
using FTCApi.Core.RepositoryInterface;
using FTCApi.Dtos;
using FTCApi.Dtos.Enum;
using FTCApi.Dtos.Projects;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using static FTCApi.Dtos.LoginEnum;

namespace FTCApi.Data.Repositories
{
    public class ProjectRepository : GenericRepository<Project>, IProjectRepository
    {
        private IAuxiliaryUserAssignedRepository _auxiliaryUserAssignedRepository;
        private IAuxiliaryUserRoleRepository _auxiliaryUserRoleRepository;
        private IRecruiterPlanRepository _recruiterPlanRepository;
        public ProjectRepository(FTCDbContext context,
                                IAuxiliaryUserAssignedRepository auxiliaryUserAssignedRepository,
                                IAuxiliaryUserRoleRepository auxiliaryUserRoleRepository,
                                IRecruiterPlanRepository recruiterPlanRepository) : base(context)
        {
            _auxiliaryUserAssignedRepository = auxiliaryUserAssignedRepository;
            _auxiliaryUserRoleRepository = auxiliaryUserRoleRepository;
            _recruiterPlanRepository = recruiterPlanRepository;
        }

        public override async Task<Project> FindAsync(Expression<Func<Project, bool>> match)
        {
            return await _context.Set<Project>()
                .Include(x => x.Plan).SingleOrDefaultAsync(match);
        }

        public async Task<List<Project>> GetAllProjects()
        {
            return await _context.Set<Project>()
                .Include(x => x.AuxiliaryUser).ToListAsync();
        }

        // not used because causing an error : an operation  is already in use in recruiter plan
        public async Task<ManageProjectDto> ManageProject(RequestManageProjectDto manageProjectParam, int recruiterId)
        {
            var userId = manageProjectParam.RecruiterId > 0 ? manageProjectParam.RecruiterId : recruiterId;
            //TODO: update if according to ithe implementation in Project controller
            var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userId);

            IQueryable<Project> query = _context.Set<Project>();
            IQueryable<ProjectJob> projectJobsQuery = _context.Set<ProjectJob>().Include(pj => pj.Project);

            query = query.Where(x => x.AuxiliaryUserId == userId || assignedProjects.ContainsKey(x.Id));

            #region Search: Project or Job & return  a list of Project
            // on search only show list of projects , no jobs
            if (!string.IsNullOrEmpty(manageProjectParam.Search))
            {
                var searchKeyword = manageProjectParam.Search.ToLower();
                // if false => search both project and job
                if (manageProjectParam.IncludeJobsInSearch)
                {
                    // to search by job from the list of projects of the recruiter
                    var projectSearchQuery = query.Where(x => x.Name.Contains(manageProjectParam.Search))
                                                    .Select(p => p.Id);

                    var jobSearchQuery = projectJobsQuery.Where(pj => pj.Title.Contains(manageProjectParam.Search))
                                                        .Select(pj => pj.ProjectId);

                    var searchResults = projectSearchQuery.Union(jobSearchQuery);
                    query = query.Where(p => searchResults.Contains(p.Id));

                }
                else
                {
                    query = query.Where(x => x.Name.ToLower().Contains(searchKeyword));
                }

            }
            #endregion

            #region Status [all, verified and not verified & Paid] FILTER
            if (manageProjectParam.ProjectStatus != ProjectStatusEnum.All)
            {
                // verified projects
                if (manageProjectParam.ProjectStatus == ProjectStatusEnum.Verified)
                {
                    query = query.Where(p => p.StatusId == (int)StatusEnum.Verified);

                }
                else if (manageProjectParam.ProjectStatus == ProjectStatusEnum.Paid)
                {
                    query = query.Where(p => p.StatusId == (int)StatusEnum.Active);
                }
                // not verified projects
                else
                {
                    query = query.Where(p => p.StatusId == (int)StatusEnum.Draft);
                }
            }
            #endregion

            #region pagination of project & Order by CreatedOn
            int projectStartIndex = (manageProjectParam.ProjectCurrentPage > 0) ? ((manageProjectParam.ProjectCurrentPage) * manageProjectParam.ProjectPerPageRecords + 1) : manageProjectParam.ProjectCurrentPage;
            int projectEndIndex = (manageProjectParam.ProjectCurrentPage > 0) ? (projectStartIndex + manageProjectParam.ProjectPerPageRecords) : manageProjectParam.ProjectPerPageRecords;

            var projectCount = query.Count();
            // order by created on
            var lstProject = query.OrderByDescending(x => x.CreatedOn)
                                    .Skip(projectStartIndex - 1)
                                    .Take(projectEndIndex - projectStartIndex);
            #endregion

            #region Job results for the specifed projectId & If not present ..get jobs for the first project in the list

            // query.First() != null added to avoid Null exception with query.First().Id : CHECK Behavior
            int projectJobCount = 0;
            var listOfProjectJob = new List<ProjectJob>();
            if (string.IsNullOrEmpty(manageProjectParam.Search) && projectCount > 0)
            {
                //TODO: Similar to Projeect Controller
                var assignedProjectJobs = await _auxiliaryUserAssignedRepository.GetAssignedJobs(userId);

                //var projectJobs = await _projectJobRepository.FindAllAsync(x => x.ProjectId == lstProject.First().Id 
                //                                    || assignedProjectJobs.Contains(x.Id));

                projectJobsQuery = projectJobsQuery.Where(x => x.ProjectId == lstProject.First().Id
                                                    || assignedProjectJobs.Contains(x.Id));

                #region pagination of project Jobs & Order by Name
                int projectJobStartIndex = (manageProjectParam.ProjectJobCurrentPage > 0) ? ((manageProjectParam.ProjectJobCurrentPage) * manageProjectParam.ProjectJobPerPageRecords + 1) : manageProjectParam.ProjectJobCurrentPage;
                int projectJobEndIndex = (manageProjectParam.ProjectJobCurrentPage > 0) ? (projectJobStartIndex + manageProjectParam.ProjectJobPerPageRecords) : manageProjectParam.ProjectJobPerPageRecords;

                projectJobCount = projectJobsQuery.Count();
                // order by created on
                listOfProjectJob = projectJobsQuery.OrderByDescending(x => x.Title)
                                                    .Skip(projectJobStartIndex - 1)
                                                    .Take(projectJobEndIndex - projectJobStartIndex).ToList();
                #endregion

            }


            #endregion                       

            #region Response Dto

            var firstProjectId = projectCount > 0 ? lstProject.First().Id : 0;

            var manageProject = new ManageProjectDto();
            foreach (var project in lstProject)
            {
                ProjectSummaryDto projectSummaryDto = await ConvertToProjectSummaryDto(project, manageProjectParam.ProjectId, firstProjectId, listOfProjectJob, projectJobCount, assignedProjects);
                manageProject.Projects.Add(projectSummaryDto);
            }
            manageProject.ProjectCount = projectCount;
            #endregion

            return manageProject;
        }


        public async Task<ProjectSummaryDto> ConvertToProjectSummaryDto(Project project, int projectId, int firstProjectId, List<ProjectJob> listOfProjectJob, int projectJobCount, Dictionary<int?, bool> assignedProjects)
        {
            var projectSummaryDto = new ProjectSummaryDto();
            projectSummaryDto.ProjectId = project.Id;
            projectSummaryDto.ProjectName = project.Name;
            projectSummaryDto.StartDate = project.StartDate;
            projectSummaryDto.EndDate = project.EndDate;
            projectSummaryDto.CreatedOn = project.CreatedOn;
            projectSummaryDto.StatusId = project.StatusId;
            var assignedProject = assignedProjects.Where(x => x.Key == project.Id);
            // if the project id is not present in the assigned projects list.. give a default
            if (assignedProject.Any())
            {
                projectSummaryDto.IsProjectAdmin = assignedProject.FirstOrDefault().Value;
            }

            if ((project.Id == projectId) || ((projectId == 0) && (project.Id == firstProjectId)))
            {
                var projectJobPlanDto = new ProjectJobPlanDto();
                projectJobPlanDto.ProjectPlanConsumed = 0;

                foreach (var projectJob in listOfProjectJob)
                {
                    // calc no of roles used throughout the project for all jobs & add them
                    projectJobPlanDto.ProjectPlanConsumed += (int)((projectJob.NumberOfRole != null) ? projectJob.NumberOfRole : 0);

                    ProjectJobSummaryDto projectJobDto = ConvertToProjectJobSummaryDto(projectJob);
                    projectSummaryDto.ProjectJobSummaryData.ProjectJobs.Add(projectJobDto);
                    projectSummaryDto.ProjectJobSummaryData.ProjectJobsCount = projectJobCount;

                }

                #region Project Plan                
                if (project.PlanId != null)
                {
                    //var recruiterPlan = _context.Set<RecruiterPlan>().FirstOrDefault(x => x.Id == project.PlanId);
                    var recruiterPlan = await _recruiterPlanRepository.FindAsync(x => x.Id == project.PlanId);
                    projectJobPlanDto.ProjectPlan = (short)recruiterPlan.RoleCount;
                    projectJobPlanDto.ProjectPlanId = (int)project.PlanId;
                    projectJobPlanDto.ProjectPlanAvailable = projectJobPlanDto.ProjectPlan - projectJobPlanDto.ProjectPlanConsumed;
                }
                #endregion

                projectSummaryDto.ProjectJobSummaryData.ProjectPlan = projectJobPlanDto;
            }
            return projectSummaryDto;
        }


        public ProjectJobSummaryDto ConvertToProjectJobSummaryDto(ProjectJob projectJob)
        {
            var projectJobDto = new ProjectJobSummaryDto();
            projectJobDto.Id = projectJob.Id;
            projectJobDto.Title = projectJob.Title;
            projectJobDto.Description = projectJob.Description;
            projectJobDto.IsFeaturedJob = projectJob.IsFeaturedJob;
            projectJobDto.isJobPublished = projectJob.StatusId == (int)StatusEnum.Active ? true : false;
            projectJobDto.StatusId = (StatusEnum)projectJob.StatusId;
            return projectJobDto;
        }

        public async Task<dynamic> GetProjectByRecruiterId(int recruiterId, string projectName, int userId, int userType)
        {
            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);
            
            IQueryable<Project> query = _context.Set<Project>();

            query = query.Where(x => ((x.StatusId ?? 0) == (int)StatusEnum.Active
                                           || (x.StatusId ?? 0) == (int)StatusEnum.Verified)
                                           && x.AuxiliaryUserId == recruiterId);

            if (isFtcProjectAdmin)
            {
                // only projects which are assigned of recruiterId
                var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userId);
                query = query.Where(x => assignedProjects.ContainsKey(x.Id));
            }
            
            // For All users other than FTC PA
            if (!string.IsNullOrEmpty(projectName))
            {
                query = query.Where(x => x.Name.ToLower().Contains(projectName.ToLower()));
            }
            
            var projects = query.Select(x => new { x.Id, Description = x.Name }).OrderBy(x => x.Description).Take(20).ToList();
            
            return projects;
        }

        public async Task<dynamic> SearchProjects(string projectName, int userId, int userType)
        {
            bool isProjectAdmin, isJobAdmin, isFtcProjectAdmin, isFtcRecruiterAdmin;
            var userRole = await _auxiliaryUserRoleRepository.FindAllAsync(c => c.AuxiliaryUserId == userId);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isProjectAdmin, out isJobAdmin, out isFtcProjectAdmin);
            _auxiliaryUserRoleRepository.CheckUserRole(userRole, out isFtcRecruiterAdmin);

            IQueryable<Project> query = _context.Set<Project>();

            
            query = query.Where(x =>(x.StatusId ?? 0) == (int)StatusEnum.Active 
                                    || (x.StatusId ?? 0) == (int)StatusEnum.Verified);


            if (isFtcRecruiterAdmin)
            {
                // get assigned recruiters & of those recruiters get all projects
                var assignedRecruiters = await _auxiliaryUserAssignedRepository.GetAssignedRecruiters(userId);
                query = query.Where(p => assignedRecruiters.Contains(p.AuxiliaryUserId));
            }
            else if (isFtcProjectAdmin || isProjectAdmin || isJobAdmin)
            {
                var assignedProjects = await _auxiliaryUserAssignedRepository.GetAssignedProjects(userId);

                query = query.Where(x => x.AuxiliaryUserId == userId || assignedProjects.ContainsKey(x.Id));        
            }
            else if (userType == (int)LoginUserType.Recruiter)
            {
                query = query.Where(x => x.AuxiliaryUserId == userId);
            }


            if (!string.IsNullOrEmpty(projectName))
            {
                query = query.Where(x => x.Name.ToLower().Contains(projectName.ToLower()));
            }

            var projects = query.Select(x => new { x.Id, Description = x.Name }).OrderBy(x => x.Description).Take(20).ToList();

            return projects;
        }

    }
}
