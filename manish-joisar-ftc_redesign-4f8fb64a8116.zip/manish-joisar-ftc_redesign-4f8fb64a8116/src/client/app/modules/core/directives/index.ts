// app
import { PlatformDirective } from './platform.directive';

export const CORE_DIRECTIVES: any[] = [
  PlatformDirective
];

export * from './platform.directive';
