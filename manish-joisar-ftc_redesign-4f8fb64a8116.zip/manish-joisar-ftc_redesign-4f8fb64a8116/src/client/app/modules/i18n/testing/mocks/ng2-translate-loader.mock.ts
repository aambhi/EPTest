export class TranslateLoaderMock {
  
}
