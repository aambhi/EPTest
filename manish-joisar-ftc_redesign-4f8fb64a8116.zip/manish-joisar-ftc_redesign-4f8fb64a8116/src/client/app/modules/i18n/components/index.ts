import { LangSwitcherComponent } from './lang-switcher.component';

export const MULTILANG_COMPONENTS: any[] = [
  LangSwitcherComponent
];

export * from './lang-switcher.component';
