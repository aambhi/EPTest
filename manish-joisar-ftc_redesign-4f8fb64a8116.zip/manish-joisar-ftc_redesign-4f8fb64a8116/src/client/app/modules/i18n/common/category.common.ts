export const CATEGORY: string = 'Multilingual';
