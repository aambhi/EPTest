import { Action } from '@ngrx/store';
import { type } from '../../core/utils/index';
import { IGroupState,IGroupDetails } from '../states/index';

/**
 * Each action should be namespaced
 * this allows the interior to have similar typed names as other actions
 * however still allow index exports
 */
export namespace Group {
    // Category to uniquely identify the actions
    export const CATEGORY: string = 'Group';


    /**
     * For each action type in an action group, make a simple
     * enum object for all of this group's action types.
     *
     * The 'type' utility function coerces strings into string
     * literal types and runs a simple check to guarantee all
     * action types in the application are unique.
     */
    export interface IGroupActions {
        LOAD_GROUP: string;
        LOAD_SUCCESSFUL: string;
        LOAD_FAILED: string;
        SEARCH_GROUP: string;
        SEARCH_SUCCESSFUL: string;
        SEARCH_FAILED: string;
        SELECT_GROUP: string;
        SELECT_SUCCESSFUL: string;
        SELECT_FAILED: string;
        UPDATE_GROUP: string;
        UPDATE_SUCCESSFUL: string;
        UPDATE_FAILED: string;
        ADD_GROUP: string;
        ADD_SUCCESSFUL: string;
        ADD_FAILED: string;
       

    }

    export const ActionTypes: IGroupActions = {
        LOAD_GROUP: type(`${CATEGORY} Load`),
        LOAD_SUCCESSFUL: type(`${CATEGORY} Load Successful`),
        LOAD_FAILED: type(`${CATEGORY} Load Failed`),
        SEARCH_GROUP: type(`${CATEGORY} Search`),
        SEARCH_SUCCESSFUL: type(`${CATEGORY} Search Successful`),
        SEARCH_FAILED: type(`${CATEGORY} Search Failed`),
        SELECT_GROUP: type(`${CATEGORY} Select`),
        SELECT_SUCCESSFUL: type(`${CATEGORY} Select Successful`),
        SELECT_FAILED: type(`${CATEGORY} Select Failed`),
        UPDATE_GROUP: type(`${CATEGORY} UPDATE`),
        UPDATE_SUCCESSFUL: type(`${CATEGORY} UPDATE Successful`),
        UPDATE_FAILED: type(`${CATEGORY} UPDATE Failed`),
        ADD_GROUP: type(`${CATEGORY} Add`),
        ADD_SUCCESSFUL: type(`${CATEGORY} Add Successful`),
        ADD_FAILED: type(`${CATEGORY} Add Failed`)       
    };

    /**
     * Every action is comprised of at least a type and an optional
     * payload. Expressing actions as classes enables powerful
     * type checking in reducer functions.
     *
     * See Discriminated Unions: https://www.typescriptlang.org/docs/handbook/advanced-types.html#discriminated-unions
     */


    export class LoadGroupAction implements Action {
        type = ActionTypes.LOAD_GROUP;
        payload: string = null;
    }

    export class LoadSuccessfulAction implements Action {
        type = ActionTypes.LOAD_SUCCESSFUL;

        constructor(public payload: IGroupState) {

        }
    }

    export class LoadFailedAction implements Action {
        type = ActionTypes.LOAD_FAILED;
        payload: string = null;
    }

    export class SearchGroupAction implements Action {
        type = ActionTypes.SEARCH_GROUP;
        constructor(public payload: string) {
        }
    }

    export class SearchGroupSuccessfulAction implements Action {
        type = ActionTypes.LOAD_SUCCESSFUL;

        constructor(public payload: IGroupState) {
        }
    }

    export class SearchGroupFailedAction implements Action {
        type = ActionTypes.SEARCH_FAILED;
        payload: string = null;
    }


    export class SelectGroupAction implements Action {
        type = ActionTypes.SELECT_GROUP;
        constructor(public payload: string) { }
    }

    export class SelectGroupSuccessfulAction implements Action {
        type = ActionTypes.SELECT_SUCCESSFUL;

        constructor(public payload: IGroupDetails) {
        }
    }

    export class SelectGroupFailedAction implements Action {
        type = ActionTypes.SELECT_FAILED;
        payload: string = null;
    }

    export class UpdateGroupAction implements Action {
        type = ActionTypes.UPDATE_GROUP;
        constructor(public payload: IGroupState) { }
    }

    export class UpdateGroupSuccessfulAction implements Action {
        type = ActionTypes.UPDATE_SUCCESSFUL;

        constructor(public payload: IGroupState) { }
    }

    export class UpdateGroupFailedAction implements Action {
        type = ActionTypes.UPDATE_FAILED;
        payload: string = null;
    }

    export class AddGroupAction implements Action {
        type = ActionTypes.ADD_GROUP;
        constructor(public payload: any) { }
    }

    export class AddGroupSuccessfulAction implements Action {
        type = ActionTypes.ADD_SUCCESSFUL;

        constructor(public payload: any) { }
    }

    export class AddGroupFailedAction implements Action {
        type = ActionTypes.ADD_FAILED;
        payload: string = null;
    }

   
    /**
     * Export a type alias of all actions in this action group
     * so that reducers can easily compose action types
     */
    export type Actions
        = LoadGroupAction
        | LoadSuccessfulAction
        | LoadFailedAction
        | SearchGroupAction
        | SearchGroupSuccessfulAction
        | SearchGroupFailedAction
        | SelectGroupAction
        | SelectGroupSuccessfulAction
        | SelectGroupFailedAction
        | UpdateGroupAction
        | UpdateGroupSuccessfulAction
        | UpdateGroupFailedAction
        | AddGroupAction
        | AddGroupSuccessfulAction
        | AddGroupFailedAction;
}
