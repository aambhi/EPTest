// angular
import { Injectable, Inject, ComponentRef, Compiler } from '@angular/core';
import { Router } from '@angular/router';

// libs
import { Store, Action } from '@ngrx/store';
import { Effect, Actions, toPayload } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';

// module
import { GroupService } from '../services/group.service';
import { Group } from '../actions/index';
import { ToasterService } from 'angular2-toaster';


@Injectable()
export class GroupEffects {

  @Effect() init$: Observable<Action> = this.actions$
    .ofType(Group.ActionTypes.LOAD_GROUP)
    .debounceTime(300)
    .switchMap(() => this.groupService.myGroup())
    .map(payload => {
      return new Group.LoadSuccessfulAction(payload);
    })
    // nothing reacting to failure at moment but you could if you want (here for example)
    .catch(() => Observable.of(new Group.LoadFailedAction()));



  @Effect()
  search$: Observable<Action> = this.actions$
    .ofType(Group.ActionTypes.SEARCH_GROUP)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(query => {
      return this.groupService.searchGroup(query)
        .map(payload => {
          return new Group.SearchGroupSuccessfulAction(payload);
        })
        .catch(() => Observable.of(new Group.SearchGroupFailedAction()));
    });

  @Effect()
  select$: Observable<Action> = this.actions$
    .ofType(Group.ActionTypes.SELECT_GROUP)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(query => {
      return this.groupService.selectGroup(query)
        .map(payload => {
          return new Group.SelectGroupSuccessfulAction(payload);
        })
        .catch(() => Observable.of(new Group.SelectGroupFailedAction()));
    });

  @Effect()
  add$: Observable<Action> = this.actions$
    .ofType(Group.ActionTypes.ADD_GROUP)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(param => {
      return this.groupService.addGroup(param)
        .map(payload => {
          return new Group.AddGroupSuccessfulAction(payload);
        }).do((payload: any) => {
           this.toasterService.pop('success', 'Group', 'added successfully.');
          let url = this._router.url;
          url = url.replace('left:new-group', 'left:group');
          this._router.navigateByUrl(url);

        })
        .catch(() => Observable.of(new Group.AddGroupFailedAction()));
    });

  @Effect()
  edit$: Observable<Action> = this.actions$
    .ofType(Group.ActionTypes.UPDATE_GROUP)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(query => {
      return this.groupService.updateGroup(query)
        .map(payload => {
          return new Group.UpdateGroupSuccessfulAction(payload);
        }).do((payload: any) => {
          this.toasterService.pop('success', 'Group', 'Updated successfully.');
          this._router.navigateByUrl('home/(left:group//main:group-timeline)');

        }) .catch((e) => {
          this.toasterService.pop('error', 'Group', 'Group update Failed.');
          return Observable.of(new Group.UpdateGroupFailedAction());
        });

    });


  private toasterService: ToasterService;

  constructor(
    private store: Store<any>,
    private actions$: Actions,
    private groupService: GroupService,
    private _router: Router,
    toasterService: ToasterService) {
    this.toasterService = toasterService;
  }
}
