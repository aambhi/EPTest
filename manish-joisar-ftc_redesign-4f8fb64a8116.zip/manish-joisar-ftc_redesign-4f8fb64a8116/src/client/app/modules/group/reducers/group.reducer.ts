import { IGroupState, groupInitialState } from '../states/index';
import { Group } from '../actions/index';

export function GroupReducer(
  state: IGroupState = groupInitialState,
  // could support multiple state actions via union type here
  action: Group.Actions //| Profile
): IGroupState {
  switch (action.type) {
    case Group.ActionTypes.LOAD_SUCCESSFUL:
      return (<any>Object).assign({}, state, action.payload);
    case Group.ActionTypes.SEARCH_SUCCESSFUL:
      return (<any>Object).assign({}, state, action.payload);
    case Group.ActionTypes.SELECT_SUCCESSFUL:
      return (<any>Object).assign({}, state, action.payload);
    case Group.ActionTypes.ADD_SUCCESSFUL:
      return (<any>Object).assign({}, state, { showmessage: true });
   
    default:
      return state;
  }
}
