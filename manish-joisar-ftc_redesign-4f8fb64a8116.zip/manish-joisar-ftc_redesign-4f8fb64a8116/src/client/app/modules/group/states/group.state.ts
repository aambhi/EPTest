import { Observable } from 'rxjs/Observable';

export interface IGroupDetails {
    id: number;
    name: string;
    bio: string;
    address: string;
    phone_number: string;
    privacy: number;
    email_address: string;
    url: string;
    twitter_url: string;
    facebook_url: string;
    ability_split_enabled: boolean;
    ability_split_default: string;
    ability_split_additional: string;
    profile_image: string;
    members_count: number;
    admins: any[];
    created_at: string;
    created_by: {
        id: number;
        first_name: string;
        last_name: string;
        username: string;
        bio: string;
        profile_image: string;
        created_at: string;
    };
}

export interface UserDetails {
    id: number;
    first_name: string;
    last_name: string;
    username: string;
    bio: string;
    profile_image: string;
    created_at: string;
}

export interface IGroupState {
    groups: Array<IGroupDetails>;
    users: Array<UserDetails>;
    selectedGroup:IGroupDetails;
}

export const groupInitialState: IGroupState = null;


