import { GroupService } from './group.service';

export const GROUP_PROVIDERS: any[] = [
  GroupService
];

export * from './group.service';
