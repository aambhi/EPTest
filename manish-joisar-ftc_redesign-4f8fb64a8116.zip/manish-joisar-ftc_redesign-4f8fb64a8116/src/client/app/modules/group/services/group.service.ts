// angular
import { Injectable } from '@angular/core';

// libs
import { Observable } from 'rxjs/Observable';

// app
import { Config } from '../../core/index';
import { Analytics, AnalyticsService } from '../../analytics/index';
import { FtcService } from '../../shared/provider/secure-http.service';

// module
import { Group } from '../actions/index';
import { IGroupState, groupInitialState } from '../states/index';

@Injectable()
export class GroupService extends Analytics {

    constructor(
        public analytics: AnalyticsService,
        private http: FtcService
    ) {
        super(analytics);
        this.category = Group.CATEGORY;
    }

    myGroup(): Observable<any> {
        return this.http.get({}, 'users/me/groups/')
            .map(res => {
                let groupInfo = {
                    groups: res,
                    users: []
                };

                return groupInfo;
            })
            .catch(this.handleError.bind(this));
    }

    searchGroup(query: any): Observable<any> {

        return this.http.get({}, 'groups/search/?query=' + query)
            .map(res => {
                let groupInfo = {
                    groups: res.groups,
                    users: res.users
                };
                return groupInfo;
            })
            .catch(this.handleError.bind(this));
    }

    selectGroup(query: any): Observable<any> {

        return this.http.get({}, 'groups/' + query + '/')
            .map(res => {
                return {
                    selectedGroup: res
                };
            })
            .catch(this.handleError.bind(this));

    }

    addGroup(group: any): Observable<any> {
        return this.http.post(group, 'groups/')
            .map(res => {   
                return res;
            })
            .catch(this.handleError.bind(this));

    }

    updateGroup(group: any): Observable<any> {
        return this.http.patch(group, 'groups/'+ group.id +'/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));

    }
    
    private handleError(error: any): Observable<any> {
        return Observable.throw(error.message || error);
    }
}
