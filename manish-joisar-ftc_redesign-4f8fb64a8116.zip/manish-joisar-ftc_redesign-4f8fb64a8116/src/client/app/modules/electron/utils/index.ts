export * from './desktop-config';
