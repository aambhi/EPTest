import { IProfileState, profileInitialState } from '../states/index';
import { Profile } from '../actions/index';

export function myProfileReducer(
  state: IProfileState = profileInitialState,
  // could support multiple state actions via union type here
  // ie: Profile.Actions | Other.Actions
  action: Profile.Actions
): IProfileState {
  switch (action.type) {
    case Profile.ActionTypes.LOAD_SUCCESSFUL:
          return (<any>Object).assign({}, state, action.payload);
    case Profile.ActionTypes.EDIT_SUCCESSFUL:   
      return (<any>Object).assign({}, state, action.payload);

    case Profile.ActionTypes.LOAD_PROFILE_CALENDER_SUCCESSFUL:   
      return (<any>Object).assign({}, state, action.payload);

    default:
      return state;
  }
}
