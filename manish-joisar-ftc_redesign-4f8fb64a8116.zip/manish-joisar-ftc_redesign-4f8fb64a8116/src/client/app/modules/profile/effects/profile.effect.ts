// angular
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
// libs
import { Store, Action } from '@ngrx/store';
import { Effect, Actions, toPayload } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';

// module
import { ProfileService } from '../services/profile.service';
import { Profile } from '../actions/index';
import { ToasterService } from 'angular2-toaster';

@Injectable()
export class ProfileEffects {

  @Effect() init$: Observable<Action> = this.actions$
    .ofType(Profile.ActionTypes.LOAD_MY_PROFILE)
    .switchMap(() => this.profileService.getMyProfile())
    .map(payload => {
      return new Profile.LoadSuccessfulAction(payload.user);
    })
    // nothing reacting to failure at moment but you could if you want (here for example)
    .catch(() => Observable.of(new Profile.LoadFailedAction()));

  @Effect()
  edit$: Observable<Action> = this.actions$
    .ofType(Profile.ActionTypes.EDIT)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(query => {
      return this.profileService.updateMyProfile(query)
        .map(payload => {
          return new Profile.EditSuccessfulAction(payload);
        }).do((payload: any) => {
          this.toasterService.pop('success', 'Profile', 'Updated successfully.');
          this._router.navigateByUrl('home/(left:my-profile//main:profile-timeline)');

        }).catch((e) => {
          this.toasterService.pop('error', 'Profile', '“Username already exist. Select other username.”');
          return Observable.of(new Profile.EditFailedAction());
        });

    });

  @Effect()
  changePassword$: Observable<Action> = this.actions$
    .ofType(Profile.ActionTypes.CHANGE_PASSWORD)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(query => {
      return this.profileService.changePassword(query)
        .map(payload => {
          return new Profile.ChangePasswordSuccessfulAction(payload);
        }).do((payload: any) => {
          this.toasterService.pop('success', 'Password', 'Changed successfully.');
          this._router.navigateByUrl('home/(left:my-profile//main:profile-timeline)');
        })
        .catch((e) => {
          this.toasterService.pop('error', 'Password', '“Your current password is not correct”');
          return Observable.of(new Profile.ChangePasswordFailedAction());
        });

    });

  @Effect()
  profileCalender$: Observable<Action> = this.actions$
    .ofType(Profile.ActionTypes.LOAD_PROFILE_CALENDER)
    .debounceTime(300)
    .map(toPayload)
    .switchMap(param => {
      return this.profileService.profileCalender(param)
        .map(payload => {
          let profileCalendar = {
            calendarWorkOuts: payload
          };
          return new Profile.LoadProfileCalenderSuccessfulAction(profileCalendar);
        })
        .catch(() => Observable.of(new Profile.LoadProfileCalenderFailedAction()));
    });

  private toasterService: ToasterService;
  constructor(
    private store: Store<any>,
    private actions$: Actions,
    private profileService: ProfileService,
    private _router: Router,
    toasterService: ToasterService) {
    this.toasterService = toasterService;
  }
}
