import { Action } from '@ngrx/store';
import { type } from '../../core/utils/index';
import { IProfileState } from '../states/index';

/**
 * Each action should be namespaced
 * this allows the interior to have similar typed names as other actions
 * however still allow index exports
 */
export namespace Profile {
    // Category to uniquely identify the actions
    export const CATEGORY: string = 'Profile';

    /**
     * For each action type in an action group, make a simple
     * enum object for all of this group's action types.
     *
     * The 'type' utility function coerces strings into string
     * literal types and runs a simple check to guarantee all
     * action types in the application are unique.
     */
    export interface IProfileActions {
        LOAD_MY_PROFILE: string;
        LOAD_PROFILE: string;
        LOAD_SUCCESSFUL: string;
        LOAD_FAILED: string;
        EDIT: string;
        EDIT_SUCCESSFUL: string;
        EDIT_FAILED: string;

        CHANGE_PASSWORD: string;
        CHANGE_SUCCESSFUL: string;
        CHANGE_FAILED: string;

        LOAD_PROFILE_CALENDER: string;
        LOAD_PROFILE_CALENDER_SUCCESSFUL: string;
        LOAD_PROFILE_CALENDER_FAILED: string;

    }

    export const ActionTypes: IProfileActions = {
        LOAD_MY_PROFILE: type(`${CATEGORY} My Profile Load`),
        LOAD_PROFILE: type(`${CATEGORY} Load`),
        LOAD_SUCCESSFUL: type(`${CATEGORY} Load Successful`),
        LOAD_FAILED: type(`${CATEGORY} Load Failed`),
        EDIT: type(`${CATEGORY} Edit`),
        EDIT_SUCCESSFUL: type(`${CATEGORY} Edit Successful`),
        EDIT_FAILED: type(`${CATEGORY} Edit Failed`),

        CHANGE_PASSWORD: type(`${CATEGORY} Change`),
        CHANGE_SUCCESSFUL: type(`${CATEGORY} Change Password Successfully`),
        CHANGE_FAILED: type(`${CATEGORY} Change Password Failed`),

        LOAD_PROFILE_CALENDER: type(`${CATEGORY} Profile Calender Load`),
        LOAD_PROFILE_CALENDER_SUCCESSFUL: type(`${CATEGORY} Profile Calender Load Successfull`),
        LOAD_PROFILE_CALENDER_FAILED: type(`${CATEGORY} Profile Calender Load Failed`),

        };

    /**
     * Every action is comprised of at least a type and an optional
     * payload. Expressing actions as classes enables powerful
     * type checking in reducer functions.
     *
     * See Discriminated Unions: https://www.typescriptlang.org/docs/handbook/advanced-types.html#discriminated-unions
     */
    export class LoadMyProfileAction implements Action {
        type = ActionTypes.LOAD_MY_PROFILE;
        payload: string = null;
    }

    export class LoadAction implements Action {
        type = ActionTypes.LOAD_PROFILE;

        constructor(public payload: number) { }
    }

    export class LoadSuccessfulAction implements Action {
        type = ActionTypes.LOAD_SUCCESSFUL;

        constructor(public payload: IProfileState) { }
    }

    export class LoadFailedAction implements Action {
        type = ActionTypes.LOAD_FAILED;
        payload: string = null;
    }

    export class EditAction implements Action {
        type = ActionTypes.EDIT;

        constructor(public payload: number) { }
    }

    export class EditSuccessfulAction implements Action {
        type = ActionTypes.EDIT_SUCCESSFUL;

        constructor(public payload: IProfileState) { }
    }

    export class EditFailedAction implements Action {
        type = ActionTypes.EDIT_FAILED;
        payload: string = null;
    }

    export class ChangePasswordAction implements Action {
        type = ActionTypes.CHANGE_PASSWORD;

        constructor(public payload: any) { }
    }

    export class ChangePasswordSuccessfulAction implements Action {
        type = ActionTypes.CHANGE_SUCCESSFUL;

        constructor(public payload: IProfileState) { }
    }

    export class ChangePasswordFailedAction implements Action {
        type = ActionTypes.CHANGE_FAILED;
        payload: string = null;
    }

    export class LoadProfileCalenderAction implements Action {
        type = ActionTypes.LOAD_PROFILE_CALENDER;

        constructor(public payload: any) { }
    }

    export class LoadProfileCalenderSuccessfulAction implements Action {
        type = ActionTypes.LOAD_PROFILE_CALENDER_SUCCESSFUL;

        constructor(public payload: any) { }
    }

    export class LoadProfileCalenderFailedAction implements Action {
        type = ActionTypes.LOAD_PROFILE_CALENDER_FAILED;
        payload: string = null;
    }

    /**
     * Export a type alias of all actions in this action group
     * so that reducers can easily compose action types
     */
    export type Actions
        = LoadMyProfileAction
        | LoadAction
        | LoadSuccessfulAction
        | LoadFailedAction
        | EditAction
        | EditSuccessfulAction
        | EditFailedAction
        | ChangePasswordAction
        | ChangePasswordSuccessfulAction
        | ChangePasswordFailedAction
        | LoadProfileCalenderAction
        | LoadProfileCalenderSuccessfulAction
        | LoadProfileCalenderFailedAction;
}
