import { Observable } from 'rxjs/Observable';

export interface IProfile {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    bio: string;
    profile_image: string;
    username: string;
    notifications_enabled: boolean;
    facebook_id: string;
}

export interface IProfileCalender {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    bio: string;
    profile_image: string;
    username: string;
    notifications_enabled: boolean;
    facebook_id: string;
}

export interface IProfileState {
    profile: IProfile;
    profileCalender: Array<IProfileCalender>;
    
}

export const profileInitialState: IProfileState = null;
