import { ProfileService } from './profile.service';

export const PROFILE_PROVIDERS: any[] = [
  ProfileService
];

export * from './profile.service';
