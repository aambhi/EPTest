// angular
import { Injectable } from '@angular/core';

// libs
import { Observable } from 'rxjs/Observable';

// app
import { Config } from '../../core/index';
import { Analytics, AnalyticsService } from '../../analytics/index';
import { FtcService } from '../../shared/provider/secure-http.service';

// module
import { Profile } from '../actions/index';

@Injectable()
export class ProfileService extends Analytics {

    constructor(
        public analytics: AnalyticsService,
        private http: FtcService
    ) {
        super(analytics);
        this.category = Profile.CATEGORY;
    }

    getMyProfile(): Observable<any> {
        return this.http.get({}, 'users/me/')
            .map(res => { return res; })
            .catch(this.handleError.bind(this));
    }

    updateMyProfile(profile: any): Observable<any> {
        return this.http.patch(profile, 'users/me/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));

    }

    changePassword(passwordInfo: any): Observable<any> {
        return this.http.post(passwordInfo, 'users/change-password/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));

    }

    profileCalender(query:any): Observable<any> {
        return this.http.get({}, 'users/me/workout-web/?From='+query.fromDate+'&To='+query.toDate)
            .map(res => {
                   return res;
            })
            .catch(this.handleError.bind(this));
    }

    private handleError(error: any): Observable<any> {
        return Observable.throw(error.message || error);
    }
}
