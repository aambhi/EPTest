import { Injectable, Inject } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Config } from '../../core/index';
import { RouterExtensions, StorageService, StorageKey } from '../../../modules/core/index';

@Injectable()
export class FtcService {

    constructor(private http: Http,
        private storage: StorageService) { }

    post(object: any, methodName: string): Observable<any> {
        let header = this.initHeaders();
        let options = new RequestOptions({ headers: header, method: 'post' });
        let body = JSON.stringify(object);
        return this.http.post(Config.ENVIRONMENT().API + methodName, body, options)
            .map(res => {
                return res.json();
            })
            .catch(this.handleError.bind(this));
    }

    put(object: any, methodName: string): Observable<any> {
        let header = this.initHeaders();
        let options = new RequestOptions({ headers: header, method: 'put' });
        let body = JSON.stringify(object);
        return this.http.put(Config.ENVIRONMENT().API + methodName, body, options)
            .map(res => {
                return res.json();
            })
            .catch(this.handleError.bind(this));
    }

    get(object: any, methodName: string): Observable<any> {
        let header = this.initHeaders();
        let options = new RequestOptions({ headers: header, method: 'get' });
        return this.http.get(Config.ENVIRONMENT().API + methodName, options)
            .map(res => {
                return res.json();
            })
            .catch(this.handleError.bind(this));
    }

    delete(object: any, methodName: string): Observable<any> {
        let header = this.initHeaders();
        let options = new RequestOptions({ headers: header, method: 'delete' });
        return this.http.delete(Config.ENVIRONMENT().API + methodName, options)
            .map(res => {
                return res.json();
            })
            .catch(this.handleError.bind(this));
    }

    patch(object: any, methodName: string): Observable<any> {
        let header = this.initHeaders();
        let options = new RequestOptions({ headers: header, method: 'patch' });
        let body = JSON.stringify(object);
        return this.http.patch(Config.ENVIRONMENT().API + methodName, body, options)
            .map(res => {
                return res.json();
            })
            .catch(this.handleError.bind(this));
    }

    patchWithFileUpload(object: any, methodName: string): Observable<any> {
        let header = this.initHeadersWithImageUpload();
        let options = new RequestOptions({ headers: header, method: 'patch' });
        let body = JSON.stringify(object);
        return this.http.patch(Config.ENVIRONMENT().API + methodName, body, options)
            .map(res => {
                return res.json();
            })
            .catch(this.handleError.bind(this));
    }

    private initHeadersWithImageUpload(): Headers {
        let token = this.storage.getItem(StorageKey.USER_TOKEN);
        var headers = new Headers();
        if (token !== null) {
            headers.append('Authorization', token);
        }

        headers.append('Accept', 'application/json');
        //headers.append('Content-Type', 'application/json');
        headers.append('Content-Type', 'image/png');
        // headers.append('fileName', 'photo.png');


        return headers;
    }

    private initHeaders(): Headers {
        let token = this.storage.getItem(StorageKey.USER_TOKEN);
        var headers = new Headers();
        if (token !== null) {
            headers.append('Authorization', token);
        }

        headers.append('Accept', 'application/json');
        headers.append('Content-Type', 'application/json');
        return headers;
    }

    private handleError(error: any): Observable<any> {
        return Observable.throw(error.message || error);
    }
}
