import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { FtcService } from './secure-http.service';

@Injectable()
export class AccountService {

    constructor(private http: FtcService) {
    }

    validateAccount(object: any): Observable<any> {
        return this.http.post(object, 'users/login/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));
    }

    createAccount(object: any): Observable<any> {
        return this.http.post(object, 'users/register/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));
    }

    forgottenPassword(object: any): Observable<any> {
        return this.http.post(object, 'users/forgotten-password/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));
    }

    changePassword(object: any): Observable<any> {
        return this.http.post(object, 'users/change-password/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));
    }

    checkUserExist(object: any): Observable<any> {
        return this.http.post(object, 'users/does-user-exist/')
            .map(res => {
                return res;
            })
            .catch(this.handleError.bind(this));
    }

    private handleError(error: any): Observable<any> {
        return Observable.throw(error.message || error);
    }
}
