// app
import { Component } from '@angular/core';
import { StorageService, StorageKey } from '../../../core/index';

@Component({
  moduleId: module.id,
  selector: 'sd-navbar',
  templateUrl: 'navbar.component.html',
  styleUrls: [
    'navbar.component.css',
  ],
})
export class NavbarComponent {
  isHidden: boolean = false;
  constructor(private _storage: StorageService) {
    this.isHidden = this._storage.getItem(StorageKey.FB_TOKEN) !== null ? true : false;
  }
}
