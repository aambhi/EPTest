import { CanActivate, Router } from '@angular/router';
import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { RouterExtensions, StorageService, StorageKey } from '../../modules/core/index';

@Injectable()
export default class AuthGuard implements CanActivate {
    constructor(private router: Router,
        private storage: StorageService) { }

    canActivate(): Observable<boolean> | boolean {
        if (this.storage.getItem(StorageKey.USER_TOKEN)) {
            return true;
        } else {
            this.router.navigate(['/account/signin']);
            return false;
        }
    }
}
