import { FormControl, AbstractControl } from '@angular/forms';
export class CustomValidation {
    static dateValidator(control: FormControl) {
        if (control.value && control.value.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/)) {
            return null;
        } else {
            return { 'invalidDate': true };
        }
    }

    static emailValidator(control: FormControl) {

        if (control.value && control.value.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,3}$/)) {
            return null;
        } else {
            return { 'invalidEmail': true };
        }
    }

    static matchPasswordValidator(AC: AbstractControl) {

        if (AC.get('password') && AC.get('confirmPassword')) {
            let password = AC.get('password').value;
            let confirmPassword = AC.get('confirmPassword').value;
            if (password !== confirmPassword) {
                AC.get('confirmPassword').setErrors({ MatchPassword: true });
            } else {
              AC.get('confirmPassword').setErrors(null);
               
            }
        }

    }



}
