import { AboutComponent } from './about.component';

export const AboutRoutes: Array<any> = [
  {
    path: 'about',
    component: AboutComponent
  }
];
