// app
import { HomeRoutes } from './home/home.routes';
import { AboutRoutes } from './about/about.routes';
import { AccountRoutes } from './account/account.routes';
import { ProfileRoutes } from './profile/profile.routes';

export const routes: Array<any> = [
  ...HomeRoutes,
  ...AboutRoutes,
  ...AccountRoutes,
  ...ProfileRoutes
];
