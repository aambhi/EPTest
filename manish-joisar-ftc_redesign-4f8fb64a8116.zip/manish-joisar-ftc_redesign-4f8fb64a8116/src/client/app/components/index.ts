import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { AccountComponent } from './account/account.component';
import { LoginComponent } from './account/login.component';
import { ForgotPasswordComponent } from './account/forgot-password.component';

import { ProfileComponent } from './profile/profile.component';

export const APP_COMPONENTS: any[] = [
  AppComponent,
  AboutComponent,
  HomeComponent,
  ProfileComponent,
  AccountComponent,
  LoginComponent,
  ForgotPasswordComponent
];

export * from './app.component';
export * from './about/about.component';
export * from './home/home.component';
export * from './account/account.component';
export * from './account/login.component';
export * from './profile/profile.component';
export * from './account/forgot-password.component';










