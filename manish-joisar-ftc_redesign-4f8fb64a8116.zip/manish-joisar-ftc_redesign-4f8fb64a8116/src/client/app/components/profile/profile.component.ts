// libs
import { Component, ElementRef, ViewChild, OnInit, Inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

// app
import { IAppState } from '../../modules/ngrx/index';
import { Router, ActivatedRoute, NavigationStart, NavigationEnd } from '@angular/router';

@Component({
  moduleId: module.id,
  selector: 'sd-profile',
  templateUrl: 'profile.component.html',
  styleUrls: ['profile.component.css']
})
export class ProfileComponent implements OnInit {


  constructor(private store: Store<IAppState>,
    private router: Router) {

  }

  ngOnInit() {
    // Should we dispatch initial actions here??
  }
}
