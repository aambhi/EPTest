import { ProfileComponent } from './profile.component';

export const ProfileRoutes: Array<any> = [
  {
    path: 'profile',
    component: ProfileComponent
  }
];
