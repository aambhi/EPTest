import { HomeComponent } from './home.component';

import AuthGuard from '../../modules/shared/authgaurd';

export const HomeRoutes: Array<any> = [
  {
    path: '', redirectTo: 'home', pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard]
  }
];
