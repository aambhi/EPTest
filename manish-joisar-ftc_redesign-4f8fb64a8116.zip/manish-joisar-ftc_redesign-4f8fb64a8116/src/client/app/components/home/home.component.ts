// libs
import { Component, ElementRef, ViewChild, OnInit, Inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

// app
import { IAppState } from '../../modules/ngrx/index';
import { Router, ActivatedRoute, NavigationStart, NavigationEnd } from '@angular/router';

@Component({
  moduleId: module.id,
  selector: 'sd-home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css']
})
export class HomeComponent implements OnInit {

  twoColumnLayoutOn: boolean = false;

  constructor(private store: Store<IAppState>,
    private router: Router) {

    router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        let url = this.router.url;
        if (url.indexOf('right') === -1) {
          this.twoColumnLayoutOn = true;
        } else {
          this.twoColumnLayoutOn = false;
        }
      }
      // NavigationEnd
      // NavigationCancel
      // NavigationError
      // RoutesRecognized
    });
  }

  ngOnInit() {
    // Should we dispatch initial actions here??
  }
}
