import { Injector, Component } from '@angular/core';
import { Config } from '../../modules/core/index';

@Component({
    moduleId: module.id,
    selector: 'sd-forgot-password',
    templateUrl: 'forgot-password.component.html',
      styleUrls: ['forgot-password.component.css']
})

export class ForgotPasswordComponent {

}
