import { AccountComponent } from './account.component';
import { LoginComponent } from './login.component';
import { ForgotPasswordComponent } from './forgot-password.component';
export const AccountRoutes: Array<any> = [
  {
    path: 'account',
    component: AccountComponent,
    children: [
      { path: '', component: LoginComponent },
      { path: 'signin', component: LoginComponent },
      { path: 'forgot-password', component: ForgotPasswordComponent }
    ]
  }
];
