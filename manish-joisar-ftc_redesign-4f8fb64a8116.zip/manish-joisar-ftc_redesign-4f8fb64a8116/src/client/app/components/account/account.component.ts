import { Injector, Component } from '@angular/core';
import { Config } from '../../modules/core/index';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
    moduleId: module.id,
    selector: 'sd-account',
    templateUrl: 'account.component.html'
})

export class AccountComponent {

    closeResult: string;
    private _page: any;

    private get page() {
        if (Config.PageClass) {
            if (!this._page) {
                this._page = this.injector.get(Config.PageClass);
            }

            return this._page;
        }
    }
    constructor(private injector: Injector, private modalService: NgbModal) {
        if (this.page) {
            this.page.actionBarHidden = true;
        }
    }


    open(content) {
        this.modalService.open(content).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}
