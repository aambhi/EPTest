import { Component, OnInit, Inject, Injector, Host } from '@angular/core';
import { AccountService } from '../../modules/shared/provider/account.service';
import { RouterExtensions, StorageService, StorageKey, Config } from '../../modules/core/index';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { AuthService } from 'angular2-social-login';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';


@Component({
    moduleId: module.id,
    selector: 'sd-login',
    templateUrl: 'login.component.html',
    providers: [AccountService],
    styleUrls: ['login.component.css']
})

export class LoginComponent {

    _loginform: FormGroup;
    _displayErrorMessage: boolean = false;
    _submitted: boolean = false;
    public _facebookData: any;
    showLogin: boolean = true;
    fullView: boolean = false;
    showOption: boolean = false;
    showTalentRegistration: boolean = false;
    _isFacebookRegister: Observable<boolean>;
    private _page: any;


    private get page() {
        if (Config.PageClass) {
            if (!this._page) {
                this._page = this.injector.get(Config.PageClass);
            }

            return this._page;
        }
    }

    constructor(
        private _accountService: AccountService,
        private _routerext: RouterExtensions,
        private _router: Router,
        private _storage: StorageService,
        private _formBuilder: FormBuilder,
        private injector: Injector,
        public _auth: AuthService) {

        this._storage.removeItem(StorageKey.USER_TOKEN);
        this._storage.removeItem(StorageKey.FB_TOKEN);

        this._loginform = _formBuilder.group({
            'userId': ['', Validators.required],
            'password': ['', Validators.required]
        });

        if (this.page) {
            this.page.actionBarHidden = true;
        }

        this._isFacebookRegister = new Observable<boolean>((observer: Subscriber<boolean>) => {
            setInterval(() => observer.next(true), 50);
        });

    }

    logIn() {
        if (!this._loginform.valid) {
            this._displayErrorMessage = true;
            this._submitted = true;
            return;
        }

        var param = {
            username: this._loginform.controls['userId'].value,
            password: this._loginform.controls['password'].value
        };

        this._accountService.validateAccount(param)
            .subscribe(
            (data: any) => {
                this._storage.setItem(StorageKey.USER_TOKEN, 'token ' + data.token);
                this._router.navigateByUrl('home/(left:my-profile//main:profile-timeline)');
            },
            error => {
                this._displayErrorMessage = true;
            },
            () => {
                //TODO:
            });
    }

    facebookLogin() {
        this._auth.login('facebook').subscribe(
            (data) => {
                this._facebookData = data;
                var param = {
                    facebook_id: data['uid'],
                    facebookToken: data['token']
                };

                this._accountService.validateAccount(param)
                    .subscribe(
                    (data: any) => {
                        this._storage.setItem(StorageKey.USER_TOKEN, 'token ' + data.token);
                        this._storage.setItem(StorageKey.FB_TOKEN, 'token ' + param.facebookToken);
                        this._router.navigateByUrl('home/(left:my-profile//main:profile-timeline)');
                    },
                    error => {
                        this._isFacebookRegister = new Observable<boolean>((observer: Subscriber<boolean>) => {
                            setInterval(() => observer.next(false), 200);
                        });
                    },
                    () => {
                        //TODO:
                    });
                //user data 
                //name, image, uid, provider, uid, email, token (returns tokenId for google, accessToken for Facebook, no token for linkedIn) 
            }
        );
    }

    showRegistration(): void {

        this.showLogin = false;
        this.fullView = true;
        this.showTalentRegistration = false;
    }

    talentRegistration(): void {
        this.showLogin = false;
        this.fullView = false;
        this.showOption = true;
        this.showTalentRegistration = true;
    }

    backToLogin(): void {
        this.showLogin = true;
        this.fullView = false;
        this.showOption = false;
        this.showTalentRegistration = false;
    }
}

