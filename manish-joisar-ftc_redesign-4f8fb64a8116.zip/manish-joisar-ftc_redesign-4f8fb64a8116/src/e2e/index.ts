
// convenient shorthand
import { Ng2Jasmine, TestApi } from './ng2-jasmine';
export const t: TestApi = Ng2Jasmine;

// e2e
export * from './framework/dropdowns';

// shorthand
export * from './ng2-jasmine';
