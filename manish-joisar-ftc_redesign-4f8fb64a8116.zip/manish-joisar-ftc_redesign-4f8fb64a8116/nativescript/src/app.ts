// nativescript
import { platformNativeScriptDynamic } from 'nativescript-angular/platform';

// app
import { NativeModule } from './native.module';

platformNativeScriptDynamic().bootstrapModule(NativeModule);
