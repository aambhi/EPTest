// app
import { StorageService } from '../../../app/modules/core/services/storage.service';

// nativescript
require('nativescript-localstorage');

export class StorageNative extends StorageService {
}
