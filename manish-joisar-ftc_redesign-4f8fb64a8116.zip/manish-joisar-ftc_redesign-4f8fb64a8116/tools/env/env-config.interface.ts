export { EnvConfig } from '../../src/client/app/modules/core/utils/config';
