import { EnvConfig } from './env-config.interface';

const DevConfig: EnvConfig = {
  ENV: 'DEV',
  API: 'http://54.72.136.227/api/v1/',
  //API: 'http://192.168.1.138:8888/api/v1/',
  FacebookClientId: '248641728825408',
  FacebookApiVersion: 'v2.6'
};

export = DevConfig;

