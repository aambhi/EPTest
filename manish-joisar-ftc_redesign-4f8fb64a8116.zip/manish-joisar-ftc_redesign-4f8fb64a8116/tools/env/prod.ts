import { EnvConfig } from './env-config.interface';

const ProdConfig: EnvConfig = {
  ENV: 'PROD',
  API: 'http://192.168.1.138:9999/api/v1/',  
  FacebookClientId: '248641728825408',
  FacebookApiVersion: 'v2.6'
};

export = ProdConfig;
