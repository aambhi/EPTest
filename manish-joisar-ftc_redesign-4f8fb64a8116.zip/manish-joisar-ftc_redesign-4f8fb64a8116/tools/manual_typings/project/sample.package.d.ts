// declare module "moment/moment" {
//   export = moment;
// }
